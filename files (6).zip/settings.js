/* ═══════════════════════════════════════════════════════════
   pages/settings.js — All Settings Sub-pages
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */

/* ── In-memory user store (shared across renderUsers calls) ── */
const UserStore = (() => {
  let _users = [
    { id:1,  name:'Sarah Leader',   email:'sarah.leader@coforge.com',   role:'sales',    bu:'TTH NA',       region:'India',   phone:'+91 98001 00001', jobTitle:'Sales Leader — TTH NA',       accounts:['American Airlines','Hawaiian Airlines','United Airlines'], status:'Active',  added:'Apr-23', last:'Today'      },
    { id:2,  name:'Alex Delivery',  email:'alex.delivery@coforge.com',  role:'delivery', bu:'TTH NA',       region:'India',   phone:'+91 98001 00002', jobTitle:'Delivery Leader — TTH NA',     accounts:['American Airlines','Hawaiian Airlines'],                   status:'Active',  added:'Apr-23', last:'Yesterday'  },
    { id:3,  name:'Ravi Sharma',    email:'ravi.sharma@coforge.com',    role:'sales',    bu:'Insurance NA', region:'India',   phone:'+91 98001 00003', jobTitle:'Sales Leader — Insurance NA',  accounts:['Mosaic Insurance','Global Life Insurers'],                 status:'Active',  added:'Jun-23', last:'28-Feb-26'  },
    { id:4,  name:'Helen Park',     email:'helen.park@coforge.com',     role:'delivery', bu:'Insurance EU', region:'UK',      phone:'+44 7700 000004', jobTitle:'Delivery Leader — Insurance EU',accounts:["Lloyd's London","Tokio Marine HCC"],                     status:'Active',  added:'Aug-23', last:'01-Mar-26'  },
    { id:5,  name:'James Carter',   email:'james.carter@coforge.com',   role:'sales',    bu:'TTH NA',       region:'USA',     phone:'+1 202 000 0005', jobTitle:'Sales Leader — TTH NA',       accounts:['United Airlines','Pacific Airlines'],                      status:'Warning', added:'Oct-23', last:'20-Jan-26'  },
    { id:6,  name:'Karen Liu',      email:'karen.liu@coforge.com',      role:'delivery', bu:'TTH NA',       region:'India',   phone:'+91 98001 00006', jobTitle:'Delivery Leader — TTH NA',     accounts:['United Airlines'],                                        status:'Active',  added:'Jan-24', last:'28-Feb-26'  },
    { id:7,  name:'Suman Mukherji', email:'suman.mukherji@coforge.com', role:'sales',    bu:'ANZ BFS',      region:'India',   phone:'+91 98001 00007', jobTitle:'Sales Leader — ANZ BFS',       accounts:['Commonwealth Bank','Acenda','ANZ Banking'],                status:'Active',  added:'Mar-24', last:'28-Feb-26'  },
    { id:8,  name:'Admin User',     email:'admin@coforge.com',          role:'admin',    bu:'Corporate',    region:'India',   phone:'+91 98001 00008', jobTitle:'Executive / Admin',            accounts:[],                                                         status:'Active',  added:'Apr-23', last:'Today'      },
  ];

  let _nextId = 9;

  function getAll()       { return [..._users]; }
  function getById(id)    { return _users.find(u => u.id === id); }
  function getSalesCount(){ return _users.filter(u => u.role === 'sales' && u.status !== 'Inactive').length; }
  function getDelivCount(){ return _users.filter(u => u.role === 'delivery' && u.status !== 'Inactive').length; }
  function getTotalCount(){ return _users.filter(u => u.status !== 'Inactive').length; }

  function add(userData) {
    const newUser = {
      id: _nextId++,
      ...userData,
      status: 'Active',
      added: new Date().toLocaleDateString('en-GB',{month:'short',year:'2-digit'}).replace(' ','-'),
      last: 'Just now',
    };
    _users.unshift(newUser);
    return newUser;
  }

  function update(id, patch) {
    const idx = _users.findIndex(u => u.id === id);
    if (idx !== -1) _users[idx] = { ..._users[idx], ...patch };
  }

  function deactivate(id) {
    update(id, { status: 'Inactive' });
  }

  function reactivate(id) {
    update(id, { status: 'Active' });
  }

  return { getAll, getById, getSalesCount, getDelivCount, getTotalCount, add, update, deactivate, reactivate };
})();

/* ── Controller for the Add/Edit User Modal ── */
const UserModal = {
  _mode: 'add',   // 'add' | 'edit'
  _editId: null,

  openAdd() {
    this._mode  = 'add';
    this._editId = null;
    this._resetForm();
    document.getElementById('um-modal-title').textContent  = '+ Add New User';
    document.getElementById('um-modal-submit').textContent = 'Add User';
    document.getElementById('um-pass-section').style.display = 'block';
    document.getElementById('um-modal-overlay').classList.add('open');
  },

  openEdit(id) {
    const u = UserStore.getById(id);
    if (!u) return;
    this._mode   = 'edit';
    this._editId = id;
    document.getElementById('um-modal-title').textContent  = 'Edit User';
    document.getElementById('um-modal-submit').textContent = 'Save Changes';
    document.getElementById('um-pass-section').style.display = 'none';
    // Populate form
    document.getElementById('um-name').value     = u.name;
    document.getElementById('um-email').value    = u.email;
    document.getElementById('um-role').value     = u.role;
    document.getElementById('um-bu').value       = u.bu;
    document.getElementById('um-region').value   = u.region;
    document.getElementById('um-phone').value    = u.phone    || '';
    document.getElementById('um-jobtitle').value = u.jobTitle || '';
    document.getElementById('um-accounts').value = (u.accounts||[]).join(', ');
    document.getElementById('um-modal-overlay').classList.add('open');
  },

  close() {
    document.getElementById('um-modal-overlay').classList.remove('open');
    this._resetForm();
  },

  _resetForm() {
    ['um-name','um-email','um-phone','um-jobtitle','um-accounts','um-pass','um-pass2'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });
    const roleEl = document.getElementById('um-role');
    if (roleEl) roleEl.value = 'sales';
    const buEl = document.getElementById('um-bu');
    if (buEl) buEl.value = 'TTH NA';
    const regEl = document.getElementById('um-region');
    if (regEl) regEl.value = 'India';
    this._clearErrors();
  },

  _clearErrors() {
    document.querySelectorAll('.um-error').forEach(e => { e.textContent=''; e.style.display='none'; });
  },

  _showError(fieldId, msg) {
    const errEl = document.getElementById('um-err-' + fieldId);
    if (errEl) { errEl.textContent = msg; errEl.style.display = 'block'; }
  },

  _validate() {
    this._clearErrors();
    let valid = true;
    const name  = document.getElementById('um-name').value.trim();
    const email = document.getElementById('um-email').value.trim();
    const role  = document.getElementById('um-role').value;
    const bu    = document.getElementById('um-bu').value;

    if (!name)  { this._showError('name',  'Full name is required.'); valid = false; }
    if (!email) { this._showError('email', 'Email address is required.'); valid = false; }
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { this._showError('email','Enter a valid email address.'); valid = false; }
    else if (this._mode === 'add') {
      const exists = UserStore.getAll().find(u => u.email.toLowerCase() === email.toLowerCase());
      if (exists) { this._showError('email','A user with this email already exists.'); valid = false; }
    }
    if (!role) { this._showError('role','Please select a role.'); valid = false; }
    if (!bu)   { this._showError('bu',  'Please select a Business Unit.'); valid = false; }

    if (this._mode === 'add') {
      const pass  = document.getElementById('um-pass').value;
      const pass2 = document.getElementById('um-pass2').value;
      if (!pass || pass.length < 8) { this._showError('pass','Password must be at least 8 characters.'); valid = false; }
      else if (pass !== pass2)      { this._showError('pass2','Passwords do not match.'); valid = false; }
    }
    return valid;
  },

  submit() {
    if (!this._validate()) return;

    const data = {
      name:     document.getElementById('um-name').value.trim(),
      email:    document.getElementById('um-email').value.trim().toLowerCase(),
      role:     document.getElementById('um-role').value,
      bu:       document.getElementById('um-bu').value,
      region:   document.getElementById('um-region').value,
      phone:    document.getElementById('um-phone').value.trim(),
      jobTitle: document.getElementById('um-jobtitle').value.trim(),
      accounts: document.getElementById('um-accounts').value.split(',').map(s=>s.trim()).filter(Boolean),
    };

    if (this._mode === 'add') {
      UserStore.add(data);
      UI.toast(`User "${data.name}" added successfully!`, '👤');
    } else {
      UserStore.update(this._editId, data);
      UI.toast(`User "${data.name}" updated successfully!`, '✅');
    }

    this.close();
    // Re-render the user management page
    const page = document.getElementById('page-settings-users');
    if (page) { page.innerHTML = Pages.Settings.renderUsers(); }
  },
};

/* ── Pages.Settings object ── */
Pages.Settings = {

  /* ══════════════════════════════════════════
     GENERAL SETTINGS
  ══════════════════════════════════════════ */
  renderGeneral() {
    return `
<div class="section-header">
  <div><div class="section-title">Settings — General</div><div class="section-sub">Platform preferences, display options and profile management</div></div>
  <button class="btn btn-primary" onclick="UI.toast('All settings saved successfully!','✅')">Save Changes</button>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>👤 My Profile</h3><p>Your account details and role configuration</p></div></div>
  <div class="profile-avatar-section">
    <div class="profile-avatar-big">SL</div>
    <div class="profile-avatar-info">
      <h3>Sarah Leader</h3>
      <p>sarah.leader@coforge.com</p>
      <div class="role-chip">Sales Leader</div>
    </div>
    <button class="btn btn-outline btn-sm" style="margin-left:auto" onclick="UI.toast('Profile photo upload coming soon.','🖼️')">Change Photo</button>
  </div>
  <div class="settings-card-body">
    <div class="form-row">
      <div class="form-group"><label>Full Name</label><input type="text" value="Sarah Leader"></div>
      <div class="form-group"><label>Email Address</label><input type="email" value="sarah.leader@coforge.com"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Job Title</label><input type="text" value="Sales Leader — TTH NA"></div>
      <div class="form-group"><label>Phone Number</label><input type="tel" placeholder="+91 98XXXXXXXX"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Business Unit</label>
        <select><option>TTH NA</option><option>ANZ BFS</option><option>Insurance NA</option><option>Insurance EU</option><option>US Geo Retail</option><option>BFS EMEA</option></select>
      </div>
      <div class="form-group"><label>Manager / Reporting To</label><input type="text" placeholder="Manager name"></div>
    </div>
  </div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>🔐 Password & Security</h3><p>Update your login credentials</p></div></div>
  <div class="settings-card-body">
    <div class="form-row">
      <div class="form-group"><label>Current Password</label><input type="password" placeholder="••••••••"></div>
      <div class="form-group"><label>New Password</label><input type="password" placeholder="Min. 8 characters"></div>
      <div class="form-group"><label>Confirm New Password</label><input type="password" placeholder="Re-enter new password"></div>
    </div>
    <div class="form-submit"><button class="btn btn-outline" onclick="UI.toast('Password updated successfully!','🔐')">Update Password</button></div>
  </div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>🎨 Display & Appearance</h3><p>Theme, language and layout preferences</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>Currency Display</h4><p>Default currency unit shown across all dashboards</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>USD ($)</option><option>GBP (£)</option><option>AUD (A$)</option><option>INR (₹)</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Number Format</h4><p>How large numbers are displayed</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>$1.2M (Millions)</option><option>$1,200K (Thousands)</option><option>$1,200,000 (Full)</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Fiscal Year Start</h4><p>Your organisation's fiscal year start month</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>April (FY Apr–Mar)</option><option>January (CY)</option><option>July</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Date Format</h4><p>How dates are displayed across the platform</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>DD-MMM-YY</option><option>MM/DD/YYYY</option><option>YYYY-MM-DD</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Show AI Insights on Dashboard</h4><p>Display AI agent panel on executive dashboard</p></div>
      <div class="settings-row-control"><label class="toggle"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Brand Theme</h4><p>Primary colour accent for the platform</p></div>
      <div class="settings-row-control">
        <div class="color-swatches">
          ${CONFIG.THEMES.map((t,i) => `<div class="color-swatch ${i===0?'active':''}" style="background:${t.primary}" title="${t.name}" onclick="this.closest('.color-swatches').querySelectorAll('.color-swatch').forEach(s=>s.classList.remove('active'));this.classList.add('active');UI.toast('Theme changed to ${t.name}','🎨')"></div>`).join('')}
        </div>
      </div>
    </div>
  </div>
</div>

<div class="settings-card">
  <div class="settings-card-header">
    <div><h3>🎯 My Accounts (Default View)</h3><p>Accounts you manage — used to pre-filter dashboards and BE forms</p></div>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('Account added.','➕')">+ Add Account</button>
  </div>
  <div class="settings-card-body">
    <div class="table-wrap"><table>
      <thead><tr><th>Account Name</th><th>BU</th><th>Role</th><th>Since</th><th>Action</th></tr></thead>
      <tbody>
        <tr><td><strong>American Airlines</strong></td><td>TTH NA</td><td>Primary Owner</td><td>Apr 2023</td><td><button class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();UI.toast('Account removed.','🗑️')">Remove</button></td></tr>
        <tr><td><strong>Hawaiian Airlines</strong></td><td>TTH NA</td><td>Primary Owner</td><td>Jan 2024</td><td><button class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();UI.toast('Account removed.','🗑️')">Remove</button></td></tr>
        <tr><td><strong>United Airlines</strong></td><td>TTH NA</td><td>Primary Owner</td><td>Jul 2024</td><td><button class="btn btn-danger btn-sm" onclick="this.closest('tr').remove();UI.toast('Account removed.','🗑️')">Remove</button></td></tr>
      </tbody>
    </table></div>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     USER MANAGEMENT  (fully live)
  ══════════════════════════════════════════ */
  renderUsers() {
    const users = UserStore.getAll();
    const roleLabel = { sales:'Sales Leader', delivery:'Delivery Leader', admin:'Admin / Executive' };
    const roleTag   = r => `<span class="user-role-tag role-${r}">${roleLabel[r]||r}</span>`;

    const avatarColors = [
      'var(--teal-grad)',
      'linear-gradient(135deg,#6b4caf,#9b74ef)',
      'linear-gradient(135deg,#FF6B35,#FF9500)',
      'linear-gradient(135deg,#007BFF,#6610F2)',
      'linear-gradient(135deg,#28C76F,#00CFB4)',
      'linear-gradient(135deg,#EA5455,#FF7676)',
    ];

    const rows = users.map((u, i) => {
      const initials = u.name.split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
      const avatarBg = avatarColors[i % avatarColors.length];
      const isInactive = u.status === 'Inactive';
      return `
      <tr id="um-row-${u.id}" style="${isInactive?'opacity:0.5':''}">
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:34px;height:34px;border-radius:8px;background:${avatarBg};display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;font-weight:700;flex-shrink:0">${initials}</div>
            <div>
              <div style="font-weight:600;font-size:13px">${u.name}</div>
              <div style="font-size:11px;color:var(--coforge-muted)">${u.email}</div>
            </div>
          </div>
        </td>
        <td>${roleTag(u.role)}</td>
        <td><span style="font-size:13px">${u.bu}</span></td>
        <td>${u.region||'—'}</td>
        <td><span class="badge badge-${u.status==='Active'?'green':u.status==='Warning'?'yellow':'gray'}">${u.status}</span></td>
        <td style="font-size:12px;color:var(--coforge-muted)">${u.last}</td>
        <td>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn btn-outline btn-sm" onclick="UserModal.openEdit(${u.id})">✏️ Edit</button>
            ${isInactive
              ? `<button class="btn btn-outline btn-sm" style="color:var(--coforge-green);border-color:var(--coforge-green)" onclick="UserStore.reactivate(${u.id});Pages.Settings._refreshUsersPage();UI.toast('User reactivated.','✅')">Reactivate</button>`
              : `<button class="btn btn-danger btn-sm" onclick="UserStore.deactivate(${u.id});Pages.Settings._refreshUsersPage();UI.toast('User deactivated.','🚫')">Deactivate</button>`
            }
          </div>
        </td>
      </tr>`;
    }).join('');

    return `
<!-- ── ADD/EDIT USER MODAL ── -->
<div class="modal-overlay" id="um-modal-overlay">
  <div class="modal" style="width:640px">
    <div class="modal-header">
      <div class="modal-title" id="um-modal-title">+ Add New User</div>
      <div class="modal-close" onclick="UserModal.close()">✕</div>
    </div>
    <div style="padding:28px">

      <!-- Role quick-select cards -->
      <div style="margin-bottom:22px">
        <div style="font-size:11.5px;font-weight:700;color:var(--coforge-teal);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Select Role</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
          <div class="um-role-card" id="um-card-sales" onclick="UserModal._selectRoleCard('sales')"
            style="border:2px solid var(--coforge-teal);border-radius:10px;padding:14px 12px;cursor:pointer;text-align:center;background:rgba(0,169,157,.06);transition:all .15s">
            <div style="font-size:24px;margin-bottom:6px">🎯</div>
            <div style="font-size:13px;font-weight:700;color:var(--coforge-teal)">Sales Leader</div>
            <div style="font-size:11px;color:var(--coforge-muted);margin-top:3px">Pipeline · BE input · Account ownership</div>
          </div>
          <div class="um-role-card" id="um-card-delivery" onclick="UserModal._selectRoleCard('delivery')"
            style="border:2px solid var(--coforge-border);border-radius:10px;padding:14px 12px;cursor:pointer;text-align:center;transition:all .15s">
            <div style="font-size:24px;margin-bottom:6px">🚚</div>
            <div style="font-size:13px;font-weight:700;color:var(--coforge-dark)">Delivery Leader</div>
            <div style="font-size:11px;color:var(--coforge-muted);margin-top:3px">Resources · Delivery BE · Margin tracking</div>
          </div>
          <div class="um-role-card" id="um-card-admin" onclick="UserModal._selectRoleCard('admin')"
            style="border:2px solid var(--coforge-border);border-radius:10px;padding:14px 12px;cursor:pointer;text-align:center;transition:all .15s">
            <div style="font-size:24px;margin-bottom:6px">⚙️</div>
            <div style="font-size:13px;font-weight:700;color:var(--coforge-dark)">Admin / Executive</div>
            <div style="font-size:11px;color:var(--coforge-muted);margin-top:3px">Full access · User mgmt · Config</div>
          </div>
        </div>
        <input type="hidden" id="um-role" value="sales">
      </div>

      <hr style="border:none;border-top:1px solid var(--coforge-border);margin-bottom:22px">

      <!-- Personal Details -->
      <div style="font-size:11.5px;font-weight:700;color:var(--coforge-teal);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px">Personal Details</div>
      <div class="form-row">
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" id="um-name" placeholder="e.g. John Smith">
          <span class="um-error" id="um-err-name" style="display:none;color:var(--coforge-red);font-size:11.5px;margin-top:4px"></span>
        </div>
        <div class="form-group">
          <label>Email Address *</label>
          <input type="email" id="um-email" placeholder="name@coforge.com">
          <span class="um-error" id="um-err-email" style="display:none;color:var(--coforge-red);font-size:11.5px;margin-top:4px"></span>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Phone Number</label>
          <input type="tel" id="um-phone" placeholder="+91 98XXXXXXXX">
        </div>
        <div class="form-group">
          <label>Job Title</label>
          <input type="text" id="um-jobtitle" placeholder="e.g. Sales Leader — TTH NA">
        </div>
      </div>

      <!-- Organisational Details -->
      <div style="font-size:11.5px;font-weight:700;color:var(--coforge-teal);text-transform:uppercase;letter-spacing:1px;margin:18px 0 14px">Organisational Details</div>
      <div class="form-row">
        <div class="form-group">
          <label>Business Unit *</label>
          <select id="um-bu">
            <option value="TTH NA">TTH NA</option>
            <option value="ANZ BFS">ANZ BFS</option>
            <option value="Insurance NA">Insurance NA</option>
            <option value="Insurance EU">Insurance EU</option>
            <option value="US Geo Retail">US Geo Retail</option>
            <option value="BFS EMEA">BFS EMEA</option>
            <option value="Corporate">Corporate</option>
          </select>
          <span class="um-error" id="um-err-bu" style="display:none;color:var(--coforge-red);font-size:11.5px;margin-top:4px"></span>
        </div>
        <div class="form-group">
          <label>Region / Geography</label>
          <select id="um-region">
            <option value="India">India</option>
            <option value="USA">USA</option>
            <option value="UK">UK</option>
            <option value="Australia">Australia</option>
            <option value="Europe">Europe</option>
            <option value="Singapore">Singapore</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Assigned Accounts <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--coforge-muted)">(comma-separated)</span></label>
          <input type="text" id="um-accounts" placeholder="e.g. American Airlines, United Airlines">
        </div>
      </div>

      <!-- Password (Add mode only) -->
      <div id="um-pass-section">
        <div style="font-size:11.5px;font-weight:700;color:var(--coforge-teal);text-transform:uppercase;letter-spacing:1px;margin:18px 0 14px">Set Password</div>
        <div class="form-row">
          <div class="form-group">
            <label>Password *</label>
            <input type="password" id="um-pass" placeholder="Min. 8 characters">
            <span class="um-error" id="um-err-pass" style="display:none;color:var(--coforge-red);font-size:11.5px;margin-top:4px"></span>
          </div>
          <div class="form-group">
            <label>Confirm Password *</label>
            <input type="password" id="um-pass2" placeholder="Re-enter password">
            <span class="um-error" id="um-err-pass2" style="display:none;color:var(--coforge-red);font-size:11.5px;margin-top:4px"></span>
          </div>
        </div>
      </div>

      <!-- Access Permissions Preview -->
      <div id="um-permissions-preview" style="background:rgba(0,169,157,.05);border:1px solid rgba(0,169,157,.2);border-radius:10px;padding:14px 16px;margin-top:6px">
        <div style="font-size:12px;font-weight:700;color:var(--coforge-teal);margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px">Access Permissions Preview</div>
        <div id="um-perms-content" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px"></div>
      </div>

      <!-- Submit -->
      <div style="display:flex;gap:12px;justify-content:flex-end;margin-top:24px;padding-top:16px;border-top:1px solid var(--coforge-border)">
        <button class="btn btn-outline" onclick="UserModal.close()">Cancel</button>
        <button class="btn btn-primary" id="um-modal-submit" onclick="UserModal.submit()">Add User</button>
      </div>
    </div>
  </div>
</div>
<!-- ── END MODAL ── -->

<div class="section-header">
  <div>
    <div class="section-title">Settings — User Management</div>
    <div class="section-sub">Add, edit and manage Sales Leaders, Delivery Leaders and Admin access</div>
  </div>
  <button class="btn btn-primary" onclick="UserModal.openAdd()">+ Add New User</button>
</div>

<div class="metric-grid metric-grid-3" style="margin-bottom:22px">
  <div class="metric-card green">
    <div class="metric-label">Total Active Users</div>
    <div class="metric-value" id="um-stat-total">${UserStore.getTotalCount()}</div>
    <div class="metric-sub">Platform users</div>
  </div>
  <div class="metric-card teal">
    <div class="metric-label">Sales Leaders</div>
    <div class="metric-value" id="um-stat-sales">${UserStore.getSalesCount()}</div>
    <div class="metric-sub">Active</div>
  </div>
  <div class="metric-card blue">
    <div class="metric-label">Delivery Leaders</div>
    <div class="metric-value" id="um-stat-deliv">${UserStore.getDelivCount()}</div>
    <div class="metric-sub">Active</div>
  </div>
</div>

<!-- Add User Quick-Action Banner -->
<div style="background:linear-gradient(135deg,#0D1E2E,#1A2B3C);border-radius:12px;padding:20px 24px;margin-bottom:22px;display:flex;align-items:center;gap:20px;border:1px solid rgba(0,169,157,.25)">
  <div style="font-size:28px">👥</div>
  <div style="flex:1">
    <div style="color:#fff;font-weight:600;font-size:14px;margin-bottom:3px">Add a Sales Leader or Delivery Leader</div>
    <div style="color:rgba(255,255,255,.5);font-size:12.5px">New users get immediate access to the platform based on their assigned role and business unit.</div>
  </div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-outline" style="color:#fff;border-color:rgba(255,255,255,.3)" onclick="UserModal.openAdd();UserModal._selectRoleCard('sales')">+ Sales Leader</button>
    <button class="btn btn-primary" onclick="UserModal.openAdd();UserModal._selectRoleCard('delivery')">+ Delivery Leader</button>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">All Users</div>
    <div class="filter-row">
      <select class="filter-select" id="um-filter-role" onchange="Pages.Settings._filterUsers()">
        <option value="">All Roles</option>
        <option value="sales">Sales Leader</option>
        <option value="delivery">Delivery Leader</option>
        <option value="admin">Admin</option>
      </select>
      <select class="filter-select" id="um-filter-bu" onchange="Pages.Settings._filterUsers()">
        <option value="">All BUs</option>
        <option value="TTH NA">TTH NA</option>
        <option value="ANZ BFS">ANZ BFS</option>
        <option value="Insurance NA">Insurance NA</option>
        <option value="Insurance EU">Insurance EU</option>
        <option value="US Geo Retail">US Geo Retail</option>
        <option value="BFS EMEA">BFS EMEA</option>
      </select>
      <select class="filter-select" id="um-filter-status" onchange="Pages.Settings._filterUsers()">
        <option value="">All Status</option>
        <option value="Active">Active</option>
        <option value="Warning">Warning</option>
        <option value="Inactive">Inactive</option>
      </select>
      <div class="search-box" style="max-width:220px">
        <span>🔍</span>
        <input type="text" id="um-search" placeholder="Search users…" oninput="Pages.Settings._filterUsers()">
      </div>
    </div>
  </div>
  <div class="card-body no-pad">
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Role</th>
            <th>Business Unit</th>
            <th>Region</th>
            <th>Status</th>
            <th>Last Active</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="um-table-body">${rows}</tbody>
      </table>
    </div>
  </div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>🔑 Role Permissions Matrix</h3><p>What each role can see and do in the platform</p></div></div>
  <div class="settings-card-body">
    <div class="table-wrap"><table>
      <thead><tr><th>Feature</th><th>Sales Leader</th><th>Delivery Leader</th><th>Admin / Executive</th></tr></thead>
      <tbody>
        ${[
          ['View All Dashboards',          '✅','✅','✅'],
          ['Pipeline Tracker (Salesforce)', '✅ Own BU','✅ Own BU','✅ All'],
          ['Finance Tracker',              '✅ Own Accounts','✅ Own Accounts','✅ All'],
          ['Resource / Bench Data',        '👁️ View Only','✅ Full','✅ Full'],
          ['Submit Sales BE',              '✅','❌','✅ Override'],
          ['Submit Delivery BE',           '❌','✅','✅ Override'],
          ['View BE Analytics',            '✅ Own','✅ Own','✅ All Leaders'],
          ['User Management',              '❌','❌','✅'],
          ['Data Source Config',           '❌','❌','✅'],
          ['Audit Log',                    '❌','❌','✅'],
        ].map(([f,...v])=>`<tr><td><strong>${f}</strong></td>${v.map(x=>`<td>${x}</td>`).join('')}</tr>`).join('')}
      </tbody>
    </table></div>
  </div>
</div>`;
  },

  /* ── Re-render helper ── */
  _refreshUsersPage() {
    const page = document.getElementById('page-settings-users');
    if (page) page.innerHTML = Pages.Settings.renderUsers();
  },

  /* ── Client-side filter ── */
  _filterUsers() {
    const roleFilter   = (document.getElementById('um-filter-role')?.value   || '').toLowerCase();
    const buFilter     = (document.getElementById('um-filter-bu')?.value     || '').toLowerCase();
    const statusFilter = (document.getElementById('um-filter-status')?.value || '').toLowerCase();
    const searchText   = (document.getElementById('um-search')?.value        || '').toLowerCase();

    document.querySelectorAll('#um-table-body tr').forEach(row => {
      const text = row.textContent.toLowerCase();
      const roleCell   = row.querySelector('td:nth-child(2)')?.textContent.toLowerCase() || '';
      const buCell     = row.querySelector('td:nth-child(3)')?.textContent.toLowerCase() || '';
      const statusCell = row.querySelector('td:nth-child(5)')?.textContent.toLowerCase() || '';

      const matchRole   = !roleFilter   || roleCell.includes(roleFilter);
      const matchBU     = !buFilter     || buCell.includes(buFilter);
      const matchStatus = !statusFilter || statusCell.includes(statusFilter);
      const matchSearch = !searchText   || text.includes(searchText);

      row.style.display = (matchRole && matchBU && matchStatus && matchSearch) ? '' : 'none';
    });
  },

  /* ══════════════════════════════════════════
     DATA SOURCE CONFIG
  ══════════════════════════════════════════ */
  renderDataSources() {
    return `
<div class="section-header">
  <div><div class="section-title">Settings — Data Source Configuration</div><div class="section-sub">Configure connections to Salesforce, RDG systems and Finance</div></div>
  <button class="btn btn-primary" onclick="UI.toast('All data source settings saved!','🔌')">Save All</button>
</div>

<div class="alert alert-info"><div class="alert-icon">ℹ️</div><div class="alert-text"><strong>Production Note:</strong> In production, store credentials securely in your backend (e.g. Azure Key Vault, AWS Secrets Manager). Never expose API keys in client-side code.</div></div>

<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">☁️ Salesforce CRM</div><div class="ds-conn-meta">Pipeline Tracker · Closed Deals · Updated every Monday 08:00 AM</div></div>
    <span class="badge badge-green">● Connected</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>Instance URL</label><input type="text" value="https://coforge.my.salesforce.com"></div>
    <div class="ds-conn-field"><label>API Version</label><input type="text" value="v58.0"></div>
    <div class="ds-conn-field"><label>Client ID (Consumer Key)</label><input type="text" value="3MVG9…redacted"></div>
    <div class="ds-conn-field"><label>Client Secret</label><input type="password" value="••••••••••••"></div>
    <div class="ds-conn-field"><label>Sync Schedule</label><select class="filter-select" style="width:100%"><option>Every Monday 08:00 AM</option><option>Daily 06:00 AM</option><option>Every 4 hours</option><option>Manual only</option></select></div>
    <div class="ds-conn-field"><label>Opportunity Filters</label><input type="text" value="Stage != 'Lost', FY = FY2026"></div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px">
    <button class="btn btn-outline btn-sm" onclick="UI.simulateSync(this,'Salesforce')">Test Connection</button>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('Salesforce sync triggered!','🔄')">Sync Now</button>
  </div>
</div>

<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">👥 RDG Resource Management System</div><div class="ds-conn-meta">Employee · Bench · Demand · Fulfillment · Updated every Monday 09:00 AM</div></div>
    <span class="badge badge-green">● Connected</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>API Endpoint</label><input type="text" value="https://rdg.coforge.internal/api/v2"></div>
    <div class="ds-conn-field"><label>API Key</label><input type="password" value="••••••••••••"></div>
    <div class="ds-conn-field"><label>Sync Schedule</label><select class="filter-select" style="width:100%"><option>Every Monday 09:00 AM</option><option>Daily 07:00 AM</option><option>Manual only</option></select></div>
    <div class="ds-conn-field"><label>Data Scope</label><input type="text" value="All IBUs, FY2026"></div>
    <div class="ds-conn-field"><label>Bench Critical Threshold (days)</label><input type="number" value="30"></div>
    <div class="ds-conn-field"><label>Demand At-Risk Threshold (days)</label><input type="number" value="30"></div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px">
    <button class="btn btn-outline btn-sm" onclick="UI.simulateSync(this,'RDG')">Test Connection</button>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('RDG sync triggered!','🔄')">Sync Now</button>
  </div>
</div>

<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">💰 Finance Tracker (DATA2.xlsx Upload)</div><div class="ds-conn-meta">Revenue Actuals · Gross Margin · Updated 1st of each month by Finance Team</div></div>
    <span class="badge badge-teal">● Monthly Upload</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>Upload Method</label><select class="filter-select" style="width:100%"><option>Manual File Upload (xlsx)</option><option>SharePoint Auto-sync</option><option>Email attachment parser</option></select></div>
    <div class="ds-conn-field"><label>SharePoint Path (if used)</label><input type="text" placeholder="https://coforge.sharepoint.com/..."></div>
    <div class="ds-conn-field"><label>Expected Sheet Name</label><input type="text" value="FINANCE TRACKER"></div>
    <div class="ds-conn-field"><label>Header Row Number</label><input type="number" value="7"></div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px">
    <label class="btn btn-outline btn-sm" style="cursor:pointer">📁 Upload DATA2.xlsx<input type="file" accept=".xlsx" style="display:none" onchange="UI.toast('File uploaded and processing…','📊')"></label>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('Last upload: Mar 1, 2026 — 46 accounts, FY2026 Q3 complete.','ℹ️')">View Last Upload</button>
  </div>
</div>

<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">🤖 AI Agent (Claude API)</div><div class="ds-conn-meta">Powered by Anthropic Claude · Revenue Intelligence Agent</div></div>
    <span class="badge badge-${CONFIG.AI.API_KEY ? 'green' : 'yellow'}">● ${CONFIG.AI.API_KEY ? 'Connected' : 'Demo Mode'}</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>API Endpoint</label><input type="text" value="${CONFIG.AI.ENDPOINT}" readonly></div>
    <div class="ds-conn-field"><label>Model</label><input type="text" value="${CONFIG.AI.MODEL}" readonly></div>
    <div class="ds-conn-field"><label>Anthropic API Key</label><input type="password" placeholder="sk-ant-api03-…"></div>
    <div class="ds-conn-field"><label>Max Tokens per Response</label><input type="number" value="${CONFIG.AI.MAX_TOKENS}"></div>
  </div>
  <div class="alert alert-warning" style="margin-top:12px"><div class="alert-icon">⚠️</div><div class="alert-text"><strong>Security:</strong> For production, route all AI calls through your backend proxy. See README for setup instructions.</div></div>
  <div style="margin-top:4px">
    <button class="btn btn-outline btn-sm" onclick="UI.toast('AI agent test — Claude responded correctly.','🤖')">Test AI Agent</button>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     NOTIFICATIONS
  ══════════════════════════════════════════ */
  renderNotifications() {
    const notifs = [
      { icon:'🎯', title:'BE Submission Reminder',           desc:'Alert when BE deadline is approaching (configurable days before end of month)',   channels:['email','platform'] },
      { icon:'⚠️', title:'Overdue BE Alert',                desc:'Alert when a leader has not submitted BE past the deadline',                       channels:['email','platform','slack'] },
      { icon:'🚨', title:'Deal Slippage Warning',            desc:'Alert when an opportunity has not moved stage for N days',                        channels:['email','platform'] },
      { icon:'📊', title:'Weekly Salesforce Sync Complete',  desc:'Confirmation when Salesforce data sync finishes each Monday',                     channels:['platform'] },
      { icon:'💰', title:'Finance Tracker Updated',          desc:'Alert when new Finance Tracker data is uploaded by Finance team',                 channels:['email','platform'] },
      { icon:'👥', title:'Critical Bench Alert',             desc:'Alert when resources have been on bench for more than threshold (default 30 days)',channels:['email','platform'] },
      { icon:'🏆', title:'Deal Won Notification',            desc:'Celebrate when a deal is marked Closed-Won in Salesforce',                        channels:['platform','slack'] },
      { icon:'📈', title:'Weekly BE Accuracy Report',        desc:'Weekly digest showing BE accuracy trends for your accounts',                      channels:['email'] },
    ];
    const notifRows = notifs.map(n => `
      <div class="settings-row">
        <div class="settings-row-label"><h4>${n.icon} ${n.title}</h4><p>${n.desc}</p></div>
        <div class="settings-row-control" style="display:flex;align-items:center;gap:14px">
          <div style="display:flex;gap:6px">${n.channels.map(ch=>`<span class="notif-channel">${ch==='email'?'📧':ch==='platform'?'🔔':'💬'} ${ch}</span>`).join('')}</div>
          <label class="toggle"><input type="checkbox" checked><span class="toggle-slider"></span></label>
        </div>
      </div>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Settings — Notifications</div><div class="section-sub">Configure when and how you receive alerts from the platform</div></div>
  <button class="btn btn-primary" onclick="UI.toast('Notification preferences saved!','🔔')">Save Preferences</button>
</div>
<div class="settings-card">
  <div class="settings-card-header"><div><h3>📬 Notification Channels</h3><p>Configure your delivery channels</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>📧 Email Address</h4><p>Primary email for notification delivery</p></div>
      <div class="settings-row-control"><input style="padding:8px 12px;border:1.5px solid var(--coforge-border);border-radius:8px;font-size:13px;width:260px" type="email" value="sarah.leader@coforge.com"></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>💬 Slack Webhook</h4><p>Post notifications to a Slack channel</p></div>
      <div class="settings-row-control"><input style="padding:8px 12px;border:1.5px solid var(--coforge-border);border-radius:8px;font-size:13px;width:260px" type="text" placeholder="https://hooks.slack.com/services/…"></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>📅 Email Digest Frequency</h4><p>How often to receive a summary email</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>Daily</option><option>Weekly (Monday)</option><option>Never</option></select></div>
    </div>
  </div>
</div>
<div class="settings-card">
  <div class="settings-card-header"><div><h3>🔔 Notification Rules</h3><p>Toggle individual notification types</p></div></div>
  <div class="settings-card-body">${notifRows}</div>
</div>
<div class="settings-card">
  <div class="settings-card-header"><div><h3>⏰ Reminder Timing</h3><p>Configure when reminders are sent before deadlines</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>BE Deadline Reminder — 1st Warning</h4><p>Send reminder N days before end of month</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>10 days before</option><option>7 days before</option><option>5 days before</option><option>3 days before</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>BE Deadline Reminder — Final Warning</h4><p>Last reminder before deadline</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>1 day before</option><option>2 days before</option><option>Day of deadline</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Deal Slippage Threshold</h4><p>Alert after opportunity has not moved stage for N days</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>30 days</option><option>21 days</option><option>45 days</option><option>60 days</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Bench Critical Threshold</h4><p>Alert when resource has been on bench for N days</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>30 days</option><option>21 days</option><option>45 days</option></select></div>
    </div>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     AUDIT LOG
  ══════════════════════════════════════════ */
  renderAudit() {
    const rows = Data.auditLog.map(a => `
      <div class="audit-row">
        <div class="audit-icon">${a.icon}</div>
        <div class="audit-info"><div class="audit-action">${a.action}</div><div class="audit-meta">${a.meta}</div></div>
        <div class="audit-time">${a.time}</div>
      </div>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Settings — Audit Log</div><div class="section-sub">Complete history of platform activity, data syncs and user actions</div></div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-outline" onclick="UI.toast('Audit log exported to CSV.','📥')">Export CSV</button>
    <button class="btn btn-outline" onclick="UI.toast('Audit log printed.','🖨️')">Print</button>
  </div>
</div>
<div class="metric-grid metric-grid-3">
  <div class="metric-card teal"><div class="metric-label">Total Events (FY2026)</div><div class="metric-value">1,842</div></div>
  <div class="metric-card green"><div class="metric-label">Data Syncs</div><div class="metric-value">164</div><div class="metric-sub">Salesforce + RDG + Finance</div></div>
  <div class="metric-card orange"><div class="metric-label">BE Submissions</div><div class="metric-value">396</div><div class="metric-sub">By all leaders YTD</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Recent Activity</div>
    <div class="filter-row">
      <select class="filter-select"><option>All Event Types</option><option>BE Submissions</option><option>Data Syncs</option><option>User Management</option><option>Settings Changes</option><option>System Alerts</option></select>
      <select class="filter-select"><option>All Time</option><option>Today</option><option>Last 7 Days</option><option>This Month</option><option>Last 3 Months</option></select>
    </div>
  </div>
  <div class="card-body">${rows}</div>
</div>
<div class="settings-card">
  <div class="settings-card-header"><div><h3>🗄️ Audit Log Retention</h3><p>Configure how long audit records are kept</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>Retention Period</h4><p>How long to keep audit log entries before archiving</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>2 Years</option><option>1 Year</option><option>6 Months</option><option>Indefinite</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Auto-export to Archive</h4><p>Automatically export and archive logs older than retention period</p></div>
      <div class="settings-row-control"><label class="toggle"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Archive Location</h4><p>Where archived logs are stored</p></div>
      <div class="settings-row-control"><input style="padding:8px 12px;border:1.5px solid var(--coforge-border);border-radius:8px;font-size:13px;width:280px" type="text" value="SharePoint: /Finance/RIP-Audit-Archive"></div>
    </div>
  </div>
</div>`;
  },
};

/* ── Attach role card selector to UserModal ── */
UserModal._selectRoleCard = function(role) {
  document.getElementById('um-role').value = role;
  ['sales','delivery','admin'].forEach(r => {
    const card = document.getElementById('um-card-' + r);
    if (!card) return;
    if (r === role) {
      card.style.borderColor = 'var(--coforge-teal)';
      card.style.background  = 'rgba(0,169,157,.06)';
      card.querySelector('div:nth-child(2)').style.color = 'var(--coforge-teal)';
    } else {
      card.style.borderColor = 'var(--coforge-border)';
      card.style.background  = 'transparent';
      card.querySelector('div:nth-child(2)').style.color = 'var(--coforge-dark)';
    }
  });
  /* Update permissions preview */
  const perms = {
    sales: [
      ['📊 Dashboards','✅ All'],['🔄 Pipeline','✅ Own BU'],['💰 Finance','✅ Own Accounts'],
      ['👥 Resources','👁️ View Only'],['🎯 Sales BE','✅ Submit'],['🚚 Delivery BE','❌'],
      ['📈 BE Analytics','✅ Own'],['⚙️ User Mgmt','❌'],
    ],
    delivery: [
      ['📊 Dashboards','✅ All'],['🔄 Pipeline','✅ Own BU'],['💰 Finance','✅ Own Accounts'],
      ['👥 Resources','✅ Full'],['🎯 Sales BE','❌'],['🚚 Delivery BE','✅ Submit'],
      ['📈 BE Analytics','✅ Own'],['⚙️ User Mgmt','❌'],
    ],
    admin: [
      ['📊 Dashboards','✅ All'],['🔄 Pipeline','✅ All'],['💰 Finance','✅ All'],
      ['👥 Resources','✅ Full'],['🎯 Sales BE','✅ Override'],['🚚 Delivery BE','✅ Override'],
      ['📈 BE Analytics','✅ All Leaders'],['⚙️ User Mgmt','✅'],
    ],
  };
  const content = document.getElementById('um-perms-content');
  if (content) {
    content.innerHTML = (perms[role]||[]).map(([label, val]) =>
      `<div style="display:flex;justify-content:space-between;padding:5px 8px;background:rgba(255,255,255,.6);border-radius:6px">
        <span style="color:var(--coforge-muted)">${label}</span>
        <span style="font-weight:600;color:${val==='❌'?'var(--coforge-red)':val.includes('View')?'var(--coforge-muted)':'var(--coforge-dark)'}">${val}</span>
      </div>`
    ).join('');
  }
};
