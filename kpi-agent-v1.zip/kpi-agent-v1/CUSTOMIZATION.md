# 🎨 Customization Guide — Wireframe 1

This document explains every customization point in the KPI Agent.
This is **Wireframe 1** — a foundation designed to be extended.

---

## 1. Change Dashboard Colors

Open `templates/dashboard.html` and edit the CSS variables at the top:

```css
:root {
  /* Background system */
  --bg-primary:   #0a0e1a;   /* Main background — change for light theme */
  --bg-surface:   #111827;   /* Card backgrounds */
  --bg-surface2:  #1a2235;   /* Nested surfaces */

  /* Accent colors */
  --accent-green: #00d97e;   /* Primary accent (good/positive) */
  --accent-blue:  #3b82f6;   /* Secondary accent (info) */
  --accent-amber: #f59e0b;   /* Warning */
  --accent-red:   #e63757;   /* Danger */

  /* Typography */
  --font-display: 'Syne', sans-serif;
  --font-mono:    'DM Mono', monospace;
}
```

### Switch to Light Theme
In `config.yaml`:
```yaml
dashboard:
  theme: light
```

---

## 2. Add a New KPI Card

**Step 1** — Add calculation in `core/kpi_calculator.py`:
```python
# Inside _revenue_kpis() method, add:
churn_col = self._col(df, 'churn_rate')
if churn_col is not None:
    out['avg_churn_rate'] = round(float(df[churn_col].mean()), 1)
```

**Step 2** — Add column alias in `config.yaml`:
```yaml
column_aliases:
  churn_rate:
    - churn_rate
    - churn
    - customer_churn
```

**Step 3** — Add to dashboard template in `templates/dashboard.html`:
```html
<div class="kpi-card">
  <div class="kpi-label">Churn Rate</div>
  <div class="kpi-value" id="kv-churn">—</div>
  <div class="kpi-sub" id="ks-churn">Monthly avg</div>
</div>
```

**Step 4** — Wire it in `ui/dashboard.py`:
```python
replacements['{{KV_CHURN}}'] = str(kpis.get('avg_churn_rate', 'N/A')) + '%'
```

---

## 3. Add a New Chart

**Step 1** — Add a canvas in `templates/dashboard.html`:
```html
<div class="chart-card">
  <div class="chart-title">Customer Acquisition</div>
  <canvas id="acqChart" height="200"></canvas>
</div>
```

**Step 2** — Add chart data in `ui/dashboard.py`:
```python
js_vars += f"const ACQ = {json.dumps(monthly_acquisition_data)};\n"
```

**Step 3** — Add Chart.js code in `templates/dashboard.html`:
```javascript
new Chart(document.getElementById('acqChart'), {
  type: 'line',
  data: {
    labels: M,
    datasets: [{
      data: ACQ,
      borderColor: '#00d97e',
      fill: false,
      tension: 0.4
    }]
  },
  options: { responsive: true, maintainAspectRatio: false }
});
```

---

## 4. Add a New Risk Rule

Open `core/risk_engine.py` and add to the `RISK_RULES` dict:

```python
RISK_RULES = {
    # ... existing rules ...

    "customer_concentration": {
        "name": "Customer concentration risk",
        "detail_template": "Top customer holds >{pct:.0f}% of revenue",
        "category": "Revenue",
        "compute": lambda kpis, cfg: (
            kpis.get('top_customer_share', 0) / 100
        ),
        "impact_template": lambda kpis: "Customer churn = immediate gap",
    },
}
```

---

## 5. Change the AI Prompt

Open `core/insight_engine.py` and edit `EXECUTIVE_PROMPT`:

```python
EXECUTIVE_PROMPT = """
You are a [YOUR ROLE HERE] analysing [YOUR COMPANY TYPE].

Focus especially on:
- [Your key metric 1]
- [Your key metric 2]
- [Industry-specific concern]

Data:
...
"""
```

---

## 6. Add a New AI Provider

Create a new file `agents/my_provider_agent.py`:

```python
from agents.base_agent import BaseAgent

class MyProviderAgent(BaseAgent):
    name = "MyProvider Agent"

    def is_available(self) -> bool:
        return bool(os.getenv('MY_PROVIDER_API_KEY'))

    def analyze_schema(self, schema):
        # Call your API here
        return {}

    def detect_relationships(self, tables):
        return []

    def suggest_normalization(self, table):
        return {}

    def generate_description(self, info):
        return "Description"
```

Then register it in `agents/base_agent.py`:
```python
PROVIDERS = {
    "anthropic": AnthropicAgent,
    "openai": OpenAIAgent,
    "copilot": CopilotAgent,
    "myprovider": MyProviderAgent,   # ← add this
}
```

---

## 7. Change Currency

In `config.yaml`:
```yaml
dashboard:
  currency: USD
  currency_symbol: "$"
```

---

## 8. Add a New Tab to the Dashboard

**Step 1** — Add tab button in `templates/dashboard.html`:
```html
<div class="tab" onclick="showTab('forecast', this)">Forecast</div>
```

**Step 2** — Add tab content section:
```html
<div id="tab-forecast" style="display:none;">
  <!-- Your forecast content -->
</div>
```

---

## 9. Change KPI Thresholds

In `config.yaml` — no code changes needed:
```yaml
kpis:
  gm_healthy_threshold: 40      # Was 35 — raise the bar
  win_rate_benchmark: 45        # Was 40 — more demanding
  pipeline_coverage_min: 4.0    # Was 3.0 — more conservative
```

---

## 10. Add Email Scheduling

In `config.yaml`:
```yaml
report:
  send_email: true
  frequency: weekly
  send_time: "08:00"
```

In `.env`:
```env
EMAIL_SENDER=reports@yourcompany.com
EMAIL_PASSWORD=your_app_password
LEADERSHIP_EMAILS=ceo@company.com,vp@company.com
```

---

## Wireframe Roadmap

| Version | Features |
|---------|----------|
| **Wireframe 1** (current) | Core KPI dashboard + executive summary + risks |
| **Wireframe 2** | Power BI MCP integration + real-time refresh |
| **Wireframe 3** | Multi-company benchmarking + industry comparison |
| **Wireframe 4** | Predictive forecasting + what-if scenario planning |
| **Wireframe 5** | Full Salesforce live integration + CRM sync |
