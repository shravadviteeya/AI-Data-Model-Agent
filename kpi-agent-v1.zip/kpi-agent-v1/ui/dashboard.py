"""
Dashboard Builder — assembles the interactive HTML dashboard.
Edit templates/dashboard.html to change the visual design.
"""

import json
from typing import Dict, List, Any
from pathlib import Path
from datetime import datetime
from loguru import logger


class DashboardBuilder:
    """Builds the interactive KPI dashboard HTML."""

    def __init__(self, config: dict):
        self.cfg = config
        self.currency = config.get(
            'dashboard', {}).get('currency_symbol', '₹')
        self.title = config.get(
            'dashboard', {}).get('title', 'Sales Intelligence Dashboard')
        self.company = config.get(
            'dashboard', {}).get('company_name', 'Company')

    def build(
        self,
        kpis: Dict[str, Any],
        risks: List[Dict],
        insights: List[Dict],
        data: Dict
    ) -> str:
        """Build complete dashboard HTML string."""
        logger.info("Building interactive dashboard...")

        # ── Chart data ────────────────────────────────────────
        monthly = kpis.get('monthly_trend', [])
        months_js = json.dumps([str(m.get('Month', m.get('month', '')))
                                 for m in monthly])
        rev_col = next(
            (k for k in ['revenue', 'Revenue'] if k in (monthly[0] if monthly else {})),
            'revenue'
        )
        rev_js = json.dumps([int(m.get(rev_col, 0)) for m in monthly])
        gm_col = next(
            (k for k in ['gross_margin', 'Gross_Margin', 'gm', 'GM']
             if k in (monthly[0] if monthly else {})),
            'gross_margin'
        )
        gm_js = json.dumps([int(m.get(gm_col, 0)) for m in monthly])
        gmpct_js = json.dumps([round(float(m.get('gm_pct', 0)), 2)
                                for m in monthly])
        vsbe_js = json.dumps([round(float(m.get('vs_be_pct',
                              m.get('VsBE', 100))), 1) for m in monthly])
        deals_col = next(
            (k for k in ['deals_closed', 'Deals_Closed', 'deals', 'Deals']
             if k in (monthly[0] if monthly else {})),
            'deals_closed'
        )
        deals_js = json.dumps([int(m.get(deals_col, 0)) for m in monthly])

        # ── Dimensional data ──────────────────────────────────
        by_region = kpis.get('by_region', [])
        by_product = kpis.get('by_product', [])
        by_owner = kpis.get('by_sales_owner', [])

        reg_labels = json.dumps([r.get('name', '') for r in by_region])
        reg_rev = json.dumps([int(r.get('revenue', r.get('Revenue', 0)))
                               for r in by_region])
        prod_labels = json.dumps([p.get('name', '') for p in by_product])
        prod_share = json.dumps([float(p.get('rev_share', 0))
                                  for p in by_product])
        own_labels = json.dumps([o.get('name', '') for o in by_owner])
        own_rev = json.dumps([int(o.get('revenue', o.get('Revenue', 0)))
                               for o in by_owner])

        # ── KPI values ────────────────────────────────────────
        tr = kpis.get('total_revenue', 0)
        tg = kpis.get('total_gm', 0)
        gp = kpis.get('avg_gm_pct', 0)
        wr = kpis.get('avg_win_rate', 0)
        td = kpis.get('total_deals', 0)
        tp = kpis.get('total_pipeline', 0)
        rvb = kpis.get('revenue_vs_be_pct', 0)
        cov = kpis.get('pipeline_coverage', 0)
        score = kpis.get('health_score', 75)
        health_label = kpis.get('health_label', 'Watch')
        rvb_color = ('#00d97e' if rvb >= 100
                     else '#f59e0b' if rvb >= 95 else '#e63757')
        score_color = ('#00d97e' if score >= 75
                       else '#f59e0b' if score >= 50 else '#e63757')

        # ── Insight HTML ──────────────────────────────────────
        type_colors = {
            'strength': ('rgba(0,217,126,.12)', '#00d97e'),
            'concern': ('rgba(245,158,11,.12)', '#f59e0b'),
            'recommendation': ('rgba(59,130,246,.12)', '#3b82f6'),
        }
        insights_html = ''
        for ins in insights[:8]:
            bg, border = type_colors.get(
                ins.get('type', 'concern'),
                ('rgba(100,116,139,.1)', '#64748b')
            )
            label = ins.get('type', 'insight').replace('_', ' ').title()
            insights_html += (
                f'<div style="background:{bg};border:1px solid {border};'
                f'border-radius:10px;padding:11px 14px;font-size:12px;'
                f'line-height:1.5;color:#e2e8f0;">'
                f'<span style="font-size:9px;font-weight:700;'
                f'color:{border};letter-spacing:.1em;text-transform:uppercase;'
                f'display:block;margin-bottom:5px;">{label}</span>'
                f'{ins.get("text", "")}</div>'
            )

        # ── Risk rows HTML ─────────────────────────────────────
        sev_colors = {
            'HIGH': ('rgba(230,55,87,.15)', '#e63757'),
            'MEDIUM': ('rgba(245,158,11,.15)', '#f59e0b'),
            'LOW': ('rgba(0,217,126,.15)', '#00d97e'),
        }
        risk_rows_html = ''
        for r in risks[:5]:
            bg, col = sev_colors.get(r['severity'],
                                      ('rgba(100,116,139,.1)', '#64748b'))
            likelihood = r.get('likelihood_pct', 50)
            impact_bar = r.get('impact_bar', 50)
            risk_rows_html += f'''
<div style="display:grid;grid-template-columns:80px 1fr 110px 110px;
     gap:12px;align-items:center;padding:10px 14px;border-radius:10px;
     border:0.5px solid rgba(30,45,69,.6);margin-bottom:6px;">
  <span style="background:{bg};color:{col};font-size:9px;font-weight:700;
        padding:3px 8px;border-radius:8px;text-align:center;
        letter-spacing:.05em;">{r["severity"]}</span>
  <div>
    <div style="font-size:12px;font-weight:500;color:#e2e8f0;">{r["name"]}</div>
    <div style="font-size:10px;color:#64748b;margin-top:2px;">{r.get("detail","")}</div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:10px;color:#64748b;">Impact</div>
    <div style="font-size:11px;color:#e2e8f0;">{r.get("impact","")}</div>
    <div style="background:#1e2d45;border-radius:3px;height:3px;margin-top:4px;">
      <div style="width:{impact_bar}%;height:3px;background:{col};border-radius:3px;"></div>
    </div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:10px;color:#64748b;">Likelihood</div>
    <div style="font-size:11px;color:#e2e8f0;">{likelihood}%</div>
    <div style="background:#1e2d45;border-radius:3px;height:3px;margin-top:4px;">
      <div style="width:{likelihood}%;height:3px;background:{col};border-radius:3px;"></div>
    </div>
  </div>
</div>'''

        # ── Owner table HTML ───────────────────────────────────
        owner_rows_html = ''
        for o in by_owner[:8]:
            nm = str(o.get('name', ''))
            rev_val = int(o.get('revenue', o.get('Revenue', 0)))
            gm_pct_val = round(float(o.get('gm_pct', 0)), 1)
            deals_val = int(o.get('deals_closed',
                             o.get('Deals_Closed', o.get('deals', 0))))
            wr_val = round(float(o.get('win_rate',
                            o.get('WR', o.get('win_rate_mean', 0)))), 1)
            rev_fmt = (f'{self.currency}{rev_val/1e7:.2f}Cr'
                       if rev_val >= 1e7 else f'{self.currency}{rev_val/1e5:.1f}L')
            owner_rows_html += f'''
<tr>
  <td style="padding:10px 12px;border-bottom:1px solid rgba(30,45,69,.5);">
    <span style="display:inline-flex;align-items:center;justify-content:center;
          width:26px;height:26px;border-radius:7px;
          background:linear-gradient(135deg,#185FA5,#993556);
          font-size:11px;font-weight:700;color:#fff;margin-right:8px;">
      {nm[0] if nm else "?"}</span>{nm}
  </td>
  <td style="padding:10px 12px;border-bottom:1px solid rgba(30,45,69,.5);
       font-weight:500;color:#00d97e;">{rev_fmt}</td>
  <td style="padding:10px 12px;border-bottom:1px solid rgba(30,45,69,.5);">{gm_pct_val}%</td>
  <td style="padding:10px 12px;border-bottom:1px solid rgba(30,45,69,.5);">{deals_val}</td>
  <td style="padding:10px 12px;border-bottom:1px solid rgba(30,45,69,.5);">
    <div style="display:flex;align-items:center;gap:7px;">
      <div style="background:#1e2d45;border-radius:3px;height:5px;width:60px;flex-shrink:0;">
        <div style="width:{min(wr_val,100):.0f}%;height:5px;
             background:linear-gradient(90deg,#185FA5,#00d97e);border-radius:3px;"></div>
      </div>
      <span style="font-size:10px;color:#64748b;">{wr_val}%</span>
    </div>
  </td>
</tr>'''

        # ── Format helpers ────────────────────────────────────
        def fmt(n):
            if n >= 1e7:
                return f'{self.currency}{n/1e7:.2f}Cr'
            if n >= 1e5:
                return f'{self.currency}{n/1e5:.1f}L'
            return f'{self.currency}{n:,.0f}'

        gm_badge_cls = 'badge-g' if gp >= 35 else 'badge-r'
        wr_badge_cls = 'badge-g' if wr >= 40 else 'badge-a'
        rvb_badge_cls = ('badge-g' if rvb >= 100
                          else 'badge-a' if rvb >= 95 else 'badge-r')
        cov_badge_cls = 'badge-g' if cov >= 3 else 'badge-a'
        now_str = datetime.now().strftime('%d %b %Y %H:%M')
        today_str = datetime.now().strftime('%d %b %Y')
        n_rows = sum(
            v.get('rows', 0) for v in data.values()
            if isinstance(v, dict)
        )

        # ── Assemble HTML ─────────────────────────────────────
        html = self._html_template()
        replacements = {
            '{{TITLE}}': self.title,
            '{{COMPANY}}': self.company,
            '{{NOW}}': now_str,
            '{{TODAY}}': today_str,
            '{{N_ROWS}}': str(n_rows),
            '{{SCORE}}': str(score),
            '{{SCORE_COLOR}}': score_color,
            '{{HEALTH_LABEL}}': health_label,
            '{{KV_REVENUE}}': fmt(tr),
            '{{KV_GM}}': fmt(tg),
            '{{KV_GMPCT}}': f'{gp}%',
            '{{KV_WINRATE}}': f'{wr}%',
            '{{KV_DEALS}}': f'{td:,}',
            '{{KV_PIPELINE}}': fmt(tp),
            '{{KV_RVB}}': f'{rvb}%',
            '{{KV_COV}}': f'{cov}x',
            '{{RVB_COLOR}}': rvb_color,
            '{{GM_BADGE}}': gm_badge_cls,
            '{{WR_BADGE}}': wr_badge_cls,
            '{{RVB_BADGE}}': rvb_badge_cls,
            '{{COV_BADGE}}': cov_badge_cls,
            '{{MONTHS_JS}}': months_js,
            '{{REV_JS}}': rev_js,
            '{{GM_JS}}': gm_js,
            '{{GMPCT_JS}}': gmpct_js,
            '{{VSBE_JS}}': vsbe_js,
            '{{DEALS_JS}}': deals_js,
            '{{REG_LABELS}}': reg_labels,
            '{{REG_REV}}': reg_rev,
            '{{PROD_LABELS}}': prod_labels,
            '{{PROD_SHARE}}': prod_share,
            '{{OWN_LABELS}}': own_labels,
            '{{OWN_REV}}': own_rev,
            '{{INSIGHTS_HTML}}': insights_html,
            '{{RISK_ROWS}}': risk_rows_html,
            '{{OWNER_ROWS}}': owner_rows_html,
        }
        for k, v in replacements.items():
            html = html.replace(k, str(v))

        return html

    def _html_template(self) -> str:
        """Return the full HTML dashboard template."""
        return open(
            Path(__file__).parent.parent / 'templates' / 'dashboard.html',
            encoding='utf-8'
        ).read() if (
            Path(__file__).parent.parent / 'templates' / 'dashboard.html'
        ).exists() else self._inline_template()

    def _inline_template(self) -> str:
        """Fallback inline template if file not found."""
        return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{{TITLE}}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
:root{--bg:#0a0e1a;--su:#111827;--s2:#1a2235;--bd:#1e2d45;--ac:#00d97e;--a2:#3b82f6;--a3:#f59e0b;--a4:#ec4899;--tx:#e2e8f0;--mu:#64748b;}
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Syne',sans-serif;background:var(--bg);color:var(--tx);padding:20px;}
.badge-g{background:rgba(0,217,126,.15);color:#00d97e;}
.badge-r{background:rgba(230,55,87,.15);color:#e63757;}
.badge-a{background:rgba(245,158,11,.15);color:#f59e0b;}
.pill{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;}
h1{font-size:22px;margin-bottom:20px;color:var(--ac);}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px;}
.card{background:var(--su);border:0.5px solid var(--bd);border-radius:14px;padding:18px;}
.lbl{font-size:10px;color:var(--mu);text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px;}
.val{font-size:22px;font-weight:800;font-family:'DM Mono',monospace;}
canvas{max-height:200px;}
table{width:100%;border-collapse:collapse;font-size:12px;}
th{text-align:left;padding:8px;color:var(--mu);font-size:9px;text-transform:uppercase;border-bottom:1px solid var(--bd);}
</style>
</head>
<body>
<h1>{{TITLE}} — {{COMPANY}}</h1>
<p style="color:var(--mu);font-size:12px;margin-bottom:20px;">Generated {{NOW}} · {{N_ROWS}} rows · Health Score: <strong style="color:{{SCORE_COLOR}}">{{SCORE}}/100</strong></p>
<div class="grid4">
  <div class="card"><div class="lbl">Revenue</div><div class="val">{{KV_REVENUE}}</div><span class="pill {{RVB_BADGE}}">{{KV_RVB}} of BE</span></div>
  <div class="card"><div class="lbl">Gross Margin</div><div class="val">{{KV_GM}}</div><span class="pill {{GM_BADGE}}">{{KV_GMPCT}}</span></div>
  <div class="card"><div class="lbl">Win Rate</div><div class="val">{{KV_WINRATE}}</div><span class="pill {{WR_BADGE}}">vs 40% bench</span></div>
  <div class="card"><div class="lbl">Pipeline</div><div class="val">{{KV_PIPELINE}}</div><span class="pill {{COV_BADGE}}">{{KV_COV}} coverage</span></div>
</div>
<div class="card" style="margin-bottom:20px;">
  <h3 style="font-size:14px;margin-bottom:14px;">Monthly Revenue Trend</h3>
  <div style="position:relative;height:200px;"><canvas id="mainChart"></canvas></div>
</div>
<div class="card" style="margin-bottom:20px;">
  <h3 style="font-size:14px;margin-bottom:14px;">AI Insights</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">{{INSIGHTS_HTML}}</div>
</div>
<div class="card">
  <h3 style="font-size:14px;margin-bottom:14px;">Risk Register</h3>
  {{RISK_ROWS}}
</div>
<p style="font-size:10px;color:var(--mu);text-align:center;margin-top:20px;">Generated by KPI Intelligence Agent · Wireframe 1 · {{TODAY}}</p>
<script>
const M={{MONTHS_JS}};const RV={{REV_JS}};const GM={{GM_JS}};
new Chart(document.getElementById('mainChart'),{type:'bar',data:{labels:M,datasets:[
  {label:'Revenue',data:RV,backgroundColor:'rgba(59,130,246,.75)',borderRadius:4},
  {label:'GM',data:GM,backgroundColor:'rgba(0,217,126,.75)',borderRadius:4}
]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top'}},scales:{y:{ticks:{callback:v=>'₹'+(v/1e6).toFixed(1)+'M'}}}}});
</script>
</body>
</html>"""
