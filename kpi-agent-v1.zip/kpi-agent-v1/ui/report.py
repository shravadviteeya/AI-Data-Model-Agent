"""
Report Builder — assembles the executive summary HTML email report.
"""

import json
from typing import Dict, List, Any
from datetime import datetime
from loguru import logger


class ReportBuilder:
    """Builds the executive summary report HTML."""

    def __init__(self, config: dict):
        self.cfg = config
        self.currency = config.get(
            'dashboard', {}).get('currency_symbol', '₹')
        self.company = config.get(
            'dashboard', {}).get('company_name', 'Company')

    def build(
        self,
        kpis: Dict[str, Any],
        risks: List[Dict],
        insights: List[Dict]
    ) -> str:
        """Build the executive report HTML."""
        logger.info("Building executive report...")

        tr = kpis.get('total_revenue', 0)
        tg = kpis.get('total_gm', 0)
        gp = kpis.get('avg_gm_pct', 0)
        wr = kpis.get('avg_win_rate', 0)
        rvb = kpis.get('revenue_vs_be_pct', 100)
        variance = kpis.get('revenue_variance', 0)
        score = kpis.get('health_score', 75)
        cov = kpis.get('pipeline_coverage', 0)

        def fmt(n):
            n = float(n)
            if n >= 1e7:
                return f'{self.currency}{n/1e7:.2f}Cr'
            if n >= 1e5:
                return f'{self.currency}{n/1e5:.1f}L'
            return f'{self.currency}{n:,.0f}'

        rvb_color = ('#28a745' if rvb >= 100
                      else '#ffc107' if rvb >= 95 else '#dc3545')
        score_color = ('#28a745' if score >= 75
                        else '#ffc107' if score >= 50 else '#dc3545')
        var_sign = '+' if variance >= 0 else ''
        now_str = datetime.now().strftime('%d %b %Y')

        # KPI cards
        kpi_html = ''
        kpi_items = [
            ('Total Revenue', fmt(tr),
             f'{rvb}% of BE', rvb_color),
            ('Gross Margin', fmt(tg),
             f'GM% {gp}%',
             '#28a745' if gp >= 35 else '#dc3545'),
            ('Win Rate', f'{wr}%',
             'vs 40% benchmark',
             '#28a745' if wr >= 40 else '#ffc107'),
            ('Pipeline Cover', f'{cov}x',
             'target 3x',
             '#28a745' if cov >= 3 else '#ffc107'),
        ]
        for label, val, sub, color in kpi_items:
            kpi_html += f'''
<td style="padding:8px;">
  <div style="background:#f8f9fa;border-radius:8px;padding:14px;
              text-align:center;border-top:3px solid {color};">
    <div style="font-size:10px;color:#6c757d;text-transform:uppercase;
                letter-spacing:.08em;margin-bottom:4px;">{label}</div>
    <div style="font-size:20px;font-weight:700;color:#212529;">{val}</div>
    <div style="font-size:10px;color:{color};margin-top:4px;
                font-weight:600;">{sub}</div>
  </div>
</td>'''

        # Findings
        type_styles = {
            'strength': ('#d4edda', '#155724', '&#10003; Strength'),
            'concern': ('#fff3cd', '#856404', '&#9888; Concern'),
            'recommendation': ('#d1ecf1', '#0c5460', '&#8594; Recommendation'),
        }
        findings_html = ''
        for ins in insights[:6]:
            bg, col, prefix = type_styles.get(
                ins.get('type', 'concern'),
                ('#f8f9fa', '#495057', '&#8226; Insight')
            )
            findings_html += f'''
<tr>
  <td style="padding:8px 0;">
    <div style="background:{bg};border-radius:6px;padding:10px 14px;">
      <span style="font-size:9px;font-weight:700;color:{col};
                   text-transform:uppercase;letter-spacing:.08em;">
        {prefix}</span>
      <p style="font-size:13px;color:#212529;margin:4px 0 0;
                line-height:1.5;">{ins.get("text","")}</p>
    </div>
  </td>
</tr>'''

        # Risk table
        sev_colors = {
            'HIGH': '#dc3545', 'MEDIUM': '#ffc107', 'LOW': '#28a745'
        }
        risk_rows = ''
        for r in risks[:5]:
            col = sev_colors.get(r['severity'], '#6c757d')
            risk_rows += f'''
<tr>
  <td style="padding:8px 10px;border-bottom:1px solid #dee2e6;">
    <span style="background:{col};color:white;font-size:9px;
                 font-weight:700;padding:2px 7px;border-radius:4px;
                 letter-spacing:.05em;">{r["severity"]}</span>
  </td>
  <td style="padding:8px 10px;border-bottom:1px solid #dee2e6;
             font-size:13px;color:#212529;">{r["name"]}</td>
  <td style="padding:8px 10px;border-bottom:1px solid #dee2e6;
             font-size:12px;color:#6c757d;">{r.get("detail","")}</td>
  <td style="padding:8px 10px;border-bottom:1px solid #dee2e6;
             font-size:12px;text-align:right;">{r.get("impact","")}</td>
</tr>'''

        # Recommendations
        rec_map = {
            ins['text']: ins for ins in insights
            if ins.get('type') == 'recommendation'
        }
        recs_html = ''
        for i, (text, _) in enumerate(rec_map.items(), 1):
            recs_html += f'''
<tr>
  <td style="padding:8px 10px;border-bottom:1px solid #dee2e6;
             font-size:22px;font-weight:700;color:#dee2e6;
             vertical-align:top;">{i:02d}</td>
  <td style="padding:8px 10px;border-bottom:1px solid #dee2e6;
             font-size:13px;color:#212529;line-height:1.5;">{text}</td>
</tr>'''

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Executive Report — {self.company}</title>
<style>
  body{{font-family:Arial,sans-serif;margin:0;padding:0;background:#f0f2f5;}}
  .wrap{{max-width:800px;margin:0 auto;background:white;}}
  h2{{font-size:16px;color:#212529;margin:0 0 12px;padding-bottom:8px;
      border-bottom:2px solid #dee2e6;}}
  .sec{{padding:20px 30px;border-bottom:1px solid #dee2e6;}}
  table{{width:100%;border-collapse:collapse;}}
  th{{background:#f8f9fa;padding:8px 10px;text-align:left;font-size:11px;
      color:#6c757d;text-transform:uppercase;letter-spacing:.06em;
      border-bottom:2px solid #dee2e6;}}
</style>
</head>
<body>
<div class="wrap">
  <!-- Header -->
  <div style="background:linear-gradient(135deg,#212529,#343a40);
              color:white;padding:28px 30px;">
    <div style="font-size:11px;opacity:.7;margin-bottom:6px;
                letter-spacing:.1em;text-transform:uppercase;">
      Executive Summary · Wireframe 1</div>
    <h1 style="font-size:22px;font-weight:700;margin:0 0 4px;">
      {self.company} — Sales Intelligence Report</h1>
    <div style="font-size:13px;opacity:.8;">{now_str}</div>
    <div style="margin-top:14px;display:inline-block;
                background:rgba(255,255,255,.12);
                border-radius:6px;padding:6px 14px;">
      <span style="font-size:12px;opacity:.8;">Health Score </span>
      <span style="font-size:22px;font-weight:700;
                   color:{score_color};">{score}</span>
      <span style="font-size:12px;opacity:.8;">/100</span>
    </div>
  </div>

  <!-- KPI Strip -->
  <div class="sec">
    <table><tr>{kpi_html}</tr></table>
  </div>

  <!-- Headline -->
  <div class="sec">
    <div style="font-size:15px;color:#212529;line-height:1.6;
                border-left:4px solid #212529;padding-left:14px;">
      Revenue is <strong style="color:{rvb_color};">{rvb}% of Budget Estimate</strong>
      ({var_sign}{fmt(abs(variance))} variance). GM% at {gp}% is
      {'above' if gp >= 35 else 'below'} the 35% healthy threshold.
      Win rate of {wr}% is {'above' if wr >= 40 else 'below'} the 40% benchmark.
    </div>
  </div>

  <!-- Findings -->
  <div class="sec">
    <h2>Key Findings</h2>
    <table><tbody>{findings_html}</tbody></table>
  </div>

  <!-- Risk Register -->
  <div class="sec">
    <h2>Risk Register</h2>
    <table>
      <thead>
        <tr>
          <th style="width:80px;">Severity</th>
          <th>Risk</th>
          <th>Detail</th>
          <th style="text-align:right;">Impact</th>
        </tr>
      </thead>
      <tbody>{risk_rows}</tbody>
    </table>
  </div>

  <!-- Recommendations -->
  <div class="sec">
    <h2>Recommendations</h2>
    <table><tbody>{recs_html}</tbody></table>
  </div>

  <!-- Footer -->
  <div style="background:#f8f9fa;padding:16px 30px;text-align:center;">
    <p style="font-size:11px;color:#6c757d;margin:0;">
      Generated by KPI Intelligence Agent · Wireframe 1 ·
      {now_str} · {self.company}</p>
  </div>
</div>
</body>
</html>"""
