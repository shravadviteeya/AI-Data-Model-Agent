# 🤖 KPI Intelligence Agent — Wireframe 1

> LangChain-powered sales analytics agent that reads Excel files, calculates KPIs, detects risks, and generates an executive dashboard with AI insights.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.9+-green)
![License](https://img.shields.io/badge/license-MIT-orange)

---

## 📸 What It Does

```
Your Excel Files  →  LangChain Agent  →  KPI Dashboard  →  Executive Report  →  Email
     (4 files)         (7 tools)        (interactive)      (risks + recs)    (leadership)
```

**Wireframe 1 includes:**
- Interactive KPI dashboard (Revenue, GM%, Win Rate, Pipeline, vs-BE)
- Executive summary with health score
- Risk register (severity, impact, likelihood)
- 6 strategic recommendations
- Monthly trend charts
- Sales team leaderboard
- AI insights via Anthropic / OpenAI / GitHub Copilot / Gemini

---

## 📁 Project Structure

```
kpi-agent-v1/
│
├── main.py                    ← Run this (CLI entry point)
├── requirements.txt           ← All Python dependencies
├── .env.example               ← Copy to .env and add your keys
├── config.yaml                ← Agent + dashboard configuration
├── README.md                  ← This file
├── CUSTOMIZATION.md           ← How to customize Wireframe 1
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py          ← Abstract agent interface
│   ├── anthropic_agent.py     ← Claude (Anthropic)
│   ├── openai_agent.py        ← GPT-4 (OpenAI)
│   ├── gemini_agent.py        ← Gemini (Google)
│   ├── copilot_agent.py       ← GitHub Copilot
│   └── fallback_agent.py      ← Rule-based (no API key needed)
│
├── core/
│   ├── __init__.py
│   ├── excel_loader.py        ← Reads & validates Excel files
│   ├── kpi_calculator.py      ← All KPI calculations
│   ├── risk_engine.py         ← Risk scoring & register
│   └── insight_engine.py      ← AI insight generation
│
├── utils/
│   ├── __init__.py
│   ├── formatter.py           ← Number & date formatting
│   └── validator.py           ← Data quality checks
│
├── ui/
│   ├── dashboard.py           ← Builds HTML dashboard
│   └── report.py              ← Builds executive report HTML
│
├── templates/
│   ├── dashboard.html         ← Wireframe 1 dashboard template
│   └── report.html            ← Executive summary template
│
├── data/
│   └── sample/
│       └── generate_sample.py ← Creates sample Excel data
│
├── tests/
│   └── test_agent.py          ← Unit tests
│
└── docs/
    ├── ARCHITECTURE.md        ← System architecture
    └── API_REFERENCE.md       ← Tool & function reference
```

---

## 🚀 Quick Start (5 Minutes)

### Step 1 — Clone from GitHub
```bash
git clone https://github.com/YOUR_USERNAME/kpi-agent-v1.git
cd kpi-agent-v1
```

### Step 2 — Create Python virtual environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Configure API keys
```bash
cp .env.example .env
# Open .env in any text editor and add your API key
```

### Step 5 — Generate sample data & run
```bash
# Generate sample Excel files
python data/sample/generate_sample.py

# Run the agent
python main.py --files data/sample/sales_data.xlsx

# Open dashboard in browser
# Output saved to: output/dashboard.html
```

---

## 🔑 API Key Setup

You only need ONE of these:

| Provider | Where to Get Key | Free Tier |
|----------|-----------------|-----------|
| Anthropic (Claude) | console.anthropic.com | Yes ($5 free) |
| OpenAI (GPT-4) | platform.openai.com | Yes ($5 free) |
| Google (Gemini) | makersuite.google.com | Yes (generous) |
| GitHub Copilot | github.com/settings/tokens | Need subscription |
| None | — | Always works (rule-based) |

Edit your `.env` file:
```env
AI_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

---

## 📊 Using Your Own Excel Files

Your Excel files need these columns (names are flexible — agent auto-detects):

### File 1: Pipeline (Salesforce export)
```
Deal Name | Client | Value | Stage | Close Date | Owner | Probability
```

### File 2: Closed Won/Loss (Salesforce export)
```
Deal Name | Client | Value | Outcome | Close Date | Owner | Loss Reason
```

### File 3: Monthly Actuals (Finance team)
```
Month | Revenue | Cost | Gross Margin | GM%
```

### File 4: BE Targets (Manual Excel)
```
Month | BE Revenue | BE Cost | BE GM
```

Run with multiple files:
```bash
python main.py \
  --files data/pipeline.xlsx \
          data/closed.xlsx \
          data/actuals.xlsx \
          data/be_targets.xlsx \
  --provider anthropic \
  --output output/my_dashboard.html
```

---

## ⚙️ Configuration (config.yaml)

Key settings you can change:
```yaml
dashboard:
  title: "My Company KPI Dashboard"
  theme: dark        # dark | light
  currency: INR      # INR | USD | EUR | GBP

kpis:
  gm_healthy_threshold: 35      # GM% below this = warning
  pipeline_coverage_min: 3.0    # Pipeline/Revenue ratio minimum
  win_rate_benchmark: 40        # Win rate below this = concern

risk:
  high_threshold: 0.6           # Risk score above this = HIGH
  medium_threshold: 0.3         # Risk score above this = MEDIUM
```

---

## 🎨 Customization

See `CUSTOMIZATION.md` for full guide. Quick reference:

| What to Change | Where |
|---------------|-------|
| Dashboard colors | `templates/dashboard.html` → CSS variables |
| KPI cards | `templates/dashboard.html` → `.kpi-grid` section |
| Chart types | `ui/dashboard.py` → `build_charts()` |
| Risk rules | `core/risk_engine.py` → `RISK_RULES` dict |
| AI prompt | `core/insight_engine.py` → `EXECUTIVE_PROMPT` |
| Email template | `ui/report.py` → `build_email()` |
| New KPI | `core/kpi_calculator.py` → add to `calculate_all()` |

---

## 🗺️ Roadmap

- **Wireframe 1** (current) — Core KPI dashboard + executive summary
- **Wireframe 2** — Power BI integration + real-time data
- **Wireframe 3** — Multi-company benchmarking
- **Wireframe 4** — Predictive forecasting + scenario planning

---

## 📜 License

MIT — free to use, modify, and distribute.
