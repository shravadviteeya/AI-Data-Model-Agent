"""
Sample data generator — creates realistic Excel files for testing.
Run: python data/sample/generate_sample.py
"""

import pandas as pd
import numpy as np
from pathlib import Path


def generate(output_dir: str = "data/sample") -> list:
    """Generate all sample Excel files. Returns list of file paths."""
    np.random.seed(42)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    files = []

    # ── File 1: Sales data (combined) ─────────────────────────
    months = [
        'Jan-2025','Feb-2025','Mar-2025','Apr-2025','May-2025',
        'Jun-2025','Jul-2025','Aug-2025','Sep-2025','Oct-2025',
        'Nov-2025','Dec-2025','Jan-2026','Feb-2026','Mar-2026'
    ]
    regions = ['North','South','East','West','Central']
    products = ['Product A','Product B','Product C','Product D','Product E']
    owners = [
        'Raj Kumar','Priya Sharma','Amit Singh','Neha Verma',
        'Vikram Patel','Sunita Joshi','Deepak Gupta','Anita Rao'
    ]

    rows = []
    for _ in range(300):
        month = np.random.choice(months)
        region = np.random.choice(regions)
        product = np.random.choice(products)
        owner = np.random.choice(owners)
        revenue = np.random.randint(50000, 800000)
        cost = revenue * np.random.uniform(0.45, 0.70)
        gm = revenue - cost
        gm_pct = gm / revenue * 100
        deals = np.random.randint(1, 15)
        be_revenue = revenue * np.random.uniform(0.88, 1.18)
        pipeline = revenue * np.random.uniform(2.2, 4.8)
        win_rate = np.random.uniform(28, 65)
        rows.append({
            'Month': month,
            'Region': region,
            'Product': product,
            'Sales_Owner': owner,
            'Revenue': round(revenue),
            'Cost': round(cost),
            'Gross_Margin': round(gm),
            'GM_Pct': round(gm_pct, 2),
            'Deals_Closed': deals,
            'BE_Revenue': round(be_revenue),
            'Pipeline_Value': round(pipeline),
            'Win_Rate': round(win_rate, 1)
        })

    df = pd.DataFrame(rows)
    path1 = out / "sales_data.xlsx"
    df.to_excel(path1, index=False)
    files.append(str(path1))
    print(f"Created: {path1} ({len(df)} rows)")

    # ── File 2: Pipeline (Salesforce style) ───────────────────
    stages = [
        'Prospecting', 'Qualification', 'Proposal',
        'Negotiation', 'Closing'
    ]
    pipeline_rows = []
    for i in range(80):
        revenue = np.random.randint(100000, 2000000)
        stage = np.random.choice(stages)
        prob = {'Prospecting': 10, 'Qualification': 25,
                'Proposal': 50, 'Negotiation': 75, 'Closing': 90}[stage]
        pipeline_rows.append({
            'Opportunity_Name': f"Deal-{1000+i}",
            'Account_Name': f"Client {chr(65+i%26)}{i//26+1}",
            'Amount': revenue,
            'Stage': stage,
            'Probability': prob + np.random.randint(-5, 5),
            'Close_Date': pd.Timestamp('2026-04-01') +
                          pd.Timedelta(days=int(np.random.randint(0, 90))),
            'Owner': np.random.choice(owners),
            'Region': np.random.choice(regions)
        })
    path2 = out / "pipeline.xlsx"
    pd.DataFrame(pipeline_rows).to_excel(path2, index=False)
    files.append(str(path2))
    print(f"Created: {path2} (80 opportunities)")

    # ── File 3: Closed Won/Loss ────────────────────────────────
    outcomes = ['Closed Won'] * 7 + ['Closed Lost'] * 3
    loss_reasons = [
        'Price too high', 'Competitor', 'No budget',
        'No decision', 'Feature gap'
    ]
    closed_rows = []
    for i in range(120):
        outcome = np.random.choice(outcomes)
        closed_rows.append({
            'Opportunity_Name': f"CL-{2000+i}",
            'Account_Name': f"Client {chr(65+i%26)}",
            'Amount': np.random.randint(80000, 1500000),
            'Stage': outcome,
            'Close_Date': pd.Timestamp('2025-01-01') +
                          pd.Timedelta(days=int(np.random.randint(0, 365))),
            'Owner': np.random.choice(owners),
            'Loss_Reason': (np.random.choice(loss_reasons)
                           if outcome == 'Closed Lost' else ''),
            'Region': np.random.choice(regions)
        })
    path3 = out / "closed_deals.xlsx"
    pd.DataFrame(closed_rows).to_excel(path3, index=False)
    files.append(str(path3))
    print(f"Created: {path3} (120 closed deals)")

    print(f"\nAll sample files in: {out.absolute()}")
    return files


if __name__ == "__main__":
    generate()
