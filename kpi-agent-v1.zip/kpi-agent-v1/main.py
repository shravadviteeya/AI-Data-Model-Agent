"""
╔══════════════════════════════════════════════════════════════╗
║   KPI Intelligence Agent — Wireframe 1                      ║
║   LangChain + Excel + AI → Dashboard + Executive Report     ║
╚══════════════════════════════════════════════════════════════╝

Usage:
    python main.py                                    # Use sample data
    python main.py --files sales.xlsx                 # Single file
    python main.py --files a.xlsx b.xlsx c.xlsx       # Multiple files
    python main.py --files a.xlsx --provider claude   # Choose AI
    python main.py --ui                               # Launch web UI
    python main.py --schedule                         # Run on schedule
"""

import os
import sys
import json
import webbrowser
import click
import yaml
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from loguru import logger
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

load_dotenv()

console = Console()

# ── Logger setup ──────────────────────────────────────────────
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | "
           "<level>{level: <8}</level> | {message}",
    level="INFO"
)
logger.add(
    "output/agent.log",
    rotation="1 MB",
    level="DEBUG",
    catch=True
)


def load_config() -> dict:
    """Load configuration from config.yaml"""
    config_path = Path("config.yaml")
    if config_path.exists():
        with open(config_path) as f:
            return yaml.safe_load(f)
    return {}


def run_agent(
    file_paths: list,
    provider: str = "auto",
    output_dir: str = "./output",
    open_browser: bool = True
) -> dict:
    """
    Run the complete KPI agent pipeline.

    Steps:
      1. Load & validate Excel files
      2. Calculate all KPIs
      3. Run AI analysis
      4. Score risks
      5. Generate insights & recommendations
      6. Build interactive dashboard
      7. Build executive report
      8. Save all outputs
    """
    config = load_config()
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    console.print(Panel(
        "[bold green]KPI Intelligence Agent[/bold green]\n"
        f"[dim]Wireframe 1 · {datetime.now().strftime('%d %b %Y %H:%M')}[/dim]",
        expand=False
    ))

    # ── Step 1: Load Excel files ──────────────────────────────
    logger.info("Step 1/7 — Loading Excel files...")
    from core.excel_loader import ExcelLoader
    loader = ExcelLoader(config)
    data = loader.load_files(file_paths)
    logger.success(
        f"Loaded {sum(len(df) for df in data.values())} "
        f"total rows from {len(data)} table(s)"
    )

    # ── Step 2: Calculate KPIs ────────────────────────────────
    logger.info("Step 2/7 — Calculating KPIs...")
    from core.kpi_calculator import KPICalculator
    calc = KPICalculator(config)
    kpis = calc.calculate_all(data)
    logger.success(
        f"Revenue: {kpis.get('total_revenue_fmt','N/A')} | "
        f"GM%: {kpis.get('avg_gm_pct','N/A')}% | "
        f"Win Rate: {kpis.get('avg_win_rate','N/A')}%"
    )

    # ── Step 3: AI Analysis ───────────────────────────────────
    logger.info(f"Step 3/7 — AI analysis ({provider})...")
    from agents.base_agent import AgentFactory
    agent = AgentFactory.create(provider)
    logger.info(f"Using: {agent.name}")
    ai_analysis = agent.analyze_schema(
        {k: v.get('columns', []) for k, v in data.items()
         if isinstance(v, dict)}
    )

    # ── Step 4: Score Risks ───────────────────────────────────
    logger.info("Step 4/7 — Scoring risks...")
    from core.risk_engine import RiskEngine
    risk_engine = RiskEngine(config)
    risks = risk_engine.score_all(kpis, data)
    logger.success(
        f"Found {len([r for r in risks if r['severity']=='HIGH'])} "
        f"high risks, {len([r for r in risks if r['severity']=='MEDIUM'])} medium"
    )

    # ── Step 5: Generate Insights ─────────────────────────────
    logger.info("Step 5/7 — Generating insights...")
    from core.insight_engine import InsightEngine
    insight_engine = InsightEngine(config)
    insights = insight_engine.generate(kpis, risks, agent)
    logger.success(f"Generated {len(insights)} insights")

    # ── Step 6: Build Dashboard ───────────────────────────────
    logger.info("Step 6/7 — Building dashboard...")
    from ui.dashboard import DashboardBuilder
    builder = DashboardBuilder(config)
    dashboard_html = builder.build(kpis, risks, insights, data)
    dash_file = out_path / config.get(
        'output', {}).get('dashboard_filename', 'dashboard.html')
    dash_file.write_text(dashboard_html, encoding='utf-8')
    logger.success(f"Dashboard saved: {dash_file}")

    # ── Step 7: Build Executive Report ───────────────────────
    logger.info("Step 7/7 — Building executive report...")
    from ui.report import ReportBuilder
    report_builder = ReportBuilder(config)
    report_html = report_builder.build(kpis, risks, insights)
    report_file = out_path / config.get(
        'output', {}).get('report_filename', 'executive_report.html')
    report_file.write_text(report_html, encoding='utf-8')
    logger.success(f"Report saved: {report_file}")

    # ── Save JSON ─────────────────────────────────────────────
    result = {
        "metadata": {
            "generated_at": datetime.now().isoformat(),
            "provider": provider,
            "files": file_paths,
            "agent": agent.name
        },
        "kpis": {k: v for k, v in kpis.items()
                 if not isinstance(v, list)},
        "risks": risks,
        "insights": insights
    }
    json_file = out_path / "kpi_data.json"
    json_file.write_text(
        json.dumps(result, indent=2, default=str),
        encoding='utf-8'
    )

    # ── Summary table ─────────────────────────────────────────
    table = Table(title="Output Files", show_header=True)
    table.add_column("File", style="cyan")
    table.add_column("Size", style="green")
    table.add_column("Description")
    for f in [dash_file, report_file, json_file]:
        if f.exists():
            size = f"{f.stat().st_size / 1024:.1f} KB"
            desc = {
                'dashboard.html': 'Interactive KPI Dashboard',
                'executive_report.html': 'Executive Summary + Risks',
                'kpi_data.json': 'Raw KPI data (JSON)'
            }.get(f.name, f.name)
            table.add_row(str(f), size, desc)
    console.print(table)

    # ── Open browser ──────────────────────────────────────────
    cfg_open = config.get('output', {}).get('open_browser', True)
    if open_browser and cfg_open:
        webbrowser.open(f"file://{dash_file.absolute()}")
        logger.info("Opening dashboard in browser...")

    console.print(
        Panel(
            f"[bold green]Done![/bold green] "
            f"Dashboard: [cyan]{dash_file}[/cyan]",
            expand=False
        )
    )
    return result


@click.command()
@click.option(
    '--files', '-f', multiple=True,
    help='Excel file paths (can specify multiple)'
)
@click.option(
    '--provider', '-p',
    default='auto',
    type=click.Choice([
        'auto', 'anthropic', 'openai', 'gemini', 'copilot'
    ]),
    help='AI provider to use'
)
@click.option(
    '--output', '-o',
    default='./output',
    help='Output directory'
)
@click.option(
    '--no-browser',
    is_flag=True,
    default=False,
    help='Do not open browser after run'
)
@click.option(
    '--ui',
    is_flag=True,
    default=False,
    help='Launch Streamlit web UI'
)
@click.option(
    '--schedule',
    is_flag=True,
    default=False,
    help='Run on schedule (from config.yaml)'
)
@click.option(
    '--sample',
    is_flag=True,
    default=False,
    help='Generate and use sample data'
)
def main(files, provider, output, no_browser, ui, schedule, sample):
    """KPI Intelligence Agent — Wireframe 1"""

    if ui:
        logger.info("Launching Streamlit UI...")
        os.system("streamlit run ui/streamlit_app.py")
        return

    if schedule:
        import schedule as sched
        import time
        config = load_config()
        freq = config.get('report', {}).get('frequency', 'weekly')
        send_time = config.get('report', {}).get('send_time', '08:00')
        if freq == 'daily':
            sched.every().day.at(send_time).do(
                lambda: run_agent(list(files), provider, output))
        elif freq == 'weekly':
            sched.every().monday.at(send_time).do(
                lambda: run_agent(list(files), provider, output))
        logger.info(f"Scheduled: {freq} at {send_time}")
        while True:
            sched.run_pending()
            time.sleep(60)
        return

    if sample or not files:
        logger.info("Generating sample data...")
        from data.sample.generate_sample import generate
        file_paths = generate()
        logger.success(f"Sample files created: {file_paths}")
    else:
        file_paths = list(files)
        for fp in file_paths:
            if not Path(fp).exists():
                logger.error(f"File not found: {fp}")
                sys.exit(1)

    run_agent(
        file_paths,
        provider=provider,
        output_dir=output,
        open_browser=not no_browser
    )


if __name__ == "__main__":
    main()
