"""Unit tests for KPI Agent — Wireframe 1"""

import sys
import pytest
import pandas as pd
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestExcelLoader:
    def setup_method(self):
        from core.excel_loader import ExcelLoader
        self.loader = ExcelLoader({
            'column_aliases': {
                'revenue': ['revenue', 'rev', 'sales'],
                'month': ['month', 'date']
            }
        })

    def test_clean_columns(self):
        df = pd.DataFrame({'First Name': [1], 'Revenue/Sales': [2]})
        cleaned = self.loader._clean(df)
        assert 'first_name' in cleaned.columns
        assert 'revenue_sales' in cleaned.columns

    def test_remap_columns(self):
        df = pd.DataFrame({'rev': [100, 200], 'date': ['Jan', 'Feb']})
        df.columns = [c.lower() for c in df.columns]
        remapped = self.loader._remap_columns(df)
        assert 'revenue' in remapped.columns

    def test_profile_output(self):
        df = pd.DataFrame({'revenue': [100, 200, 300]})
        result = self.loader._profile('test', df)
        assert result['rows'] == 3
        assert len(result['columns']) == 1
        assert result['columns'][0]['name'] == 'revenue'


class TestKPICalculator:
    def setup_method(self):
        from core.kpi_calculator import KPICalculator
        self.calc = KPICalculator({
            'dashboard': {'currency_symbol': '₹'},
            'column_aliases': {},
            'kpis': {
                'gm_healthy_threshold': 35,
                'gm_critical_threshold': 25,
                'pipeline_coverage_min': 3.0,
                'pipeline_coverage_warn': 2.5,
                'win_rate_benchmark': 40,
                'win_rate_good': 50,
                'be_achievement_warn': 95,
                'be_achievement_critical': 90,
                'health_score_green': 75,
                'health_score_amber': 50,
            }
        })

    def _make_data(self):
        df = pd.DataFrame({
            'revenue': [100000, 200000, 150000],
            'cost': [60000, 120000, 90000],
            'gross_margin': [40000, 80000, 60000],
            'gm_pct': [40.0, 40.0, 40.0],
            'be_revenue': [110000, 190000, 160000],
            'deals_closed': [5, 8, 6],
            'win_rate': [45.0, 42.0, 48.0],
        })
        return {'main': {'df': df, 'rows': 3, 'columns': []}}

    def test_revenue_totals(self):
        data = self._make_data()
        kpis = self.calc.calculate_all(data)
        assert kpis['total_revenue'] == 450000
        assert kpis['total_gm'] == 180000

    def test_gm_pct(self):
        data = self._make_data()
        kpis = self.calc.calculate_all(data)
        assert kpis['avg_gm_pct'] == 40.0

    def test_health_score_range(self):
        data = self._make_data()
        kpis = self.calc.calculate_all(data)
        assert 0 <= kpis['health_score'] <= 100

    def test_format_kpis(self):
        data = self._make_data()
        kpis = self.calc.calculate_all(data)
        assert 'total_revenue_fmt' in kpis
        assert '₹' in kpis['total_revenue_fmt']


class TestRiskEngine:
    def setup_method(self):
        from core.risk_engine import RiskEngine
        self.engine = RiskEngine({
            'kpis': {'gm_healthy_threshold': 35,
                     'pipeline_coverage_min': 3.0},
            'risk': {'high_threshold': 0.6, 'medium_threshold': 0.35}
        })

    def test_risk_severity_high(self):
        kpis = {
            'revenue_vs_be_pct': 85,  # 15% below = high risk
            'pipeline_coverage': 1.5,
            'avg_gm_pct': 40,
            'by_sales_owner': [{'rev_share': 30}],
            'by_product': [{'rev_share': 50}, {'rev_share': 10}],
        }
        risks = self.engine.score_all(kpis, {})
        sev_map = {r['id']: r['severity'] for r in risks}
        assert sev_map.get('budget_shortfall') == 'HIGH'

    def test_risk_output_fields(self):
        kpis = {
            'revenue_vs_be_pct': 97,
            'pipeline_coverage': 2.8,
            'avg_gm_pct': 42,
            'by_sales_owner': [{'rev_share': 17}],
            'by_product': [{'rev_share': 22}, {'rev_share': 15}],
            'total_revenue': 12500000,
        }
        risks = self.engine.score_all(kpis, {})
        for r in risks:
            assert 'name' in r
            assert 'severity' in r
            assert r['severity'] in ('HIGH', 'MEDIUM', 'LOW')
            assert 0 <= r['score'] <= 1


class TestFallbackAgent:
    def setup_method(self):
        from agents.base_agent import FallbackAgent
        self.agent = FallbackAgent()

    def test_always_available(self):
        assert self.agent.is_available() is True

    def test_analyze_schema(self):
        result = self.agent.analyze_schema({
            'sales': [{'name': 'id'}, {'name': 'revenue'}]
        })
        assert 'primary_keys' in result
        assert result['primary_keys'].get('sales') == 'id'

    def test_detect_relationships(self):
        tables = [
            {'name': 'orders',
             'columns': [{'name': 'customer_id'}]},
            {'name': 'customers',
             'columns': [{'name': 'id'}]},
        ]
        rels = self.agent.detect_relationships(tables)
        assert isinstance(rels, list)

    def test_generate_description(self):
        desc = self.agent.generate_description({
            'name': 'revenue',
            'table_name': 'sales'
        })
        assert isinstance(desc, str)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
