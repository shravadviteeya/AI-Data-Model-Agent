# 🏗️ Architecture — KPI Intelligence Agent (Wireframe 1)

---

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    KPI INTELLIGENCE AGENT                       │
│                       Wireframe 1                               │
├─────────────┬───────────────────────────┬───────────────────────┤
│  INPUT      │      PROCESSING           │   OUTPUT              │
├─────────────┼───────────────────────────┼───────────────────────┤
│ Excel files │  ExcelLoader              │ dashboard.html        │
│ .xlsx/.xls  │    → KPICalculator        │ executive_report.html │
│ (1-4 files) │    → RiskEngine           │ kpi_data.json         │
│             │    → InsightEngine        │ agent.log             │
│             │    → AgentFactory (AI)    │                       │
│             │  DashboardBuilder         │                       │
│             │  ReportBuilder            │                       │
└─────────────┴───────────────────────────┴───────────────────────┘
```

---

## Data Flow

```
1. main.py
   │
   ├── ExcelLoader.load_files()
   │     ├── Read all .xlsx sheets
   │     ├── Clean column names
   │     ├── Remap aliases → canonical names
   │     └── Profile each column (dtype, nulls, sample)
   │
   ├── KPICalculator.calculate_all()
   │     ├── _revenue_kpis()    → total_revenue, total_gm, avg_gm_pct...
   │     ├── _trend_kpis()      → monthly_trend[], avg_mom_growth...
   │     ├── _dimensional_kpis()→ by_region[], by_product[], by_owner[]
   │     ├── _pipeline_kpis()   → by_stage[]
   │     └── _health_score()    → 0-100 composite score
   │
   ├── AgentFactory.create(provider)
   │     ├── AnthropicAgent  (if ANTHROPIC_API_KEY set)
   │     ├── OpenAIAgent     (if OPENAI_API_KEY set)
   │     ├── CopilotAgent    (if GITHUB_TOKEN set)
   │     └── FallbackAgent   (always available)
   │
   ├── RiskEngine.score_all()
   │     ├── budget_shortfall   risk score
   │     ├── pipeline_thin      risk score
   │     ├── key_person         risk score
   │     ├── product_underperform risk score
   │     └── margin_pressure    risk score
   │
   ├── InsightEngine.generate()
   │     ├── Try AI provider → parse [S]/[C]/[R] format
   │     └── Fallback → rule_based_insights()
   │
   ├── DashboardBuilder.build()
   │     ├── Prepare JS chart data
   │     ├── Render KPI cards
   │     ├── Build insight pills
   │     ├── Build risk rows
   │     └── Build owner leaderboard
   │
   └── ReportBuilder.build()
         ├── KPI strip table
         ├── Findings section
         ├── Risk register table
         └── Recommendations table
```

---

## Agent Providers

| Provider | Class | Key Env Var | Model |
|----------|-------|-------------|-------|
| Anthropic | AnthropicAgent | ANTHROPIC_API_KEY | claude-sonnet-4-5 |
| OpenAI | OpenAIAgent | OPENAI_API_KEY | gpt-4o |
| GitHub Copilot | CopilotAgent | GITHUB_TOKEN | gpt-4o |
| Rule-based | FallbackAgent | — | — |

Auto-selection order: Anthropic → OpenAI → Copilot → Fallback

---

## Adding a New Module

1. Create `core/my_module.py` with a class
2. Import and call in `main.py` → `run_agent()`
3. Pass output to `DashboardBuilder.build()`
4. Add placeholder `{{MY_DATA}}` in template
5. Replace in `ui/dashboard.py` → `_build()` replacements dict

---

## File Size Reference

| File | Purpose | Edit? |
|------|---------|-------|
| `config.yaml` | All thresholds & settings | ✅ Yes |
| `core/risk_engine.py` | Risk rules dict | ✅ Yes |
| `core/insight_engine.py` | AI prompt | ✅ Yes |
| `ui/dashboard.py` | Template bindings | Rarely |
| `templates/dashboard.html` | Visual design | ✅ Yes |
| `agents/base_agent.py` | AI provider logic | Rarely |
| `main.py` | Pipeline orchestration | Rarely |
