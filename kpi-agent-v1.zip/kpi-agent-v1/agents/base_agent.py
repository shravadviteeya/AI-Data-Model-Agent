"""
Agent base class and factory.
Add new AI providers by subclassing BaseAgent.
"""

import os
import json
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from loguru import logger


class BaseAgent(ABC):
    """Abstract base — all AI providers implement this interface."""

    name: str = "BaseAgent"

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if this provider's API key is configured."""

    @abstractmethod
    def analyze_schema(self, schema: Dict) -> Dict:
        """Analyse table schemas and suggest improvements."""

    @abstractmethod
    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        """Detect FK relationships between tables."""

    @abstractmethod
    def suggest_normalization(self, table: Dict) -> Dict:
        """Suggest normalisation steps for a table."""

    @abstractmethod
    def generate_description(self, column_info: Dict) -> str:
        """Generate a description — also used for free-form prompts."""

    def _schema_prompt(self, schema: Dict) -> str:
        parts = []
        for t, cols in schema.items():
            if isinstance(cols, list):
                col_str = ", ".join(
                    c.get('name', str(c)) if isinstance(c, dict)
                    else str(c)
                    for c in cols
                )
            else:
                col_str = str(cols)
            parts.append(f"Table '{t}': {col_str}")
        return (
            "You are a senior data architect. Analyse these tables and "
            "return JSON with keys: primary_keys, relationships, "
            "normalization, type_corrections, indexes.\n\n" +
            "\n".join(parts)
        )

    def _rel_prompt(self, tables: List[Dict]) -> str:
        rows = [
            f"- {t['name']}: {', '.join(c['name'] for c in t.get('columns',[]))}"
            for t in tables
        ]
        return (
            "Detect FK relationships between these tables. "
            "Return a JSON array with fields: parent_table, parent_column, "
            "child_table, child_column, relationship_type, confidence.\n\n"
            + "\n".join(rows)
        )


# ── Fallback (rule-based, no API key) ─────────────────────────

class FallbackAgent(BaseAgent):
    """Rule-based agent — always available, no API key required."""
    name = "FallbackAgent (rule-based)"

    def is_available(self) -> bool:
        return True

    def analyze_schema(self, schema: Dict) -> Dict:
        primary_keys = {}
        for table, cols in schema.items():
            if isinstance(cols, list):
                names = [
                    c.get('name', '') if isinstance(c, dict)
                    else str(c)
                    for c in cols
                ]
                pk = next((n for n in names if n.lower() in
                           ('id', f'{table}_id')), names[0] if names else None)
                primary_keys[table] = pk
        return {"primary_keys": primary_keys, "relationships": [],
                "normalization": {}, "type_corrections": {}, "indexes": {}}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        import re
        rels = []
        table_map = {t['name']: t for t in tables}
        for t in tables:
            for col in t.get('columns', []):
                m = re.search(r'^(.+?)(_id|_fk|_ref)$',
                              col.get('name', ''), re.I)
                if m:
                    base = m.group(1)
                    for tname in table_map:
                        if base.lower() in tname.lower() and tname != t['name']:
                            rels.append({
                                "parent_table": tname,
                                "parent_column": "id",
                                "child_table": t['name'],
                                "child_column": col['name'],
                                "relationship_type": "one-to-many",
                                "confidence": 0.7
                            })
        return rels

    def suggest_normalization(self, table: Dict) -> Dict:
        return {"issues": [], "suggestions": [], "split_tables": []}

    def generate_description(self, info: Dict) -> str:
        if 'prompt' in info:
            return ""  # Rule-based can't answer free prompts
        name = info.get('name', '')
        table = info.get('table_name', '')
        return f"Column {name} in {table}."


# ── Anthropic Claude ──────────────────────────────────────────

class AnthropicAgent(BaseAgent):
    name = "AnthropicAgent (Claude)"

    def __init__(self):
        self.client = None
        self.model = os.getenv('ANTHROPIC_MODEL',
                               'claude-sonnet-4-5')
        if self.is_available():
            try:
                import anthropic
                self.client = anthropic.Anthropic(
                    api_key=os.getenv('ANTHROPIC_API_KEY'))
            except ImportError:
                logger.warning("anthropic package not installed")

    def is_available(self) -> bool:
        return bool(os.getenv('ANTHROPIC_API_KEY'))

    def _call(self, prompt: str, max_tokens: int = 1500) -> str:
        if not self.client:
            return ""
        r = self.client.messages.create(
            model=self.model, max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}])
        return r.content[0].text

    def analyze_schema(self, schema: Dict) -> Dict:
        try:
            raw = self._call(self._schema_prompt(schema))
            s = raw.find('{'); e = raw.rfind('}') + 1
            return json.loads(raw[s:e])
        except Exception:
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        try:
            raw = self._call(self._rel_prompt(tables))
            s = raw.find('['); e = raw.rfind(']') + 1
            return json.loads(raw[s:e])
        except Exception:
            return []

    def suggest_normalization(self, table: Dict) -> Dict:
        return {}

    def generate_description(self, info: Dict) -> str:
        prompt = info.get('prompt') or (
            f"Describe column '{info.get('name')}' in table "
            f"'{info.get('table_name')}'. One sentence.")
        try:
            return self._call(prompt, max_tokens=300).strip()
        except Exception:
            return ""


# ── OpenAI GPT-4 ─────────────────────────────────────────────

class OpenAIAgent(BaseAgent):
    name = "OpenAIAgent (GPT-4)"

    def __init__(self):
        self.client = None
        self.model = os.getenv('OPENAI_MODEL', 'gpt-4o')
        if self.is_available():
            try:
                from openai import OpenAI
                self.client = OpenAI(
                    api_key=os.getenv('OPENAI_API_KEY'))
            except ImportError:
                logger.warning("openai package not installed")

    def is_available(self) -> bool:
        return bool(os.getenv('OPENAI_API_KEY'))

    def _call(self, prompt: str, max_tokens: int = 1500) -> str:
        if not self.client:
            return ""
        r = self.client.chat.completions.create(
            model=self.model, max_tokens=max_tokens,
            messages=[{"role": "system",
                       "content": "You are an expert data analyst."},
                      {"role": "user", "content": prompt}])
        return r.choices[0].message.content

    def analyze_schema(self, schema: Dict) -> Dict:
        try:
            return json.loads(self._call(self._schema_prompt(schema)))
        except Exception:
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        try:
            raw = json.loads(self._call(self._rel_prompt(tables)))
            return raw if isinstance(raw, list) else raw.get(
                'relationships', [])
        except Exception:
            return []

    def suggest_normalization(self, table: Dict) -> Dict:
        return {}

    def generate_description(self, info: Dict) -> str:
        prompt = info.get('prompt') or (
            f"Describe '{info.get('name')}' column. One sentence.")
        try:
            return self._call(prompt, max_tokens=300).strip()
        except Exception:
            return ""


# ── GitHub Copilot ────────────────────────────────────────────

class CopilotAgent(BaseAgent):
    name = "CopilotAgent (GitHub Models)"

    def __init__(self):
        self.client = None
        self.model = "gpt-4o"
        if self.is_available():
            try:
                from openai import OpenAI
                self.client = OpenAI(
                    api_key=os.getenv('GITHUB_TOKEN'),
                    base_url="https://models.inference.ai.azure.com")
            except ImportError:
                logger.warning("openai package not installed")

    def is_available(self) -> bool:
        return bool(os.getenv('GITHUB_TOKEN'))

    def _call(self, prompt: str, max_tokens: int = 1500) -> str:
        if not self.client:
            return ""
        r = self.client.chat.completions.create(
            model=self.model, max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}])
        return r.choices[0].message.content

    def analyze_schema(self, schema: Dict) -> Dict:
        try:
            raw = self._call(self._schema_prompt(schema))
            s = raw.find('{'); e = raw.rfind('}') + 1
            return json.loads(raw[s:e])
        except Exception:
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        return []

    def suggest_normalization(self, table: Dict) -> Dict:
        return {}

    def generate_description(self, info: Dict) -> str:
        prompt = info.get('prompt', f"Describe '{info.get('name')}'.")
        try:
            return self._call(prompt, max_tokens=300).strip()
        except Exception:
            return ""


# ── Factory ───────────────────────────────────────────────────

class AgentFactory:
    """Creates the right agent based on environment / preference."""

    PROVIDERS = {
        "anthropic": AnthropicAgent,
        "openai": OpenAIAgent,
        "copilot": CopilotAgent,
    }

    @staticmethod
    def create(provider: str = "auto") -> BaseAgent:
        if provider == "auto":
            for name, cls in AgentFactory.PROVIDERS.items():
                agent = cls()
                if agent.is_available():
                    logger.info(f"Auto-selected provider: {name}")
                    return agent
            logger.warning("No AI provider available — using rule-based")
            return FallbackAgent()

        cls = AgentFactory.PROVIDERS.get(provider)
        if not cls:
            logger.warning(f"Unknown provider '{provider}' — using fallback")
            return FallbackAgent()

        agent = cls()
        if not agent.is_available():
            logger.warning(
                f"{provider} API key not found — using fallback")
            return FallbackAgent()

        return agent
