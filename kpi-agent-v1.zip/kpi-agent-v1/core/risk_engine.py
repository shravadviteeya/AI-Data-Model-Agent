"""
Risk Engine — scores and categorises business risks from KPI data.
Add new risk rules to RISK_RULES dict below.
"""

from typing import Dict, List, Any
from loguru import logger


RISK_RULES = {
    "budget_shortfall": {
        "name": "Budget shortfall escalation",
        "detail_template": "{gap:.1f}% below BE — could widen if pipeline does not close",
        "category": "Revenue",
        "compute": lambda kpis, cfg: max(
            0, 100 - kpis.get('revenue_vs_be_pct', 100)) / 100,
        "impact_template": lambda kpis: (
            f"₹{abs(kpis.get('revenue_variance',0))/1e5:.0f}L exposure"),
    },
    "pipeline_thin": {
        "name": "Pipeline coverage below target",
        "detail_template": "{coverage:.1f}x coverage — below {target}x minimum",
        "category": "Pipeline",
        "compute": lambda kpis, cfg: max(
            0, cfg.get('kpis',{}).get('pipeline_coverage_min',3) -
            kpis.get('pipeline_coverage', 3)) / 3,
        "impact_template": lambda kpis: (
            f"₹{kpis.get('total_revenue',0)*0.05/1e5:.0f}L at risk"),
    },
    "key_person": {
        "name": "Key person revenue concentration",
        "detail_template": "Top performer holds >{pct:.0f}% of revenue",
        "category": "Talent",
        "compute": lambda kpis, cfg: (
            max(kpis.get('by_sales_owner',
                         [{'rev_share': 0}]),
                key=lambda x: x.get('rev_share', 0),
                default={'rev_share': 0}
            ).get('rev_share', 0) / 100
            if kpis.get('by_sales_owner') else 0
        ),
        "impact_template": lambda kpis: (
            "Revenue continuity risk"),
    },
    "product_underperform": {
        "name": "Product revenue concentration",
        "detail_template": "Weakest product at {pct:.1f}% share",
        "category": "Product",
        "compute": lambda kpis, cfg: max(
            0, 20 - min(
                [p.get('rev_share', 100)
                 for p in kpis.get('by_product', [{'rev_share': 100}])],
                default=100
            )) / 20,
        "impact_template": lambda kpis: "Product mix imbalance",
    },
    "margin_pressure": {
        "name": "Gross margin deterioration",
        "detail_template": "GM% at {gm:.1f}% — watch for compression",
        "category": "Finance",
        "compute": lambda kpis, cfg: max(
            0, cfg.get('kpis',{}).get('gm_healthy_threshold',35) -
            kpis.get('avg_gm_pct', 35)) / 35,
        "impact_template": lambda kpis: (
            f"₹{kpis.get('total_revenue',0)*0.02/1e5:.0f}L margin at risk"),
    },
}


class RiskEngine:
    """Scores risks based on KPI data."""

    HIGH_THRESH = 0.60
    MEDIUM_THRESH = 0.35

    def __init__(self, config: dict):
        self.cfg = config
        thresholds = config.get('risk', {})
        self.HIGH_THRESH = thresholds.get('high_threshold', 0.60)
        self.MEDIUM_THRESH = thresholds.get('medium_threshold', 0.35)

    def score_all(
        self, kpis: Dict[str, Any], data: Dict
    ) -> List[Dict[str, Any]]:
        """Score all risks and return sorted list."""
        risks = []
        for rule_id, rule in RISK_RULES.items():
            try:
                score = float(rule['compute'](kpis, self.cfg))
                score = max(0.0, min(1.0, score))
                severity = self._severity(score)
                likelihood_pct = round(score * 100)
                impact_str = rule['impact_template'](kpis)
                detail = self._format_detail(rule, kpis)
                risks.append({
                    "id": rule_id,
                    "name": rule["name"],
                    "detail": detail,
                    "category": rule.get("category", "General"),
                    "severity": severity,
                    "score": round(score, 3),
                    "likelihood_pct": likelihood_pct,
                    "impact": impact_str,
                    "likelihood_bar": likelihood_pct,
                    "impact_bar": min(100, int(score * 120)),
                })
            except Exception as e:
                logger.warning(f"Risk scoring failed for {rule_id}: {e}")

        risks.sort(key=lambda r: r['score'], reverse=True)
        return risks

    def _severity(self, score: float) -> str:
        if score >= self.HIGH_THRESH:
            return "HIGH"
        if score >= self.MEDIUM_THRESH:
            return "MEDIUM"
        return "LOW"

    def _format_detail(self, rule: dict, kpis: dict) -> str:
        tmpl = rule.get("detail_template", "")
        try:
            return tmpl.format(
                gap=round(100 - kpis.get('revenue_vs_be_pct', 100), 1),
                coverage=kpis.get('pipeline_coverage', 3),
                target=self.cfg.get('kpis', {}).get(
                    'pipeline_coverage_min', 3),
                pct=max(
                    [o.get('rev_share', 0)
                     for o in kpis.get('by_sales_owner', [])],
                    default=0
                ),
                gm=kpis.get('avg_gm_pct', 35),
            )
        except (KeyError, ValueError):
            return tmpl
