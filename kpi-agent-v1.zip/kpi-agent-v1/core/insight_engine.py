"""
Insight Engine — generates AI-powered executive insights.
Edit EXECUTIVE_PROMPT below to customise the analysis style.
"""

from typing import List, Dict, Any
from loguru import logger

# ── Customise this prompt to change AI analysis style ─────────
EXECUTIVE_PROMPT = """
You are a senior sales analytics consultant briefing C-suite executives.

Analyse this business performance data and generate exactly 6 insights:
- 2 strengths (things going well)
- 2 concerns (things to watch)
- 2 recommendations (specific actions)

Data:
Total Revenue: {total_revenue_fmt}
GM%: {avg_gm_pct}% (healthy = 35%+)
Win Rate: {avg_win_rate}% (benchmark = 40%)
Pipeline Coverage: {pipeline_coverage}x (target = 3x)
Revenue vs BE: {revenue_vs_be_pct}%
Health Score: {health_score}/100
Top Region: {top_region}
Top Performer: {top_performer}

Format each insight as one sentence. Be specific with numbers.
Start strengths with [S], concerns with [C], recommendations with [R].
"""

# ── Rule-based fallback (no API key needed) ────────────────────
def rule_based_insights(
    kpis: Dict[str, Any], risks: List[Dict]
) -> List[Dict[str, str]]:
    insights = []
    rvb = kpis.get('revenue_vs_be_pct', 100)
    gm = kpis.get('avg_gm_pct', 35)
    wr = kpis.get('avg_win_rate', 40)
    cov = kpis.get('pipeline_coverage', 3)
    variance = kpis.get('revenue_variance', 0)

    # Strengths
    if gm >= 35:
        insights.append({
            "type": "strength",
            "text": f"GM% of {gm}% is {gm-35:.1f} points above the "
                    f"35% healthy threshold — pricing discipline is strong."
        })
    if wr >= 40:
        insights.append({
            "type": "strength",
            "text": f"Win rate of {wr}% exceeds the 40% industry benchmark "
                    f"— the sales team is converting well-qualified pipeline."
        })
    by_region = kpis.get('by_region', [])
    if by_region:
        top = by_region[0]
        insights.append({
            "type": "strength",
            "text": f"{top.get('name','Top region')} leads with "
                    f"{top.get('rev_share',0):.1f}% revenue share and "
                    f"GM% of {top.get('gm_pct',0):.1f}% — "
                    f"a replicable model for other regions."
        })

    # Concerns
    if rvb < 100:
        insights.append({
            "type": "concern",
            "text": f"Revenue is {100-rvb:.1f}% below Budget Estimate "
                    f"(₹{abs(variance)/1e5:.0f}L gap) — "
                    f"requires pipeline acceleration before quarter-end."
        })
    if cov < 3:
        insights.append({
            "type": "concern",
            "text": f"Pipeline coverage at {cov:.1f}x is below the "
                    f"3x minimum — any deal slippage directly impacts "
                    f"the quarterly number."
        })

    by_product = kpis.get('by_product', [])
    if by_product and len(by_product) > 1:
        bottom = by_product[-1]
        insights.append({
            "type": "concern",
            "text": f"{bottom.get('name','Bottom product')} has the "
                    f"lowest revenue share at {bottom.get('rev_share',0):.1f}% "
                    f"— investigate pricing or seller enablement gaps."
        })

    # Recommendations
    if rvb < 100:
        insights.append({
            "type": "recommendation",
            "text": f"Launch a deal acceleration sprint: assign executive sponsors "
                    f"to top 10 open opportunities to close the "
                    f"₹{abs(variance)/1e5:.0f}L BE gap before quarter-end."
        })
    if cov < 3:
        insights.append({
            "type": "recommendation",
            "text": "Increase outbound prospecting by 40% for the next "
                    "60 days and set a pipeline coverage gate of 3.5x "
                    "before the next planning cycle."
        })

    return insights[:8]


class InsightEngine:
    """Generates insights from KPIs using AI or rule-based logic."""

    def __init__(self, config: dict):
        self.cfg = config

    def generate(
        self,
        kpis: Dict[str, Any],
        risks: List[Dict],
        agent
    ) -> List[Dict[str, str]]:
        """Generate insights — tries AI first, falls back to rules."""

        # Build top region/performer strings
        by_region = kpis.get('by_region', [{}])
        by_owner = kpis.get('by_sales_owner', [{}])
        top_region = by_region[0].get('name', 'N/A') if by_region else 'N/A'
        top_owner = by_owner[0].get('name', 'N/A') if by_owner else 'N/A'

        prompt = EXECUTIVE_PROMPT.format(
            total_revenue_fmt=kpis.get('total_revenue_fmt', 'N/A'),
            avg_gm_pct=kpis.get('avg_gm_pct', 'N/A'),
            avg_win_rate=kpis.get('avg_win_rate', 'N/A'),
            pipeline_coverage=kpis.get('pipeline_coverage', 'N/A'),
            revenue_vs_be_pct=kpis.get('revenue_vs_be_pct', 'N/A'),
            health_score=kpis.get('health_score', 'N/A'),
            top_region=top_region,
            top_performer=top_owner,
        )

        ai_cfg = self.cfg.get('ai', {})
        if ai_cfg.get('fallback_to_rules', True):
            try:
                raw = agent.generate_description({'prompt': prompt})
                if raw and len(raw) > 50:
                    return self._parse_ai_response(raw)
            except Exception as e:
                logger.warning(f"AI insight generation failed: {e}")

        logger.info("Using rule-based insight generation")
        return rule_based_insights(kpis, risks)

    def _parse_ai_response(
        self, text: str
    ) -> List[Dict[str, str]]:
        insights = []
        for line in text.strip().split('\n'):
            line = line.strip()
            if not line:
                continue
            if line.startswith('[S]'):
                insights.append({
                    "type": "strength",
                    "text": line[3:].strip()
                })
            elif line.startswith('[C]'):
                insights.append({
                    "type": "concern",
                    "text": line[3:].strip()
                })
            elif line.startswith('[R]'):
                insights.append({
                    "type": "recommendation",
                    "text": line[3:].strip()
                })
        return insights if insights else []
