"""
Excel Loader — reads and validates all input Excel files.
Auto-detects column names using aliases from config.yaml
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional
from loguru import logger


class ExcelLoader:
    """Loads and standardises Excel data for the KPI agent."""

    def __init__(self, config: dict):
        self.config = config
        self.aliases = config.get('column_aliases', {})

    def load_files(self, file_paths: List[str]) -> Dict[str, dict]:
        """Load all Excel files and return standardised table data."""
        tables = {}
        for fp in file_paths:
            path = Path(fp)
            if not path.exists():
                logger.warning(f"File not found: {fp}")
                continue
            try:
                xl = pd.ExcelFile(fp)
                for sheet in xl.sheet_names:
                    df = pd.read_excel(fp, sheet_name=sheet)
                    if df.empty:
                        continue
                    name = self._table_name(path, sheet, len(xl.sheet_names))
                    df = self._clean(df)
                    df = self._remap_columns(df)
                    tables[name] = self._profile(name, df)
                    logger.info(
                        f"  Loaded '{name}': "
                        f"{len(df)} rows × {len(df.columns)} cols"
                    )
            except Exception as e:
                logger.error(f"Failed to load {fp}: {e}")
        return tables

    def _table_name(self, path: Path, sheet: str, n_sheets: int) -> str:
        stem = path.stem.lower().replace(' ', '_')
        if n_sheets == 1:
            return stem
        return f"{stem}_{sheet.lower().replace(' ','_')}"

    def _clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df.columns = [
            str(c).strip().lower()
                  .replace(' ', '_')
                  .replace('-', '_')
                  .replace('/', '_')
            for c in df.columns
        ]
        df = df.dropna(how='all').reset_index(drop=True)
        return df

    def _remap_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Map any recognised alias to the canonical column name."""
        rename = {}
        for canonical, aliases in self.aliases.items():
            for col in df.columns:
                if col in aliases and col != canonical:
                    rename[col] = canonical
        return df.rename(columns=rename)

    def _profile(self, name: str, df: pd.DataFrame) -> dict:
        cols = []
        for col in df.columns:
            series = df[col]
            dtype = self._detect_type(series)
            cols.append({
                'name': col,
                'dtype': dtype,
                'null_pct': round(series.isnull().mean(), 4),
                'unique': int(series.nunique()),
                'sample': series.dropna().head(3).tolist()
            })
        return {
            'df': df,
            'name': name,
            'rows': len(df),
            'columns': cols
        }

    def _detect_type(self, series: pd.Series) -> str:
        if pd.api.types.is_bool_dtype(series):
            return 'boolean'
        if pd.api.types.is_integer_dtype(series):
            return 'integer'
        if pd.api.types.is_float_dtype(series):
            return 'float'
        if pd.api.types.is_datetime64_any_dtype(series):
            return 'datetime'
        non_null = series.dropna()
        if len(non_null) > 0:
            try:
                pd.to_numeric(non_null.head(20))
                return 'numeric'
            except (ValueError, TypeError):
                pass
            try:
                pd.to_datetime(non_null.head(10))
                return 'date_string'
            except (ValueError, TypeError):
                pass
        return 'string'
