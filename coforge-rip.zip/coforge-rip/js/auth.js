/* ═══════════════════════════════════════════════════════════
   js/auth.js  — Authentication Module
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */
const Auth = (() => {
  const ROLE_MAP = {
    sales:    { name: 'Sarah Leader',  role: 'Sales Leader',    initials: 'SL' },
    delivery: { name: 'Alex Delivery', role: 'Delivery Leader', initials: 'AD' },
    admin:    { name: 'Admin User',    role: 'Executive',       initials: 'AU' },
  };
  let _currentUser = null;

  function login() {
    const role  = document.getElementById('login-role').value;
    const email = document.getElementById('login-email').value;
    if (!email) { UI.toast('Please enter your email address.', '⚠️'); return; }
    const userData = ROLE_MAP[role] || ROLE_MAP['sales'];
    _currentUser = { ...userData, email, role };
    document.getElementById('user-avatar').textContent = _currentUser.initials;
    document.getElementById('user-name').textContent   = _currentUser.name;
    document.getElementById('user-role').textContent   = _currentUser.role;
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('app').style.display        = 'block';
    Nav.goto('dashboard');
    UI.toast(`Welcome back, ${_currentUser.name.split(' ')[0]}! 👋`, '🎉');
  }

  function logout() {
    _currentUser = null;
    document.getElementById('app').style.display        = 'none';
    document.getElementById('login-page').style.display = 'flex';
    document.getElementById('login-email').value = 'sarah.leader@coforge.com';
    document.getElementById('login-pass').value  = 'password';
    document.getElementById('login-role').value  = 'sales';
  }

  function getCurrentUser() { return _currentUser; }

  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('login-pass').addEventListener('keydown', e => {
      if (e.key === 'Enter') login();
    });
  });

  return { login, logout, getCurrentUser };
})();
