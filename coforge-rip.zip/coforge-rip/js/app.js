/* ═══════════════════════════════════════════════════════════
   js/app.js  — Application Bootstrap
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* Populate settings profile from auth on load */
  const avatarEl = document.getElementById('settings-avatar');
  const nameEl   = document.getElementById('settings-name');
  const emailEl  = document.getElementById('settings-email');

  /* Patch profile avatar when user logs in */
  const origLogin = Auth.login.bind(Auth);

  /* Wire Enter key on login email field too */
  const emailField = document.getElementById('login-email');
  if (emailField) {
    emailField.addEventListener('keydown', e => {
      if (e.key === 'Enter') Auth.login();
    });
  }

  /* Ensure app starts hidden */
  document.getElementById('app').style.display = 'none';

  console.log(`%c${CONFIG.APP_NAME} v${CONFIG.APP_VERSION}`, 'color:#00A99D;font-size:14px;font-weight:bold');
  console.log('%cTo enable AI features, add your Anthropic API key to js/config.js', 'color:#718096;font-size:12px');
});
