/* ═══════════════════════════════════════════════════════════
   js/nav.js  — Navigation Module
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */
const Nav = (() => {
  let _current = 'dashboard';

  function goto(page) {
    // Hide all sections
    document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    // Find or render page
    const pageId = 'page-' + page;
    let section = document.getElementById(pageId);
    if (!section) {
      section = document.createElement('div');
      section.id = pageId;
      section.className = 'page-section';
      document.getElementById('main-content').appendChild(section);
      // Render content from page module
      _renderPage(page, section);
    }
    section.classList.add('active');

    // Highlight nav item
    const navItem = document.querySelector(`[data-page="${page}"]`);
    if (navItem) navItem.classList.add('active');

    // Update header title
    const title = CONFIG.PAGE_TITLES[page] || page;
    document.getElementById('header-title').textContent = title;

    _current = page;
  }

  function _renderPage(page, container) {
    const renderers = {
      'dashboard':             Pages.Dashboard.render,
      'ai-insights':           Pages.AIInsights.render,
      'pipeline':              Pages.Pipeline.render,
      'closed-deals':          Pages.ClosedDeals.render,
      'employees':             Pages.Employees.render,
      'bench':                 Pages.Bench.render,
      'demand':                Pages.Demand.render,
      'fulfillment':           Pages.Fulfillment.render,
      'finance':               Pages.Finance.render,
      'best-estimates':        Pages.BestEstimates.render,
      'be-analytics':          Pages.BEAnalytics.render,
      'settings-general':      Pages.Settings.renderGeneral,
      'settings-users':        Pages.Settings.renderUsers,
      'settings-datasources':  Pages.Settings.renderDataSources,
      'settings-notifications':Pages.Settings.renderNotifications,
      'settings-audit':        Pages.Settings.renderAudit,
    };
    const fn = renderers[page];
    if (fn) container.innerHTML = fn();
    else container.innerHTML = `<div style="padding:40px;color:var(--coforge-muted)">Page "${page}" coming soon.</div>`;
  }

  function getCurrent() { return _current; }

  /* Wire up sidebar nav clicks */
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
      item.addEventListener('click', () => goto(item.dataset.page));
    });
  });

  return { goto, getCurrent };
})();

/* Namespace for page modules */
const Pages = {};
