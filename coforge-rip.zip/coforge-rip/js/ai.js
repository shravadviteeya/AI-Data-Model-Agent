/* ═══════════════════════════════════════════════════════════
   js/ai.js  — AI Agent Module (Claude API)
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */
const AI = (() => {

  const SYSTEM_PROMPT = `You are an AI Revenue Intelligence Agent for Coforge, an IT services company.
You have access to live data from:
- Salesforce: 124 open opportunities worth $87.4M pipeline; 38 closed deals worth $42.2M in FY2026
- RDG (Resource Deployment Group): 12,840 employees; 156 on bench; 284 open demands; 1,284 fulfilled YTD (82% rate)
- Finance Tracker: FY2026 actuals by account (American Airlines $3.52M YTD; Mosaic Insurance $2.74M; Tokio Marine $1.69M)
- Best Estimates: 34 submitted, 18 pending for March 2026; overall accuracy 84.2%

Key alerts:
- 7 Insurance NA deals stagnant 30+ days ($4.2M at risk of slippage)
- 18 Sales/Delivery Leaders haven't submitted March BE (deadline Mar 31)
- 4 bench resources match open demand profiles
- BFS EMEA and TTH NA show largest gap vs BE

Answer concisely and practically. Use bullet points. Include specific numbers. Keep under 180 words.`;

  async function ask(inputEl) {
    const question = inputEl.value.trim();
    if (!question) return;

    // Find sibling loading and response elements
    const promptDiv  = inputEl.closest('.ai-prompt');
    const panel      = inputEl.closest('.ai-panel');
    const loadingEl  = panel.querySelector('.ai-loading');
    const responseEl = panel.querySelector('.ai-response');

    loadingEl.classList.add('visible');
    responseEl.classList.remove('visible');
    inputEl.value = '';

    try {
      let text;

      if (CONFIG.AI.API_KEY) {
        // Real API call
        const res = await fetch(CONFIG.AI.ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: CONFIG.AI.MODEL,
            max_tokens: CONFIG.AI.MAX_TOKENS,
            system: SYSTEM_PROMPT,
            messages: [{ role: 'user', content: question }],
          }),
        });
        const data = await res.json();
        text = data.content?.map(b => b.text || '').join('') || _fallback(question);
      } else {
        // Demo fallback (no API key)
        await _sleep(1200 + Math.random() * 600);
        text = _fallback(question);
      }

      loadingEl.classList.remove('visible');
      responseEl.textContent = text;
      responseEl.classList.add('visible');

    } catch (err) {
      console.error('AI error:', err);
      loadingEl.classList.remove('visible');
      responseEl.textContent = _fallback(question);
      responseEl.classList.add('visible');
    }
  }

  function _fallback(question) {
    const q = question.toLowerCase();
    if (q.includes('bench') || q.includes('resource') || q.includes('placement'))
      return CONFIG.AI_FALLBACKS.bench;
    if (q.includes('forecast') || q.includes('gap') || q.includes('q4') || q.includes('quarter'))
      return CONFIG.AI_FALLBACKS.forecast;
    return CONFIG.AI_FALLBACKS.default;
  }

  function _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  /* Build a standard AI panel HTML string */
  function panelHTML({ id, title = 'AI Revenue Agent', subtitle = 'Powered by Claude · Real-time analysis', insights = [] }) {
    const insightHTML = insights.map(ins =>
      `<div class="ai-insight">
        <div class="ai-insight-icon">${ins.icon}</div>
        <div class="ai-insight-text">${ins.text}</div>
      </div>`
    ).join('');

    return `
      <div class="ai-panel">
        <div class="ai-header">
          <div class="ai-icon">🤖</div>
          <div>
            <div class="ai-title">${title}</div>
            <div class="ai-sub">${subtitle}</div>
          </div>
        </div>
        ${insightHTML}
        <div class="ai-prompt">
          <input class="ai-input" id="${id}-input" placeholder="Ask AI: pipeline risk, bench match, revenue gaps…">
          <button class="ai-send" onclick="AI.ask(document.getElementById('${id}-input'))">➤</button>
        </div>
        <div class="ai-loading">
          <div class="pulse-dots"><span></span><span></span><span></span></div>
          Analyzing data…
        </div>
        <div class="ai-response"></div>
      </div>`;
  }

  return { ask, panelHTML };
})();
