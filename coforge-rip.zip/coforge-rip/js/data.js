/* ═══════════════════════════════════════════════════════════
   js/data.js  — Mock/Demo Data Store
   Replace these datasets with real API calls in production.
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */
const Data = {

  pipeline: [
    { id:1, account:'Acenda',             opp:'AI - Pricing back book',          bu:'ANZ BFS',       owner:'Suman Mukherji',   stage:'1 Prospect',   type:'New NN',   prob:5,  acv:'$493K', tcv:'$500K',  close:'Jun-26', ai:true  },
    { id:2, account:'American Airlines',  opp:'Data Analytics Platform',         bu:'TTH NA',        owner:'James Carter',     stage:'3 Proposal',   type:'EN',       prob:40, acv:'$1.2M', tcv:'$2.4M',  close:'Apr-26', ai:false },
    { id:3, account:'Mosaic Insurance',   opp:'L&A Core Transformation',         bu:'Insurance NA',  owner:'Ravi Sharma',      stage:'4 Negotiation',type:'New NN',   prob:75, acv:'$3.1M', tcv:'$8.6M',  close:'May-26', ai:true  },
    { id:4, account:'Lloyd\'s London',    opp:'Process Automation Suite',        bu:'Insurance EU',  owner:'Helen Park',       stage:'2 Qualified',  type:'New NN',   prob:25, acv:'$780K', tcv:'$1.6M',  close:'Jul-26', ai:true  },
    { id:5, account:'Commonwealth Bank',  opp:'Digital Modernization Wave 2',    bu:'ANZ BFS',       owner:'Suman Mukherji',   stage:'3 Proposal',   type:'EN',       prob:55, acv:'$2.4M', tcv:'$5.8M',  close:'Jun-26', ai:true  },
    { id:6, account:'United Airlines',    opp:'Revenue Management System',       bu:'TTH NA',        owner:'Karen Liu',        stage:'4 Negotiation',type:'EN',       prob:70, acv:'$1.8M', tcv:'$4.2M',  close:'Apr-26', ai:false },
    { id:7, account:'Aviva Insurance',    opp:'Claims Process Automation',       bu:'Insurance EU',  owner:'Helen Park',       stage:'1 Prospect',   type:'New NN',   prob:10, acv:'$620K', tcv:'$1.4M',  close:'Aug-26', ai:true  },
    { id:8, account:'HSBC',              opp:'Trade Finance Digitisation',       bu:'BFS EMEA',      owner:'David Mills',      stage:'2 Qualified',  type:'New NN',   prob:20, acv:'$1.4M', tcv:'$3.2M',  close:'Sep-26', ai:true  },
  ],

  closedDeals: [
    { id:1, account:'Signet Group Services', opp:'Signet D&A Phase 1',              bu:'US Retail',    type:'EN', closed:'23-Mar-26', acv:'$366K', tcv:'$366K', margin:'29.4%', ai:false, terms:'T&M'    },
    { id:2, account:'Tokio Marine HCC',      opp:'HCC International D&A SEZ4',      bu:'Insurance EU', type:'NN', closed:'15-Feb-26', acv:'$1.2M', tcv:'$2.8M', margin:'31.8%', ai:false, terms:'T&M'    },
    { id:3, account:'Pacific Airlines',      opp:'Reservation System Upgrade',      bu:'TTH NA',       type:'EN', closed:'08-Feb-26', acv:'$890K', tcv:'$1.8M', margin:'24.2%', ai:true,  terms:'Fixed'  },
    { id:4, account:'Global Life Insurers',  opp:'L&A Policy Admin Modernization',  bu:'Insurance NA', type:'NN', closed:'31-Jan-26', acv:'$4.2M', tcv:'$9.6M', margin:'34.1%', ai:true,  terms:'Fixed'  },
    { id:5, account:'ANZ Banking',           opp:'Core Banking Data Platform',      bu:'ANZ BFS',      type:'NN', closed:'20-Jan-26', acv:'$2.1M', tcv:'$5.4M', margin:'28.9%', ai:true,  terms:'T&M'    },
  ],

  bench: [
    { empId:'49155', name:'Anirudh Singh',   pool:'Data Pool',      band:'5.2', skill:'Data Architect',      ageing:'0-15 Days', status:'Available',  from:'AITS-MVP',       positioned:'Chhub'       },
    { empId:'28341', name:'Kavita Sharma',   pool:'Engineering Pool',band:'4.1', skill:'Java Developer',      ageing:'15-30 Days',status:'WIP',         from:'Retail Platform',positioned:'Insurance NA' },
    { empId:'61234', name:'Rohan Verma',     pool:'Data Pool',      band:'5.1', skill:'Data Engineer',        ageing:'>30 Days',  status:'Available',  from:'D&A Project',    positioned:'—'           },
    { empId:'72891', name:'Meena Krishnan',  pool:'Insurance Pool', band:'3.2', skill:'Business Analyst',     ageing:'15-30 Days',status:'WIP',         from:'TMHCC',          positioned:'ANZ BFS'     },
    { empId:'83120', name:'Sameer Gupta',    pool:'Cloud Pool',     band:'4.2', skill:'AWS Architect',        ageing:'>30 Days',  status:'Available',  from:'Cloud Project',  positioned:'—'           },
    { empId:'91042', name:'Pooja Nair',      pool:'Data Pool',      band:'3.1', skill:'Python Developer',     ageing:'0-15 Days', status:'Positioned', from:'Analytics Hub',  positioned:'United Airlines'},
  ],

  demand: [
    { reqId:'259055', customer:'Tokio Marine HCC', ibu:'Insurance EU', band:3, skills:'Python, MSBI',   location:'Gr. Noida', ageing:'0-15d',  status:'Pending TA', reqBy:'05-Mar-26', month:"May'26"  },
    { reqId:'276105', customer:'SEI & LPL',         ibu:'BFS NA',       band:4, skills:'Business Analysis',location:'India',   ageing:'0-15d',  status:'Internal',   reqBy:'01-Mar-26', month:"Mar'26"  },
    { reqId:'248921', customer:'American Airlines',  ibu:'TTH NA',       band:5, skills:'Data Engg, AWS', location:'Onsite',   ageing:'>30d',   status:'At Risk',    reqBy:'28-Jan-26', month:"Feb'26"  },
    { reqId:'261892', customer:'Mosaic Insurance',   ibu:'Insurance NA', band:4, skills:'Snowflake, Python',location:'Gr. Noida',ageing:'15-30d', status:'WIP',       reqBy:'15-Mar-26', month:"Apr'26"  },
    { reqId:'284011', customer:'Commonwealth Bank',  ibu:'ANZ BFS',      band:5, skills:'Java, Microservices',location:'India', ageing:'0-15d',  status:'Pending TA', reqBy:'20-Mar-26', month:"Apr'26"  },
  ],

  fulfillment: [
    { reqId:'276105', emp:'Harmohan Sahoo', customer:'SEI & LPL',        ibu:'BFS NA',       month:"Mar'26", joined:'11-Mar-26', days:1,  fftp:-9, type:'Internal', skills:'Business Analysis' },
    { reqId:'248210', emp:'Priya Nair',     customer:'American Airlines', ibu:'TTH NA',       month:"Feb'26", joined:'28-Feb-26', days:32, fftp:12, type:'Market',   skills:'Data Engineering'  },
    { reqId:'261120', emp:'Anil Desai',     customer:'Mosaic Insurance',  ibu:'Insurance NA', month:"Jan'26", joined:'15-Jan-26', days:18, fftp:3,  type:'Internal', skills:'Snowflake'         },
    { reqId:'270001', emp:'Sara Thomas',    customer:'HSBC',              ibu:'BFS EMEA',     month:"Mar'26", joined:'05-Mar-26', days:5,  fftp:-5, type:'Market',   skills:'Trade Finance'     },
  ],

  finance: [
    { geo:'US',   ibu:'Travel NA',   customer:'American Airlines',  q1:'$1.08M', q2:'$927K',  q3:'$1.01M', ytd:'$3.52M', gm1:'31.5%', gm2:'25.4%', gm3:'34.6%', gmClass1:'green', gmClass2:'orange', gmClass3:'green' },
    { geo:'US',   ibu:'Insurance NA',customer:'Mosaic Insurance',   q1:'$891K',  q2:'$748K',  q3:'$820K',  ytd:'$2.74M', gm1:'22.4%', gm2:'21.8%', gm3:'22.1%', gmClass1:'orange',gmClass2:'orange', gmClass3:'orange'},
    { geo:'EMEA', ibu:'Insurance EU',customer:'Tokio Marine HCC',   q1:'$512K',  q2:'$489K',  q3:'$534K',  ytd:'$1.69M', gm1:'32.1%', gm2:'31.4%', gm3:'31.8%', gmClass1:'green', gmClass2:'green',  gmClass3:'green' },
    { geo:'ANZ',  ibu:'ANZ BFS',     customer:'Commonwealth Bank',  q1:'$640K',  q2:'$710K',  q3:'$780K',  ytd:'$2.13M', gm1:'28.2%', gm2:'29.1%', gm3:'30.4%', gmClass1:'teal',  gmClass2:'teal',   gmClass3:'green' },
    { geo:'US',   ibu:'TTH NA',      customer:'Hawaiian Airlines',  q1:'$642K',  q2:'$571K',  q3:'$612K',  ytd:'$2.03M', gm1:'27.9%', gm2:'27.1%', gm3:'28.6%', gmClass1:'teal',  gmClass2:'teal',   gmClass3:'teal'  },
  ],

  beSubmissions: [
    { leader:'Sarah Leader',   role:'Sales',    accounts:3, submitted:12, onTime:11, accuracy:92, lastSubmit:'28-Feb-26', status:'due'     },
    { leader:'Ravi Sharma',    role:'Sales',    accounts:4, submitted:11, onTime:9,  accuracy:88, lastSubmit:'28-Feb-26', status:'due'     },
    { leader:'Helen Park',     role:'Delivery', accounts:2, submitted:12, onTime:12, accuracy:95, lastSubmit:'01-Mar-26', status:'done'    },
    { leader:'James Carter',   role:'Sales',    accounts:3, submitted:9,  onTime:6,  accuracy:71, lastSubmit:'20-Jan-26', status:'overdue' },
    { leader:'Karen Liu',      role:'Delivery', accounts:2, submitted:10, onTime:10, accuracy:89, lastSubmit:'28-Feb-26', status:'due'     },
    { leader:'Suman Mukherji', role:'Sales',    accounts:5, submitted:12, onTime:8,  accuracy:82, lastSubmit:'28-Feb-26', status:'due'     },
  ],

  auditLog: [
    { icon:'🎯', action:'Best Estimate Submitted',             meta:'Helen Park · American Airlines · March 2026',   time:'01-Mar-26 09:14' },
    { icon:'🔄', action:'Salesforce Sync Completed',           meta:'124 opportunities updated · 0 errors',           time:'01-Mar-26 08:00' },
    { icon:'💰', action:'Finance Tracker Uploaded',            meta:'DATA2.xlsx · FY2026 Q3 actuals added',           time:'01-Mar-26 07:45' },
    { icon:'🔌', action:'RDG Data Sync Completed',             meta:'Employee, Bench, Demand refreshed',             time:'24-Feb-26 09:00' },
    { icon:'👤', action:'New User Added',                      meta:'Karen Liu · Delivery Leader · TTH NA',           time:'20-Feb-26 14:22' },
    { icon:'⚙️', action:'Notification Settings Updated',       meta:'Admin User · BE deadline reminder enabled',      time:'15-Feb-26 11:05' },
    { icon:'🚨', action:'Deal Slippage Alert Triggered',       meta:'Insurance NA · 7 deals stagnant >30 days',       time:'14-Feb-26 08:30' },
    { icon:'🎯', action:'Best Estimate Submitted (Late)',       meta:'James Carter · United Airlines · February 2026', time:'08-Feb-26 16:45' },
  ],
};
