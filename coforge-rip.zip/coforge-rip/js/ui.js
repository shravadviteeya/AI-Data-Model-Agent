/* ═══════════════════════════════════════════════════════════
   js/ui.js  — UI Utilities (Toast, Modal, Sync)
   Coforge Revenue Intelligence Platform
═══════════════════════════════════════════════════════════ */
const UI = (() => {
  let _toastTimer = null;

  function toast(msg, icon = '✅') {
    const t   = document.getElementById('toast');
    const m   = document.getElementById('toast-msg');
    const ic  = document.getElementById('toast-icon');
    m.textContent  = msg;
    ic.textContent = icon;
    t.classList.add('show');
    if (_toastTimer) clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => t.classList.remove('show'), 3500);
  }

  function showModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('open');
  }

  function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('open');
  }

  function simulateSync(btn, sourceName) {
    btn.textContent = 'Syncing...';
    btn.disabled = true;
    btn.style.opacity = '0.7';
    setTimeout(() => {
      btn.textContent = '✓ Synced';
      btn.style.background = 'var(--green-grad)';
      btn.style.opacity = '1';
      toast(`${sourceName} data synced successfully!`, '🔄');
    }, 1600 + Math.random() * 600);
  }

  function progressBar(value, cls = 'progress-teal') {
    return `<div class="progress-bar"><div class="progress-fill ${cls}" style="width:${value}%"></div></div>`;
  }

  function badge(text, cls) {
    return `<span class="badge badge-${cls}">${text}</span>`;
  }

  /* Close modals on outside click */
  document.addEventListener('click', e => {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      if (e.target === m) m.classList.remove('open');
    });
  });

  /* Enter key in AI inputs */
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const focused = document.querySelector('.ai-input:focus');
      if (focused) AI.ask(focused);
    }
  });

  return { toast, showModal, closeModal, simulateSync, progressBar, badge };
})();
