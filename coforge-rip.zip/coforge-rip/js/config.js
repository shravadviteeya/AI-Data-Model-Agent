/* ═══════════════════════════════════════════════════════════
   js/config.js  — App Configuration & Constants
   Coforge Revenue Intelligence Platform
   
   ⚠️  PRODUCTION NOTE:
   Replace ANTHROPIC_API_KEY with your actual key, or better:
   proxy all AI calls through your own backend API to avoid
   exposing the key in client-side code.
═══════════════════════════════════════════════════════════ */

const CONFIG = {
  APP_NAME:    'Coforge Revenue Intelligence Platform',
  APP_VERSION: '1.0.0',
  FISCAL_YEAR: 'FY2026',
  CURRENT_PERIOD: 'March 2026',
  CURRENT_QUARTER: 'Q4 FY2026',

  /* ── AI / Claude ── */
  AI: {
    ENDPOINT: 'https://api.anthropic.com/v1/messages',
    MODEL:    'claude-sonnet-4-20250514',
    MAX_TOKENS: 600,
    /*
     * Set your Anthropic API key here for local/dev use.
     * For production: set to '' and implement a backend proxy at /api/ai
     * so the key is never exposed to the browser.
     */
    API_KEY: '',  // ← REPLACE with your key for local testing
  },

  /* ── Data Refresh Schedule ── */
  REFRESH: {
    SALESFORCE:  { label: 'Every Monday 08:00 AM',  type: 'weekly'  },
    RDG:         { label: 'Every Monday 09:00 AM',  type: 'weekly'  },
    FINANCE:     { label: '1st of each month',      type: 'monthly' },
    BE_DEADLINE: { label: 'Last day of each month', type: 'monthly' },
  },

  /* ── BE Submission ── */
  BE: {
    DEADLINE_DAY: 31,        // Day of month
    HIGH_ACCURACY_THRESHOLD: 85,   // % above which accuracy is "green"
    LOW_ACCURACY_THRESHOLD:  70,   // % below which accuracy is "red"
    EARLY_SUBMISSION_DAYS:   10,   // Days into month = "early"
  },

  /* ── Page Titles ── */
  PAGE_TITLES: {
    'dashboard':            'Executive Dashboard',
    'ai-insights':          'AI Agent Insights',
    'pipeline':             'Pipeline Tracker',
    'closed-deals':         'Closed Deals',
    'employees':            'Employee Master',
    'bench':                'Bench Data',
    'demand':               'Demand Data',
    'fulfillment':          'YTD Fulfillment',
    'finance':              'Finance Tracker',
    'best-estimates':       'Best Estimate Input',
    'be-analytics':         'BE Accuracy & Trends',
    'settings-general':     'Settings — General',
    'settings-users':       'Settings — User Management',
    'settings-datasources': 'Settings — Data Sources',
    'settings-notifications':'Settings — Notifications',
    'settings-audit':       'Settings — Audit Log',
  },

  /* ── Color Themes ── */
  THEMES: [
    { name: 'Coforge Teal', primary: '#00A99D', dark: '#1A2B3C' },
    { name: 'Ocean Blue',   primary: '#007BFF', dark: '#0D2137' },
    { name: 'Indigo',       primary: '#6610F2', dark: '#1A0B3C' },
    { name: 'Forest',       primary: '#28C76F', dark: '#0D2B1A' },
  ],

  /* ── Fallback AI Responses (used when API key not set) ── */
  AI_FALLBACKS: {
    default: `Based on my analysis across all connected data sources:

📊 Revenue Gap: FY2026 is tracking $8.4M below aggregate Best Estimate. Primary gap in BFS EMEA (-$3.2M) and TTH NA (-$2.8M).

🔄 Pipeline Risk: 7 deals totalling $4.2M in Insurance NA have been stagnant for 30+ days. Recommend urgent pipeline review.

👥 Bench Match: 4 D&A resources on bench match 3 open demand requests. Placing them saves ~$180K/month.

🎯 BE Accuracy: Leaders submitting before 10th show 23% higher accuracy. Current on-time rate is 65%.`,

    forecast: `📈 Q4 FY2026 Forecast Analysis:

Based on Salesforce pipeline and historical actuals:
• TTH NA — Pipeline $11.2M at 60% weighted → Expected Q4: $6.7M
• Insurance NA — $22.6M at 74% weighted → Expected Q4: $16.7M
• ANZ BFS — 55% weighted → Expected Q4: $8.1M

Total AI-Forecast Q4: $42.8M
Current Aggregate BE: $38.4M → Gap of $4.4M (potential upside)

Recommend Sales Leaders revise BE upward for accounts with 70%+ probability deals.`,

    bench: `👥 Bench–Demand Match Analysis:

4 critical matches found:
1. Anirudh Singh (Data Architect, 0-15d) → Demand #248921 (American Airlines, AWS+Data)
2. Kavita Sharma (Java Developer) → Digital Engineering demand in TTH NA
3. Meena Krishnan (BA, Insurance) → Demand #259055 (Tokio Marine HCC)
4. Rohan Verma (Data Engineer) → Open D&A demand in ANZ BFS

Cost impact: Placing these 4 saves ~$180K/month in bench costs.
Recommendation: RDG to initiate placement within 5 business days.`,
  },
};

/* Make config immutable */
Object.freeze(CONFIG);
Object.freeze(CONFIG.AI);
Object.freeze(CONFIG.REFRESH);
Object.freeze(CONFIG.BE);
