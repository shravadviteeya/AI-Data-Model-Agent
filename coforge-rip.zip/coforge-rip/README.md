# Coforge Revenue Intelligence Platform (RIP)

A full-featured, industry-level pipeline monitoring and Best Estimate management system for Coforge's Sales and Delivery leadership teams.

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/YOUR-ORG/coforge-rip.git
cd coforge-rip
```

### 2. Open in browser (no build step required)
```bash
# Option A — Just open the file
open index.html

# Option B — Serve locally (recommended)
npx serve .
# or
python3 -m http.server 8080
```

Visit `http://localhost:8080` and sign in with the demo credentials.

---

## 🔑 Enable AI Features

1. Open `js/config.js`
2. Set your Anthropic API key:
```js
API_KEY: 'sk-ant-api03-YOUR-KEY-HERE',
```

> ⚠️ **Production Security:** Never expose API keys in client-side code.  
> Route AI requests through a backend proxy (e.g. `/api/ai` on your server).  
> The `CONFIG.AI.ENDPOINT` can be changed to point to your proxy.

---

## 📁 Project Structure

```
coforge-rip/
├── index.html              # App shell, login page, modals
├── css/
│   ├── base.css            # CSS variables, reset, typography, animations
│   ├── layout.css          # Sidebar, header, main content shell, login
│   ├── components.css      # Cards, tables, badges, forms, AI panel, etc.
│   └── pages.css           # Page-specific overrides
├── js/
│   ├── config.js           # ⚙️  App config, API keys, constants — EDIT THIS
│   ├── auth.js             # Login / logout logic
│   ├── ui.js               # Toast, modals, sync helpers
│   ├── nav.js              # Navigation, page routing
│   ├── ai.js               # Claude API calls and AI panel builder
│   ├── data.js             # 📊 Mock data store — replace with real API calls
│   └── app.js              # Bootstrap / DOMContentLoaded
└── pages/
    ├── dashboard.js         # Executive Dashboard
    ├── ai-insights.js       # AI Agent Insights
    ├── pipeline.js          # Salesforce Pipeline Tracker
    ├── closed-deals.js      # Closed Deals
    ├── employees.js         # Employee Master (RDG)
    ├── bench.js             # Bench Data (RDG)
    ├── demand.js            # Demand Data (RDG)
    ├── fulfillment.js       # YTD Fulfillment (RDG)
    ├── finance.js           # Finance Tracker (DATA2.xlsx)
    ├── best-estimates.js    # BE Input Form (Sales + Delivery)
    ├── be-analytics.js      # BE Accuracy & Trends
    └── settings.js          # All Settings sub-pages
```

---

## 📊 Data Sources

| Source | Module | Refresh |
|--------|--------|---------|
| **Salesforce CRM** | Pipeline Tracker, Closed Deals | Weekly (Monday) |
| **RDG System** | Employee Master, Bench, Demand, Fulfillment | Weekly (Monday) |
| **Finance Team** | Finance Tracker (DATA2.xlsx) | Monthly (1st) |
| **Leaders** | Best Estimates | Monthly (by deadline) |

To connect real data sources, replace the mock objects in `js/data.js` with API calls to your backend.

---

## 🔌 Connecting Real Data

### Salesforce
Configure your Salesforce Connected App credentials in **Settings → Data Source Config**, or update `js/config.js` directly.

```js
// Example: fetch pipeline from your backend which queries Salesforce
async function fetchPipeline() {
  const res = await fetch('/api/salesforce/pipeline');
  return res.json();
}
```

### RDG System
Update the RDG API endpoint and key in **Settings → Data Source Config**.

### Finance Tracker
Upload DATA2.xlsx via **Settings → Data Source Config → Finance Tracker**. The platform expects:
- Sheet: `FINANCE TRACKER`
- Headers at row 7
- Columns: Geo, Cost Center, Customer, then monthly values (Apr25→Mar26) for Accrued Revenue, Direct Expenses, Gross Margin %

---

## 👥 User Roles

| Role | Access |
|------|--------|
| **Sales Leader** | View dashboards, submit Sales BE, view own accounts |
| **Delivery Leader** | View dashboards, submit Delivery BE, view resource data |
| **Admin / Executive** | Full access including User Management, Data Config, Audit Log |

---

## 🤖 AI Agent

The embedded AI agent uses **Claude claude-sonnet-4-20250514** (Anthropic) to:
- Analyse pipeline risk and deal slippage
- Match bench resources to open demands
- Identify revenue gaps between BE and actuals
- Generate forecast suggestions based on Salesforce data
- Answer free-text questions about any data in the platform

---

## 🛠️ Customisation

### Change Brand Colors
Edit the CSS variables in `css/base.css`:
```css
:root {
  --coforge-teal:  #00A99D;  /* Primary accent */
  --coforge-dark:  #1A2B3C;  /* Sidebar background */
  --coforge-accent:#FF6B35;  /* Orange accent */
}
```

### Add a New Page
1. Create `pages/my-page.js` with:
```js
Pages.MyPage = {
  render() { return `<div>...your HTML...</div>`; }
};
```
2. Add script tag in `index.html`
3. Add nav item in `index.html` with `data-page="my-page"`
4. Add title in `CONFIG.PAGE_TITLES` in `js/config.js`

### Add New Data
Add your data arrays to `js/data.js` and reference them in your page render functions.

---

## 📦 Deployment

### Static Hosting (Simplest)
Upload all files to any static host:
- **GitHub Pages** — push to `gh-pages` branch
- **Azure Static Web Apps** — connect GitHub repo
- **AWS S3 + CloudFront**
- **Netlify / Vercel** — drag-and-drop the folder

### Production Checklist
- [ ] Remove demo API key from `js/config.js`
- [ ] Set up backend proxy for Anthropic API calls
- [ ] Configure real Salesforce OAuth credentials
- [ ] Set up RDG API connection
- [ ] Configure SharePoint sync for Finance Tracker
- [ ] Enable authentication (Azure AD / Okta / SAML recommended)
- [ ] Set up HTTPS

---

## 📄 License
Internal use — Coforge Ltd. All rights reserved.

---

## 📞 Support
For platform issues contact the Internal Tools team.  
For AI/Claude API issues see [docs.anthropic.com](https://docs.anthropic.com).
