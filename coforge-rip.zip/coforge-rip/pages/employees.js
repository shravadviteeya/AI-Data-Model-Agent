/* pages/employees.js */
Pages.Employees = {
  render() {
    return `
<div class="section-header">
  <div><div class="section-title">Employee Master</div><div class="section-sub">Resource data from RDG · Updated weekly</div></div>
  <span class="data-source ds-rdg">RDG · Weekly</span>
</div>
<div class="metric-grid">
  <div class="metric-card teal"><div class="metric-label">Total Employees</div><div class="metric-value">12,840</div></div>
  <div class="metric-card green"><div class="metric-label">Billed Resources</div><div class="metric-value">11,204</div><div class="metric-sub">87.3% utilization</div></div>
  <div class="metric-card orange"><div class="metric-label">Unbilled / Bench</div><div class="metric-value">1,636</div></div>
  <div class="metric-card blue"><div class="metric-label">Onsite Headcount</div><div class="metric-value">1,842</div><div class="metric-sub">14.3% of total</div></div>
</div>
<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Distribution by Practice</div></div>
    <div class="card-body">
      ${[['Data & Analytics (D&A)',3241,25.2,'teal'],['Digital Engineering',2890,22.5,'blue'],['Insurance BPS',2410,18.8,'orange'],['Cloud & Infra',1820,14.2,'green'],['QE & Testing',980,7.6,'red'],['AI / ML',700,5.4,'purple']].map(([name,n,pct,cls])=>`
      <div style="margin-bottom:13px"><div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px"><span><strong>${name}</strong></span><span>${n.toLocaleString()} (${pct}%)</span></div>
      <div class="progress-bar"><div class="progress-fill progress-${cls}" style="width:${pct*3}%"></div></div></div>`).join('')}
    </div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Sample Employee Records</div>
      <div class="filter-row">
        <select class="filter-select"><option>All Status</option><option>Billed</option><option>Bench</option></select>
        <select class="filter-select"><option>All IBUs</option><option>Insurance NA</option><option>BFS NA</option><option>TTH NA</option></select>
      </div>
    </div>
    <div class="card-body no-pad"><table>
      <thead><tr><th>Emp ID</th><th>Name</th><th>Role</th><th>IBU</th><th>Practice</th><th>Status</th><th>Location</th></tr></thead>
      <tbody>
        <tr><td>3615</td><td>Sandeep Tibrewal</td><td>Lead Architect</td><td>Insurance NA</td><td>D&A</td><td><span class="badge badge-green">Billed</span></td><td>Gr. Noida</td></tr>
        <tr><td>49155</td><td>Anirudh Singh</td><td>Data Architect</td><td>D&A Pool</td><td>D&A</td><td><span class="badge badge-orange">Bench</span></td><td>Gr. Noida</td></tr>
        <tr><td>13542</td><td>Priya Mehta</td><td>Sr. Developer</td><td>BFS NA</td><td>D&A</td><td><span class="badge badge-green">Billed</span></td><td>Hyderabad</td></tr>
        <tr><td>28341</td><td>Kavita Sharma</td><td>Java Developer</td><td>Engineering</td><td>DE</td><td><span class="badge badge-orange">Bench</span></td><td>Pune</td></tr>
        <tr><td>72891</td><td>Meena Krishnan</td><td>Business Analyst</td><td>Insurance EU</td><td>BPS</td><td><span class="badge badge-orange">Bench</span></td><td>Gr. Noida</td></tr>
        <tr><td>91042</td><td>Pooja Nair</td><td>Python Developer</td><td>TTH NA</td><td>D&A</td><td><span class="badge badge-green">Billed</span></td><td>Bangalore</td></tr>
      </tbody>
    </table></div>
  </div>
</div>`;
  }
};
