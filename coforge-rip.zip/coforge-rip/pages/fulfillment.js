/* pages/fulfillment.js */
Pages.Fulfillment = {
  render() {
    const rows = Data.fulfillment.map(f => `
      <tr><td>${f.reqId}</td><td><strong>${f.emp}</strong></td><td>${f.customer}</td><td>${f.ibu}</td>
      <td>${f.month}</td><td>${f.joined}</td>
      <td><span class="badge badge-${f.days<=7?'green':f.days<=21?'yellow':'orange'}">${f.days} day${f.days!==1?'s':''}</span></td>
      <td>${f.fftp}</td><td><span class="badge badge-${f.type==='Internal'?'blue':'teal'}">${f.type}</span></td>
      <td style="font-size:12px">${f.skills}</td></tr>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">YTD Fulfillment Data</div><div class="section-sub">Resource fulfillment tracking · RDG · FY2026 Year to Date</div></div>
  <span class="data-source ds-rdg">RDG · Weekly</span>
</div>
<div class="metric-grid">
  <div class="metric-card green"><div class="metric-label">YTD Fulfilled</div><div class="metric-value">1,284</div></div>
  <div class="metric-card teal"><div class="metric-label">Fulfillment Rate</div><div class="metric-value">82%</div><div class="metric-sub">Target: 90%</div></div>
  <div class="metric-card orange"><div class="metric-label">Avg Fulfil Days</div><div class="metric-value">18.4d</div></div>
  <div class="metric-card blue"><div class="metric-label">Market Hires</div><div class="metric-value">384</div><div class="metric-sub">30% of total</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Fulfillment Records (YTD)</div></div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table><thead><tr><th>Request ID</th><th>Employee</th><th>Customer</th><th>IBU</th><th>Month</th><th>Joining Date</th><th>Fulfilment Days</th><th>FFTP</th><th>Type</th><th>Skills</th></tr></thead>
    <tbody>${rows}</tbody></table>
  </div></div>
</div>`;
  }
};
