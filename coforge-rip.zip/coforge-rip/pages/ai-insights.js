/* pages/ai-insights.js */
Pages.AIInsights = {
  render() {
    return `
<div class="section-header">
  <div><div class="section-title">AI Agent Insights</div><div class="section-sub">Intelligent analysis across all connected data sources · Powered by Claude</div></div>
</div>
<div class="grid-2">
  ${AI.panelHTML({ id:'ai-main', title:'Revenue Intelligence Agent', subtitle:'Analyzes pipeline, actuals, BE accuracy & resource data', insights:[
    { icon:'🚨', text:'<strong>Deal Slippage Risk:</strong> 7 Insurance NA opps ($4.2M) not moved stage in 30+ days. Recommend immediate sales review.' },
    { icon:'💡', text:'<strong>Revenue Gap:</strong> FY2026 actuals are $8.4M below March Best Estimate. Primary gap in BFS EMEA and TTH NA.' },
    { icon:'📊', text:'<strong>BE Accuracy:</strong> Leaders who submit BE before 10th of month show <strong>23% higher accuracy</strong> vs late submitters.' },
    { icon:'🏆', text:'<strong>Signet Retail deal ($365K)</strong> closed Q4 FY2026. Recommend cross-sell analysis for adjacent accounts.' },
    { icon:'⚡', text:'<strong>Bench Alert:</strong> 12 D&A resources on bench >30 days. 4 active demands match their profiles.' },
  ]})}
  <div style="display:flex;flex-direction:column;gap:18px">
    <div class="card">
      <div class="card-header"><div class="card-title">BE Submission Status — March 2026</div></div>
      <div class="card-body">
        <div style="display:flex;gap:24px;margin-bottom:16px;text-align:center">
          <div style="flex:1"><div style="font-size:32px;font-weight:700;color:var(--coforge-green);font-family:'DM Serif Display',serif">34</div><div style="font-size:12px;color:var(--coforge-muted)">Submitted</div></div>
          <div style="flex:1"><div style="font-size:32px;font-weight:700;color:var(--coforge-red);font-family:'DM Serif Display',serif">18</div><div style="font-size:12px;color:var(--coforge-muted)">Pending</div></div>
          <div style="flex:1"><div style="font-size:32px;font-weight:700;color:var(--coforge-yellow);font-family:'DM Serif Display',serif">65%</div><div style="font-size:12px;color:var(--coforge-muted)">Completion</div></div>
        </div>
        <div class="progress-bar" style="height:10px;margin-bottom:12px"><div class="progress-fill progress-teal" style="width:65%"></div></div>
        <div class="alert alert-warning"><div class="alert-icon">⚠️</div><div class="alert-text"><strong>18 leaders</strong> haven't submitted BE for March. Deadline: <strong>March 31, 2026.</strong></div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title">AI-Suggested Actions</div></div>
      <div class="card-body">
        <div class="action-item action-red"><span>🔴</span><div class="action-item-title">Escalate: 7 stale deals<div class="action-item-sub">Insurance NA · $4.2M at risk</div></div><button class="btn btn-outline btn-sm" onclick="Nav.goto('pipeline')">Review</button></div>
        <div class="action-item action-yellow"><span>🟡</span><div class="action-item-title">Place 4 bench resources<div class="action-item-sub">D&A profiles match open demands</div></div><button class="btn btn-outline btn-sm" onclick="Nav.goto('bench')">Match</button></div>
        <div class="action-item action-teal"><span>🟢</span><div class="action-item-title">Send BE reminders<div class="action-item-sub">18 leaders pending submission</div></div><button class="btn btn-outline btn-sm" onclick="UI.toast('Reminder emails sent to 18 leaders.','📧')">Notify</button></div>
      </div>
    </div>
  </div>
</div>`;
  }
};
