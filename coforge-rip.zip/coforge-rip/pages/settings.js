/* pages/settings.js — All Settings Sub-pages */
Pages.Settings = {

  /* ══════════════════════════════════════════
     GENERAL SETTINGS
  ══════════════════════════════════════════ */
  renderGeneral() {
    return `
<div class="section-header">
  <div><div class="section-title">Settings — General</div><div class="section-sub">Platform preferences, display options and profile management</div></div>
  <button class="btn btn-primary" onclick="UI.toast('All settings saved successfully!','✅')">Save Changes</button>
</div>

<!-- Profile -->
<div class="settings-card">
  <div class="settings-card-header"><div><h3>👤 My Profile</h3><p>Your account details and role configuration</p></div></div>
  <div class="profile-avatar-section">
    <div class="profile-avatar-big" id="settings-avatar">SL</div>
    <div class="profile-avatar-info">
      <h3 id="settings-name">Sarah Leader</h3>
      <p id="settings-email">sarah.leader@coforge.com</p>
      <div class="role-chip">Sales Leader</div>
    </div>
    <button class="btn btn-outline btn-sm" style="margin-left:auto" onclick="UI.toast('Profile photo upload coming soon.','🖼️')">Change Photo</button>
  </div>
  <div class="settings-card-body">
    <div class="form-row">
      <div class="form-group"><label>Full Name</label><input type="text" value="Sarah Leader"></div>
      <div class="form-group"><label>Email Address</label><input type="email" value="sarah.leader@coforge.com"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Job Title</label><input type="text" value="Sales Leader — TTH NA"></div>
      <div class="form-group"><label>Phone Number</label><input type="tel" placeholder="+91 98XXXXXXXX"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Business Unit</label>
        <select><option>TTH NA</option><option>ANZ BFS</option><option>Insurance NA</option><option>Insurance EU</option><option>US Geo Retail</option><option>BFS EMEA</option></select>
      </div>
      <div class="form-group"><label>Manager / Reporting To</label><input type="text" placeholder="Manager name"></div>
    </div>
  </div>
</div>

<!-- Password -->
<div class="settings-card">
  <div class="settings-card-header"><div><h3>🔐 Password & Security</h3><p>Update your login credentials</p></div></div>
  <div class="settings-card-body">
    <div class="form-row">
      <div class="form-group"><label>Current Password</label><input type="password" placeholder="••••••••"></div>
      <div class="form-group"><label>New Password</label><input type="password" placeholder="Min. 10 characters"></div>
      <div class="form-group"><label>Confirm New Password</label><input type="password" placeholder="Re-enter new password"></div>
    </div>
    <div class="form-submit"><button class="btn btn-outline" onclick="UI.toast('Password updated successfully!','🔐')">Update Password</button></div>
  </div>
</div>

<!-- Display Preferences -->
<div class="settings-card">
  <div class="settings-card-header"><div><h3>🎨 Display & Appearance</h3><p>Theme, language and layout preferences</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>Currency Display</h4><p>Default currency unit shown across all dashboards</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>USD ($)</option><option>GBP (£)</option><option>AUD (A$)</option><option>INR (₹)</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Number Format</h4><p>How large numbers are displayed</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>$1.2M (Millions)</option><option>$1,200K (Thousands)</option><option>$1,200,000 (Full)</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Fiscal Year Start</h4><p>Your organisation's fiscal year start month</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>April (FY Apr–Mar)</option><option>January (CY)</option><option>July</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Date Format</h4><p>How dates are displayed across the platform</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>DD-MMM-YY</option><option>MM/DD/YYYY</option><option>YYYY-MM-DD</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Compact Sidebar</h4><p>Show icons-only sidebar to maximise screen space</p></div>
      <div class="settings-row-control"><label class="toggle"><input type="checkbox"><span class="toggle-slider"></span></label></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Show AI Insights on Dashboard</h4><p>Display AI agent panel on executive dashboard</p></div>
      <div class="settings-row-control"><label class="toggle"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Brand Theme</h4><p>Primary colour accent for the platform</p></div>
      <div class="settings-row-control">
        <div class="color-swatches">
          ${CONFIG.THEMES.map((t,i) => `<div class="color-swatch ${i===0?'active':''}" style="background:${t.primary}" title="${t.name}" onclick="this.closest('.color-swatches').querySelectorAll('.color-swatch').forEach(s=>s.classList.remove('active'));this.classList.add('active');UI.toast('Theme changed to ${t.name}','🎨')"></div>`).join('')}
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Default Accounts -->
<div class="settings-card">
  <div class="settings-card-header"><div><h3>🎯 My Accounts (Default View)</h3><p>Accounts you manage — used to pre-filter dashboards and BE forms</p></div>
  <button class="btn btn-outline btn-sm" onclick="UI.toast('Account added. Refresh to see changes.','➕')">+ Add Account</button>
  </div>
  <div class="settings-card-body">
    <div class="table-wrap"><table>
      <thead><tr><th>Account Name</th><th>BU</th><th>Role</th><th>Since</th><th>Action</th></tr></thead>
      <tbody>
        <tr><td><strong>American Airlines</strong></td><td>TTH NA</td><td>Primary Owner</td><td>Apr 2023</td><td><button class="btn btn-danger btn-sm" onclick="UI.toast('Account removed from your list.','🗑️')">Remove</button></td></tr>
        <tr><td><strong>Hawaiian Airlines</strong></td><td>TTH NA</td><td>Primary Owner</td><td>Jan 2024</td><td><button class="btn btn-danger btn-sm" onclick="UI.toast('Account removed from your list.','🗑️')">Remove</button></td></tr>
        <tr><td><strong>United Airlines</strong></td><td>TTH NA</td><td>Primary Owner</td><td>Jul 2024</td><td><button class="btn btn-danger btn-sm" onclick="UI.toast('Account removed from your list.','🗑️')">Remove</button></td></tr>
      </tbody>
    </table></div>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     USER MANAGEMENT
  ══════════════════════════════════════════ */
  renderUsers() {
    const users = [
      { name:'Sarah Leader',   email:'sarah.leader@coforge.com',   role:'sales',    bu:'TTH NA',        status:'Active',  last:'Today' },
      { name:'Alex Delivery',  email:'alex.delivery@coforge.com',  role:'delivery', bu:'TTH NA',        status:'Active',  last:'Yesterday' },
      { name:'Ravi Sharma',    email:'ravi.sharma@coforge.com',    role:'sales',    bu:'Insurance NA',  status:'Active',  last:'28-Feb-26' },
      { name:'Helen Park',     email:'helen.park@coforge.com',     role:'delivery', bu:'Insurance EU',  status:'Active',  last:'01-Mar-26' },
      { name:'James Carter',   email:'james.carter@coforge.com',   role:'sales',    bu:'TTH NA',        status:'Warning', last:'20-Jan-26' },
      { name:'Karen Liu',      email:'karen.liu@coforge.com',      role:'delivery', bu:'TTH NA',        status:'Active',  last:'28-Feb-26' },
      { name:'Suman Mukherji', email:'suman.mukherji@coforge.com', role:'sales',    bu:'ANZ BFS',       status:'Active',  last:'28-Feb-26' },
      { name:'Admin User',     email:'admin@coforge.com',          role:'admin',    bu:'Corporate',     status:'Active',  last:'Today' },
    ];
    const roleLabel = { sales:'Sales Leader', delivery:'Delivery Leader', admin:'Admin / Executive' };
    const roleTag   = r => `<span class="user-role-tag role-${r}">${roleLabel[r]}</span>`;
    const rows = users.map(u => `
      <tr>
        <td><div style="display:flex;align-items:center;gap:10px">
          <div style="width:32px;height:32px;border-radius:7px;background:var(--teal-grad);display:flex;align-items:center;justify-content:center;color:#fff;font-size:11px;font-weight:700;flex-shrink:0">${u.name.split(' ').map(n=>n[0]).join('').slice(0,2)}</div>
          <div><div style="font-weight:600;font-size:13px">${u.name}</div><div style="font-size:11px;color:var(--coforge-muted)">${u.email}</div></div>
        </div></td>
        <td>${roleTag(u.role)}</td>
        <td>${u.bu}</td>
        <td><span class="badge badge-${u.status==='Active'?'green':'orange'}">${u.status}</span></td>
        <td style="font-size:12px;color:var(--coforge-muted)">${u.last}</td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="UI.toast('Edit user modal — coming soon.','✏️')" style="margin-right:6px">Edit</button>
          <button class="btn btn-danger btn-sm" onclick="UI.toast('User deactivated.','🚫')">Deactivate</button>
        </td>
      </tr>`).join('');

    return `
<div class="section-header">
  <div><div class="section-title">Settings — User Management</div><div class="section-sub">Manage Sales Leaders, Delivery Leaders and Admin access</div></div>
  <button class="btn btn-primary" onclick="UI.toast('Invite user dialog — coming soon.','👤')">+ Invite User</button>
</div>

<div class="metric-grid metric-grid-3">
  <div class="metric-card green"><div class="metric-label">Total Users</div><div class="metric-value">52</div><div class="metric-sub">Active platform users</div></div>
  <div class="metric-card teal"><div class="metric-label">Sales Leaders</div><div class="metric-value">34</div></div>
  <div class="metric-card blue"><div class="metric-label">Delivery Leaders</div><div class="metric-value">18</div></div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">All Users</div>
    <div class="filter-row">
      <select class="filter-select"><option>All Roles</option><option>Sales Leader</option><option>Delivery Leader</option><option>Admin</option></select>
      <select class="filter-select"><option>All BUs</option><option>TTH NA</option><option>ANZ BFS</option><option>Insurance NA</option><option>Insurance EU</option></select>
      <select class="filter-select"><option>All Status</option><option>Active</option><option>Inactive</option></select>
    </div>
  </div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Role</th><th>BU</th><th>Status</th><th>Last Active</th><th>Actions</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div></div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>🔑 Role Permissions</h3><p>What each role can see and do in the platform</p></div></div>
  <div class="settings-card-body">
    <div class="table-wrap"><table>
      <thead><tr><th>Feature</th><th>Sales Leader</th><th>Delivery Leader</th><th>Admin / Executive</th></tr></thead>
      <tbody>
        ${[
          ['View All Dashboards',         '✅','✅','✅'],
          ['Pipeline Tracker (Salesforce)','✅ Own BU','✅ Own BU','✅ All'],
          ['Finance Tracker',             '✅ Own Accounts','✅ Own Accounts','✅ All'],
          ['Resource / Bench Data',       '👁️ View Only','✅ Full','✅ Full'],
          ['Submit Sales BE',             '✅','❌','✅ Override'],
          ['Submit Delivery BE',          '❌','✅','✅ Override'],
          ['View BE Analytics',           '✅ Own','✅ Own','✅ All Leaders'],
          ['User Management',             '❌','❌','✅'],
          ['Data Source Config',          '❌','❌','✅'],
          ['Audit Log',                   '❌','❌','✅'],
        ].map(([f,...v])=>`<tr><td><strong>${f}</strong></td>${v.map(x=>`<td>${x}</td>`).join('')}</tr>`).join('')}
      </tbody>
    </table></div>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     DATA SOURCE CONFIG
  ══════════════════════════════════════════ */
  renderDataSources() {
    return `
<div class="section-header">
  <div><div class="section-title">Settings — Data Source Configuration</div><div class="section-sub">Configure connections to Salesforce, RDG systems and Finance</div></div>
  <button class="btn btn-primary" onclick="UI.toast('All data source settings saved!','🔌')">Save All</button>
</div>

<div class="alert alert-info"><div class="alert-icon">ℹ️</div><div class="alert-text"><strong>Production Note:</strong> In production, these credentials should be stored securely in your backend (e.g. Azure Key Vault, AWS Secrets Manager). Never expose API keys in client-side code.</div></div>

<!-- Salesforce -->
<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">☁️ Salesforce CRM</div><div class="ds-conn-meta">Pipeline Tracker · Closed Deals · Updated every Monday 08:00 AM</div></div>
    <span class="badge badge-green">● Connected</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>Instance URL</label><input type="text" value="https://coforge.my.salesforce.com" placeholder="https://your-org.salesforce.com"></div>
    <div class="ds-conn-field"><label>API Version</label><input type="text" value="v58.0" placeholder="e.g. v58.0"></div>
    <div class="ds-conn-field"><label>Client ID (Consumer Key)</label><input type="text" value="3MVG9…redacted" placeholder="Salesforce Connected App Client ID"></div>
    <div class="ds-conn-field"><label>Client Secret</label><input type="password" value="••••••••••••" placeholder="Client Secret"></div>
    <div class="ds-conn-field"><label>Sync Schedule</label><select class="filter-select" style="width:100%"><option>Every Monday 08:00 AM</option><option>Daily 06:00 AM</option><option>Every 4 hours</option><option>Manual only</option></select></div>
    <div class="ds-conn-field"><label>Opportunity Filters</label><input type="text" value="Stage != 'Lost', FY = FY2026" placeholder="SOQL WHERE clause filters"></div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px">
    <button class="btn btn-outline btn-sm" onclick="UI.simulateSync(this,'Salesforce')">Test Connection</button>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('Salesforce sync triggered!','🔄')">Sync Now</button>
  </div>
</div>

<!-- RDG -->
<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">👥 RDG Resource Management System</div><div class="ds-conn-meta">Employee Master · Bench Data · Demand · Fulfillment · Updated every Monday 09:00 AM</div></div>
    <span class="badge badge-green">● Connected</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>API Endpoint</label><input type="text" value="https://rdg.coforge.internal/api/v2" placeholder="RDG API base URL"></div>
    <div class="ds-conn-field"><label>API Key</label><input type="password" value="••••••••••••" placeholder="RDG API Key"></div>
    <div class="ds-conn-field"><label>Sync Schedule</label><select class="filter-select" style="width:100%"><option>Every Monday 09:00 AM</option><option>Daily 07:00 AM</option><option>Manual only</option></select></div>
    <div class="ds-conn-field"><label>Data Scope</label><input type="text" value="All IBUs, FY2026" placeholder="IBU filter or leave blank for all"></div>
    <div class="ds-conn-field"><label>Bench Ageing Threshold (days)</label><input type="number" value="30" placeholder="Days before bench is marked critical"></div>
    <div class="ds-conn-field"><label>Demand Critical Ageing (days)</label><input type="number" value="30" placeholder="Days before demand is at-risk"></div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px">
    <button class="btn btn-outline btn-sm" onclick="UI.simulateSync(this,'RDG')">Test Connection</button>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('RDG sync triggered!','🔄')">Sync Now</button>
  </div>
</div>

<!-- Finance -->
<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">💰 Finance Tracker (DATA2.xlsx Upload)</div><div class="ds-conn-meta">Revenue Actuals · Gross Margin · Updated 1st of each month by Finance Team</div></div>
    <span class="badge badge-teal">● Monthly Upload</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>Upload Method</label><select class="filter-select" style="width:100%"><option>Manual File Upload (xlsx)</option><option>SharePoint Auto-sync</option><option>Email attachment parser</option></select></div>
    <div class="ds-conn-field"><label>SharePoint Path (if used)</label><input type="text" placeholder="https://coforge.sharepoint.com/sites/Finance/..."></div>
    <div class="ds-conn-field"><label>Expected Sheet Name</label><input type="text" value="FINANCE TRACKER" placeholder="Excel sheet tab name"></div>
    <div class="ds-conn-field"><label>Header Row Number</label><input type="number" value="7" placeholder="Row number containing column headers"></div>
  </div>
  <div style="display:flex;gap:10px;margin-top:14px">
    <label class="btn btn-outline btn-sm" style="cursor:pointer">📁 Upload DATA2.xlsx<input type="file" accept=".xlsx" style="display:none" onchange="UI.toast('File uploaded and processing…','📊')"></label>
    <button class="btn btn-outline btn-sm" onclick="UI.toast('Last upload: Mar 1, 2026 — 46 accounts, FY2026 Q3 complete.','ℹ️')">View Last Upload</button>
  </div>
</div>

<!-- AI Config -->
<div class="ds-conn-card">
  <div class="ds-conn-header">
    <div><div class="ds-conn-name">🤖 AI Agent (Claude API)</div><div class="ds-conn-meta">Powered by Anthropic Claude · Revenue Intelligence Agent</div></div>
    <span class="badge badge-${CONFIG.AI.API_KEY ? 'green' : 'yellow'}">● ${CONFIG.AI.API_KEY ? 'Connected' : 'Demo Mode'}</span>
  </div>
  <div class="ds-conn-fields">
    <div class="ds-conn-field"><label>API Endpoint</label><input type="text" value="${CONFIG.AI.ENDPOINT}" readonly></div>
    <div class="ds-conn-field"><label>Model</label><input type="text" value="${CONFIG.AI.MODEL}" readonly></div>
    <div class="ds-conn-field"><label>Anthropic API Key</label><input type="password" id="settings-api-key" placeholder="sk-ant-api03-…" value="${CONFIG.AI.API_KEY || ''}"></div>
    <div class="ds-conn-field"><label>Max Tokens per Response</label><input type="number" value="${CONFIG.AI.MAX_TOKENS}"></div>
  </div>
  <div class="alert alert-warning" style="margin-top:12px"><div class="alert-icon">⚠️</div><div class="alert-text"><strong>Security:</strong> For production deployment, never expose the API key in client-side code. Route all AI calls through your backend proxy (e.g. <code>/api/ai</code>). See README for setup instructions.</div></div>
  <div style="display:flex;gap:10px;margin-top:4px">
    <button class="btn btn-outline btn-sm" onclick="UI.toast('AI agent test successful — Claude responded correctly.','🤖')">Test AI Agent</button>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     NOTIFICATIONS
  ══════════════════════════════════════════ */
  renderNotifications() {
    const notifs = [
      { icon:'🎯', title:'BE Submission Reminder',          desc:'Alert when BE deadline is approaching (configurable days before end of month)', weekly:false, channels:['email','platform'] },
      { icon:'⚠️', title:'Overdue BE Alert',               desc:'Alert when a leader has not submitted BE past the deadline', weekly:false, channels:['email','platform','slack'] },
      { icon:'🚨', title:'Deal Slippage Warning',           desc:'Alert when an opportunity has not moved stage for N days', weekly:true,  channels:['email','platform'] },
      { icon:'📊', title:'Weekly Salesforce Sync Complete', desc:'Confirmation when Salesforce data sync finishes each Monday', weekly:true,  channels:['platform'] },
      { icon:'💰', title:'Finance Tracker Updated',         desc:'Alert when new Finance Tracker data is uploaded by Finance team', weekly:false, channels:['email','platform'] },
      { icon:'👥', title:'Critical Bench Alert',            desc:'Alert when resources have been on bench for more than the threshold (default: 30 days)', weekly:true,  channels:['email','platform'] },
      { icon:'🏆', title:'Deal Won Notification',           desc:'Celebrate when a deal is marked Closed-Won in Salesforce', weekly:false, channels:['platform','slack'] },
      { icon:'📈', title:'Weekly BE Accuracy Report',       desc:'Weekly digest showing BE accuracy trends for your accounts', weekly:true,  channels:['email'] },
    ];

    const rows = notifs.map(n => `
      <div class="settings-row">
        <div class="settings-row-label">
          <h4>${n.icon} ${n.title}</h4>
          <p>${n.desc}</p>
        </div>
        <div class="settings-row-control" style="display:flex;align-items:center;gap:16px">
          <div style="display:flex;gap:8px">
            ${n.channels.map(ch => `<span class="notif-channel">${ch==='email'?'📧':ch==='platform'?'🔔':'💬'} ${ch}</span>`).join('')}
          </div>
          <label class="toggle"><input type="checkbox" checked><span class="toggle-slider"></span></label>
        </div>
      </div>`).join('');

    return `
<div class="section-header">
  <div><div class="section-title">Settings — Notifications</div><div class="section-sub">Configure when and how you receive alerts from the platform</div></div>
  <button class="btn btn-primary" onclick="UI.toast('Notification preferences saved!','🔔')">Save Preferences</button>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>📬 Notification Channels</h3><p>Configure your delivery channels</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>📧 Email Address</h4><p>Primary email for notification delivery</p></div>
      <div class="settings-row-control"><input style="padding:8px 12px;border:1.5px solid var(--coforge-border);border-radius:8px;font-size:13px;width:260px" type="email" value="sarah.leader@coforge.com"></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>💬 Slack Webhook</h4><p>Post notifications to a Slack channel</p></div>
      <div class="settings-row-control"><input style="padding:8px 12px;border:1.5px solid var(--coforge-border);border-radius:8px;font-size:13px;width:260px" type="text" placeholder="https://hooks.slack.com/services/…"></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>📅 Email Digest Frequency</h4><p>How often to receive a summary email</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>Daily</option><option>Weekly (Monday)</option><option>Never</option></select></div>
    </div>
  </div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>🔔 Notification Rules</h3><p>Toggle individual notification types</p></div></div>
  <div class="settings-card-body">${rows}</div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>⏰ Reminder Timing</h3><p>Configure when reminder notifications are sent before deadlines</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>BE Deadline Reminder — 1st Warning</h4><p>Send reminder N days before end of month</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>10 days before</option><option>7 days before</option><option>5 days before</option><option>3 days before</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>BE Deadline Reminder — Final Warning</h4><p>Last reminder before deadline</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>1 day before</option><option>2 days before</option><option>Day of deadline</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Deal Slippage Threshold</h4><p>Alert after opportunity has not moved stage for N days</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>30 days</option><option>21 days</option><option>45 days</option><option>60 days</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Bench Critical Threshold</h4><p>Alert when resource has been on bench for N days</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>30 days</option><option>21 days</option><option>45 days</option></select></div>
    </div>
  </div>
</div>`;
  },

  /* ══════════════════════════════════════════
     AUDIT LOG
  ══════════════════════════════════════════ */
  renderAudit() {
    const rows = Data.auditLog.map(a => `
      <div class="audit-row">
        <div class="audit-icon">${a.icon}</div>
        <div class="audit-info">
          <div class="audit-action">${a.action}</div>
          <div class="audit-meta">${a.meta}</div>
        </div>
        <div class="audit-time">${a.time}</div>
      </div>`).join('');

    return `
<div class="section-header">
  <div><div class="section-title">Settings — Audit Log</div><div class="section-sub">Complete history of platform activity, data syncs and user actions</div></div>
  <div style="display:flex;gap:10px">
    <button class="btn btn-outline" onclick="UI.toast('Audit log exported to CSV.','📥')">Export CSV</button>
    <button class="btn btn-outline" onclick="UI.toast('Audit log printed.','🖨️')">Print</button>
  </div>
</div>

<div class="metric-grid metric-grid-3">
  <div class="metric-card teal"><div class="metric-label">Total Events (FY2026)</div><div class="metric-value">1,842</div></div>
  <div class="metric-card green"><div class="metric-label">Data Syncs</div><div class="metric-value">164</div><div class="metric-sub">Salesforce + RDG + Finance</div></div>
  <div class="metric-card orange"><div class="metric-label">BE Submissions</div><div class="metric-value">396</div><div class="metric-sub">By all leaders YTD</div></div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">📜 Recent Activity</div>
    <div class="filter-row">
      <select class="filter-select"><option>All Event Types</option><option>BE Submissions</option><option>Data Syncs</option><option>User Management</option><option>Settings Changes</option><option>System Alerts</option></select>
      <select class="filter-select"><option>All Time</option><option>Today</option><option>Last 7 Days</option><option>This Month</option><option>Last 3 Months</option></select>
      <select class="filter-select"><option>All Users</option><option>Sarah Leader</option><option>Helen Park</option><option>James Carter</option><option>Admin User</option></select>
    </div>
  </div>
  <div class="card-body">${rows}</div>
</div>

<div class="settings-card">
  <div class="settings-card-header"><div><h3>🗄️ Audit Log Retention</h3><p>Configure how long audit records are kept</p></div></div>
  <div class="settings-card-body">
    <div class="settings-row">
      <div class="settings-row-label"><h4>Retention Period</h4><p>How long to keep audit log entries before archiving</p></div>
      <div class="settings-row-control"><select class="filter-select"><option>2 Years</option><option>1 Year</option><option>6 Months</option><option>Indefinite</option></select></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Auto-export to Archive</h4><p>Automatically export and archive logs older than retention period</p></div>
      <div class="settings-row-control"><label class="toggle"><input type="checkbox" checked><span class="toggle-slider"></span></label></div>
    </div>
    <div class="settings-row">
      <div class="settings-row-label"><h4>Archive Location</h4><p>Where archived logs are stored</p></div>
      <div class="settings-row-control"><input style="padding:8px 12px;border:1.5px solid var(--coforge-border);border-radius:8px;font-size:13px;width:280px" type="text" value="SharePoint: /Finance/RIP-Audit-Archive" placeholder="SharePoint or Azure Blob path"></div>
    </div>
  </div>
</div>`;
  }
};
