/* pages/be-analytics.js */
Pages.BEAnalytics = {
  render() {
    const statusBadge = { done:'<span class="badge badge-green">✓</span>', due:'<span class="badge badge-yellow">Due</span>', overdue:'<span class="badge badge-red">Overdue</span>' };
    const accuracyClass = s => s >= 90 ? 'green' : s >= 80 ? 'teal' : s >= 70 ? 'orange' : 'red';

    const leaderRows = Data.beSubmissions.map(b => `
      <tr>
        <td><strong>${b.leader}</strong></td>
        <td><span class="badge badge-${b.role==='Sales'?'teal':'purple'}">${b.role}</span></td>
        <td>${b.accounts}</td>
        <td>${b.submitted}/12</td>
        <td>${b.onTime}/12</td>
        <td><span class="badge badge-${accuracyClass(b.accuracy)}">${b.accuracy}%</span></td>
        <td style="font-size:12px">${b.lastSubmit}</td>
        <td>${statusBadge[b.status]||''}</td>
      </tr>`).join('');

    const calMonths = ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'];
    const calData = {
      'Sarah Leader': ['done','done','late','done','done','done','done','done','done','done','done','due'],
      'Helen Park':   ['done','done','done','done','done','done','done','done','done','done','done','done'],
      'James Carter': ['done','late','miss','done','done','late','miss','done','done','done','miss','over'],
    };
    const calBadge = { done:'<span class="badge badge-green calendar-badge">✓</span>', late:'<span class="badge badge-orange calendar-badge">Late</span>', miss:'<span class="badge badge-red calendar-badge">✗</span>', due:'<span class="badge badge-yellow calendar-badge">Due</span>', over:'<span class="badge badge-red calendar-badge">Overdue</span>' };
    const calRows = Object.entries(calData).map(([name, months]) => `
      <tr>
        <td><strong>${name}</strong></td>
        ${months.map(m => `<td>${calBadge[m]||''}</td>`).join('')}
        <td><strong style="color:var(--coforge-${accuracyClass(Data.beSubmissions.find(b=>b.leader===name)?.accuracy||80)})">${Data.beSubmissions.find(b=>b.leader===name)?.accuracy||'—'}%</strong></td>
      </tr>`).join('');

    return `
<div class="section-header">
  <div><div class="section-title">BE Accuracy & Submission Trends</div><div class="section-sub">Analysis of Best Estimate quality vs Salesforce actuals and finance data</div></div>
</div>

<div class="metric-grid">
  <div class="metric-card green"><div class="metric-label">Avg BE Accuracy (Overall)</div><div class="metric-value">84.2%</div><div class="metric-sub"><span class="metric-trend trend-up">▲ +3.1% vs last quarter</span></div></div>
  <div class="metric-card teal"><div class="metric-label">On-Time Submission Rate</div><div class="metric-value">65%</div><div class="metric-sub"><span class="metric-trend trend-down">18 pending this month</span></div></div>
  <div class="metric-card orange"><div class="metric-label">Avg Days to Submit</div><div class="metric-value">8.4d</div><div class="metric-sub">After month start</div></div>
  <div class="metric-card blue"><div class="metric-label">Leaders with >90% Accuracy</div><div class="metric-value">22</div><div class="metric-sub">Out of 52 total leaders</div></div>
</div>

<div class="grid-2" style="margin-bottom:20px">
  <div class="card">
    <div class="card-header"><div class="card-title">Leader-wise BE Accuracy & Frequency</div></div>
    <div class="card-body no-pad"><div class="table-wrap">
      <table>
        <thead><tr><th>Leader</th><th>Role</th><th>Accounts</th><th>Submissions</th><th>On Time</th><th>Accuracy</th><th>Last Submit</th><th>March Status</th></tr></thead>
        <tbody>${leaderRows}</tbody>
      </table>
    </div></div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">BE vs Actual — Account Comparison</div></div>
    <div class="card-body">
      ${[
        ['American Airlines', '$1.0M', '$1.01M', '+1%', 100, 'teal'],
        ['Mosaic Insurance',  '$900K', '$820K',  '-9%',  91, 'orange'],
        ['Tokio Marine HCC', '$500K', '$534K',  '+6.8%', 97, 'green'],
        ['United Airlines',  '$900K', '$760K',  '-15.6%',84, 'red'],
        ['Hawaiian Airlines','$600K', '$612K',  '+2%',   98, 'green'],
      ].map(([name, be, actual, var_, pct, cls]) => `
        <div style="margin-bottom:14px">
          <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px">
            <span><strong>${name}</strong></span>
            <span style="color:var(--coforge-${cls==='orange'||cls==='red'?'red':'green'});font-weight:600">BE ${be} → Actual ${actual} (${var_})</span>
          </div>
          <div class="progress-bar" style="height:8px"><div class="progress-fill progress-${cls}" style="width:${pct}%"></div></div>
        </div>`).join('')}
      <div class="alert alert-info" style="margin-top:16px">
        <div class="alert-icon">🤖</div>
        <div class="alert-text"><strong>AI Insight:</strong> Leaders referencing Salesforce pipeline before submitting BE show <strong>18% higher accuracy.</strong> This platform pre-populates SF data automatically to improve estimates.</div>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><div class="card-title">Monthly Submission Calendar — FY2026</div></div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Leader</th>
          ${calMonths.map(m=>`<th>${m}'25/'26</th>`).join('')}
          <th>Accuracy</th>
        </tr>
      </thead>
      <tbody>${calRows}</tbody>
    </table>
  </div></div>
</div>

<div class="card" style="margin-top:20px">
  <div class="card-header"><div class="card-title">Accuracy Improvement Levers</div></div>
  <div class="card-body">
    <div class="grid-3">
      <div style="padding:16px;background:rgba(0,169,157,.05);border-radius:10px;border:1px solid rgba(0,169,157,.15)">
        <div style="font-size:20px;margin-bottom:8px">📅</div>
        <div style="font-weight:600;margin-bottom:4px">Submit Early</div>
        <div style="font-size:12px;color:var(--coforge-muted)">Leaders submitting before the 10th show 23% higher accuracy. Set a personal reminder for the 7th of each month.</div>
      </div>
      <div style="padding:16px;background:rgba(0,123,255,.05);border-radius:10px;border:1px solid rgba(0,123,255,.15)">
        <div style="font-size:20px;margin-bottom:8px">🔄</div>
        <div style="font-weight:600;margin-bottom:4px">Reference Pipeline</div>
        <div style="font-size:12px;color:var(--coforge-muted)">Always cross-check live Salesforce pipeline before finalising your BE. This platform auto-populates the data for you.</div>
      </div>
      <div style="padding:16px;background:rgba(255,184,0,.05);border-radius:10px;border:1px solid rgba(255,184,0,.2)">
        <div style="font-size:20px;margin-bottom:8px">📝</div>
        <div style="font-weight:600;margin-bottom:4px">Add Commentary</div>
        <div style="font-size:12px;color:var(--coforge-muted)">Leaders who add detailed commentary have 15% fewer large variances. Explain key assumptions and risks clearly.</div>
      </div>
    </div>
  </div>
</div>`;
  }
};
