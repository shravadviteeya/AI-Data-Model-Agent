/* pages/bench.js */
Pages.Bench = {
  render() {
    const ageClass = { '0-15 Days':'green', '15-30 Days':'yellow', '>30 Days':'red' };
    const statClass = { 'Available':'blue', 'WIP':'orange', 'Positioned':'teal' };
    const rows = Data.bench.map(b => `
      <tr><td>${b.empId}</td><td><strong>${b.name}</strong></td><td>${b.pool}</td><td>${b.band}</td>
      <td>${b.skill}</td>
      <td><span class="badge badge-${ageClass[b.ageing]||'gray'}">${b.ageing}</span></td>
      <td><span class="badge badge-${statClass[b.status]||'gray'}">${b.status}</span></td>
      <td style="font-size:12px">${b.from}</td><td style="font-size:12px">${b.positioned}</td></tr>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Bench Data</div><div class="section-sub">Resources in resource pool · RDG · Updated weekly</div></div>
  <span class="data-source ds-rdg">RDG · Weekly</span>
</div>
<div class="metric-grid">
  <div class="metric-card red"><div class="metric-label">Total on Bench</div><div class="metric-value">156</div></div>
  <div class="metric-card orange"><div class="metric-label">Available (0-15d)</div><div class="metric-value">48</div></div>
  <div class="metric-card blue"><div class="metric-label">Positioned / WIP</div><div class="metric-value">72</div></div>
  <div class="metric-card teal"><div class="metric-label">Critical (>30d)</div><div class="metric-value">36</div></div>
</div>
<div class="alert alert-warning"><div class="alert-icon">⚠️</div><div class="alert-text"><strong>AI Match Alert:</strong> 4 bench resources have skill profiles matching open demand requests. <strong>Initiate placement to reduce bench days and fill delivery gaps.</strong></div></div>
<div class="card">
  <div class="card-header"><div class="card-title">Bench Resource Details</div>
    <div class="filter-row">
      <select class="filter-select"><option>All Pools</option><option>Data Pool</option><option>Engineering Pool</option><option>Insurance Pool</option><option>Cloud Pool</option></select>
      <select class="filter-select"><option>All Ageing</option><option>0-15 Days</option><option>15-30 Days</option><option>>30 Days</option></select>
      <select class="filter-select"><option>All Status</option><option>Available</option><option>WIP</option><option>Positioned</option></select>
    </div>
  </div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table><thead><tr><th>Emp ID</th><th>Name</th><th>Pool</th><th>Band</th><th>Skill Cluster</th><th>Ageing</th><th>Status</th><th>Released From</th><th>Positioned For</th></tr></thead>
    <tbody>${rows}</tbody></table>
  </div></div>
</div>`;
  }
};
