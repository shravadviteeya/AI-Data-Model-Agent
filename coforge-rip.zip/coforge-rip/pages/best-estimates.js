/* pages/best-estimates.js */
Pages.BestEstimates = {
  render() {
    return `
<div class="section-header">
  <div><div class="section-title">Best Estimate Input</div><div class="section-sub">Monthly revenue forecast submission for your accounts · March 2026</div></div>
  <div class="chip chip-orange">Due: March 31, 2026</div>
</div>
<div class="grid-1-3">
  <div style="display:flex;flex-direction:column;gap:18px">
    ${AI.panelHTML({ id:'be', title:'AI-Assisted BE', subtitle:'Pre-fills based on Salesforce data', insights:[
      { icon:'💡', text:'Based on <strong>American Airlines</strong> pipeline ($2.4M at 40%), Q4 BE suggested: <strong>$1.8M</strong>. Actual Q3 was $1.01M.' },
      { icon:'📊', text:'Your last 3 BE submissions were <strong>92% accurate</strong>. Keep it up!' },
    ]})}
    <div class="card">
      <div class="card-header"><div class="card-title">Account Reference Data</div></div>
      <div class="card-body">
        <div style="font-size:11px;font-weight:600;color:var(--coforge-muted);text-transform:uppercase;margin-bottom:10px">Your Accounts</div>
        <div class="account-item"><div class="account-avatar" style="background:var(--teal-grad)">AA</div><div class="account-info"><div class="account-name">American Airlines</div><div class="account-meta">Q3 Actual: $1.01M · Pipeline: $2.4M@40%</div></div><div class="account-val"><div class="av-amount">$1.8M</div><div class="av-label">AI Suggested Q4</div></div></div>
        <div class="account-item"><div class="account-avatar" style="background:linear-gradient(135deg,#6b4caf,#9b74ef)">HA</div><div class="account-info"><div class="account-name">Hawaiian Airlines</div><div class="account-meta">Q3 Actual: $612K · Pipeline: $890K</div></div><div class="account-val"><div class="av-amount">$680K</div><div class="av-label">AI Suggested Q4</div></div></div>
        <div class="account-item"><div class="account-avatar" style="background:var(--orange-grad)">UA</div><div class="account-info"><div class="account-name">United Airlines</div><div class="account-meta">Q3 Actual: $780K · Pipeline: $1.8M@70%</div></div><div class="account-val"><div class="av-amount">$1.4M</div><div class="av-label">AI Suggested Q4</div></div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title">Update Frequency</div></div>
      <div class="card-body"><div class="freq-grid">
        <div class="freq-card freq-weekly"><h4 style="color:var(--coforge-teal)">Weekly Data</h4><p>Pipeline, Bench, Demand, Fulfillment</p></div>
        <div class="freq-card freq-monthly"><h4 style="color:var(--coforge-purple)">Monthly Data</h4><p>Finance Actuals, Best Estimates</p></div>
      </div></div>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><div class="card-title">Submit Best Estimate — March 2026</div><span class="badge badge-yellow" id="be-status-badge">Not Submitted</span></div>
    <div class="be-form">
      <div class="tab-nav">
        <button class="tab-btn active" onclick="BEForm.switchTab('sales',this)">Sales Leader BE</button>
        <button class="tab-btn" onclick="BEForm.switchTab('delivery',this)">Delivery Leader BE</button>
      </div>
      <div id="tab-sales" class="tab-content active">${this._salesTab()}</div>
      <div id="tab-delivery" class="tab-content">${this._deliveryTab()}</div>
    </div>
  </div>
</div>`;
  },

  _salesTab() {
    return `
<div class="form-section-label">📋 Account & Period</div>
<div class="form-row">
  <div class="form-group"><label>Account Name *</label><select id="be-account"><option value="">Select Account</option><option>American Airlines</option><option>Hawaiian Airlines</option><option>United Airlines</option><option>Pacific Airlines</option></select></div>
  <div class="form-group"><label>Period *</label><select><option>March 2026</option><option>Q4 FY2026</option><option>FY2026 Full Year</option></select></div>
</div>
<div class="form-row">
  <div class="form-group"><label>BU / Vertical</label><select><option>TTH NA</option><option>ANZ BFS</option><option>Insurance NA</option><option>Insurance EU</option></select></div>
  <div class="form-group"><label>Sales Leader</label><input type="text" id="be-leader" value="Sarah Leader" readonly></div>
</div>
<hr class="form-divider">
<div class="form-section-label">💰 Revenue Best Estimate</div>
<div class="form-row">
  <div class="form-group"><label>Month BE ($) — March 2026 *</label><input type="number" id="be-month" placeholder="e.g. 1800000" oninput="BEForm.updateSummary()"></div>
  <div class="form-group"><label>Quarter BE ($) — Q4 FY2026</label><input type="number" id="be-quarter" placeholder="Auto-calc or override" oninput="BEForm.updateSummary()"></div>
</div>
<div class="form-row">
  <div class="form-group"><label>Full Year BE ($) — FY2026</label><input type="number" id="be-fy" placeholder="FY2026 full year estimate"></div>
  <div class="form-group"><label>Confidence Level</label><select id="be-confidence"><option>High (>85%)</option><option>Medium (60-85%)</option><option>Low (<60%)</option></select></div>
</div>
<hr class="form-divider">
<div class="form-section-label">🔄 Pipeline Context (from Salesforce)</div>
<div class="form-row">
  <div class="form-group"><label>Active Pipeline $ (Referenced)</label><input type="text" value="$2,400,000" readonly></div>
  <div class="form-group"><label>Closed Deals YTD $</label><input type="text" value="$1,366,000" readonly></div>
</div>
<div class="form-row">
  <div class="form-group"><label>Deals Expected to Close in Q4</label><input type="text" placeholder="e.g. United Airlines $1.8M opp at 70%"></div>
  <div class="form-group"><label>Upside / Downside Risk</label><select><option>No significant risk</option><option>Upside potential</option><option>Downside risk</option><option>Both sides</option></select></div>
</div>
<hr class="form-divider">
<div class="form-section-label">📝 Commentary</div>
<div class="form-group" style="margin-bottom:18px"><label>Sales Commentary / Rationale *</label><textarea placeholder="Explain key assumptions, deal timelines, risks driving your BE number…"></textarea></div>
<div class="be-summary-box" id="be-summary">
  <div class="be-summary-title">BE Summary Preview</div>
  <div class="be-summary-grid" id="be-summary-content"></div>
</div>
<div class="form-submit">
  <button class="btn btn-outline" onclick="BEForm.saveDraft()">Save Draft</button>
  <button class="btn btn-primary" onclick="BEForm.submit()">Submit Best Estimate ✓</button>
</div>`;
  },

  _deliveryTab() {
    return `
<div class="form-section-label">🚚 Delivery View</div>
<div class="form-row">
  <div class="form-group"><label>Account *</label><select><option>American Airlines</option><option>Hawaiian Airlines</option><option>United Airlines</option></select></div>
  <div class="form-group"><label>Period *</label><select><option>March 2026</option><option>Q4 FY2026</option></select></div>
</div>
<hr class="form-divider">
<div class="form-section-label">💰 Revenue Estimate</div>
<div class="form-row">
  <div class="form-group"><label>Month Revenue BE ($)</label><input type="number" placeholder="Delivery view of March revenue"></div>
  <div class="form-group"><label>Contracted Revenue ($)</label><input type="number" placeholder="Under active SOW/contract"></div>
</div>
<div class="form-row">
  <div class="form-group"><label>At-Risk Revenue ($)</label><input type="number" placeholder="Revenue at risk this month"></div>
  <div class="form-group"><label>Upsell / Cross-sell Potential ($)</label><input type="number" placeholder="Potential new work"></div>
</div>
<hr class="form-divider">
<div class="form-section-label">👥 Resource Context (from RDG)</div>
<div class="form-row">
  <div class="form-group"><label>Total Billed HC</label><input type="text" value="28" placeholder="Billed resources on account"></div>
  <div class="form-group"><label>Open Demands</label><input type="text" value="3" placeholder="Open RRs for this account"></div>
</div>
<div class="form-row">
  <div class="form-group"><label>Avg Billing Rate ($/month)</label><input type="number" placeholder="Average billing rate"></div>
  <div class="form-group"><label>Gross Margin % Estimate</label><input type="text" placeholder="e.g. 28%"></div>
</div>
<hr class="form-divider">
<div class="form-group" style="margin-bottom:18px"><label>Delivery Commentary</label><textarea placeholder="Delivery risks, resource constraints, ramp-ups, attrition impact, margin levers…"></textarea></div>
<div class="form-submit">
  <button class="btn btn-outline" onclick="BEForm.saveDraft()">Save Draft</button>
  <button class="btn btn-primary" onclick="BEForm.submit()">Submit Delivery BE ✓</button>
</div>`;
  }
};

/* BE Form helper object */
const BEForm = {
  switchTab(tab, btn) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + tab).classList.add('active');
  },
  updateSummary() {
    const month    = document.getElementById('be-month')?.value;
    const quarter  = document.getElementById('be-quarter')?.value;
    const conf     = document.getElementById('be-confidence')?.value || 'High';
    const leader   = document.getElementById('be-leader')?.value || '';
    if (!month) return;
    const fmt = v => v ? '$' + parseInt(v).toLocaleString() : '—';
    const box = document.getElementById('be-summary');
    if (box) {
      box.classList.add('visible');
      document.getElementById('be-summary-content').innerHTML = `
        <div><div class="label">Month BE</div><div class="val">${fmt(month)}</div></div>
        <div><div class="label">Quarter BE</div><div class="val">${fmt(quarter)}</div></div>
        <div><div class="label">Confidence</div><div class="val" style="font-size:13px">${conf}</div></div>
        <div><div class="label">Submitted by</div><div class="val" style="font-size:13px">${leader}</div></div>`;
    }
  },
  submit() {
    const badge = document.getElementById('be-status-badge');
    if (badge) { badge.className = 'badge badge-green'; badge.textContent = '✓ Submitted'; }
    const navBadge = document.getElementById('be-badge');
    if (navBadge) { navBadge.textContent = 'Done'; }
    UI.toast('Best Estimate submitted successfully for March 2026!', '🎯');
  },
  saveDraft() {
    UI.toast('Draft saved. You can continue editing before the deadline.', '💾');
  }
};
