/* pages/closed-deals.js */
Pages.ClosedDeals = {
  render() {
    const rows = Data.closedDeals.map(d => `
      <tr><td>${d.id}</td><td><strong>${d.account}</strong></td><td>${d.opp}</td><td>${d.bu}</td>
      <td>${d.closed}</td><td><span class="badge badge-teal">${d.type}</span></td>
      <td>${d.acv}</td><td>${d.tcv}</td>
      <td><span class="badge badge-${parseFloat(d.margin)>=30?'green':'orange'}">${d.margin}</span></td>
      <td>${d.ai?'<span class="badge badge-green">✓ AI</span>':'<span class="badge badge-gray">No</span>'}</td>
      <td>${d.terms}</td></tr>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Closed Deals — FY2026</div><div class="section-sub">Won deals · Salesforce · Updated weekly</div></div>
  <span class="data-source ds-salesforce">Salesforce</span>
</div>
<div class="metric-grid">
  <div class="metric-card green"><div class="metric-label">Total Won</div><div class="metric-value">38</div></div>
  <div class="metric-card teal"><div class="metric-label">Total ACV</div><div class="metric-value">$42.2M</div></div>
  <div class="metric-card blue"><div class="metric-label">Avg Deal Size</div><div class="metric-value">$1.11M</div></div>
  <div class="metric-card orange"><div class="metric-label">Avg Margin</div><div class="metric-value">29.8%</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Won Deals</div></div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table><thead><tr><th>#</th><th>Account</th><th>Opportunity</th><th>BU</th><th>Closed</th><th>Type</th><th>ACV</th><th>TCV</th><th>Margin%</th><th>AI?</th><th>Terms</th></tr></thead>
    <tbody>${rows}</tbody></table>
  </div></div>
</div>`;
  }
};
