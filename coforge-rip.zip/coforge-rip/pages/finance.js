/* pages/finance.js */
Pages.Finance = {
  render() {
    const rows = Data.finance.map(f => `
      <tr>
        <td>${f.geo}</td><td>${f.ibu}</td><td><strong>${f.customer}</strong></td>
        <td>${f.q1}</td><td>${f.q2}</td><td>${f.q3}</td><td><strong>${f.ytd}</strong></td>
        <td><span class="badge badge-${f.gmClass1}">${f.gm1}</span></td>
        <td><span class="badge badge-${f.gmClass2}">${f.gm2}</span></td>
        <td><span class="badge badge-${f.gmClass3}">${f.gm3}</span></td>
      </tr>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Finance Tracker — Actuals</div><div class="section-sub">Revenue actuals from Finance team · DATA2.xlsx · Monthly refresh</div></div>
  <div style="display:flex;gap:10px">
    <span class="data-source ds-finance">Finance Team</span>
    <span class="data-source ds-monthly">Monthly</span>
  </div>
</div>
<div class="alert alert-info"><div class="alert-icon">ℹ️</div><div class="alert-text">Finance data shows <strong>Total Accrued Revenue, Direct Expenses & Gross Margin %</strong> per account by month (Apr'25–Mar'26, FY2026). Currency: USD at Budget Rate (ACTUAL_BUDGETRATE).</div></div>
<div class="metric-grid">
  <div class="metric-card green"><div class="metric-label">Q1 FY2026 Actuals</div><div class="metric-value">$28.4M</div></div>
  <div class="metric-card teal"><div class="metric-label">Q2 FY2026 Actuals</div><div class="metric-value">$31.2M</div></div>
  <div class="metric-card blue"><div class="metric-label">Q3 FY2026 Actuals</div><div class="metric-value">$34.8M</div></div>
  <div class="metric-card orange"><div class="metric-label">YTD Avg Gross Margin %</div><div class="metric-value">28.4%</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Account-wise Monthly Actuals (USD)</div>
    <div class="filter-row">
      <select class="filter-select"><option>All Geos</option><option>US</option><option>EMEA</option><option>ANZ</option></select>
      <select class="filter-select"><option>All Periods</option><option>Q1 FY2026</option><option>Q2 FY2026</option><option>Q3 FY2026</option><option>Q4 FY2026</option></select>
    </div>
  </div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table>
      <thead><tr><th>Geo</th><th>IBU</th><th>Customer</th><th>Q1 Rev</th><th>Q2 Rev</th><th>Q3 Rev</th><th>YTD</th><th>GM% Q1</th><th>GM% Q2</th><th>GM% Q3</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div></div>
</div>`;
  }
};
