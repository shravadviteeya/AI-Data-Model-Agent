/* pages/pipeline.js */
Pages.Pipeline = {
  render() {
    const stageClass = { '1 Prospect':'gray','2 Qualified':'blue','3 Proposal':'orange','4 Negotiation':'yellow','5 Deal Closed':'green' };
    const rows = Data.pipeline.map(p => `
      <tr>
        <td>${p.id}</td><td><strong>${p.account}</strong></td><td>${p.opp}</td><td>${p.bu}</td><td>${p.owner}</td>
        <td><span class="badge badge-${stageClass[p.stage]||'gray'}">${p.stage}</span></td>
        <td><span class="badge badge-teal">${p.type}</span></td>
        <td>${p.prob}%</td><td>${p.acv}</td><td>${p.tcv}</td><td>${p.close}</td>
        <td>${p.ai ? '<span class="badge badge-green">✓ AI</span>' : '<span class="badge badge-gray">No</span>'}</td>
      </tr>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Pipeline Tracker</div><div class="section-sub">Salesforce pipeline · Updated weekly by Hunters</div></div>
  <span class="data-source ds-salesforce">Salesforce CRM · Weekly</span>
</div>
<div class="metric-grid metric-grid-5">
  <div class="metric-card teal"><div class="metric-label">Total Open Opps</div><div class="metric-value">124</div></div>
  <div class="metric-card orange"><div class="metric-label">Pipeline Value</div><div class="metric-value">$87.4M</div></div>
  <div class="metric-card green"><div class="metric-label">TCV (All Opps)</div><div class="metric-value">$142M</div></div>
  <div class="metric-card blue"><div class="metric-label">Weighted Value</div><div class="metric-value">$51.2M</div></div>
  <div class="metric-card navy"><div class="metric-label">AI-Enabled Deals</div><div class="metric-value">38%</div></div>
</div>
<div class="card">
  <div class="card-header">
    <div class="card-title">Active Pipeline</div>
    <div class="filter-row">
      <select class="filter-select"><option>All BUs</option><option>US Geo Retail</option><option>ANZ BFS</option><option>Insurance EU</option><option>Insurance NA</option><option>TTH NA</option></select>
      <select class="filter-select"><option>All Stages</option><option>1 Prospect</option><option>2 Qualified</option><option>3 Proposal</option><option>4 Negotiation</option></select>
      <select class="filter-select"><option>All Types</option><option>New (NN)</option><option>Existing New (EN)</option><option>Renewal (EE)</option></select>
    </div>
  </div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table><thead><tr><th>#</th><th>Account</th><th>Opportunity</th><th>BU</th><th>Owner</th><th>Stage</th><th>Type</th><th>Prob%</th><th>ACV</th><th>TCV</th><th>Close</th><th>AI?</th></tr></thead>
    <tbody>${rows}</tbody></table>
  </div></div>
</div>`;
  }
};
