/* pages/demand.js */
Pages.Demand = {
  render() {
    const ageClass = { '0-15d':'green', '15-30d':'yellow', '>30d':'red' };
    const statClass = { 'Pending TA':'orange', 'Internal':'blue', 'At Risk':'red', 'WIP':'yellow' };
    const rows = Data.demand.map(d => `
      <tr><td>${d.reqId}</td><td><strong>${d.customer}</strong></td><td>${d.ibu}</td><td>${d.band}</td>
      <td style="font-size:12px">${d.skills}</td><td>${d.location}</td>
      <td><span class="badge badge-${ageClass[d.ageing]||'gray'}">${d.ageing}</span></td>
      <td><span class="badge badge-${statClass[d.status]||'gray'}">${d.status}</span></td>
      <td style="font-size:12px">${d.reqBy}</td><td style="font-size:12px">${d.month}</td></tr>`).join('');
    return `
<div class="section-header">
  <div><div class="section-title">Demand Data</div><div class="section-sub">Open resource requirements · RDG · Updated weekly</div></div>
  <span class="data-source ds-rdg">RDG · Weekly</span>
</div>
<div class="metric-grid">
  <div class="metric-card orange"><div class="metric-label">Total Open Demands</div><div class="metric-value">284</div></div>
  <div class="metric-card red"><div class="metric-label">Critical (>30d)</div><div class="metric-value">62</div></div>
  <div class="metric-card teal"><div class="metric-label">In Progress</div><div class="metric-value">148</div></div>
  <div class="metric-card green"><div class="metric-label">Confirmed</div><div class="metric-value">74</div></div>
</div>
<div class="card">
  <div class="card-header"><div class="card-title">Open Demand Requests</div>
    <div class="filter-row">
      <select class="filter-select"><option>All IBUs</option><option>Insurance EU</option><option>BFS NA</option><option>TTH NA</option><option>Insurance NA</option></select>
      <select class="filter-select"><option>All Status</option><option>Pending TA</option><option>Internal</option><option>At Risk</option><option>WIP</option></select>
    </div>
  </div>
  <div class="card-body no-pad"><div class="table-wrap">
    <table><thead><tr><th>Req ID</th><th>Customer</th><th>IBU</th><th>Band</th><th>Skills</th><th>Location</th><th>Ageing</th><th>Status</th><th>Required By</th><th>Fulfil Month</th></tr></thead>
    <tbody>${rows}</tbody></table>
  </div></div>
</div>`;
  }
};
