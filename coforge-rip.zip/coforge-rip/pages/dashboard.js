/* pages/dashboard.js */
Pages.Dashboard = {
  render() {
    return `
<div class="section-header">
  <div><div class="section-title">Executive Dashboard</div><div class="section-sub">Consolidated view across all data sources · FY2026 Full Year</div></div>
  <div class="section-actions">
    <div class="data-source ds-weekly"><span class="dot" style="background:var(--coforge-teal)"></span> Weekly refresh</div>
    <div class="data-source ds-monthly"><span class="dot" style="background:var(--coforge-purple)"></span> Monthly BE</div>
  </div>
</div>
<div class="metric-grid">
  <div class="metric-card teal"><div class="metric-label">FY2026 Revenue Actual (YTD)</div><div class="metric-value">$119.8M</div><div class="metric-sub"><span class="metric-trend trend-up">▲ 8.1% QoQ</span> Finance Tracker</div></div>
  <div class="metric-card orange"><div class="metric-label">Pipeline Value (Active)</div><div class="metric-value">$87.4M</div><div class="metric-sub"><span class="metric-trend trend-up">▲ 124 Opps</span> Salesforce</div></div>
  <div class="metric-card green"><div class="metric-label">Closed Deals (FY2026)</div><div class="metric-value">$42.2M</div><div class="metric-sub"><span class="metric-trend trend-up">38 Deals</span> Win Rate: 67%</div></div>
  <div class="metric-card blue"><div class="metric-label">Open Demand Positions</div><div class="metric-value">284</div><div class="metric-sub"><span class="metric-trend trend-down">18 Critical</span> RDG</div></div>
</div>
<div class="metric-grid metric-grid-3" style="margin-bottom:22px">
  <div class="metric-card navy"><div class="metric-label">Bench Pool</div><div class="metric-value">156</div><div class="metric-sub"><span class="metric-trend trend-neutral">48 Available</span></div></div>
  <div class="metric-card teal"><div class="metric-label">YTD Fulfillment Rate</div><div class="metric-value">82%</div><div class="metric-sub"><span class="metric-trend trend-up">Target: 90%</span></div></div>
  <div class="metric-card orange"><div class="metric-label">Gross Margin % YTD</div><div class="metric-value">28.4%</div><div class="metric-sub"><span class="metric-trend trend-down">-1.2% vs Budget</span></div></div>
</div>
<div class="grid-3-1" style="margin-bottom:22px">
  <div class="card">
    <div class="card-header"><div class="card-title">Pipeline Health by BU</div><span class="data-source ds-salesforce">Salesforce</span></div>
    <div class="card-body no-pad"><div class="table-wrap"><table>
      <thead><tr><th>BU / Vertical</th><th>Opps</th><th>Pipeline</th><th>Probability</th></tr></thead>
      <tbody>
        <tr><td><strong>Insurance NA</strong></td><td>31</td><td>$22.6M</td><td><div class="progress-bar"><div class="progress-fill progress-orange" style="width:74%"></div></div></td></tr>
        <tr><td><strong>US Geo Retail</strong></td><td>28</td><td>$18.4M</td><td><div class="progress-bar"><div class="progress-fill progress-green" style="width:72%"></div></div></td></tr>
        <tr><td><strong>ANZ BFS</strong></td><td>19</td><td>$14.7M</td><td><div class="progress-bar"><div class="progress-fill progress-teal" style="width:58%"></div></div></td></tr>
        <tr><td><strong>Insurance EU</strong></td><td>22</td><td>$12.1M</td><td><div class="progress-bar"><div class="progress-fill progress-blue" style="width:61%"></div></div></td></tr>
        <tr><td><strong>TTH NA</strong></td><td>14</td><td>$11.2M</td><td><div class="progress-bar"><div class="progress-fill progress-green" style="width:60%"></div></div></td></tr>
        <tr><td><strong>BFS EMEA</strong></td><td>10</td><td>$8.4M</td><td><div class="progress-bar"><div class="progress-fill progress-red" style="width:44%"></div></div></td></tr>
      </tbody>
    </table></div></div>
  </div>
  ${AI.panelHTML({ id:'dash', insights:[
    { icon:'⚠️', text:'<strong>3 deals</strong> in Insurance NA stagnant >45 days. Risk of Q1 FY2027 slippage.' },
    { icon:'📈', text:'<strong>American Airlines</strong> actual ($3.52M) exceeds BE by 12%. Consider revising Q4 forecast.' },
    { icon:'🎯', text:'<strong>18 leaders</strong> yet to submit March BE. Deadline: Mar 31.' },
  ]})}
</div>
<div class="grid-2">
  <div class="card">
    <div class="card-header"><div class="card-title">Finance Tracker — Revenue YTD</div><span class="data-source ds-finance">Finance</span></div>
    <div class="card-body no-pad"><table>
      <thead><tr><th>Account</th><th>Q1</th><th>Q2</th><th>Q3</th><th>YTD</th><th>GM%</th></tr></thead>
      <tbody>
        ${Data.finance.map(r => `<tr><td><strong>${r.customer}</strong></td><td>${r.q1}</td><td>${r.q2}</td><td>${r.q3}</td><td><strong>${r.ytd}</strong></td><td><span class="badge badge-${r.gmClass3}">${r.gm3}</span></td></tr>`).join('')}
      </tbody>
    </table></div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title">Data Feed Status</div><span class="badge badge-green">All Live</span></div>
    <div class="card-body">
      <div class="status-row"><div class="status-row-info"><h4>Salesforce Pipeline</h4><p>Pipeline & Closed Deals · Weekly</p></div><span class="badge badge-green">Live</span></div>
      <div class="status-row"><div class="status-row-info"><h4>RDG Resource Data</h4><p>Employee, Bench, Demand · Weekly</p></div><span class="badge badge-green">Live</span></div>
      <div class="status-row"><div class="status-row-info"><h4>Finance Tracker (DATA2.xlsx)</h4><p>Revenue Actuals · Monthly</p></div><span class="badge badge-teal">Monthly</span></div>
      <div class="status-row"><div class="status-row-info"><h4>Best Estimates Input</h4><p>Sales & Delivery Leaders · Monthly</p></div><span class="badge badge-yellow">18 Pending</span></div>
    </div>
  </div>
</div>`;
  }
};
