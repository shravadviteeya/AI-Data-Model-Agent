"""
KPI Intelligence Agent v2 — Main Entry Point
Multi-source unified dashboard for Coforge D&A PMO.

Usage:
  python main.py --file DATA2.xlsx
  python main.py --file DATA2.xlsx --provider anthropic
  python main.py --sample
  python main.py --ui
"""

import os, sys, json, webbrowser, click, yaml, warnings
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from loguru import logger
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

warnings.filterwarnings('ignore')
load_dotenv()

logger.remove()
logger.add(sys.stderr,
           format="<green>{time:HH:mm:ss}</green> | "
                  "<level>{level:<8}</level> | {message}",
           level="INFO")
Path("output").mkdir(exist_ok=True)
logger.add("output/agent.log", rotation="1 MB", level="DEBUG", catch=True)

console = Console()


def load_config() -> dict:
    p = Path("config.yaml")
    return yaml.safe_load(p.read_text()) if p.exists() else {}


def run_agent(file_path: str, provider: str = "auto",
              output_dir: str = "./output") -> dict:
    """Full 9-step pipeline."""
    config   = load_config()
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    console.print(Panel(
        "[bold cyan]KPI Intelligence Agent v2[/bold cyan]\n"
        f"[dim]Wireframe 2 · {datetime.now().strftime('%d %b %Y %H:%M')}[/dim]",
        expand=False))

    # ── Step 1: Load all sheets ───────────────────────────────
    logger.info("Step 1/9 — Loading multi-sheet Excel...")
    from core.multi_sheet_loader import MultiSheetLoader
    loader = MultiSheetLoader(config)
    sheets = loader.load(file_path)
    loaded = sum(1 for v in sheets.values() if v is not None)
    logger.success(f"Loaded {loaded}/8 sheets")

    # ── Step 2: Map relationships ─────────────────────────────
    logger.info("Step 2/9 — Mapping cross-sheet relationships...")
    from core.relationship_mapper import RelationshipMapper
    mapper = RelationshipMapper(config)
    relationships = mapper.map(sheets)
    valid = sum(1 for r in relationships if r['validated'])
    logger.success(f"Validated {valid}/{len(relationships)} relationships")

    # ── Step 3: Finance KPIs ──────────────────────────────────
    logger.info("Step 3/9 — Finance Tracker KPIs...")
    from core.finance_kpi import FinanceKPI
    fin_kpis = FinanceKPI(config).calculate(sheets.get('finance'))

    # ── Step 4: Salesforce KPIs ───────────────────────────────
    logger.info("Step 4/9 — Salesforce KPIs...")
    from core.salesforce_kpi import SalesforceKPI
    sf = SalesforceKPI(config)
    pipe_kpis   = sf.calculate_pipeline(sheets.get('sf_pipeline'))
    closed_kpis = sf.calculate_closed(sheets.get('closed'))

    # ── Step 5: People KPIs ───────────────────────────────────
    logger.info("Step 5/9 — People KPIs (Employee / Bench / Fulfillment)...")
    from core.people_kpi import PeopleKPI
    people = PeopleKPI(config)
    emp_kpis = people.calculate_employee(sheets.get('employee'))
    bench_kpis = people.calculate_bench(sheets.get('bench'))
    ful_kpis = people.calculate_fulfillment(sheets.get('fulfillment'))

    # ── Step 6: Demand KPIs ───────────────────────────────────
    logger.info("Step 6/9 — Demand KPIs...")
    from core.demand_kpi import DemandKPI
    dem_kpis = DemandKPI(config).calculate(sheets.get('demand'))

    # ── Step 7: Master / unified KPIs ────────────────────────
    logger.info("Step 7/9 — Master unified KPIs...")
    from core.master_kpi import MasterKPI
    all_kpis = {
        'finance': fin_kpis, 'pipeline': pipe_kpis,
        'closed': closed_kpis, 'demand': dem_kpis,
        'bench': bench_kpis, 'fulfillment': ful_kpis,
        'employee': emp_kpis,
    }
    master_kpis = MasterKPI(config).calculate(all_kpis)
    all_kpis['master'] = master_kpis

    # ── Step 8: AI insights ───────────────────────────────────
    logger.info(f"Step 8/9 — AI insights ({provider})...")
    from agents.base_agent import AgentFactory
    from agents.insight_engine import InsightEngine
    agent = AgentFactory.create(provider)
    logger.info(f"  Using: {agent.name}")
    insights = InsightEngine(config).generate(all_kpis, agent)
    logger.success(f"Generated {len(insights)} insights")

    # ── Step 9: Build outputs ─────────────────────────────────
    logger.info("Step 9/9 — Building dashboard & report...")
    from ui.dashboard_builder import DashboardBuilder
    from ui.report_builder import ReportBuilder

    dash_html = DashboardBuilder(config).build(
        all_kpis, relationships, insights)
    dash_file = out_path / config.get('output', {}).get(
        'dashboard_file', 'dashboard.html')
    dash_file.write_text(dash_html, encoding='utf-8')

    rep_html  = ReportBuilder(config).build(master_kpis, insights)
    rep_file  = out_path / config.get('output', {}).get(
        'report_file', 'executive_report.html')
    rep_file.write_text(rep_html, encoding='utf-8')

    result = {
        'metadata': {
            'generated_at': datetime.now().isoformat(),
            'provider': provider, 'file': file_path,
            'sheets_loaded': loaded, 'agent': agent.name,
        },
        'kpis': {k: {kk: vv for kk, vv in v.items()
                     if not isinstance(vv, list)}
                 for k, v in all_kpis.items()},
        'relationships': relationships,
        'insights': insights,
    }
    json_file = out_path / "kpi_data.json"
    json_file.write_text(json.dumps(result, indent=2, default=str),
                         encoding='utf-8')

    # ── Summary table ─────────────────────────────────────────
    tbl = Table(title="Output Files", show_header=True)
    tbl.add_column("File", style="cyan")
    tbl.add_column("Size", style="green")
    for f in [dash_file, rep_file, json_file]:
        if f.exists():
            tbl.add_row(str(f), f"{f.stat().st_size/1024:.1f} KB")
    console.print(tbl)

    if config.get('output', {}).get('open_browser', True):
        webbrowser.open(f"file://{dash_file.absolute()}")

    console.print(Panel(
        f"[bold green]Complete![/bold green] "
        f"Health Score: [cyan]{master_kpis.get('health_score',0)}/100[/cyan]  "
        f"Dashboard: [cyan]{dash_file}[/cyan]",
        expand=False))
    return result


@click.command()
@click.option('--file', '-f', default=None,
              help='Path to multi-sheet Excel file (e.g. DATA2.xlsx)')
@click.option('--provider', '-p', default='auto',
              type=click.Choice(['auto','anthropic','openai','gemini','copilot']),
              help='AI provider')
@click.option('--output', '-o', default='./output',
              help='Output directory')
@click.option('--sample', is_flag=True, default=False,
              help='Generate and use sample data')
@click.option('--no-browser', is_flag=True, default=False,
              help='Do not open browser after run')
@click.option('--ui', is_flag=True, default=False,
              help='Launch Streamlit web UI')
def main(file, provider, output, sample, no_browser, ui):
    """KPI Intelligence Agent v2 — Unified Multi-Source Dashboard"""
    if ui:
        os.system("streamlit run ui/streamlit_app.py")
        return

    if sample or not file:
        logger.info("Generating sample data...")
        from data.sample.generate_sample import generate
        file = generate()
        logger.success(f"Sample file: {file}")
    else:
        if not Path(file).exists():
            logger.error(f"File not found: {file}")
            sys.exit(1)

    run_agent(file, provider=provider, output_dir=output)


if __name__ == "__main__":
    main()
