"""
Sample Data Generator v2 — creates a realistic 8-sheet Excel file.
Run: python data/sample/generate_sample.py
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta


def generate(output_dir: str = "data/sample") -> str:
    np.random.seed(42)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    file = out / "sample_DATA2.xlsx"

    ibus    = ['INSURANCE NA','INSURANCE EU','BFS NA','BFS EU',
               'TRAVEL NA','RETAIL','HEALTHCARE','ANZ']
    regions = ['North', 'South', 'East', 'West', 'Central']
    owners  = ['Raj Kumar','Priya Sharma','Amit Singh','Neha Verma',
               'Vikram Patel','Sunita Joshi','Deepak Gupta','Anita Rao']
    geos    = ['US','UK','India','ANZ','EU']
    practices = ['DATA & AI','CLOUD','DIGITAL','ERP','TESTING']

    with pd.ExcelWriter(file, engine='openpyxl') as writer:

        # ── 1. Finance Tracker (multi-row header structure) ────
        months = ['Apr25','May25','Jun25','Jul25','Aug25','Sep25',
                  'Oct25','Nov25','Dec25','Jan26','Feb26','Mar26']
        rev_vals  = [np.random.randint(300000, 600000) for _ in months]
        exp_vals  = [r * np.random.uniform(0.55, 0.80) for r in rev_vals]
        gm_pcts   = [(r-e)/r for r, e in zip(rev_vals, exp_vals)]
        q1r, q2r  = sum(rev_vals[:3]),  sum(rev_vals[3:6])
        q3r, q4r  = sum(rev_vals[6:9]), sum(rev_vals[9:])
        q1e, q2e  = sum(exp_vals[:3]),  sum(exp_vals[3:6])
        q3e, q4e  = sum(exp_vals[6:9]), sum(exp_vals[9:])
        fyr, fye  = sum(rev_vals), sum(exp_vals)

        # All 52 columns: 3 dims + 17 rev + 17 exp + 17 gm = 54
        cols = (['Geo','CostCenter','Customer'] +
                months + ['Q12026','Q22026','Q32026','Q42026','FY2026'] +
                months + ['Q12026','Q22026','Q32026','Q42026','FY2026'] +
                months + ['Q12026','Q22026','Q32026','Q42026','FY2026'])

        row_measures = (['Measures'] + ['C_USD']*51)
        row_version  = (['Version']  + ['ACTUAL_BUDGETRATE']*51)
        row_account  = (['Account']  +
                        ['Total Accrued Revenue']*17 +
                        ['Total Direct Expenses']*17 +
                        ['Gross Margin %']*17)
        row_date     = (['Date'] +
                        months + ['Q12026','Q22026','Q32026','Q42026','FY2026'] +
                        months + ['Q12026','Q22026','Q32026','Q42026','FY2026'] +
                        months + ['Q12026','Q22026','Q32026','Q42026','FY2026'])
        row_dims     = (['Geo','Cost Center','Customer'] + ['']*51)

        rev_row = (['US','Travel NA','American Airlines'] +
                   rev_vals + [q1r,q2r,q3r,q4r,fyr] +
                   exp_vals + [q1e,q2e,q3e,q4e,fye] +
                   gm_pcts  + [(q1r-q1e)/q1r,(q2r-q2e)/q2r,
                                (q3r-q3e)/q3r,(q4r-q4e)/q4r,(fyr-fye)/fyr])

        fin_rows = [row_measures, row_version, row_account,
                    row_date, row_dims, rev_row]
        max_cols = max(len(r) for r in fin_rows)
        fin_rows_padded = [r + [None]*(max_cols-len(r)) for r in fin_rows]
        pd.DataFrame(fin_rows_padded).to_excel(
            writer, sheet_name='FINANCE TRACKER',
            index=False, header=False)

        # ── 2. Master Reference ───────────────────────────────
        pd.DataFrame([{
            'Concatenate': f'{ibu} Client{i}',
            'IBU as per system': ibu,
            'Customer Name as per System': f'Client {i}',
            'Customer Name': f'Client {i}',
            'GEO': np.random.choice(geos),
            'IBU': ibu,
            'Key Accounts': np.random.choice(['Yes','No'])
        } for i, ibu in enumerate(ibus*5)]).to_excel(
            writer, sheet_name='Master', index=False)

        # ── 3. Employee Master ────────────────────────────────
        emps = []
        for i in range(150):
            ibu = np.random.choice(ibus)
            emps.append({
                'Employee No': 10000 + i,
                'Name': f'Employee {i}',
                'Email': f'emp{i}@coforge.com',
                'Employee Type': np.random.choice(
                    ['Regular Staff Member']*8 + ['Contract']),
                'Gender': np.random.choice(['Male','Female']),
                'Onsite/Offshore': np.random.choice(
                    ['Offshore']*3 + ['Onsite']),
                'IBU': ibu, 'Sub IBU': ibu + ' Sub',
                'Employee Group Practice': np.random.choice(practices),
                'Designation': np.random.choice(
                    ['SR DEVELOPER','LEAD CONSULTANT','SR CONSULTANT',
                     'ARCHITECT','SENIOR MANAGER']),
                'Designation Level': np.random.choice([4.1,4.2,5.1,5.2,6.1,6.2]),
                'Role Band': np.random.choice([4,5,6]),
                'Customer Name': f'Client {np.random.randint(1,20)}',
                'Billed/Unbilled': np.random.choice(
                    ['Billed']*8 + ['Unbilled']),
                'Geo': np.random.choice(geos),
                'Location': np.random.choice(
                    ['Noida','Bangalore','Hyderabad','Pune','London']),
                'Skill Area': np.random.choice(
                    ['DATA & AI','CLOUD','JAVA','DOTNET']),
                'Skill Cluster': np.random.choice(
                    ['Data Engineering','Data Architect',
                     'Business Analysis','Cloud Infra']),
                'Date of Joining': (datetime(2015,1,1) +
                    timedelta(days=int(np.random.randint(0,3000))))
                    .strftime('%d-%m-%Y'),
                'Status': 'Allocated',
            })
        pd.DataFrame(emps).to_excel(
            writer, sheet_name='EMPLOYEE MASTER', index=False)

        # ── 4. Salesforce Pipeline ────────────────────────────
        stages_prob = [('1 Prospect',5),('2 Qualify',20),
                       ('3 Propose',40),('4 Negotiate',60),
                       ('5 Commit',80),('6 Close Plan',90)]
        sf_rows = []
        for i in range(80):
            stage, prob = stages_prob[np.random.randint(0, len(stages_prob))]
            tcv = np.random.randint(100000, 5000000)
            ibu = np.random.choice(ibus)
            sf_rows.append({
                'Sr.No': i+1, 'BU': ibu,
                'VERTICAL': ibu,
                'AccountName': f'Client {np.random.randint(1,30)}',
                'OpportunityOwner': np.random.choice(owners),
                'SFDC_OPPORTUNITYID': f'006{i:015d}',
                'OPPORTUNITYNAME': f'Opportunity {i} — Data & Analytics',
                'TYPE': np.random.choice(['New (NN)','Existing New (EN)','Renewal (EE)']),
                'OpportunityStatus': 'Open',
                'STAGE': stage,
                'Probability(%)': prob + np.random.randint(-3,3),
                'TCV($)': tcv, 'ACV($)': round(tcv * 0.95),
                'HBU_TCV($)': tcv,
                'Product': 'Data & Analytics',
                'ProductFamily(Practice)': 'Data & Analytics (DNA)',
                'EstCloseDate': (datetime.now() +
                    timedelta(days=int(np.random.randint(30,365)))).date(),
                'PROPOSAL_CONTAINS_AI': np.random.choice(
                    ['Yes']*3 + ['No']*7),
                'SubBu': ibu,
                'PMOName': np.random.choice(owners),
                'BIDTYPE': np.random.choice(['T&M','Fixed Price','Fixed Capacity']),
            })
        pd.DataFrame(sf_rows).to_excel(
            writer, sheet_name='SALESFORCE DATA', index=False)

        # ── 5. Demand Data ────────────────────────────────────
        statuses = ['Pending with TA','Pending with RDG',
                    'Offered','Joined','Closed']
        aging_ranges = ['0-15 Days','> 15 to 30 Days',
                        '> 30 to 60 Days','> 60 Days']
        dem_rows = []
        for i in range(120):
            ibu = np.random.choice(ibus)
            dem_rows.append({
                'RequestID': 250000 + i,
                'IBU': ibu, 'Sub IBU': ibu + ' Sub',
                'BU': ibu.split()[0],
                'Customer Group': f'Group {np.random.randint(1,15)}',
                'Customer Name / Other Customer': f'Client {np.random.randint(1,30)}',
                'Offshore / Onsite': np.random.choice(['Offshore']*3+['Onsite']),
                'Location': np.random.choice(['Noida','Bangalore','London','New York']),
                'Primary Skills': np.random.choice(
                    ['PYTHON','JAVA','AWS','AZURE','SNOWFLAKE',
                     'TABLEAU','SPARK','SQL']),
                'RR Status': np.random.choice(statuses),
                'Ageing Range': np.random.choice(aging_ranges),
                'Ageing (RDG  Recvd DATE)': np.random.randint(0, 90),
                'Ageing (TA Recvd DATE)': np.random.randint(0, 60),
                'Requested Role Band': np.random.choice([3,4,5,6]),
                'Requested Positions': 1,
                'Open Position': np.random.choice([0,0,1,1,1]),
                'WIP': np.random.choice([0,1]),
                'Offered': np.random.choice([0,1]),
                'FFTP': np.random.randint(-5, 30),
                'FFTP Range': np.random.choice(['<= 15 Days','16-30 Days','> 30 Days']),
                'Skill Category': np.random.choice(['Niche','Commodity','Specialist']),
                'Demand category ': np.random.choice(['Confirmed','Tentative']),
                'Opportunity ID': f'006{np.random.randint(0,80):015d}',
                'Fulfillment Month': np.random.choice(
                    ["Apr'26","May'26","Jun'26","Jul'26"]),
            })
        pd.DataFrame(dem_rows).to_excel(
            writer, sheet_name='DEMAND DATA', index=False)

        # ── 6. Bench Data ─────────────────────────────────────
        bench_rows = []
        for i in range(35):
            bench_rows.append({
                'Employee No': 20000 + i,
                'Name': f'Bench Employee {i}',
                'Pool Type': np.random.choice(
                    ['Data Pool']*4 + ['Cloud Pool','App Dev Pool']),
                'Role Band': np.random.choice([3.2,4.1,4.2,5.1,5.2]),
                'PSA': np.random.choice(
                    ['Gr.Noida SEZ 4','Bangalore','Pune']),
                'No. of Days in RP': round(np.random.uniform(1, 90), 2),
                'Ageing (Days)': np.random.choice(
                    ['0-15 Days']*4 + ['16-30 Days']*3 +
                    ['31-60 Days']*2 + ['> 60 Days']),
                'Skill Cluster': np.random.choice(
                    ['Data Architect','Data Engineering',
                     'Business Analysis','Cloud Infra','BI & Visualization']),
                'Skill': 'Python, SQL, AWS, Spark',
                'Status': np.random.choice(
                    ['Available']*6 + ['Positioned']*3 + ['Finalised']),
                'Pool Start Date': (datetime.now() -
                    timedelta(days=int(np.random.randint(1, 90)))).date(),
                'E-mail id': f'bench{i}@coforge.com',
                'Emp Practise': 'DATA & AI',
            })
        pd.DataFrame(bench_rows).to_excel(
            writer, sheet_name='BENCH DATA', index=False)

        # ── 7. YTD Fulfillment ────────────────────────────────
        ful_rows = []
        for i in range(90):
            ibu = np.random.choice(ibus)
            ful_rows.append({
                'Request ID': 250000 + np.random.randint(0, 120),
                'Employee Code': 10000 + np.random.randint(0, 150),
                'NAME': f'Fulfilled Employee {i}',
                'Employee Type': np.random.choice(
                    ['Internal']*6 + ['External']),
                'Joining Date': (datetime(2025,4,1) +
                    timedelta(days=int(np.random.randint(0, 365)))).date(),
                'Quarter': np.random.choice(
                    ["Q1'25","Q2'25","Q3'25","Q4'25 TD"]),
                'VBU': ibu, 'VDU': ibu + ' Unit',
                'Customer Group': f'Group {np.random.randint(1,15)}',
                'Employee Practice': 'DATA & ANALYTICS (D&A)',
                'Employee Group Practice': 'DATA & AI',
                'FFTP': np.random.randint(-15, 30),
                'Offshore / Onsite': np.random.choice(['Offshore']*3+['Onsite']),
                'Closed By': np.random.choice(
                    ['By RDG(Internally)','By TA(Externally)',
                     'By RDG(Externally)']),
                'Skill Category': np.random.choice(['Niche','Commodity']),
                'Skills': np.random.choice(['PYTHON','JAVA','AWS','SNOWFLAKE']),
                'Opportunity ID': f'006{np.random.randint(0,80):015d}',
            })
        pd.DataFrame(ful_rows).to_excel(
            writer, sheet_name='YTD FULFILLMENT DATA', index=False)

        # ── 8. Closed Deals ───────────────────────────────────
        cl_rows = []
        for i in range(60):
            ibu = np.random.choice(ibus)
            won = np.random.random() > 0.25
            tcv = np.random.randint(50000, 3000000)
            cl_rows.append({
                'Sr.No': i+1, 'BU': ibu, 'Vertical': ibu,
                'OpportunityID': f'006{i:015d}',
                'OpportunityOwner': np.random.choice(owners),
                'Account': f'Client {np.random.randint(1,30)}',
                'OpportunityName': f'Closed Deal {i} — Data',
                'Currency': 'USD',
                'TCV($)': tcv, 'ACV($)': round(tcv*0.95),
                'HBU_TCV($)': tcv,
                'Stage': '5 Deal Closed',
                'Type': np.random.choice(
                    ['New (NN)','Existing New (EN)','Renewal (EE)']),
                'Status': 'Closed- Won' if won else 'Closed- Lost',
                'ActualCloseDate': (datetime(2025,4,1) +
                    timedelta(days=int(np.random.randint(0,365)))).date(),
                'ActualCloseQTR': np.random.choice(
                    ['Q1 2026','Q2 2026','Q3 2026','Q4 2026']),
                'OverallMargin(%)': round(np.random.uniform(15,45), 1) if won else 0,
                'Product': 'Data & Analytics',
                'SubBu': ibu,
                'BIDTYPE': np.random.choice(['T&M','Fixed Price']),
                'PROPOSAL_CONTAINS_AI': np.random.choice(['Yes','No']),
                'DEALTERMS': np.random.choice(
                    ['Staffing','Project','Managed Services']),
            })
        pd.DataFrame(cl_rows).to_excel(
            writer, sheet_name='salesforce closed deal', index=False)

    print(f"Sample file created: {file.absolute()}")
    print(f"  8 sheets, realistic Coforge D&A PMO data")
    return str(file)


if __name__ == "__main__":
    generate()
