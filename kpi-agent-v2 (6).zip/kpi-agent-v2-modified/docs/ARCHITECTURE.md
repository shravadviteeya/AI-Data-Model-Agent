# 🏗️ Architecture — KPI Intelligence Agent v2

## System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                  KPI INTELLIGENCE AGENT v2 — WIREFRAME 2            │
├──────────────────┬──────────────────────────┬───────────────────────┤
│   INPUT (8 src)  │    PROCESSING (9 steps)  │   OUTPUT              │
├──────────────────┼──────────────────────────┼───────────────────────┤
│ Finance Tracker  │  1. MultiSheetLoader      │ dashboard.html        │
│ Master Ref       │  2. RelationshipMapper    │ executive_report.html │
│ Employee Master  │  3. FinanceKPI            │ kpi_data.json         │
│ SF Pipeline      │  4. SalesforceKPI         │ agent.log             │
│ Demand Data      │  5. PeopleKPI (3 sheets)  │                       │
│ Bench Data       │  6. DemandKPI             │                       │
│ YTD Fulfillment  │  7. MasterKPI (unified)   │                       │
│ Closed Deals     │  8. InsightEngine (AI)    │                       │
│                  │  9. DashboardBuilder      │                       │
└──────────────────┴──────────────────────────┴───────────────────────┘
```

## Cross-Sheet Relationship Map

```
┌─────────────────┐      OpportunityID      ┌──────────────┐
│  SF Pipeline    │─────────────────────────►│  Demand Data │
└────────┬────────┘                          └──────┬───────┘
         │ AccountName                              │ RequestID
         ▼                                          ▼
┌─────────────────┐                         ┌──────────────────┐
│ Master Ref      │◄────IBU/GEO─────────────│  YTD Fulfillment │
└─────────────────┘   (all sheets)          └──────────────────┘
         ▲                                          ▲
         │                                          │ Employee Code
┌─────────────────┐      Employee No        ┌──────────────────┐
│ Employee Master │◄────────────────────────│  Bench Data      │
└────────┬────────┘                         └──────────────────┘
         │ Customer Name
         ▼
┌─────────────────┐      OpportunityID      ┌──────────────────┐
│ Finance Tracker │      ┌──────────────────│  Closed Deals    │
└─────────────────┘      │  SF Pipeline     └──────────────────┘
                         └──────────────────►
```

## Data Flow (9 Steps)

```
Step 1: MultiSheetLoader.load(file)
  ├── Detect sheet names (alias matching)
  ├── Finance: parse multi-row merged header → tidy long format
  └── Others: standard pd.read_excel + column cleaning

Step 2: RelationshipMapper.map(sheets)
  ├── Validate 8 known join keys
  └── Flag which relationships are available vs missing

Step 3: FinanceKPI.calculate(finance_df)
  ├── Filter monthly periods (exclude Q/FY rows)
  ├── Pivot Revenue / Expenses / GM% series
  └── Calculate FY totals, best/worst month

Step 4: SalesforceKPI.calculate_pipeline(sf_df)
     SalesforceKPI.calculate_closed(closed_df)
  ├── TCV/ACV totals, stage breakdown, BU breakdown
  ├── Win rate, margin, AI deal %
  └── Quarter analysis

Step 5: PeopleKPI.calculate_employee(emp_df)
         PeopleKPI.calculate_bench(bench_df)
         PeopleKPI.calculate_fulfillment(ful_df)
  ├── Billed HC %, practice/IBU/geo distribution
  ├── Bench availability, ageing, skill clusters
  └── FFTP, internal%, quarter breakdown

Step 6: DemandKPI.calculate(demand_df)
  ├── Open RRs, ageing distribution
  └── IBU breakdown, skill category, FFTP

Step 7: MasterKPI.calculate(all_kpis)
  ├── Aggregate cross-source KPIs
  ├── Health score (0-100 composite)
  └── Cross-source insights list

Step 8: InsightEngine.generate(all_kpis, agent)
  ├── Try AI: agent.analyze_multi_source(all_kpis)
  └── Fallback: rule_based_insights(all_kpis, config)

Step 9: DashboardBuilder.build(all_kpis, rels, insights)
         ReportBuilder.build(master, insights)
  ├── Inject JS data variables
  ├── Build insight/relationship HTML
  └── Write dashboard.html + executive_report.html
```

## File Reference

| File | Edit? | Purpose |
|------|-------|---------|
| `config.yaml` | ✅ Yes | All thresholds, aliases, refresh schedule |
| `core/multi_sheet_loader.py` | Rarely | Sheet loading + Finance header parsing |
| `core/relationship_mapper.py` | ✅ Add rules | Cross-sheet join definitions |
| `core/finance_kpi.py` | Add metrics | Finance calculations |
| `core/salesforce_kpi.py` | Add metrics | SF pipeline + closed |
| `core/people_kpi.py` | Add metrics | Employee + bench + fulfillment |
| `core/demand_kpi.py` | Add metrics | Demand RR analysis |
| `core/master_kpi.py` | ✅ Add rules | Health score + cross insights |
| `agents/base_agent.py` | Add providers | AI provider implementations |
| `agents/insight_engine.py` | ✅ Edit prompt | AI + rule-based insights |
| `ui/dashboard_builder.py` | Rarely | Template binding logic |
| `templates/dashboard.html` | ✅ Yes | Visual design + charts |
| `main.py` | Rarely | Pipeline orchestration |
