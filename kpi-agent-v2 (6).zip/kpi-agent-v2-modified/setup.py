from setuptools import setup, find_packages

setup(
    name="kpi-agent-v2",
    version="2.0.0",
    description="Unified multi-source KPI dashboard with AI insights for D&A PMO",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=open("requirements.txt").read().splitlines(),
    entry_points={"console_scripts": ["kpi-agent=main:main"]},
)
