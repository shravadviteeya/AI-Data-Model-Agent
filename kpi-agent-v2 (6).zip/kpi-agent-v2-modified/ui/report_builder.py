"""
Report Builder v2 — executive summary HTML report.
"""

from typing import Dict, List, Any
from datetime import datetime
from loguru import logger


class ReportBuilder:
    def __init__(self, config: dict):
        self.cfg = config
        self.sym = config.get('dashboard', {}).get('currency_symbol', '$')
        self.company = config.get('dashboard', {}).get('company', 'Coforge')

    def build(self, master: Dict[str, Any],
              insights: List[Dict]) -> str:
        logger.info("Building executive report...")
        score = master.get('health_score', 75)
        score_col = ('#28a745' if score >= 75 else
                     '#ffc107' if score >= 50 else '#dc3545')
        now_str = datetime.now().strftime('%d %b %Y')

        kpi_html = ''
        kpi_items = [
            ('FY Revenue',       master.get('fy_revenue_fmt','N/A'),     '#28a745'),
            ('Pipeline TCV',     master.get('pipeline_tcv_fmt','N/A'),   '#17a2b8'),
            ('Win Rate',         f"{master.get('win_rate',0):.1f}%",     '#28a745' if master.get('win_rate',0)>=40 else '#ffc107'),
            ('Avg GM%',          f"{master.get('avg_gm_pct',0):.1f}%",   '#28a745' if master.get('avg_gm_pct',0)>=35 else '#dc3545'),
            ('Total HC',         str(master.get('total_hc',0)),           '#6c757d'),
            ('Bench Available',  str(master.get('bench_available',0)),    '#17a2b8'),
            ('Open RRs',         str(master.get('open_rrs',0)),           '#ffc107'),
            ('Billed HC%',       f"{master.get('billed_pct',0):.1f}%",   '#28a745' if master.get('billed_pct',0)>=85 else '#ffc107'),
        ]
        for lbl, val, col in kpi_items:
            kpi_html += f'''
<td style="padding:6px;">
  <div style="background:#f8f9fa;border-radius:6px;padding:12px;
              text-align:center;border-top:3px solid {col};">
    <div style="font-size:9px;color:#6c757d;text-transform:uppercase;
                letter-spacing:.06em;margin-bottom:3px;">{lbl}</div>
    <div style="font-size:18px;font-weight:700;color:#212529;">{val}</div>
  </div>
</td>'''

        type_styles = {
            'strength':       ('#d4edda','#155724','Strength'),
            'concern':        ('#fff3cd','#856404','Concern'),
            'recommendation': ('#d1ecf1','#0c5460','Recommendation'),
            'opportunity':    ('#d1ecf1','#0c5460','Opportunity'),
            'risk':           ('#f8d7da','#721c24','Risk'),
            'info':           ('#e2e3e5','#383d41','Insight'),
        }
        findings_html = ''
        for ins in insights[:6]:
            bg, col, pfx = type_styles.get(ins.get('type','info'),
                                            type_styles['info'])
            srcs = ', '.join(ins.get('sources', []))
            findings_html += f'''
<tr><td style="padding:7px 0;">
  <div style="background:{bg};border-radius:5px;padding:9px 12px;">
    <span style="font-size:9px;font-weight:700;color:{col};
                 text-transform:uppercase;">{pfx}
    {(' · <span style="font-weight:400">' + srcs + '</span>') if srcs else ''}</span>
    <p style="font-size:12px;color:#212529;margin:3px 0 0;
              line-height:1.5;">{ins.get("text","")}</p>
  </div>
</td></tr>'''

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Executive Report — {self.company}</title>
<style>
body{{font-family:Arial,sans-serif;margin:0;background:#f0f2f5;}}
.wrap{{max-width:820px;margin:0 auto;background:white;}}
.hdr{{background:linear-gradient(135deg,#1a1a2e,#16213e);
      color:white;padding:26px 28px;}}
h1{{font-size:20px;font-weight:700;margin:0 0 4px;}}
.sec{{padding:18px 28px;border-bottom:1px solid #dee2e6;}}
h2{{font-size:14px;color:#212529;margin:0 0 10px;
    padding-bottom:6px;border-bottom:2px solid #dee2e6;}}
table{{width:100%;border-collapse:collapse;}}
th{{background:#f8f9fa;padding:7px 10px;font-size:10px;color:#6c757d;
    text-transform:uppercase;letter-spacing:.05em;
    border-bottom:2px solid #dee2e6;text-align:left;}}
.ftr{{background:#f8f9fa;padding:14px 28px;text-align:center;
      font-size:10px;color:#6c757d;}}
</style>
</head>
<body>
<div class="wrap">
  <div class="hdr">
    <div style="font-size:10px;opacity:.7;margin-bottom:5px;
                letter-spacing:.1em;text-transform:uppercase;">
      Executive Report · Wireframe 2 · {now_str}</div>
    <h1>{self.company} — Unified PMO Intelligence Report</h1>
    <div style="margin-top:12px;">
      <span style="font-size:12px;opacity:.8;">Health Score </span>
      <span style="font-size:26px;font-weight:700;color:{score_col};">{score}</span>
      <span style="font-size:12px;opacity:.8;">/100 · {master.get('health_label','Watch')}</span>
    </div>
  </div>
  <div class="sec">
    <table><tr style="display:flex;flex-wrap:wrap;">{kpi_html}</tr></table>
  </div>
  <div class="sec">
    <h2>Key Findings & Recommendations</h2>
    <table><tbody>{findings_html}</tbody></table>
  </div>
  <div class="ftr">
    KPI Intelligence Agent v2 · Wireframe 2 · {self.company} · {now_str}
  </div>
</div>
</body></html>"""
