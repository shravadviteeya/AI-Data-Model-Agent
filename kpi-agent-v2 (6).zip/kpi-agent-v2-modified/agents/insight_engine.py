"""
Insight Engine — generates AI + rule-based insights
from all 8 data sources combined.
"""

from typing import Dict, List, Any
from loguru import logger


def rule_based_insights(all_kpis: Dict[str, Dict],
                         config: dict) -> List[Dict]:
    """Generate structured insights without AI."""
    t = config.get('kpis', {})
    insights = []
    fin  = all_kpis.get('finance', {})
    pipe = all_kpis.get('pipeline', {})
    cl   = all_kpis.get('closed', {})
    dem  = all_kpis.get('demand', {})
    bench= all_kpis.get('bench', {})
    emp  = all_kpis.get('employee', {})
    ful  = all_kpis.get('fulfillment', {})

    # ── Finance insights ──────────────────────────────────────
    gm = fin.get('avg_gm_pct', 35)
    if gm >= t.get('gm_healthy', 35):
        insights.append({'type':'strength',
            'text': f"GM% at {gm}% is above the 35% healthy threshold — pricing and cost discipline is strong.",
            'sources':['finance']})
    else:
        insights.append({'type':'concern',
            'text': f"GM% at {gm}% is below the 35% threshold — review direct cost composition for {fin.get('customer','the account')}.",
            'sources':['finance']})

    worst = fin.get('worst_month','N/A')
    worst_gm = fin.get('worst_month_gm', 0)
    if worst_gm < 0:
        insights.append({'type':'concern',
            'text': f"{worst} posted negative GM% ({worst_gm}%) — investigate cost spike or revenue recognition delay.",
            'sources':['finance']})

    # ── Pipeline insights ─────────────────────────────────────
    deals = pipe.get('total_deals', 0)
    tcv   = pipe.get('total_tcv', 0)
    ai_pct= pipe.get('ai_deals_pct', 0)
    if deals > 0:
        insights.append({'type':'info',
            'text': f"Pipeline has {deals} open deal(s) worth {pipe.get('total_tcv_fmt','N/A')} TCV. Avg probability: {pipe.get('avg_probability',0):.0f}%.",
            'sources':['sf_pipeline']})
    if ai_pct < 30 and deals > 0:
        insights.append({'type':'recommendation',
            'text': f"Only {ai_pct:.0f}% of pipeline proposals include AI — embed AI assets to differentiate and improve win rates.",
            'sources':['sf_pipeline']})

    # ── Win rate ─────────────────────────────────────────────
    wr = cl.get('win_rate', 0)
    if wr >= t.get('win_rate_good', 50):
        insights.append({'type':'strength',
            'text': f"Win rate of {wr}% exceeds the 50% benchmark — strong sales-to-close conversion.",
            'sources':['closed']})
    elif wr > 0:
        insights.append({'type':'concern',
            'text': f"Win rate at {wr}% — below 50% benchmark. Focus on later-stage pipeline qualification.",
            'sources':['closed']})

    # ── Bench vs Demand match ─────────────────────────────────
    avail = bench.get('available', 0)
    open_rrs = dem.get('total_open', 0)
    if avail > 0 and open_rrs > 0:
        insights.append({'type':'opportunity',
            'text': f"{avail} bench resource(s) available vs {open_rrs} open RR(s) — cross-match skills to fulfill internally before external hiring.",
            'sources':['bench','demand']})

    # ── Fulfillment efficiency ────────────────────────────────
    fftp = ful.get('avg_fftp', 0)
    int_pct = ful.get('internal_pct', 0)
    if abs(fftp) <= t.get('fftp_good', 15):
        insights.append({'type':'strength',
            'text': f"Avg FFTP of {fftp} days — fulfillment is within the 15-day target. {int_pct:.0f}% fulfilled internally.",
            'sources':['fulfillment']})
    else:
        insights.append({'type':'concern',
            'text': f"Avg FFTP {fftp} days exceeds 15-day target — review TA pipeline and RDG response times.",
            'sources':['fulfillment']})

    # ── Billed HC ─────────────────────────────────────────────
    bp = emp.get('billed_pct', 0)
    if bp >= t.get('billed_pct_good', 85):
        insights.append({'type':'strength',
            'text': f"Billed HC at {bp}% — above 85% target. Headcount is well-utilised.",
            'sources':['employee']})
    elif bp > 0:
        insights.append({'type':'recommendation',
            'text': f"Billed HC at {bp}% — below 85% target. Deploy {emp.get('unbilled_hc',0)} unbilled resources to active projects urgently.",
            'sources':['employee','bench']})

    return insights[:8]


def parse_ai_insights(text: str) -> List[Dict]:
    """Parse [S]/[C]/[R] tagged AI response into structured list."""
    insights = []
    type_map = {'S': 'strength', 'C': 'concern', 'R': 'recommendation'}
    for line in text.strip().split('\n'):
        line = line.strip()
        for tag, itype in type_map.items():
            if line.startswith(f'[{tag}]'):
                txt = line[3:].strip()
                if txt:
                    insights.append({'type': itype, 'text': txt,
                                     'sources': []})
                break
    return insights


class InsightEngine:
    def __init__(self, config: dict):
        self.cfg = config

    def generate(self, all_kpis: dict, agent) -> List[Dict]:
        """Try AI first, fall back to rules."""
        try:
            raw = agent.analyze_multi_source(all_kpis)
            if raw and len(raw) > 80:
                parsed = parse_ai_insights(raw)
                if len(parsed) >= 3:
                    logger.success(f"AI generated {len(parsed)} insights")
                    return parsed
        except Exception as e:
            logger.warning(f"AI insight generation failed: {e}")
        logger.info("Using rule-based insight generation")
        return rule_based_insights(all_kpis, self.cfg)
