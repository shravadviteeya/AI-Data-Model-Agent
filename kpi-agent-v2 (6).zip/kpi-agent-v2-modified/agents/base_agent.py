"""
AI Agent base class, all providers, and factory.
Identical interface — swap providers via .env AI_PROVIDER.
"""

import os
import json
from abc import ABC, abstractmethod
from typing import Dict, List
from loguru import logger


class BaseAgent(ABC):
    name = "BaseAgent"

    @abstractmethod
    def is_available(self) -> bool: ...

    @abstractmethod
    def generate(self, prompt: str) -> str: ...

    def analyze_multi_source(self, all_kpis: dict) -> str:
        """Generate executive insights from all 8 source KPIs."""
        fin  = all_kpis.get('finance', {})
        pipe = all_kpis.get('pipeline', {})
        cl   = all_kpis.get('closed', {})
        dem  = all_kpis.get('demand', {})
        bench= all_kpis.get('bench', {})
        emp  = all_kpis.get('employee', {})
        mast = all_kpis.get('master', {})

        prompt = f"""You are a senior PMO consultant analysing 8 data sources for Coforge D&A practice.

DATA SNAPSHOT:
- FY Revenue: {fin.get('fy_revenue_fmt','N/A')} | Avg GM%: {fin.get('avg_gm_pct','N/A')}%
- Pipeline TCV: {pipe.get('total_tcv_fmt','N/A')} | Deals: {pipe.get('total_deals',0)} | AI proposals: {pipe.get('ai_deals_pct',0)}%
- Closed Won TCV: {cl.get('won_tcv_fmt','N/A')} | Win Rate: {cl.get('win_rate',0)}% | Avg Margin: {cl.get('avg_margin_pct',0)}%
- Open RRs: {dem.get('total_open',0)} | Avg Ageing: {dem.get('avg_fftp',0)} days
- Bench Available: {bench.get('available',0)} of {bench.get('total_bench',0)}
- Total HC: {emp.get('total_hc',0)} | Billed%: {emp.get('billed_pct',0)}%
- Health Score: {mast.get('health_score',0)}/100

Generate exactly 6 insights using this format:
[S] <strength — something going well>
[S] <strength>
[C] <concern — something to watch>
[C] <concern>
[R] <recommendation — specific action>
[R] <recommendation>

Be specific with numbers. One sentence each. Focus on cross-source findings."""

        return self.generate(prompt)


class FallbackAgent(BaseAgent):
    name = "Rule-based Agent"
    def is_available(self) -> bool: return True
    def generate(self, prompt: str) -> str: return ""
    def analyze_multi_source(self, all_kpis: dict) -> str: return ""


class AnthropicAgent(BaseAgent):
    name = "Claude (Anthropic)"
    def __init__(self):
        self.client = None
        self.model  = os.getenv('ANTHROPIC_MODEL', 'claude-sonnet-4-5')
        if self.is_available():
            try:
                import anthropic
                self.client = anthropic.Anthropic(
                    api_key=os.getenv('ANTHROPIC_API_KEY'))
            except ImportError:
                logger.warning("anthropic package not installed")

    def is_available(self) -> bool:
        return bool(os.getenv('ANTHROPIC_API_KEY'))

    def generate(self, prompt: str) -> str:
        if not self.client: return ""
        try:
            r = self.client.messages.create(
                model=self.model, max_tokens=2000,
                messages=[{"role": "user", "content": prompt}])
            return r.content[0].text
        except Exception as e:
            logger.error(f"Claude error: {e}")
            return ""


class OpenAIAgent(BaseAgent):
    name = "GPT-4 (OpenAI)"
    def __init__(self):
        self.client = None
        self.model  = os.getenv('OPENAI_MODEL', 'gpt-4o')
        if self.is_available():
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            except ImportError:
                logger.warning("openai package not installed")

    def is_available(self) -> bool:
        return bool(os.getenv('OPENAI_API_KEY'))

    def generate(self, prompt: str) -> str:
        if not self.client: return ""
        try:
            r = self.client.chat.completions.create(
                model=self.model, max_tokens=2000,
                messages=[{"role": "system",
                           "content": "You are a senior PMO data analyst."},
                          {"role": "user", "content": prompt}])
            return r.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI error: {e}")
            return ""


class CopilotAgent(BaseAgent):
    name = "GitHub Copilot"
    def __init__(self):
        self.client = None
        if self.is_available():
            try:
                from openai import OpenAI
                self.client = OpenAI(
                    api_key=os.getenv('GITHUB_TOKEN'),
                    base_url="https://models.inference.ai.azure.com")
            except ImportError:
                pass

    def is_available(self) -> bool:
        return bool(os.getenv('GITHUB_TOKEN'))

    def generate(self, prompt: str) -> str:
        if not self.client: return ""
        try:
            r = self.client.chat.completions.create(
                model="gpt-4o", max_tokens=2000,
                messages=[{"role": "user", "content": prompt}])
            return r.choices[0].message.content
        except Exception as e:
            logger.error(f"Copilot error: {e}")
            return ""


class AgentFactory:
    PROVIDERS = {
        "anthropic": AnthropicAgent,
        "openai":    OpenAIAgent,
        "copilot":   CopilotAgent,
    }

    @staticmethod
    def create(provider: str = "auto") -> BaseAgent:
        if provider == "auto":
            for name, cls in AgentFactory.PROVIDERS.items():
                a = cls()
                if a.is_available():
                    logger.info(f"Auto-selected AI: {a.name}")
                    return a
            logger.warning("No AI provider found — using rule-based fallback")
            return FallbackAgent()
        cls = AgentFactory.PROVIDERS.get(provider)
        if not cls:
            logger.warning(f"Unknown provider '{provider}' — using fallback")
            return FallbackAgent()
        a = cls()
        if not a.is_available():
            logger.warning(f"{provider} key not found — using fallback")
            return FallbackAgent()
        return a
