"""Unit tests for KPI Agent v2"""

import sys, pytest, pandas as pd, numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


class TestMultiSheetLoader:
    def setup_method(self):
        from core.multi_sheet_loader import MultiSheetLoader
        self.loader = MultiSheetLoader({'sheet_aliases': {
            'finance': ['FINANCE TRACKER'],
            'employee': ['EMPLOYEE MASTER'],
        }})

    def test_detect_sheets(self):
        available = ['FINANCE TRACKER','Master','EMPLOYEE MASTER']
        result = self.loader._detect_sheets(available)
        assert result['finance'] == 'FINANCE TRACKER'
        assert result['employee'] == 'EMPLOYEE MASTER'

    def test_clean_df(self):
        df = pd.DataFrame({'First Name ': [1,2], '  Col B': [3,4]})
        cleaned = self.loader._clean_df(df)
        assert 'First Name' in cleaned.columns

    def test_clean_df_drops_all_null(self):
        df = pd.DataFrame({'A': [1, None, 3], 'B': [None, None, None]})
        df.loc[1] = [None, None]
        cleaned = self.loader._clean_df(df)
        assert len(cleaned) <= 3


class TestFinanceKPI:
    def setup_method(self):
        from core.finance_kpi import FinanceKPI
        self.kpi = FinanceKPI({'dashboard': {'currency_symbol': '$'}})

    def _make_df(self):
        rows = []
        months = ['Apr25','May25','Jun25','Jul25','Aug25','Sep25',
                  'Oct25','Nov25','Dec25','Jan26','Feb26','Mar26']
        for m in months:
            rows.append({'geo':'US','cost_center':'BU1',
                         'customer':'Client A','period':m,
                         'metric':'Total Accrued Revenue',
                         'value':np.random.randint(200000,500000)})
            rows.append({'geo':'US','cost_center':'BU1',
                         'customer':'Client A','period':m,
                         'metric':'Total Direct Expenses',
                         'value':np.random.randint(100000,300000)})
            rows.append({'geo':'US','cost_center':'BU1',
                         'customer':'Client A','period':m,
                         'metric':'Gross Margin %',
                         'value':np.random.uniform(0.25, 0.45)})
        return pd.DataFrame(rows)

    def test_calculate_returns_keys(self):
        df = self._make_df()
        result = self.kpi.calculate(df)
        assert 'total_revenue' in result
        assert 'avg_gm_pct' in result
        assert 'months' in result
        assert 'revenue_series' in result

    def test_calculate_empty(self):
        result = self.kpi.calculate(pd.DataFrame())
        assert result == {}

    def test_gm_pct_converts_decimal(self):
        df = self._make_df()
        result = self.kpi.calculate(df)
        # GM% should be in percentage form (not 0-1)
        assert result['avg_gm_pct'] > 1


class TestSalesforceKPI:
    def setup_method(self):
        from core.salesforce_kpi import SalesforceKPI
        self.kpi = SalesforceKPI({'dashboard': {'currency_symbol': '$'}})

    def _make_pipeline(self):
        return pd.DataFrame([{
            'BU': 'US', 'VERTICAL': 'BFS',
            'TCV($)': 500000, 'ACV($)': 480000,
            'HBU_TCV($)': 500000,
            'Probability(%)': 40,
            'STAGE': '3 Propose',
            'PROPOSAL_CONTAINS_AI': 'Yes',
        } for _ in range(10)])

    def test_pipeline_kpis(self):
        df = self._make_pipeline()
        result = self.kpi.calculate_pipeline(df)
        assert result['total_deals'] == 10
        assert result['total_tcv'] == 5000000
        assert result['ai_deals_pct'] == 100.0

    def _make_closed(self):
        rows = []
        for i in range(10):
            rows.append({
                'TCV($)': 300000,
                'ACV($)': 290000,
                'HBU_TCV($)': 300000,
                'Status': 'Closed- Won' if i < 7 else 'Closed- Lost',
                'OverallMargin(%)': 30,
                'BU': 'US',
                'ActualCloseQTR': 'Q4 2026',
            })
        return pd.DataFrame(rows)

    def test_closed_win_rate(self):
        df = self._make_closed()
        result = self.kpi.calculate_closed(df)
        assert result['win_rate'] == 70.0
        assert result['total_won'] == 7


class TestPeopleKPI:
    def setup_method(self):
        from core.people_kpi import PeopleKPI
        self.kpi = PeopleKPI({})

    def test_employee_kpis(self):
        df = pd.DataFrame([{
            'Billed/Unbilled': 'Billed' if i < 8 else 'Unbilled',
            'IBU': 'Insurance NA',
            'Employee Group Practice': 'DATA & AI',
            'Geo': 'India',
            'Onsite/Offshore': 'Offshore',
        } for i in range(10)])
        result = self.kpi.calculate_employee(df)
        assert result['total_hc'] == 10
        assert result['billed_hc'] == 8
        assert result['billed_pct'] == 80.0

    def test_bench_kpis(self):
        df = pd.DataFrame([{
            'Status': 'Available' if i < 5 else 'Positioned',
            'Pool Type': 'Data Pool',
            'Skill Cluster': 'Data Engineering',
            'Ageing (Days)': '0-15 Days',
        } for i in range(8)])
        result = self.kpi.calculate_bench(df)
        assert result['total_bench'] == 8
        assert result['available'] == 5


class TestDemandKPI:
    def setup_method(self):
        from core.demand_kpi import DemandKPI
        self.kpi = DemandKPI({})

    def test_demand_kpis(self):
        df = pd.DataFrame([{
            'RequestID': 1000 + i,
            'IBU': 'Insurance EU',
            'Open Position': 1,
            'Requested Positions': 1,
            'RR Status': 'Pending with TA',
            'Ageing Range': '>15 to 30 Days',
            'Skill Category': 'Niche',
            'FFTP': 10,
            'WIP': 1,
            'Offered': 0,
        } for i in range(5)])
        result = self.kpi.calculate(df)
        assert result['total_rrs'] == 5
        assert result['total_open'] == 5


class TestMasterKPI:
    def setup_method(self):
        from core.master_kpi import MasterKPI
        self.kpi = MasterKPI({'kpis': {
            'gm_healthy': 35, 'gm_critical': 20,
            'win_rate_good': 50, 'win_rate_benchmark': 40,
            'billed_pct_good': 85, 'billed_pct_warn': 75,
            'fftp_good': 15, 'fftp_warn': 30,
        }})

    def test_health_score_range(self):
        all_kpis = {
            'finance': {'avg_gm_pct': 38, 'fy_revenue': 5000000,
                        'fy_revenue_fmt': '$5M', 'total_gm_fmt': '$2M',
                        'best_month': 'Oct25', 'worst_month': 'Jul25'},
            'pipeline': {'total_tcv': 2000000, 'total_tcv_fmt': '$2M',
                         'total_deals': 10, 'ai_deals_pct': 30},
            'closed': {'win_rate': 55, 'won_tcv': 1000000,
                       'won_tcv_fmt': '$1M', 'avg_margin_pct': 32},
            'demand': {'total_open': 5, 'avg_fftp': 10},
            'bench': {'total_bench': 8, 'available': 3},
            'fulfillment': {'total_fulfilled': 20, 'avg_fftp': 8,
                            'internal_pct': 70},
            'employee': {'total_hc': 100, 'billed_pct': 88,
                         'unbilled_hc': 12},
        }
        result = self.kpi.calculate(all_kpis)
        assert 0 <= result['health_score'] <= 100
        assert result['health_label'] in ('Healthy','Watch','At Risk')
        assert isinstance(result['cross_insights'], list)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
