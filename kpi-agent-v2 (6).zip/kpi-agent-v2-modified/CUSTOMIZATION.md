# 🎨 Customization Guide — Wireframe 2

Complete guide for extending the 8-source unified dashboard.

---

## 1. Add a New Data Source (9th Sheet)

**Step 1** — Add alias in `config.yaml`:
```yaml
sheet_aliases:
  my_new_source: ["MY SHEET NAME", "My Sheet", "alternate_name"]
  refresh_schedule:
    my_new_source: "Weekly"
```

**Step 2** — Create `core/my_source_kpi.py`:
```python
from typing import Dict, Any
import pandas as pd

class MySourceKPI:
    def __init__(self, config): self.cfg = config
    def calculate(self, df: pd.DataFrame) -> Dict[str, Any]:
        if df is None or df.empty: return {}
        return {
            'total_records': len(df),
            'my_metric': df['my_column'].sum(),
        }
```

**Step 3** — Load it in `main.py`:
```python
from core.my_source_kpi import MySourceKPI
my_kpis = MySourceKPI(config).calculate(sheets.get('my_new_source'))
all_kpis['my_source'] = my_kpis
```

**Step 4** — Add to `core/master_kpi.py` `calculate()`:
```python
my = all_kpis.get('my_source', {})
master['my_metric'] = my.get('my_metric', 0)
```

---

## 2. Change KPI Thresholds (No Code Needed)

Edit `config.yaml`:
```yaml
kpis:
  gm_healthy:           40.0   # Was 35 — raise the bar
  win_rate_good:        55.0   # Was 50 — more demanding
  billed_pct_good:      90.0   # Was 85
  bench_ageing_warn:    20     # Was 30 — flag sooner
  demand_ageing_warn:   15     # Was 30 — tighter SLA
```

---

## 3. Add a New Cross-Sheet Relationship

Open `core/relationship_mapper.py` and add to `KNOWN_RELATIONSHIPS`:
```python
{
    "from_sheet":  "my_new_source",
    "from_field":  "Employee_ID",
    "to_sheet":    "employee",
    "to_field":    "Employee No",
    "type":        "many-to-one",
    "description": "My source links to employee master",
    "join_key":    "employee_id",
},
```

---

## 4. Add a New KPI Card to the Dashboard

In `ui/dashboard_builder.py` → `build()` method, add to `replacements`:
```python
'KV_MY_METRIC': str(my_kpis.get('my_metric', 0)),
```

In `templates/dashboard.html`, add a card tile:
```html
<div class="kpi" style="--kc:#534AB7;">
  <div class="kpi-lbl">My Metric</div>
  <div class="kpi-val">{KV_MY_METRIC}</div>
  <div class="kpi-sub">Source: My Sheet</div>
</div>
```

---

## 5. Change the AI Insight Prompt

Open `agents/base_agent.py` → `analyze_multi_source()`:
```python
prompt = f"""You are a [YOUR ROLE] for [YOUR COMPANY].

Focus on:
- [Your priority 1]
- [Your priority 2]

Data: ...
```

---

## 6. Change Dashboard Colors

Open `templates/dashboard.html`, edit CSS variables:
```css
:root {
  --bg: #0a0e1a;          /* Main background */
  --surface: #111827;     /* Card background */
  --accent: #00d97e;      /* Primary green accent */
  --accent2: #3b82f6;     /* Secondary blue */
  --accent3: #f59e0b;     /* Amber/warning */
  --accent4: #ec4899;     /* Pink */
}
```

Switch to light theme:
```yaml
# config.yaml
dashboard:
  theme: light
```

---

## 7. Change Refresh Schedule Labels

```yaml
# config.yaml
refresh_schedule:
  finance:      "Monthly"       # change to "Bi-weekly"
  sf_pipeline:  "Daily"         # change to "Every 4 hours"
  demand:       "Daily"
  bench:        "Real-time"     # new label
```

---

## 8. Add a New Risk Rule (for Executive Report)

Open `core/master_kpi.py` → `_cross_insights()`:
```python
# Add after existing rules:
lost_deals = cl.get('total_lost', 0)
total_deals = cl.get('total_won', 0) + lost_deals
if total_deals > 0 and lost_deals / total_deals > 0.4:
    insights.append({
        'type': 'risk',
        'text': f"Loss rate {lost_deals/total_deals*100:.0f}% is above 40% — review deal qualification process.",
        'sources': ['closed']
    })
```

---

## 9. Add Auto Email Scheduling

In `.env`:
```env
EMAIL_SENDER=pmo@coforge.com
EMAIL_PASSWORD=your_app_password
EMAIL_SMTP=smtp.office365.com
EMAIL_PORT=587
LEADERSHIP_EMAILS=ceo@coforge.com,vp@coforge.com
```

In `config.yaml`:
```yaml
report:
  send_email: true
  frequency: weekly
  send_time: "08:00"
```

Run on schedule:
```bash
python main.py --file DATA2.xlsx --schedule
```

---

## 10. Column Name Mapping

If your Excel uses different column names, add aliases in `config.yaml`:
```yaml
# The agent auto-detects these column names
# Add your custom names to the list
column_aliases:
  revenue:    ["Revenue", "Rev", "Total Revenue", "MY_REV_COL"]
  ibu:        ["IBU", "Business Unit", "BU_NAME"]
  employee_no: ["Employee No", "Emp ID", "EMPID", "EMP_CODE"]
```

---

## Wireframe Roadmap

| Wireframe | Status | Key Feature Added |
|-----------|--------|------------------|
| **1** | ✅ Done | Single Excel, core KPIs |
| **2** | ✅ Done | 8-sheet multi-source, relationships |
| **3** | 🔜 Next | Power BI MCP + live auto-refresh |
| **4** | 🔜 Next | Salesforce direct API (no export) |
| **5** | 🔜 Next | Predictive forecast + scenario planning |
