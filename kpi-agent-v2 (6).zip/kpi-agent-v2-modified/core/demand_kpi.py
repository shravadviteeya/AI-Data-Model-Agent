"""
Demand KPI Calculator — Demand Data sheet (open RRs).
"""

import pandas as pd
from typing import Dict, Any
from loguru import logger


class DemandKPI:
    """KPIs for the Demand Data sheet."""

    def __init__(self, config: dict):
        self.cfg = config

    def calculate(self, df: pd.DataFrame) -> Dict[str, Any]:
        if df is None or df.empty:
            return {}

        total_rrs  = len(df)
        open_col   = next((c for c in df.columns if c == 'Open Position'), None)
        req_col    = next((c for c in df.columns if 'Requested Positions' in c), None)
        status_col = 'RR Status'
        aging_col  = next((c for c in df.columns if 'Ageing Range' in c), None)
        ibu_col    = 'IBU'
        skill_col  = 'Skill Category'
        fftp_col   = next((c for c in df.columns if c == 'FFTP'), None)
        sub_ibu    = 'Sub IBU'
        demand_cat = next((c for c in df.columns if 'Demand category' in c), None)
        wip_col    = 'WIP'
        offered_col = 'Offered'

        total_open  = int(df[open_col].sum())  if open_col  else 0
        total_req   = int(df[req_col].sum())   if req_col   else 0
        total_wip   = int(df[wip_col].sum())   if wip_col in df.columns else 0
        total_offered = int(df[offered_col].sum()) if offered_col in df.columns else 0
        avg_fftp    = round(float(df[fftp_col].mean()), 1) if fftp_col else 0

        by_status   = self._vcounts(df, status_col)
        by_ibu      = (df.groupby(ibu_col)[open_col].sum()
                       .sort_values(ascending=False).head(8).to_dict()
                       if ibu_col in df.columns and open_col else {})
        by_aging    = self._vcounts(df, aging_col)
        by_skill    = (df.groupby(skill_col)[open_col].sum()
                       .sort_values(ascending=False).to_dict()
                       if skill_col in df.columns and open_col else {})
        by_sub_ibu  = (df.groupby(sub_ibu)[open_col].sum()
                       .sort_values(ascending=False).head(6).to_dict()
                       if sub_ibu in df.columns and open_col else {})
        by_dem_cat  = self._vcounts(df, demand_cat)

        out = {
            'total_rrs':      total_rrs,
            'total_open':     total_open,
            'total_requested': total_req,
            'total_wip':      total_wip,
            'total_offered':  total_offered,
            'avg_fftp':       avg_fftp,
            'by_status':      by_status,
            'by_ibu':         {str(k): int(v) for k, v in by_ibu.items()},
            'by_aging':       by_aging,
            'by_skill_cat':   {str(k): int(v) for k, v in by_skill.items()},
            'by_sub_ibu':     {str(k): int(v) for k, v in by_sub_ibu.items()},
            'by_demand_cat':  by_dem_cat,
        }
        logger.success(f"Demand KPIs: {total_rrs} RRs, "
                       f"{total_open} open, avg FFTP={avg_fftp}")
        return out

    def _vcounts(self, df, col) -> dict:
        if col and col in df.columns:
            return df[col].value_counts().head(8).to_dict()
        return {}
