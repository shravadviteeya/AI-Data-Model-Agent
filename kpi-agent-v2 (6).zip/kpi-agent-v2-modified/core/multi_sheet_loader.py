"""
Multi-Sheet Loader — intelligently reads all 8 source sheets.
Handles merged headers (Finance), date formats, and column aliases.
"""

import pandas as pd
import numpy as np
import warnings
from pathlib import Path
from typing import Dict, Optional
from loguru import logger

warnings.filterwarnings('ignore')


class MultiSheetLoader:
    """Loads and normalises all 8 sheets from the unified Excel file."""

    def __init__(self, config: dict):
        self.cfg = config
        self.aliases = config.get('sheet_aliases', {})
        self.sheets: Dict[str, Optional[pd.DataFrame]] = {
            'finance': None, 'master': None, 'employee': None,
            'sf_pipeline': None, 'demand': None, 'bench': None,
            'fulfillment': None, 'closed': None,
        }
        self.raw_finance = None   # keeps raw for multi-row header parsing

    def load(self, file_path: str) -> Dict[str, Optional[pd.DataFrame]]:
        """Load all sheets from the file. Returns dict of DataFrames."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        logger.info(f"Opening: {path.name}")
        xl = pd.ExcelFile(file_path)
        available = xl.sheet_names
        logger.info(f"Found {len(available)} sheets: {available}")

        # Map each logical key to its actual sheet name
        mapping = self._detect_sheets(available)

        for key, sheet_name in mapping.items():
            if sheet_name is None:
                logger.warning(f"  Sheet '{key}' not found in file")
                continue
            try:
                if key == 'finance':
                    self.sheets[key] = self._load_finance(file_path, sheet_name)
                else:
                    df = pd.read_excel(file_path, sheet_name=sheet_name)
                    df = self._clean_df(df)
                    self.sheets[key] = df
                    logger.info(f"  Loaded '{key}' ({sheet_name}): "
                                f"{len(df)} rows × {len(df.columns)} cols")
            except Exception as e:
                logger.error(f"  Failed to load '{key}': {e}")

        return self.sheets

    def _detect_sheets(self, available: list) -> dict:
        """Map logical keys to actual sheet names using aliases."""
        result = {k: None for k in self.sheets}
        avail_lower = {s.lower().strip(): s for s in available}
        for key, aliases in self.aliases.items():
            for alias in aliases:
                if alias.lower() in avail_lower:
                    result[key] = avail_lower[alias.lower()]
                    break
        return result

    def _load_finance(self, file_path: str, sheet_name: str) -> pd.DataFrame:
        """
        Finance Tracker has a multi-row merged header structure:
          Row 3: Measures
          Row 4: Version
          Row 5: Account (Revenue / Expenses / GM%)
          Row 6: Date columns (Apr25, May25 … FY2026)
          Row 7: Geo, Cost Center, Customer
          Row 8+: Data rows
        Returns a tidy long-format DataFrame.
        """
        raw = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
        self.raw_finance = raw

        # Find header rows
        date_row_idx = None
        for i, row in raw.iterrows():
            vals = [str(v) for v in row if str(v) != 'nan']
            if any(v.startswith('Apr') or v.startswith('FY') or
                   v.startswith('Q1') for v in vals):
                date_row_idx = i
                break

        if date_row_idx is None:
            logger.warning("Finance: could not find date header row")
            return pd.DataFrame()

        metric_row_idx  = date_row_idx - 1  # Account row (Revenue/Expenses/GM%)
        dim_row_idx     = date_row_idx + 1  # Geo/CostCenter/Customer

        dates   = list(raw.iloc[date_row_idx])
        metrics = list(raw.iloc[metric_row_idx])

        # Build column metadata: col_idx → (date_label, metric_name)
        col_meta = {}
        for col_idx in range(3, raw.shape[1]):
            date_lbl   = str(dates[col_idx])   if str(dates[col_idx])   != 'nan' else None
            metric_lbl = str(metrics[col_idx]) if str(metrics[col_idx]) != 'nan' else None
            if date_lbl and metric_lbl:
                col_meta[col_idx] = (date_lbl, metric_lbl)

        # Parse data rows (dim_row_idx + 1 onwards)
        records = []
        for row_i in range(dim_row_idx + 1, raw.shape[0]):
            row = raw.iloc[row_i]
            geo_val = str(row.iloc[0]) if str(row.iloc[0]) != 'nan' else None
            cc_val  = str(row.iloc[1]) if str(row.iloc[1]) != 'nan' else None
            cust    = str(row.iloc[2]) if str(row.iloc[2]) != 'nan' else None
            if not geo_val:
                continue
            for col_idx, (date_lbl, metric_lbl) in col_meta.items():
                val = row.iloc[col_idx]
                try:
                    val = float(val)
                except (ValueError, TypeError):
                    val = np.nan
                records.append({
                    'geo': geo_val,
                    'cost_center': cc_val,
                    'customer': cust,
                    'period': date_lbl,
                    'metric': metric_lbl.strip(),
                    'value': val,
                })

        df = pd.DataFrame(records)
        logger.info(f"  Loaded 'finance' ({sheet_name}): "
                    f"{len(df)} records (tidy format)")
        return df

    def _clean_df(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardise column names and drop fully-empty rows."""
        df.columns = [
            str(c).strip().replace('\n', ' ').replace('  ', ' ')
            for c in df.columns
        ]
        # Fix date columns stored as numbers
        for col in df.columns:
            if 'date' in col.lower() or 'doj' in col.lower():
                try:
                    df[col] = pd.to_datetime(df[col], errors='coerce',
                                              format='mixed')
                except Exception:
                    pass
        df = df.dropna(how='all').reset_index(drop=True)
        return df
