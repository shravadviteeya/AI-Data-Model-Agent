"""
People KPI Calculator — Employee Master + Bench + YTD Fulfillment.
"""

import pandas as pd
from typing import Dict, Any
from loguru import logger


class PeopleKPI:
    """KPIs across Employee Master, Bench Data, and YTD Fulfillment."""

    def __init__(self, config: dict):
        self.cfg = config

    def calculate_employee(self, df: pd.DataFrame) -> Dict[str, Any]:
        if df is None or df.empty:
            return {}

        total = len(df)
        billed_col  = next((c for c in df.columns
                            if 'Billed' in c and 'Un' not in c
                            and '/' in c), 'Billed/Unbilled')
        onsite_col  = next((c for c in df.columns
                            if 'Onsite' in c or 'Offshore' in c), None)
        ibu_col     = next((c for c in df.columns if c == 'IBU'), None)
        prac_col    = next((c for c in df.columns
                            if 'Group Practice' in c), None)
        geo_col     = next((c for c in df.columns if c == 'Geo'), None)
        skill_col   = next((c for c in df.columns
                            if 'Skill Area' in c or 'Skill Cluster' in c), None)

        billed = (int((df[billed_col] == 'Billed').sum())
                  if billed_col in df.columns else 0)
        billed_pct = round(billed / total * 100, 1) if total else 0

        by_ibu     = self._top(df, ibu_col, 8)
        by_practice = self._top(df, prac_col, 6)
        by_geo      = self._top(df, geo_col, 6)
        by_onsite   = self._vcounts(df, onsite_col)
        by_billed   = self._vcounts(df, billed_col)
        by_skill    = self._top(df, skill_col, 6)

        out = {
            'total_hc':        total,
            'billed_hc':       billed,
            'unbilled_hc':     total - billed,
            'billed_pct':      billed_pct,
            'by_ibu':          by_ibu,
            'by_practice':     by_practice,
            'by_geo':          by_geo,
            'by_onsite':       by_onsite,
            'by_billed':       by_billed,
            'by_skill':        by_skill,
        }
        logger.success(f"Employee KPIs: {total} HC, {billed_pct}% billed")
        return out

    def calculate_bench(self, df: pd.DataFrame) -> Dict[str, Any]:
        if df is None or df.empty:
            return {}

        total = len(df)
        status_col  = 'Status'
        aging_col   = next((c for c in df.columns if 'Ageing' in c), None)
        pool_col    = 'Pool Type'
        skill_col   = 'Skill Cluster'
        days_col    = next((c for c in df.columns
                            if 'Days in RP' in c or 'Days_in' in c), None)

        avail   = (int((df[status_col] == 'Available').sum())
                   if status_col in df.columns else 0)
        avail_pct = round(avail / total * 100, 1) if total else 0

        avg_days = (round(float(df[days_col].mean()), 1)
                    if days_col and days_col in df.columns else 0)

        by_pool    = self._vcounts(df, pool_col)
        by_status  = self._vcounts(df, status_col)
        by_aging   = self._vcounts(df, aging_col)
        by_skill   = self._top(df, skill_col, 6)

        out = {
            'total_bench':   total,
            'available':     avail,
            'available_pct': avail_pct,
            'avg_days_in_pool': avg_days,
            'by_pool':       by_pool,
            'by_status':     by_status,
            'by_aging':      by_aging,
            'by_skill':      by_skill,
        }
        logger.success(f"Bench KPIs: {total} total, {avail} available")
        return out

    def calculate_fulfillment(self, df: pd.DataFrame) -> Dict[str, Any]:
        if df is None or df.empty:
            return {}

        total = len(df)
        fftp_col  = next((c for c in df.columns if 'FFTP' in c), None)
        type_col  = 'Employee Type'
        qtr_col   = 'Quarter'
        vbu_col   = 'VBU'
        prac_col  = next((c for c in df.columns
                          if 'Group Practice' in c), None)

        avg_fftp = (round(float(df[fftp_col].mean()), 1)
                    if fftp_col and fftp_col in df.columns else 0)
        internal = (int((df[type_col] == 'Internal').sum())
                    if type_col in df.columns else 0)
        internal_pct = round(internal / total * 100, 1) if total else 0

        by_qtr      = self._vcounts(df, qtr_col)
        by_type     = self._vcounts(df, type_col)
        by_vbu      = self._top(df, vbu_col, 6)
        by_practice = self._top(df, prac_col, 6)

        out = {
            'total_fulfilled': total,
            'avg_fftp':        avg_fftp,
            'internal_count':  internal,
            'internal_pct':    internal_pct,
            'by_quarter':      by_qtr,
            'by_type':         by_type,
            'by_vbu':          by_vbu,
            'by_practice':     by_practice,
        }
        logger.success(f"Fulfillment KPIs: {total} fulfilled, "
                       f"avg FFTP={avg_fftp} days, {internal_pct}% internal")
        return out

    # ── helpers ──────────────────────────────────────────────
    def _vcounts(self, df: pd.DataFrame, col) -> dict:
        if col and col in df.columns:
            return df[col].value_counts().head(8).to_dict()
        return {}

    def _top(self, df: pd.DataFrame, col, n: int = 6) -> dict:
        if col and col in df.columns:
            return df[col].value_counts().head(n).to_dict()
        return {}
