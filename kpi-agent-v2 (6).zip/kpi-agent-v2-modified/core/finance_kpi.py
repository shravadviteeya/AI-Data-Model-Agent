"""
Finance KPI Calculator — processes Finance Tracker sheet.
Handles multi-row header structure with Revenue / Expenses / GM% metrics.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from loguru import logger


class FinanceKPI:
    """Calculates all Finance Tracker KPIs from tidy-format DataFrame."""

    MONTH_ORDER = [
        'Apr25', 'May25', 'Jun25', 'Jul25', 'Aug25', 'Sep25',
        'Oct25', 'Nov25', 'Dec25', 'Jan26', 'Feb26', 'Mar26',
    ]

    def __init__(self, config: dict):
        self.cfg = config
        self.sym = config.get('dashboard', {}).get('currency_symbol', '$')

    def calculate(self, df: pd.DataFrame) -> Dict[str, Any]:
        if df is None or df.empty:
            logger.warning("Finance: no data available")
            return {}

        out: Dict[str, Any] = {}

        # ── Filter to monthly periods only (exclude Q and FY rows) ──
        monthly = df[~df['period'].str.startswith(('Q', 'FY'),
                                                    na=False)].copy()

        # Sort months
        order_map = {m: i for i, m in enumerate(self.MONTH_ORDER)}
        monthly['sort_key'] = monthly['period'].map(order_map)
        monthly = monthly.sort_values('sort_key').reset_index(drop=True)

        # ── Revenue ──────────────────────────────────────────────
        rev_df = monthly[monthly['metric'].str.contains(
            'Revenue', case=False, na=False)]
        rev_by_month = (rev_df.groupby('period')['value']
                        .sum().reindex(self.MONTH_ORDER, fill_value=0))

        # ── Expenses ─────────────────────────────────────────────
        exp_df = monthly[monthly['metric'].str.contains(
            'Expense|Cost|Direct', case=False, na=False)]
        exp_by_month = (exp_df.groupby('period')['value']
                        .sum().reindex(self.MONTH_ORDER, fill_value=0))

        # ── GM% ──────────────────────────────────────────────────
        gm_df = monthly[monthly['metric'].str.contains(
            'Gross Margin', case=False, na=False)]
        gm_by_month = (gm_df.groupby('period')['value']
                       .mean().reindex(self.MONTH_ORDER, fill_value=0))
        # Convert decimal to % if needed
        if gm_by_month.abs().max() < 2:
            gm_by_month = gm_by_month * 100

        # ── Aggregates ────────────────────────────────────────────
        total_rev  = float(rev_by_month.sum())
        total_exp  = float(exp_by_month.sum())
        total_gm   = total_rev - total_exp
        nonzero_gm = [g for g in gm_by_month if g != 0]
        avg_gm_pct = round(sum(nonzero_gm) / len(nonzero_gm), 1) if nonzero_gm else 0

        # ── Best / Worst month ───────────────────────────────────
        rev_series = rev_by_month[rev_by_month > 0]
        best_month  = rev_series.idxmax() if len(rev_series) > 0 else 'N/A'
        worst_month = rev_series.idxmin() if len(rev_series) > 0 else 'N/A'

        # ── FY totals from raw (includes Q/FY aggregates) ────────
        fy_df = df[df['period'] == 'FY2026']
        fy_rev = float(fy_df[fy_df['metric'].str.contains(
            'Revenue', case=False, na=False)]['value'].sum()) or total_rev
        fy_exp = float(fy_df[fy_df['metric'].str.contains(
            'Expense|Cost|Direct', case=False, na=False)]['value'].sum()) or total_exp

        # ── Customer / Geo metadata ───────────────────────────────
        customer    = df['customer'].dropna().iloc[0] if 'customer' in df.columns and len(df) > 0 else 'N/A'
        geo         = df['geo'].dropna().iloc[0] if 'geo' in df.columns and len(df) > 0 else 'N/A'
        cost_center = df['cost_center'].dropna().iloc[0] if 'cost_center' in df.columns and len(df) > 0 else 'N/A'

        out = {
            # Scalars
            'total_revenue':    round(total_rev, 2),
            'total_expenses':   round(total_exp, 2),
            'total_gm':         round(total_gm, 2),
            'avg_gm_pct':       avg_gm_pct,
            'fy_revenue':       round(fy_rev, 2),
            'fy_expenses':      round(fy_exp, 2),
            'best_month':       best_month,
            'best_month_rev':   round(float(rev_by_month.get(best_month, 0)), 2),
            'worst_month':      worst_month,
            'worst_month_gm':   round(float(gm_by_month.get(worst_month, 0)), 1),
            'customer':         str(customer),
            'geo':              str(geo),
            'cost_center':      str(cost_center),
            # Series (for charts)
            'months':           list(rev_by_month.index),
            'revenue_series':   [round(float(v), 2) for v in rev_by_month],
            'expense_series':   [round(float(v), 2) for v in exp_by_month],
            'gm_pct_series':    [round(float(v), 1) for v in gm_by_month],
            # Formatted
            'total_revenue_fmt': self._fmt(total_rev),
            'total_gm_fmt':      self._fmt(total_gm),
            'fy_revenue_fmt':    self._fmt(fy_rev),
        }

        logger.success(
            f"Finance KPIs: Revenue={self._fmt(total_rev)}, "
            f"GM%={avg_gm_pct}%, Best={best_month}"
        )
        return out

    def _fmt(self, n: float) -> str:
        s = self.sym
        n = abs(float(n))
        if n >= 1e6:
            return f"{s}{n/1e6:.2f}M"
        if n >= 1e3:
            return f"{s}{n/1e3:.0f}K"
        return f"{s}{n:.0f}"
