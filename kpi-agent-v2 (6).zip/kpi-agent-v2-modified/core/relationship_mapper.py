"""
Relationship Mapper — discovers and maps cross-sheet join keys.
Outputs a relationship graph and linked KPI matrix.
"""

import pandas as pd
from typing import Dict, List, Optional
from loguru import logger


# ── Hard-coded relationship definitions (from domain knowledge) ──
KNOWN_RELATIONSHIPS = [
    {
        "from_sheet":  "sf_pipeline",
        "from_field":  "SFDC_OPPORTUNITYID",
        "to_sheet":    "demand",
        "to_field":    "Opportunity ID",
        "type":        "one-to-many",
        "description": "Pipeline opportunity drives demand requests",
        "join_key":    "opportunity_id",
    },
    {
        "from_sheet":  "sf_pipeline",
        "from_field":  "AccountName",
        "to_sheet":    "master",
        "to_field":    "Customer Name as per System",
        "type":        "many-to-one",
        "description": "Account maps to master customer reference",
        "join_key":    "customer_name",
    },
    {
        "from_sheet":  "sf_pipeline",
        "from_field":  "SFDC_OPPORTUNITYID",
        "to_sheet":    "closed",
        "to_field":    "OpportunityID",
        "type":        "one-to-one",
        "description": "Open opportunity becomes closed deal",
        "join_key":    "opportunity_id",
    },
    {
        "from_sheet":  "demand",
        "from_field":  "Employee Code",
        "to_sheet":    "employee",
        "to_field":    "Employee No",
        "type":        "many-to-one",
        "description": "Fulfilled demand links to employee record",
        "join_key":    "employee_id",
    },
    {
        "from_sheet":  "demand",
        "from_field":  "RequestID",
        "to_sheet":    "fulfillment",
        "to_field":    "Request ID",
        "type":        "one-to-one",
        "description": "Open demand fulfilled in YTD fulfillment",
        "join_key":    "request_id",
    },
    {
        "from_sheet":  "bench",
        "from_field":  "Employee No",
        "to_sheet":    "employee",
        "to_field":    "Employee No",
        "type":        "many-to-one",
        "description": "Bench resource is a subset of employee master",
        "join_key":    "employee_id",
    },
    {
        "from_sheet":  "employee",
        "from_field":  "Customer Name",
        "to_sheet":    "finance",
        "to_field":    "customer",
        "type":        "many-to-one",
        "description": "Employee billed to customer in finance tracker",
        "join_key":    "customer_name",
    },
    {
        "from_sheet":  "master",
        "from_field":  "IBU",
        "to_sheet":    "employee",
        "to_field":    "IBU",
        "type":        "one-to-many",
        "description": "IBU master drives IBU classification across all sheets",
        "join_key":    "ibu",
    },
]


class RelationshipMapper:
    """Maps cross-sheet relationships and validates join keys."""

    def __init__(self, config: dict):
        self.cfg = config
        self.relationships = KNOWN_RELATIONSHIPS.copy()
        self.validated: List[dict] = []

    def map(self, sheets: Dict[str, pd.DataFrame]) -> List[dict]:
        """Validate and return all relationships given loaded sheets."""
        validated = []
        for rel in self.relationships:
            from_df = sheets.get(rel['from_sheet'])
            to_df   = sheets.get(rel['to_sheet'])
            from_ok = (from_df is not None and
                       rel['from_field'] in (from_df.columns
                                              if isinstance(from_df, pd.DataFrame)
                                              else []))
            to_ok   = (to_df is not None and
                       rel['to_field'] in (to_df.columns
                                            if isinstance(to_df, pd.DataFrame)
                                            else []))
            rel_out = {**rel,
                       'from_available': from_ok,
                       'to_available':   to_ok,
                       'validated':      from_ok and to_ok}
            validated.append(rel_out)
            status = "✓" if rel_out['validated'] else "~"
            logger.info(f"  Relationship [{status}] "
                        f"{rel['from_sheet']}.{rel['from_field']} → "
                        f"{rel['to_sheet']}.{rel['to_field']}")
        self.validated = validated
        return validated

    def get_linked_kpis(self, sheets: Dict, kpis: dict) -> List[dict]:
        """Generate cross-source insight pairs from relationships."""
        insights = []
        # Bench → Demand match opportunity
        bench_df = sheets.get('bench')
        demand_df = sheets.get('demand')
        if (bench_df is not None and demand_df is not None
                and isinstance(bench_df, pd.DataFrame)
                and isinstance(demand_df, pd.DataFrame)):
            avail = (bench_df[bench_df['Status'] == 'Available']
                     if 'Status' in bench_df.columns
                     else bench_df)
            open_rrs = (demand_df[demand_df['Open Position'] > 0]
                        if 'Open Position' in demand_df.columns
                        else demand_df)
            if len(avail) > 0 and len(open_rrs) > 0:
                insights.append({
                    'type': 'opportunity',
                    'text': (f"{len(avail)} bench resource(s) available — "
                             f"{len(open_rrs)} open RR(s) exist. "
                             f"Cross-match skills to reduce external hiring."),
                    'sources': ['bench', 'demand'],
                })
        # Finance → Employee billed linkage
        emp_df = sheets.get('employee')
        if emp_df is not None and isinstance(emp_df, pd.DataFrame):
            total = len(emp_df)
            billed = (len(emp_df[emp_df['Billed/Unbilled'] == 'Billed'])
                      if 'Billed/Unbilled' in emp_df.columns else 0)
            if total > 0:
                pct = billed / total * 100
                if pct < 85:
                    insights.append({
                        'type': 'risk',
                        'text': (f"Billed HC is {pct:.1f}% — "
                                 f"below 85% healthy threshold. "
                                 f"{total - billed} employees unbilled."),
                        'sources': ['employee', 'finance'],
                    })
        return insights
