"""
Master KPI Aggregator — combines all source KPIs into
unified cross-source metrics and health score.
"""

from typing import Dict, Any
from loguru import logger


class MasterKPI:
    """Aggregates KPIs across all 8 sources."""

    def __init__(self, config: dict):
        self.cfg  = config
        self.thresholds = config.get('kpis', {})

    def calculate(self, all_kpis: Dict[str, Dict]) -> Dict[str, Any]:
        finance     = all_kpis.get('finance',     {})
        pipeline    = all_kpis.get('pipeline',    {})
        closed      = all_kpis.get('closed',      {})
        demand      = all_kpis.get('demand',      {})
        bench       = all_kpis.get('bench',       {})
        fulfillment = all_kpis.get('fulfillment', {})
        employee    = all_kpis.get('employee',    {})

        master: Dict[str, Any] = {}

        # ── Revenue & Finance ─────────────────────────────────
        master['fy_revenue']       = finance.get('fy_revenue', 0)
        master['fy_revenue_fmt']   = finance.get('fy_revenue_fmt', 'N/A')
        master['avg_gm_pct']       = finance.get('avg_gm_pct', 0)
        master['total_gm_fmt']     = finance.get('total_gm_fmt', 'N/A')
        master['best_month']       = finance.get('best_month', 'N/A')
        master['worst_month']      = finance.get('worst_month', 'N/A')

        # ── Pipeline & Closed ─────────────────────────────────
        master['pipeline_tcv']      = pipeline.get('total_tcv', 0)
        master['pipeline_tcv_fmt']  = pipeline.get('total_tcv_fmt', 'N/A')
        master['pipeline_deals']    = pipeline.get('total_deals', 0)
        master['ai_deals_pct']      = pipeline.get('ai_deals_pct', 0)
        master['win_rate']          = closed.get('win_rate', 0)
        master['won_tcv']           = closed.get('won_tcv', 0)
        master['won_tcv_fmt']       = closed.get('won_tcv_fmt', 'N/A')
        master['avg_deal_margin']   = closed.get('avg_margin_pct', 0)

        # ── People ────────────────────────────────────────────
        master['total_hc']          = employee.get('total_hc', 0)
        master['billed_pct']        = employee.get('billed_pct', 0)
        master['bench_total']       = bench.get('total_bench', 0)
        master['bench_available']   = bench.get('available', 0)
        master['open_rrs']          = demand.get('total_open', 0)
        master['total_fulfilled']   = fulfillment.get('total_fulfilled', 0)
        master['avg_fftp']          = fulfillment.get('avg_fftp', 0)
        master['internal_pct']      = fulfillment.get('internal_pct', 0)

        # ── Health score ──────────────────────────────────────
        master['health_score'] = self._health_score(master)
        master['health_label'] = self._health_label(master['health_score'])

        # ── Cross-source insights ─────────────────────────────
        master['cross_insights'] = self._cross_insights(master)

        logger.success(
            f"Master KPIs: Health={master['health_score']}/100, "
            f"Revenue={master['fy_revenue_fmt']}, "
            f"Win Rate={master['win_rate']}%"
        )
        return master

    def _health_score(self, m: dict) -> int:
        score = 70
        t = self.thresholds
        gm   = m.get('avg_gm_pct', 35)
        wr   = m.get('win_rate', 40)
        bp   = m.get('billed_pct', 80)
        fftp = m.get('avg_fftp', 15)

        if gm  >= t.get('gm_healthy', 35):    score += 5
        elif gm < t.get('gm_critical', 20):   score -= 20
        else:                                   score -= 8

        if wr  >= t.get('win_rate_good', 50):  score += 5
        elif wr < t.get('win_rate_benchmark', 40): score -= 8

        if bp  >= t.get('billed_pct_good', 85): score += 5
        elif bp < t.get('billed_pct_warn', 75):  score -= 10

        if abs(fftp) <= t.get('fftp_good', 15):  score += 5
        elif abs(fftp) > t.get('fftp_warn', 30):  score -= 8

        return max(0, min(100, score))

    def _health_label(self, score: int) -> str:
        if score >= 75: return 'Healthy'
        if score >= 50: return 'Watch'
        return 'At Risk'

    def _cross_insights(self, m: dict) -> list:
        insights = []
        t = self.thresholds
        gm = m.get('avg_gm_pct', 35)
        if gm < t.get('gm_healthy', 35):
            insights.append({
                'type': 'warn',
                'text': f"GM% {gm}% is below the {t.get('gm_healthy',35)}% "
                        f"healthy threshold — review cost structure.",
                'sources': ['finance']
            })
        else:
            insights.append({
                'type': 'good',
                'text': f"GM% at {gm}% is above the 35% threshold — "
                        f"healthy margin management.",
                'sources': ['finance']
            })
        wr = m.get('win_rate', 0)
        if wr > 0:
            if wr >= 50:
                insights.append({
                    'type': 'good',
                    'text': f"Win rate of {wr}% exceeds 50% benchmark — "
                            f"strong sales conversion.",
                    'sources': ['closed']
                })
            else:
                insights.append({
                    'type': 'info',
                    'text': f"Win rate {wr}% — focus on deal qualification "
                            f"to push above 50%.",
                    'sources': ['closed']
                })
        bench = m.get('bench_available', 0)
        rrs   = m.get('open_rrs', 0)
        if bench > 0 and rrs > 0:
            insights.append({
                'type': 'opportunity',
                'text': f"{bench} bench resource(s) available — "
                        f"{rrs} open RR(s) can potentially be filled "
                        f"internally, saving hiring cost.",
                'sources': ['bench', 'demand']
            })
        bp = m.get('billed_pct', 0)
        if bp > 0 and bp < t.get('billed_pct_warn', 75):
            insights.append({
                'type': 'risk',
                'text': f"Billed HC at {bp}% — below 75% threshold. "
                        f"Unbilled headcount is a revenue leakage risk.",
                'sources': ['employee', 'finance']
            })
        return insights
