# Changelog

## [2.2.0] — 2026-04-13

### Fixed
- **Tab navigation completely rewritten** — replaced `style="display:none"` inline styles with CSS class-based `.tab-pane` / `.tab-pane.active` approach. All 9 tabs now switch correctly on every browser and screen size.
- **Duplicate closing `</div>` removed** — stray tag was breaking the DOM tree and preventing JS from finding tab elements.
- **Duplicate `<script src>` tag removed** — Chart.js was being loaded twice, causing rendering conflicts.
- **JavaScript brace escaping fixed** — `{{{{` over-escaping from multiple format-escape passes collapsed back to correct `{{` → `{` rendering.
- **Mobile navigation added** — horizontal scrollable pill nav bar on screens ≤900px so tabs are reachable when sidebar is hidden.

### Added
- **EE & NN HBU TCV KPI tile** on SF Pipeline tab — 6th tile tracking `HBU_TCV($)` for Existing New (EN) and Renewal (EE) deal types.
- **Multi-provider AI Agent panel** — floating chat widget on all 9 tabs with:
  - ⚙️ settings button to configure provider + API key per session
  - **Groq** (free, `llama-3.1-8b-instant`) — recommended free provider
  - **Gemini Flash** (free, `gemini-2.0-flash`) — Google's free tier
  - **OpenRouter** (free models, `:free` suffix) — aggregator with free options
  - **Anthropic Claude** (`claude-haiku`) — paid option
  - Context-aware KPI snapshot injected per tab
  - 3 smart suggestion chips that update on tab switch
  - 10-turn conversation memory per session
  - Key-required guard — prompts setup before first message

## [2.1.0] — 2026-04-12

### Added
- EE & NN HBU TCV calculation in `core/salesforce_kpi.py`
- JS constants `EE_NN_HBU_TCV`, `PIPE_AVG_PROB`, `PIPE_AI_PCT`, `CL_WON_COUNT`, `CL_LOST_COUNT` injected by dashboard builder
- `LICENSE` (MIT), `setup.py`, `CHANGELOG.md`

## [2.0.0] — 2026-04-10

### Initial Release
- 8-source unified Excel dashboard (Finance, SF Pipeline, Closed Deals, Demand, Bench, Fulfillment, Employee Master, Master Reference)
- 9-tab dark SPA with Chart.js charts
- AI insights via Claude / GPT-4o / Copilot / rule-based fallback
- Composite Health Score (0–100)
- Cross-sheet relationship mapper
- CLI (`python main.py --file DATA2.xlsx`) with auto browser-open
