# KPI Intelligence Agent v2

> **Unified multi-source KPI dashboard** for Coforge D&A PMO — 8 Excel sheets, 9-tab dark SPA, AI-powered insights, and a per-page chat agent with **free AI provider support**.

![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![AI](https://img.shields.io/badge/AI-Groq%20%7C%20Gemini%20%7C%20OpenRouter%20%7C%20Claude-purple)

---

## ✨ What's New in v2.2

- ✅ **Tab navigation fixed** — all 9 pages now switch correctly
- ✅ **EE & NN HBU TCV tile** — 6th KPI on SF Pipeline tab
- ✅ **Multi-provider AI Agent** — Groq, Gemini, OpenRouter, Anthropic (all configurable from the UI, **free options included**)
- ✅ **Mobile nav bar** — scrollable pill nav on small screens

---

## 🖥️ Dashboard Pages

| Page | Data Source | Key KPIs |
|------|-------------|----------|
| Overview | All 8 sources | Revenue, GM%, Win Rate, Pipeline, Bench, HC |
| Finance Tracker | Finance sheet | FY Revenue, GM%, Monthly trend |
| SF Pipeline | SALESFORCE DATA | Total TCV, EE & NN HBU TCV, AI Proposals, Stage/BU |
| Closed Deals | Closed sheet | Won TCV, Win Rate, Margin, Won/Lost count |
| Demand Data | Demand sheet | Open RRs, Ageing, IBU breakdown |
| Bench Data | Bench sheet | Available HC, Pool, Skills, Ageing |
| YTD Fulfillment | Fulfillment sheet | Fulfilled count, FFTP, Internal% |
| Employee Master | Employee sheet | Total HC, Billed%, Practice, Geo |
| Relationships | All | Join keys, refresh schedules |

---

## 🤖 Per-Page AI Agent

Every tab has a floating **AI Agent panel** (bottom-right corner).

### Free Providers (no credit card needed)

| Provider | Model | Get Key |
|----------|-------|---------|
| ⚡ **Groq** *(recommended)* | `llama-3.1-8b-instant` | [console.groq.com](https://console.groq.com) |
| ✨ **Google Gemini** | `gemini-2.0-flash` | [aistudio.google.com](https://aistudio.google.com) |
| 🔀 **OpenRouter** | Any `:free` model | [openrouter.ai](https://openrouter.ai) |
| 🧠 **Anthropic** *(paid)* | `claude-haiku` | [console.anthropic.com](https://console.anthropic.com) |

**How to use:** Click ⚙️ in the agent panel → pick provider → paste API key → ask questions.

The agent automatically receives the live KPI snapshot for the current page as context.

---

## 🚀 Quick Start

### 1. Clone & install

```bash
git clone https://github.com/YOUR-ORG/kpi-agent-v2.git
cd kpi-agent-v2
pip install -r requirements.txt
```

### 2. Run with sample data

```bash
python main.py --sample
```

### 3. Run with your Excel file

```bash
python main.py --file path/to/DATA2.xlsx
```

The dashboard opens automatically at `output/dashboard.html`.

---

## 📊 Excel Sheet Requirements

| Sheet Name (configurable in `config.yaml`) | Key Columns |
|---------------------------------------------|-------------|
| Finance Tracker | Revenue($), Expenses($), Month |
| SALESFORCE DATA | TCV($), **HBU_TCV($)**, TYPE, STAGE, Probability(%), BU |
| Closed Deals | TCV($), Status (Won/Lost), CloseQTR, BU |
| Demand Data | RequestID, IBU, Status, Ageing bucket |
| BENCH DATA | Employee No, Pool, Skill, Days on bench |
| YTD Fulfillment | Request ID, Type, Quarter, FFTP days |
| EMPLOYEE MASTER | Employee No, IBU, Practice, Billed flag |
| Master Reference | IBU / BU concatenation keys |

### EE & NN HBU TCV Explained

The **EE & NN HBU TCV** tile on the SF Pipeline page sums the `HBU_TCV($)` column for deals where the `TYPE` field contains:
- **Existing New (EN)** — new scope on existing accounts
- **Renewal (EE)** — contract renewals

---

## 🗂 Project Structure

```
kpi-agent-v2/
├── main.py                     # CLI entry point
├── config.yaml                 # Column names, thresholds, sheet names
├── requirements.txt
├── .env.example                # Copy to .env for AI provider keys
│
├── core/
│   ├── salesforce_kpi.py       # Pipeline KPIs incl. EE_NN HBU TCV
│   ├── finance_kpi.py
│   ├── people_kpi.py
│   ├── demand_kpi.py
│   ├── master_kpi.py
│   ├── multi_sheet_loader.py
│   └── relationship_mapper.py
│
├── agents/
│   ├── base_agent.py           # Claude / GPT-4o / Copilot providers
│   └── insight_engine.py       # AI + rule-based insight generation
│
├── ui/
│   ├── dashboard_builder.py    # Injects KPIs into HTML template
│   └── report_builder.py
│
├── templates/
│   └── dashboard.html          # 9-tab SPA with multi-provider AI agent
│
└── data/sample/
    └── generate_sample.py      # Generates realistic test data
```

---

## ⚙️ Configuration

Edit `config.yaml` to set sheet names, column mappings, KPI thresholds, currency symbol, and company name.

---

## 🧪 Tests

```bash
pytest tests/ -v
```

---

## 📄 License

MIT — see [LICENSE](LICENSE)
