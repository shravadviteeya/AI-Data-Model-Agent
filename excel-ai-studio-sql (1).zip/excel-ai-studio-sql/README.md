# 🤖 Excel AI Studio — SQL Edition

> Three AI agents in a desktop GUI: clean your Excel data, generate Power BI files, push to MySQL, and run live SQL queries from inside the app.

---

## What's New vs Wireframe 1

| Feature | Wireframe 1 | SQL Edition |
|---------|------------|-------------|
| Data Cleaning Agent | ✅ | ✅ |
| Power BI Agent | ✅ | ✅ |
| SQL Agent (new) | ❌ | ✅ |
| MySQL Integration | ❌ | ✅ |
| SQL Workbench Tab | ❌ | ✅ Live query runner |
| Power BI Views | ❌ | ✅ 4 MySQL views |
| DDL + Insert SQL | ❌ | ✅ 5 SQL files |
| Direct DB Push | ❌ | ✅ One click |

---

## Architecture

```
Excel File (messy)
      ↓
┌─────────────────────────────────────────────┐
│          Excel AI Studio GUI                │
│                                             │
│  Agent 1: Data Cleaning (10 LangChain tools)│
│      ↓ clean_data.xlsx                      │
│  Agent 2: Power BI (4 tools)                │
│      ↓ dax_measures.txt                     │
│      ↓ powerquery_transform.m               │
│      ↓ powerbi_setup_guide.md               │
│  Agent 3: SQL (5 tools)                     │
│      ↓ 01_create_database.sql               │
│      ↓ 02_create_table.sql                  │
│      ↓ 03_insert_data.sql                   │
│      ↓ 04_useful_queries.sql                │
│      ↓ 05_powerbi_views.sql                 │
│      ↓ [Optional: Push to MySQL directly]   │
│  SQL Workbench Tab                          │
│      ↓ Live query runner                    │
└─────────────────────────────────────────────┘
      ↓                    ↓
  Power BI Desktop    MySQL / SQL Workbench
  (use clean Excel     (use SQL files or
   or connect MySQL)    direct connection)
```

---

## Quick Start

### Step 1 — Clone from GitHub
```bash
git clone https://github.com/YOUR_USERNAME/excel-ai-studio-sql.git
cd excel-ai-studio-sql
```

### Step 2 — Setup Python Environment
```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Mac/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 3 — Configure MySQL
```bash
# Copy .env template
cp .env.example .env

# Edit .env with your MySQL credentials
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password_here
DB_NAME=excel_ai_studio
```

### Step 4 — Run
```bash
python app.py
```

---

## How to Use the App

### Tab 1 — Home
Overview of the full pipeline. Click "Use Sample Data" to test immediately.

### Tab 2 — Agent 1: Clean Data
1. Select your Excel file or click "Use Sample Data"
2. Click "Run Agent 1"
3. Watch 10 tools run in sequence
4. Quality score before/after appears at bottom

### Tab 3 — Agent 2: Power BI
1. Run Agent 1 first
2. Click "Run Agent 2"
3. Gets you: DAX measures, Power Query M code, setup guide

### Tab 4 — Agent 3: SQL
1. Enter MySQL credentials (or load from .env)
2. Click "Test Connection" to verify
3. Optionally tick "Push data to MySQL"
4. Click "Run Agent 3"
5. 5 SQL files generated in `sql/` folder

### Tab 5 — SQL Workbench
- Write any SQL query or use Quick preset buttons
- Press F5 or click "Run Query"
- Results show in grid below
- Works only when MySQL is connected

### Tab 6 — Output Files
All generated files listed here with one-click Open buttons.

---

## SQL Files Explained

| File | Purpose | When to Run |
|------|---------|------------|
| `01_create_database.sql` | Creates the MySQL database | Run first, once |
| `02_create_table.sql` | CREATE TABLE with correct types | Run second |
| `03_insert_data.sql` | All your data as INSERT statements | Run third |
| `04_useful_queries.sql` | KPI queries ready to copy-paste | Use anytime |
| `05_powerbi_views.sql` | MySQL views for Power BI DirectQuery | Run after inserts |

### Run in SQL Workbench in order:
```sql
-- 1. Right-click in SQL Workbench → Open SQL Script
-- 2. Open 01_create_database.sql → Execute All (⚡)
-- 3. Open 02_create_table.sql   → Execute All
-- 4. Open 03_insert_data.sql    → Execute All
-- 5. Open 05_powerbi_views.sql  → Execute All
-- 6. Open 04_useful_queries.sql → Run individual queries
```

---

## Connect Power BI to MySQL

1. Power BI Desktop → Get Data → MySQL Database
2. Server: `127.0.0.1`  Port: `3306`
3. Database: `excel_ai_studio`
4. Choose **DirectQuery** for live data
5. Select these views:
   - `vw_revenue_summary`
   - `vw_monthly_kpis`
   - `vw_region_summary`
   - `vw_win_rate`

---

## Project Structure
```
excel-ai-studio-sql/
├── app.py                         ← Run this
├── requirements.txt
├── .env.example
├── README.md
│
├── agents/
│   ├── cleaning_agent.py          ← Agent 1: 10 cleaning tools
│   ├── powerbi_agent.py           ← Agent 2: 4 PBI tools
│   └── sql_agent.py               ← Agent 3: 5 SQL tools
│
├── core/
│   └── db_manager.py              ← MySQL connection & operations
│
├── config/
│   └── settings.py                ← Central configuration
│
├── data/
│   └── sample_messy.xlsx          ← Sample data
│
├── sql/                           ← Generated SQL files
│   ├── 01_create_database.sql
│   ├── 02_create_table.sql
│   ├── 03_insert_data.sql
│   ├── 04_useful_queries.sql
│   └── 05_powerbi_views.sql
│
└── output/                        ← Clean Excel + Power BI files
    ├── clean_data.xlsx
    ├── dax_measures.txt
    ├── powerquery_transform.m
    └── powerbi_setup_guide.md
```

---

## Customise

**Change how nulls are filled** — `agents/cleaning_agent.py` → `fix_nulls` tool → change `median` to `mean` or `0`.

**Add more DAX measures** — `agents/powerbi_agent.py` → `generate_dax_measures` tool → add to the `lines` list.

**Change MySQL batch size** — `config/settings.py` → `SQL_SETTINGS["batch_size"]`.

**Add a new cleaning rule** — copy any `@tool` function in `cleaning_agent.py`, add your logic, add it to `run_cleaning_pipeline`.

---

## Upload to GitHub
```bash
git init
git add .
git commit -m "Excel AI Studio SQL Edition v1"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/excel-ai-studio-sql.git
git push -u origin main
```

---

## License
MIT — free for personal and commercial use.
