"""
Database Manager
=================
Handles all MySQL operations:
  - Create database & tables
  - Insert cleaned data in batches
  - Run migrations
  - Export query results
  - Test connections
"""

import json
import re
from pathlib import Path
from datetime import datetime

try:
    import mysql.connector
    from mysql.connector import Error as MySQLError
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


class DBManager:
    """
    MySQL database manager for Excel AI Studio.
    Works with SQL Workbench via standard MySQL connector.
    """

    def __init__(self, config: dict):
        self.cfg  = config
        self.conn = None
        self._available = MYSQL_AVAILABLE

    # ── Connection ────────────────────────────────────────────

    def test_connection(self) -> dict:
        """Test MySQL connection and return status dict."""
        if not MYSQL_AVAILABLE:
            return {
                "status": "error",
                "message": "mysql-connector-python not installed.\nRun: pip install mysql-connector-python"
            }
        try:
            conn = mysql.connector.connect(
                host=self.cfg["host"],
                port=self.cfg["port"],
                user=self.cfg["user"],
                password=self.cfg["password"],
                connection_timeout=5
            )
            version = conn.get_server_info()
            conn.close()
            return {
                "status": "ok",
                "message": f"Connected — MySQL {version}",
                "host": f"{self.cfg['host']}:{self.cfg['port']}",
                "user": self.cfg["user"]
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def connect(self) -> bool:
        """Open a persistent connection, create DB if needed."""
        if not MYSQL_AVAILABLE:
            return False
        try:
            # Connect without specifying database first
            self.conn = mysql.connector.connect(
                host=self.cfg["host"],
                port=self.cfg["port"],
                user=self.cfg["user"],
                password=self.cfg["password"],
                charset=self.cfg.get("charset","utf8mb4")
            )
            # Create database if it doesn't exist
            cur = self.conn.cursor()
            db = self.cfg["database"]
            cur.execute(
                f"CREATE DATABASE IF NOT EXISTS `{db}` "
                f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
            cur.execute(f"USE `{db}`")
            self.conn.commit()
            return True
        except Exception as e:
            print(f"DB connect failed: {e}")
            return False

    def disconnect(self):
        if self.conn and self.conn.is_connected():
            self.conn.close()
            self.conn = None

    # ── Schema & DDL ──────────────────────────────────────────

    def infer_ddl(self, df, table_name: str,
                  add_timestamps: bool = True) -> str:
        """
        Infer CREATE TABLE DDL from a pandas DataFrame.
        Produces MySQL-compatible SQL.
        """
        type_map = {
            'int64':   'BIGINT',
            'int32':   'INT',
            'float64': 'DECIMAL(18,4)',
            'float32': 'DECIMAL(10,2)',
            'bool':    'TINYINT(1)',
            'object':  'VARCHAR(500)',
            'datetime64[ns]': 'DATETIME',
        }

        cols_sql = []

        # Auto PK
        cols_sql.append(
            f"  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY"
        )

        for col in df.columns:
            dtype  = str(df[col].dtype)
            sql_t  = type_map.get(dtype, 'TEXT')
            safe   = re.sub(r'[^\w]', '_', col).lower()

            # Refine VARCHAR length
            if sql_t == 'VARCHAR(500)' and not df[col].empty:
                max_len = int(df[col].dropna().astype(str).str.len().max())
                max_len = max(max_len, 10)
                sql_t   = f'VARCHAR({min(max_len * 2, 1000)})'

            # Detect DATE columns
            if any(kw in col.lower() for kw in ['date','month','period']):
                sql_t = 'DATE'

            nullable = 'NOT NULL' if df[col].notna().all() else 'NULL'
            cols_sql.append(f"  `{safe}` {sql_t} {nullable}")

        if add_timestamps:
            cols_sql.append(
                "  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            )
            cols_sql.append(
                "  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP "
                "ON UPDATE CURRENT_TIMESTAMP"
            )

        body = ',\n'.join(cols_sql)
        ddl  = (
            f"-- Table: {table_name}\n"
            f"-- Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
            f"CREATE TABLE IF NOT EXISTS `{table_name}` (\n"
            f"{body}\n"
            f") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 "
            f"COLLATE=utf8mb4_unicode_ci;"
        )
        return ddl

    def create_table(self, df, table_name: str) -> dict:
        """Create table in MySQL from DataFrame schema."""
        if not self.conn or not self.conn.is_connected():
            if not self.connect():
                return {"status": "error", "message": "Not connected"}
        try:
            ddl = self.infer_ddl(df, table_name)
            cur = self.conn.cursor()
            cur.execute(f"DROP TABLE IF EXISTS `{table_name}`")
            cur.execute(ddl)
            self.conn.commit()
            return {
                "status": "ok",
                "table": table_name,
                "ddl": ddl,
                "columns": len(df.columns)
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── Data Loading ──────────────────────────────────────────

    def load_dataframe(self, df, table_name: str,
                       batch_size: int = 500,
                       progress_cb=None) -> dict:
        """
        Insert DataFrame rows into MySQL table in batches.
        progress_cb(loaded, total) for GUI progress bar.
        """
        if not self.conn or not self.conn.is_connected():
            if not self.connect():
                return {"status": "error",
                        "message": "Could not connect to MySQL"}
        try:
            # Create table first
            create_result = self.create_table(df, table_name)
            if create_result["status"] != "ok":
                return create_result

            cur = self.conn.cursor()

            # Build safe column names
            safe_cols = [
                re.sub(r'[^\w]', '_', c).lower()
                for c in df.columns
            ]
            placeholders = ', '.join(['%s'] * len(safe_cols))
            col_str      = ', '.join([f'`{c}`' for c in safe_cols])
            insert_sql   = (
                f"INSERT INTO `{table_name}` ({col_str}) "
                f"VALUES ({placeholders})"
            )

            total    = len(df)
            loaded   = 0
            errors   = 0

            for i in range(0, total, batch_size):
                batch = df.iloc[i:i+batch_size]
                rows  = []
                for _, row in batch.iterrows():
                    vals = []
                    for v in row.values:
                        if pd.isna(v) if PANDAS_AVAILABLE else v is None:
                            vals.append(None)
                        elif hasattr(v, 'item'):
                            vals.append(v.item())
                        else:
                            vals.append(str(v) if not isinstance(
                                v, (int, float, bool)) else v)
                    rows.append(tuple(vals))
                try:
                    cur.executemany(insert_sql, rows)
                    self.conn.commit()
                    loaded += len(rows)
                except Exception as batch_err:
                    errors += 1
                    self.conn.rollback()

                if progress_cb:
                    progress_cb(loaded, total)

            return {
                "status":     "ok",
                "table":      table_name,
                "loaded":     loaded,
                "errors":     errors,
                "total_rows": total
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── Queries ───────────────────────────────────────────────

    def run_query(self, sql: str) -> dict:
        """Execute a SELECT query and return rows + columns."""
        if not self.conn or not self.conn.is_connected():
            if not self.connect():
                return {"status": "error", "message": "Not connected"}
        try:
            cur = self.conn.cursor(dictionary=True)
            cur.execute(sql)
            rows    = cur.fetchall()
            columns = [d[0] for d in cur.description] if cur.description else []
            return {
                "status":  "ok",
                "rows":    rows,
                "columns": columns,
                "count":   len(rows)
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def list_tables(self) -> list:
        """List all tables in the current database."""
        result = self.run_query("SHOW TABLES")
        if result["status"] == "ok":
            return [list(row.values())[0] for row in result["rows"]]
        return []

    def table_info(self, table_name: str) -> dict:
        """Get column info for a table."""
        result = self.run_query(f"DESCRIBE `{table_name}`")
        return result

    def row_count(self, table_name: str) -> int:
        """Get row count for a table."""
        result = self.run_query(
            f"SELECT COUNT(*) as cnt FROM `{table_name}`")
        if result["status"] == "ok" and result["rows"]:
            return result["rows"][0].get("cnt", 0)
        return 0

    # ── SQL File Generation ───────────────────────────────────

    def generate_sql_files(self, df, table_name: str,
                           output_dir: str) -> dict:
        """
        Generate all SQL files for SQL Workbench:
          - 01_create_database.sql
          - 02_create_table.sql
          - 03_insert_data.sql
          - 04_useful_queries.sql
          - 05_powerbi_views.sql
        """
        out = Path(output_dir)
        out.mkdir(exist_ok=True)
        db  = self.cfg["database"]
        files_created = []

        # ── 01 Create Database ────────────────────────────────
        sql1 = f"""-- ============================================================
-- 01_create_database.sql
-- Run this first in SQL Workbench
-- ============================================================

CREATE DATABASE IF NOT EXISTS `{db}`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `{db}`;

SELECT 'Database created successfully' AS status;
"""
        p1 = out / "01_create_database.sql"
        p1.write_text(sql1)
        files_created.append(str(p1))

        # ── 02 Create Table ───────────────────────────────────
        ddl = self.infer_ddl(df, table_name)
        sql2 = f"""-- ============================================================
-- 02_create_table.sql
-- Creates the main data table
-- ============================================================

USE `{db}`;

-- Drop if exists (safe re-run)
DROP TABLE IF EXISTS `{table_name}`;

{ddl}

-- Verify
DESCRIBE `{table_name}`;
SELECT 'Table created successfully' AS status;
"""
        p2 = out / "02_create_table.sql"
        p2.write_text(sql2)
        files_created.append(str(p2))

        # ── 03 Insert Data ────────────────────────────────────
        safe_cols = [re.sub(r'[^\w]','_',c).lower() for c in df.columns]
        col_str   = ', '.join([f'`{c}`' for c in safe_cols])

        insert_lines = [
            f"-- ============================================================",
            f"-- 03_insert_data.sql",
            f"-- {len(df)} rows · Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"-- ============================================================",
            f"",
            f"USE `{db}`;",
            f"",
            f"-- Disable checks for faster loading",
            f"SET foreign_key_checks = 0;",
            f"SET sql_mode = '';",
            f"",
        ]

        batch_size = 100
        for start in range(0, len(df), batch_size):
            batch    = df.iloc[start:start+batch_size]
            val_rows = []
            for _, row in batch.iterrows():
                vals = []
                for v in row.values:
                    if v is None or (
                        PANDAS_AVAILABLE and
                        hasattr(v,'__float__') and
                        pd.isna(float(v)) if isinstance(v,float) else False
                    ):
                        vals.append('NULL')
                    elif isinstance(v, (int, float)):
                        vals.append(str(v))
                    else:
                        escaped = str(v).replace("'","''").replace("\\","\\\\")
                        vals.append(f"'{escaped}'")
                val_rows.append(f"  ({', '.join(vals)})")

            insert_lines.append(
                f"INSERT INTO `{table_name}` ({col_str}) VALUES"
            )
            insert_lines.append(',\n'.join(val_rows) + ';')
            insert_lines.append("")

        insert_lines += [
            "SET foreign_key_checks = 1;",
            "",
            f"SELECT COUNT(*) as total_rows FROM `{table_name}`;",
            "SELECT 'Data loaded successfully' AS status;"
        ]

        p3 = out / "03_insert_data.sql"
        p3.write_text('\n'.join(insert_lines))
        files_created.append(str(p3))

        # ── 04 Useful Queries ─────────────────────────────────
        rev_col  = next((c for c in safe_cols if 'revenue' in c), None)
        cost_col = next((c for c in safe_cols if 'cost'    in c), None)
        gm_col   = next((c for c in safe_cols if 'margin'  in c), None)
        reg_col  = next((c for c in safe_cols if 'region'  in c), None)
        prod_col = next((c for c in safe_cols if 'product' in c), None)
        rep_col  = next((c for c in safe_cols if 'rep' in c or 'owner' in c), None)
        date_col = next((c for c in safe_cols if 'date' in c or 'month' in c), None)
        stat_col = next((c for c in safe_cols if 'status' in c), None)

        q4 = f"""-- ============================================================
-- 04_useful_queries.sql
-- KPI queries for analysis and Power BI
-- ============================================================

USE `{db}`;

-- ── 1. Overall KPI Summary ───────────────────────────────
SELECT
    COUNT(*)                              AS total_records,
    {f'SUM(`{rev_col}`)                  AS total_revenue,' if rev_col else ''}
    {f'SUM(`{cost_col}`)                 AS total_cost,' if cost_col else ''}
    {f'SUM(`{gm_col}`)                   AS total_gm,' if gm_col else ''}
    {f'ROUND(AVG(`{rev_col}`),2)         AS avg_revenue,' if rev_col else ''}
    {f'ROUND(SUM(`{gm_col}`)/NULLIF(SUM(`{rev_col}`),0)*100,2) AS gm_pct' if gm_col and rev_col else '1 AS placeholder'}
FROM `{table_name}`;

-- ── 2. Revenue by Region ─────────────────────────────────
{f"""SELECT
    `{reg_col}` AS region,
    COUNT(*)                                            AS deal_count,
    SUM(`{rev_col}`)                                   AS total_revenue,
    ROUND(SUM(`{rev_col}`) / (SELECT SUM(`{rev_col}`) FROM `{table_name}`) * 100, 2) AS revenue_share_pct,
    ROUND(AVG(`{rev_col}`), 2)                         AS avg_deal_size
FROM `{table_name}`
GROUP BY `{reg_col}`
ORDER BY total_revenue DESC;""" if reg_col and rev_col else "-- Region column not found"}

-- ── 3. Revenue by Product ────────────────────────────────
{f"""SELECT
    `{prod_col}`   AS product,
    COUNT(*)       AS deals,
    SUM(`{rev_col}`) AS total_revenue,
    ROUND(AVG(`{rev_col}`), 2) AS avg_revenue
FROM `{table_name}`
GROUP BY `{prod_col}`
ORDER BY total_revenue DESC;""" if prod_col and rev_col else "-- Product column not found"}

-- ── 4. Monthly Trend ────────────────────────────────────
{f"""SELECT
    DATE_FORMAT(`{date_col}`, '%Y-%m') AS year_month,
    COUNT(*)                            AS total_deals,
    SUM(`{rev_col}`)                   AS total_revenue,
    ROUND(SUM(`{gm_col}`)/NULLIF(SUM(`{rev_col}`),0)*100, 2) AS gm_pct
FROM `{table_name}`
WHERE `{date_col}` IS NOT NULL
GROUP BY DATE_FORMAT(`{date_col}`, '%Y-%m')
ORDER BY year_month;""" if date_col and rev_col and gm_col else "-- Date/Revenue columns not found"}

-- ── 5. Sales Rep Leaderboard ─────────────────────────────
{f"""SELECT
    `{rep_col}` AS sales_rep,
    COUNT(*)    AS total_deals,
    SUM(`{rev_col}`) AS total_revenue,
    ROUND(AVG(`{rev_col}`), 2) AS avg_deal_size
FROM `{table_name}`
GROUP BY `{rep_col}`
ORDER BY total_revenue DESC
LIMIT 10;""" if rep_col and rev_col else "-- Rep column not found"}

-- ── 6. Win/Loss Analysis ─────────────────────────────────
{f"""SELECT
    `{stat_col}` AS status,
    COUNT(*) AS count,
    SUM(`{rev_col}`) AS total_revenue,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM `{table_name}`), 2) AS pct
FROM `{table_name}`
GROUP BY `{stat_col}`
ORDER BY count DESC;""" if stat_col and rev_col else "-- Status column not found"}

-- ── 7. Top 10 Records by Revenue ─────────────────────────
SELECT * FROM `{table_name}`
{f'ORDER BY `{rev_col}` DESC' if rev_col else ''}
LIMIT 10;
"""

        p4 = out / "04_useful_queries.sql"
        p4.write_text(q4)
        files_created.append(str(p4))

        # ── 05 Power BI Views ─────────────────────────────────
        sql5 = f"""-- ============================================================
-- 05_powerbi_views.sql
-- MySQL Views optimised for Power BI DirectQuery
-- Connect Power BI to MySQL and use these views
-- ============================================================

USE `{db}`;

-- ── View 1: Revenue Summary ──────────────────────────────
CREATE OR REPLACE VIEW `vw_revenue_summary` AS
SELECT
    {f'`{reg_col}` AS Region,' if reg_col else ''}
    {f'`{prod_col}` AS Product,' if prod_col else ''}
    {f'`{rep_col}` AS Sales_Rep,' if rep_col else ''}
    {f'`{date_col}` AS Sale_Date,' if date_col else ''}
    {f'`{stat_col}` AS Status,' if stat_col else ''}
    {f'`{rev_col}` AS Revenue,' if rev_col else ''}
    {f'`{cost_col}` AS Cost,' if cost_col else ''}
    {f'`{gm_col}` AS Gross_Margin,' if gm_col else ''}
    {f'ROUND(`{gm_col}` / NULLIF(`{rev_col}`, 0) * 100, 2) AS GM_Pct' if gm_col and rev_col else '0 AS GM_Pct'}
FROM `{table_name}`;

-- ── View 2: Monthly KPIs ─────────────────────────────────
CREATE OR REPLACE VIEW `vw_monthly_kpis` AS
SELECT
    {f"DATE_FORMAT(`{date_col}`, '%Y-%m-01') AS Month_Start," if date_col else "NULL AS Month_Start,"}
    {f"DATE_FORMAT(`{date_col}`, '%Y') AS Year," if date_col else ""}
    {f"DATE_FORMAT(`{date_col}`, '%m') AS Month_Num," if date_col else ""}
    {f"DATE_FORMAT(`{date_col}`, '%M') AS Month_Name," if date_col else ""}
    {f"CONCAT('Q', QUARTER(`{date_col}`)) AS Quarter," if date_col else ""}
    COUNT(*) AS Total_Deals,
    {f'SUM(`{rev_col}`) AS Total_Revenue,' if rev_col else ''}
    {f'SUM(`{cost_col}`) AS Total_Cost,' if cost_col else ''}
    {f'SUM(`{gm_col}`) AS Total_GM,' if gm_col else ''}
    {f'ROUND(SUM(`{gm_col}`) / NULLIF(SUM(`{rev_col}`),0) * 100, 2) AS GM_Pct' if gm_col and rev_col else '0 AS GM_Pct'}
FROM `{table_name}`
{f"WHERE `{date_col}` IS NOT NULL" if date_col else ""}
{f"GROUP BY DATE_FORMAT(`{date_col}`, '%Y-%m-01')" if date_col else ""}
ORDER BY Month_Start;

-- ── View 3: Region Summary ───────────────────────────────
CREATE OR REPLACE VIEW `vw_region_summary` AS
SELECT
    {f'`{reg_col}` AS Region,' if reg_col else "'All' AS Region,"}
    COUNT(*) AS Total_Deals,
    {f'SUM(`{rev_col}`) AS Total_Revenue,' if rev_col else '0 AS Total_Revenue,'}
    {f'ROUND(SUM(`{gm_col}`)/NULLIF(SUM(`{rev_col}`),0)*100,2) AS GM_Pct,' if gm_col and rev_col else '0 AS GM_Pct,'}
    {f'ROUND(SUM(`{rev_col}`) / (SELECT SUM(`{rev_col}`) FROM `{table_name}`) * 100, 2) AS Revenue_Share_Pct' if rev_col else '100 AS Revenue_Share_Pct'}
FROM `{table_name}`
{f'GROUP BY `{reg_col}`' if reg_col else ''}
ORDER BY Total_Revenue DESC;

-- ── View 4: Win Rate Dashboard ───────────────────────────
{f"""CREATE OR REPLACE VIEW `vw_win_rate` AS
SELECT
    {f'`{rep_col}` AS Sales_Rep,' if rep_col else ''}
    {f'`{reg_col}` AS Region,' if reg_col else ''}
    COUNT(*) AS Total_Deals,
    SUM(CASE WHEN LOWER(`{stat_col}`) = 'won' THEN 1 ELSE 0 END) AS Won_Deals,
    SUM(CASE WHEN LOWER(`{stat_col}`) = 'lost' THEN 1 ELSE 0 END) AS Lost_Deals,
    ROUND(
        SUM(CASE WHEN LOWER(`{stat_col}`) = 'won' THEN 1 ELSE 0 END)
        / NULLIF(COUNT(*), 0) * 100, 2
    ) AS Win_Rate_Pct,
    SUM(`{rev_col}`) AS Total_Revenue
FROM `{table_name}`
{f"GROUP BY `{rep_col}`, `{reg_col}`" if rep_col and reg_col else ""}
ORDER BY Win_Rate_Pct DESC;""" if stat_col and rep_col else "-- Status/Rep columns not found for win rate view"}

SELECT 'Views created successfully' AS status;
"""

        p5 = out / "05_powerbi_views.sql"
        p5.write_text(sql5)
        files_created.append(str(p5))

        return {
            "status": "ok",
            "files": files_created,
            "table_name": table_name,
            "database": db
        }
