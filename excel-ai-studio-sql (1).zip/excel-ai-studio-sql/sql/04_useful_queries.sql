-- ============================================================
-- 04_useful_queries.sql
-- KPI queries for analysis and Power BI
-- ============================================================

USE `excel_ai_studio`;

-- ── 1. Overall KPI Summary ───────────────────────────────
SELECT
    COUNT(*)                              AS total_records,
    SUM(`revenue`)                  AS total_revenue,
    SUM(`cost`)                 AS total_cost,
    SUM(`gross_margin`)                   AS total_gm,
    ROUND(AVG(`revenue`),2)         AS avg_revenue,
    ROUND(SUM(`gross_margin`)/NULLIF(SUM(`revenue`),0)*100,2) AS gm_pct
FROM `clean_data`;

-- ── 2. Revenue by Region ─────────────────────────────────
SELECT
    `region` AS region,
    COUNT(*)                                            AS deal_count,
    SUM(`revenue`)                                   AS total_revenue,
    ROUND(SUM(`revenue`) / (SELECT SUM(`revenue`) FROM `clean_data`) * 100, 2) AS revenue_share_pct,
    ROUND(AVG(`revenue`), 2)                         AS avg_deal_size
FROM `clean_data`
GROUP BY `region`
ORDER BY total_revenue DESC;

-- ── 3. Revenue by Product ────────────────────────────────
SELECT
    `product`   AS product,
    COUNT(*)       AS deals,
    SUM(`revenue`) AS total_revenue,
    ROUND(AVG(`revenue`), 2) AS avg_revenue
FROM `clean_data`
GROUP BY `product`
ORDER BY total_revenue DESC;

-- ── 4. Monthly Trend ────────────────────────────────────
SELECT
    DATE_FORMAT(`sale_date`, '%Y-%m') AS year_month,
    COUNT(*)                            AS total_deals,
    SUM(`revenue`)                   AS total_revenue,
    ROUND(SUM(`gross_margin`)/NULLIF(SUM(`revenue`),0)*100, 2) AS gm_pct
FROM `clean_data`
WHERE `sale_date` IS NOT NULL
GROUP BY DATE_FORMAT(`sale_date`, '%Y-%m')
ORDER BY year_month;

-- ── 5. Sales Rep Leaderboard ─────────────────────────────
SELECT
    `sales_rep` AS sales_rep,
    COUNT(*)    AS total_deals,
    SUM(`revenue`) AS total_revenue,
    ROUND(AVG(`revenue`), 2) AS avg_deal_size
FROM `clean_data`
GROUP BY `sales_rep`
ORDER BY total_revenue DESC
LIMIT 10;

-- ── 6. Win/Loss Analysis ─────────────────────────────────
SELECT
    `status` AS status,
    COUNT(*) AS count,
    SUM(`revenue`) AS total_revenue,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM `clean_data`), 2) AS pct
FROM `clean_data`
GROUP BY `status`
ORDER BY count DESC;

-- ── 7. Top 10 Records by Revenue ─────────────────────────
SELECT * FROM `clean_data`
ORDER BY `revenue` DESC
LIMIT 10;
