-- ============================================================
-- 01_create_database.sql
-- Run this first in SQL Workbench
-- ============================================================

CREATE DATABASE IF NOT EXISTS `excel_ai_studio`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `excel_ai_studio`;

SELECT 'Database created successfully' AS status;
