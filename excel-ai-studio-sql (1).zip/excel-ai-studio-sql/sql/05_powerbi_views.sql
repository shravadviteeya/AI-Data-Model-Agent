-- ============================================================
-- 05_powerbi_views.sql
-- MySQL Views optimised for Power BI DirectQuery
-- Connect Power BI to MySQL and use these views
-- ============================================================

USE `excel_ai_studio`;

-- ── View 1: Revenue Summary ──────────────────────────────
CREATE OR REPLACE VIEW `vw_revenue_summary` AS
SELECT
    `region` AS Region,
    `product` AS Product,
    `sales_rep` AS Sales_Rep,
    `sale_date` AS Sale_Date,
    `status` AS Status,
    `revenue` AS Revenue,
    `cost` AS Cost,
    `gross_margin` AS Gross_Margin,
    ROUND(`gross_margin` / NULLIF(`revenue`, 0) * 100, 2) AS GM_Pct
FROM `clean_data`;

-- ── View 2: Monthly KPIs ─────────────────────────────────
CREATE OR REPLACE VIEW `vw_monthly_kpis` AS
SELECT
    DATE_FORMAT(`sale_date`, '%Y-%m-01') AS Month_Start,
    DATE_FORMAT(`sale_date`, '%Y') AS Year,
    DATE_FORMAT(`sale_date`, '%m') AS Month_Num,
    DATE_FORMAT(`sale_date`, '%M') AS Month_Name,
    CONCAT('Q', QUARTER(`sale_date`)) AS Quarter,
    COUNT(*) AS Total_Deals,
    SUM(`revenue`) AS Total_Revenue,
    SUM(`cost`) AS Total_Cost,
    SUM(`gross_margin`) AS Total_GM,
    ROUND(SUM(`gross_margin`) / NULLIF(SUM(`revenue`),0) * 100, 2) AS GM_Pct
FROM `clean_data`
WHERE `sale_date` IS NOT NULL
GROUP BY DATE_FORMAT(`sale_date`, '%Y-%m-01')
ORDER BY Month_Start;

-- ── View 3: Region Summary ───────────────────────────────
CREATE OR REPLACE VIEW `vw_region_summary` AS
SELECT
    `region` AS Region,
    COUNT(*) AS Total_Deals,
    SUM(`revenue`) AS Total_Revenue,
    ROUND(SUM(`gross_margin`)/NULLIF(SUM(`revenue`),0)*100,2) AS GM_Pct,
    ROUND(SUM(`revenue`) / (SELECT SUM(`revenue`) FROM `clean_data`) * 100, 2) AS Revenue_Share_Pct
FROM `clean_data`
GROUP BY `region`
ORDER BY Total_Revenue DESC;

-- ── View 4: Win Rate Dashboard ───────────────────────────
CREATE OR REPLACE VIEW `vw_win_rate` AS
SELECT
    `sales_rep` AS Sales_Rep,
    `region` AS Region,
    COUNT(*) AS Total_Deals,
    SUM(CASE WHEN LOWER(`status`) = 'won' THEN 1 ELSE 0 END) AS Won_Deals,
    SUM(CASE WHEN LOWER(`status`) = 'lost' THEN 1 ELSE 0 END) AS Lost_Deals,
    ROUND(
        SUM(CASE WHEN LOWER(`status`) = 'won' THEN 1 ELSE 0 END)
        / NULLIF(COUNT(*), 0) * 100, 2
    ) AS Win_Rate_Pct,
    SUM(`revenue`) AS Total_Revenue
FROM `clean_data`
GROUP BY `sales_rep`, `region`
ORDER BY Win_Rate_Pct DESC;

SELECT 'Views created successfully' AS status;
