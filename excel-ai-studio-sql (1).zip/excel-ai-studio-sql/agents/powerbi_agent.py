"""
Agent 2: Power BI Report Generator
Generates DAX, Power Query M, and setup guide.
"""

import pandas as pd
import json, re
from pathlib import Path
from datetime import datetime

try:
    from langchain.tools import tool
except ImportError:
    def tool(fn):
        fn.invoke = lambda args: fn(**args) if isinstance(args, dict) else fn(args)
        return fn


@tool
def analyse_for_powerbi(file_path: str) -> str:
    """Analyse schema and suggest Power BI visuals."""
    try:
        df = pd.read_excel(file_path)
        dims, measures, dates = [], [], []
        for col in df.columns:
            dtype = str(df[col].dtype)
            sample = [str(v) for v in df[col].dropna().head(5).tolist()]
            if 'int' in dtype or 'float' in dtype:
                measures.append({"column": col, "sum": float(df[col].sum()), "mean": float(df[col].mean())})
            elif any(k in col.lower() for k in ['date','month','period']):
                dates.append({"column": col, "sample": sample})
            else:
                dims.append({"column": col, "unique": int(df[col].nunique()), "sample": sample, "cardinality": "low" if df[col].nunique() <= 20 else "high"})

        visuals = []
        if measures: visuals.append({"type": "Card", "fields": [m["column"] for m in measures[:4]]})
        if dates and measures: visuals.append({"type": "Line Chart", "x": dates[0]["column"], "y": [m["column"] for m in measures[:2]]})
        low = [d for d in dims if d["cardinality"]=="low"]
        if low and measures:
            visuals.append({"type": "Bar Chart", "axis": low[0]["column"], "values": [m["column"] for m in measures[:2]]})
            visuals.append({"type": "Donut", "legend": low[1]["column"] if len(low)>1 else low[0]["column"], "values": [measures[0]["column"]]})
        visuals.append({"type": "Slicer", "fields": [d["column"] for d in low[:3]]})
        visuals.append({"type": "Table", "rows": [d["column"] for d in low[:2]], "values": [m["column"] for m in measures[:3]]})

        return json.dumps({"status":"success","total_rows":len(df),"dimensions":dims,"measures":measures,"dates":dates,"suggested_visuals":visuals})
    except Exception as e:
        return json.dumps({"status":"error","message":str(e)})


@tool
def generate_dax_measures(file_path: str) -> str:
    """Generate DAX measures for Power BI."""
    try:
        df = pd.read_excel(file_path)
        cols = {c.lower(): c for c in df.columns}
        rev  = next((cols[k] for k in cols if 'revenue' in k or 'sales' in k), None)
        cost = next((cols[k] for k in cols if 'cost' in k), None)
        gm   = next((cols[k] for k in cols if 'margin' in k or k=='gm'), None)
        qty  = next((cols[k] for k in cols if 'qty' in k or 'quantity' in k or 'deal' in k), None)
        stat = next((cols[k] for k in cols if 'status' in k), None)
        tbl  = "SalesData"

        lines = []
        if rev:
            lines += [f"-- Revenue\nTotal Revenue = SUM('{tbl}'[{rev}])\n",
                      f"Revenue YTD = TOTALYTD(SUM('{tbl}'[{rev}]), 'DateTable'[Date])\n",
                      f"Revenue MTD = TOTALMTD(SUM('{tbl}'[{rev}]), 'DateTable'[Date])\n",
                      f"Revenue PY = CALCULATE(SUM('{tbl}'[{rev}]), SAMEPERIODLASTYEAR('DateTable'[Date]))\n",
                      f"Revenue Growth % = DIVIDE([Total Revenue]-[Revenue PY],[Revenue PY],0)*100\n"]
        if cost and rev:
            lines += [f"-- Margin\nTotal Cost = SUM('{tbl}'[{cost}])\n",
                      f"Gross Margin = [Total Revenue]-[Total Cost]\n",
                      f"GM % = DIVIDE([Gross Margin],[Total Revenue],0)*100\n"]
        if qty:
            lines += [f"-- Volume\nTotal Deals = COUNTA('{tbl}'[{qty}])\n",
                      f"Avg Deal Size = DIVIDE([Total Revenue],[Total Deals],0)\n"]
        if stat:
            lines += [f"-- Win Rate\nWon Deals = CALCULATE(COUNTA('{tbl}'[{stat}]),'{tbl}'[{stat}]=\"Won\")\n",
                      f"Win Rate % = DIVIDE([Won Deals],[Total Deals],0)*100\n"]
        if rev:
            lines.append(f"-- Ranking\nRevenue Rank = RANKX(ALL('{tbl}'),[Total Revenue],,DESC)\n")

        dax = "\n".join(lines)
        return json.dumps({"status":"success","dax_code":dax,"measure_count":len([l for l in lines if '=' in l and not l.startswith('--')])})
    except Exception as e:
        return json.dumps({"status":"error","message":str(e)})


@tool
def generate_power_query(file_path: str) -> str:
    """Generate Power Query M transformation code."""
    try:
        df = pd.read_excel(file_path)
        type_map = {'int64':'Int64.Type','int32':'Int64.Type','float64':'type number','object':'type text','datetime64[ns]':'type date'}
        col_types = ',\n'.join([f'        {{"{c}", {type_map.get(str(df[c].dtype),"type text")}}}' for c in df.columns])

        m = f'''let
    Source = Excel.Workbook(File.Contents("{file_path}"), null, true),
    Sheet  = Source{{[Item="Sheet1",Kind="Sheet"]}}[Data],
    Headers = Table.PromoteHeaders(Sheet, [PromoteAllScalars=true]),
    Types  = Table.TransformColumnTypes(Headers, {{
{col_types}
    }}),
    NoDups  = Table.Distinct(Types),
    CleanNull = Table.ReplaceValue(NoDups,"N/A",null,Replacer.ReplaceValue,Table.ColumnNames(NoDups)),
    TrimText = Table.TransformColumns(CleanNull, List.Transform(
        Table.ColumnsOfType(CleanNull, {{type text}}), each {{_, Text.Trim}})),
    NoBlank = Table.SelectRows(TrimText, each not List.IsEmpty(
        List.RemoveMatchingItems(Record.FieldValues(_), {{"", null}})))
in
    NoBlank'''

        return json.dumps({"status":"success","m_code":m,"steps":["Source","Headers","Types","NoDups","CleanNull","TrimText","NoBlank"]})
    except Exception as e:
        return json.dumps({"status":"error","message":str(e)})


@tool
def generate_setup_guide(file_path: str, output_dir: str) -> str:
    """Generate step-by-step Power BI + MySQL setup guide."""
    try:
        df = pd.read_excel(file_path)
        fname = Path(file_path).name
        guide = f"""# Power BI + MySQL Setup Guide
Generated: {datetime.now().strftime('%d %b %Y %H:%M')}

## Option A — Load from Clean Excel
1. Open Power BI Desktop → Get Data → Excel → select `{fname}`
2. Transform Data → Advanced Editor → paste `powerquery_transform.m`
3. Close & Apply

## Option B — Connect to MySQL (Recommended for live data)
1. Get Data → MySQL Database
2. Server: 127.0.0.1:3306  Database: excel_ai_studio
3. Select views: `vw_revenue_summary`, `vw_monthly_kpis`, `vw_region_summary`
4. Load

## Create Date Table
```dax
DateTable = ADDCOLUMNS(
    CALENDAR(DATE(2024,1,1), DATE(2027,12,31)),
    "Year",      YEAR([Date]),
    "Month Num", MONTH([Date]),
    "Month",     FORMAT([Date],"MMMM"),
    "Quarter",   "Q" & QUARTER([Date])
)
```

## Add DAX Measures
Paste each measure from `dax_measures.txt` using New Measure.

## Recommended Pages
| Page | Visuals |
|------|---------|
| Executive Summary | KPI Cards + Line Chart + Region Bar |
| Sales Performance | Rep Leaderboard + Win Rate + Deals |
| Product Analysis | Product Donut + Revenue Table |
| Filters | Date Slicer + Region + Product + Status |

## Columns: {', '.join(df.columns)}
"""
        path = str(Path(output_dir) / "powerbi_setup_guide.md")
        Path(path).write_text(guide)
        return json.dumps({"status":"success","guide_path":path})
    except Exception as e:
        return json.dumps({"status":"error","message":str(e)})


def run_powerbi_pipeline(clean_file, output_dir, progress_callback=None):
    """Run full Power BI generation pipeline."""
    Path(output_dir).mkdir(exist_ok=True)
    def cb(s,t,m):
        if progress_callback: progress_callback(s,t,m)

    cb(1,4,"Analysing schema...")
    schema = json.loads(analyse_for_powerbi.invoke({"file_path":clean_file}))

    cb(2,4,"Generating DAX measures...")
    dax = json.loads(generate_dax_measures.invoke({"file_path":clean_file}))
    Path(output_dir,"dax_measures.txt").write_text(dax.get("dax_code",""))

    cb(3,4,"Generating Power Query M code...")
    pq = json.loads(generate_power_query.invoke({"file_path":clean_file}))
    Path(output_dir,"powerquery_transform.m").write_text(pq.get("m_code",""))

    cb(4,4,"Generating setup guide...")
    guide = json.loads(generate_setup_guide.invoke({"file_path":clean_file,"output_dir":output_dir}))

    return {
        "status":"success",
        "files_created":[str(Path(output_dir,"dax_measures.txt")), str(Path(output_dir,"powerquery_transform.m")), guide.get("guide_path","")],
        "dax_measure_count": dax.get("measure_count",0),
        "suggested_visuals": schema.get("suggested_visuals",[]),
        "schema": schema
    }
