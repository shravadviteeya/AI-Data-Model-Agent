"""
Agent 3: SQL Agent
===================
LangChain tools for SQL Workbench integration.
Converts cleaned Excel → MySQL tables + views + queries.

Tools:
  - analyse_for_sql     → schema analysis for SQL design
  - generate_ddl        → CREATE TABLE statements
  - generate_inserts    → INSERT data SQL
  - generate_views      → Power BI optimised MySQL views
  - generate_queries    → KPI queries for analysis
  - push_to_mysql       → Actually load data into MySQL
  - generate_er_diagram → SQL schema diagram
"""

import pandas as pd
import numpy as np
import json, re
from pathlib import Path
from datetime import datetime

try:
    from langchain.tools import tool
except ImportError:
    def tool(fn):
        fn.invoke = lambda args: fn(**args) if isinstance(args, dict) else fn(args)
        return fn

try:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from config.settings import DB, SQL_SETTINGS
except:
    DB = {"host":"127.0.0.1","port":3306,"user":"root","password":"","database":"excel_ai_studio"}
    SQL_SETTINGS = {"dialect":"mysql","schema_name":"excel_ai_studio","batch_size":500}


@tool
def analyse_for_sql(file_path: str) -> str:
    """
    Analyse clean Excel file and suggest optimal SQL schema:
    table name, column types, indexes, relationships.
    """
    try:
        df = pd.read_excel(file_path)
        table_name = re.sub(r'[^\w]','_', Path(file_path).stem).lower()

        col_analysis = []
        for col in df.columns:
            dtype    = str(df[col].dtype)
            unique   = int(df[col].nunique())
            nulls    = int(df[col].isnull().sum())
            sample   = [str(v) for v in df[col].dropna().head(3).tolist()]
            nullable = nulls > 0

            # Suggest SQL type
            if 'int' in dtype:    sql_type = 'BIGINT' if df[col].max() > 2e9 else 'INT'
            elif 'float' in dtype: sql_type = 'DECIMAL(18,4)'
            elif any(k in col.lower() for k in ['date','month','period']): sql_type = 'DATE'
            elif any(k in col.lower() for k in ['revenue','cost','margin','amount','price']): sql_type = 'DECIMAL(18,2)'
            else:
                max_len = int(df[col].dropna().astype(str).str.len().max()) if not df[col].empty else 50
                sql_type = 'TEXT' if max_len > 500 else f'VARCHAR({min(max_len*2, 500)})'

            suggest_index = (
                any(k in col.lower() for k in ['id','date','region','product','status','rep','owner']) or
                unique < 20
            )

            col_analysis.append({
                "column": col, "dtype": dtype, "sql_type": sql_type,
                "unique": unique, "nulls": nulls, "nullable": nullable,
                "sample": sample, "suggest_index": suggest_index
            })

        return json.dumps({
            "status": "success",
            "table_name": table_name,
            "row_count": len(df),
            "col_count": len(df.columns),
            "columns": col_analysis,
            "database": DB["database"]
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def push_to_mysql(file_path: str, table_name: str = "") -> str:
    """
    Connect to MySQL and load the clean Excel data.
    Creates database, table, and inserts all rows.
    Requires mysql-connector-python: pip install mysql-connector-python
    """
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from core.db_manager import DBManager

        df = pd.read_excel(file_path)
        if not table_name:
            table_name = re.sub(r'[^\w]','_', Path(file_path).stem).lower()

        mgr = DBManager(DB)
        test = mgr.test_connection()
        if test["status"] != "ok":
            return json.dumps({
                "status": "error",
                "message": f"Cannot connect to MySQL: {test['message']}\n\nCheck your .env file:\n  DB_HOST, DB_PORT, DB_USER, DB_PASSWORD"
            })

        result = mgr.load_dataframe(df, table_name, batch_size=SQL_SETTINGS["batch_size"])
        mgr.disconnect()
        return json.dumps(result)
    except ImportError:
        return json.dumps({
            "status": "error",
            "message": "mysql-connector-python not installed.\nRun: pip install mysql-connector-python"
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def generate_all_sql_files(file_path: str, output_dir: str = "") -> str:
    """
    Generate all 5 SQL files for SQL Workbench:
    database creation, table DDL, inserts, queries, Power BI views.
    """
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from core.db_manager import DBManager

        df = pd.read_excel(file_path)
        if not output_dir:
            output_dir = str(Path(file_path).parent.parent / "sql")
        table_name = re.sub(r'[^\w]','_', Path(file_path).stem).lower()

        mgr = DBManager(DB)
        result = mgr.generate_sql_files(df, table_name, output_dir)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def test_mysql_connection(dummy: str = "") -> str:
    """Test MySQL connection and return server info."""
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from core.db_manager import DBManager
        mgr = DBManager(DB)
        return json.dumps(mgr.test_connection())
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def run_kpi_query(query_name: str, table_name: str = "clean_data") -> str:
    """
    Run a pre-built KPI query against MySQL.
    query_name options: summary | by_region | monthly | by_rep | win_rate
    """
    queries = {
        "summary": f"""
            SELECT COUNT(*) total_records,
                   SUM(Revenue) total_revenue,
                   SUM(Gross_Margin) total_gm,
                   ROUND(AVG(Gm_Pct),2) avg_gm_pct
            FROM `{table_name}`""",
        "by_region": f"""
            SELECT Region, COUNT(*) deals,
                   SUM(Revenue) total_revenue,
                   ROUND(AVG(Gm_Pct),2) avg_gm_pct
            FROM `{table_name}`
            GROUP BY Region ORDER BY total_revenue DESC""",
        "monthly": f"""
            SELECT DATE_FORMAT(Sale_Date,'%Y-%m') ym,
                   SUM(Revenue) revenue,
                   COUNT(*) deals
            FROM `{table_name}`
            GROUP BY ym ORDER BY ym""",
        "by_rep": f"""
            SELECT Sales_Rep, SUM(Revenue) revenue,
                   COUNT(*) deals
            FROM `{table_name}`
            GROUP BY Sales_Rep ORDER BY revenue DESC LIMIT 10""",
        "win_rate": f"""
            SELECT Status, COUNT(*) count,
                   ROUND(COUNT(*)*100/(SELECT COUNT(*) FROM `{table_name}`),1) pct
            FROM `{table_name}` GROUP BY Status"""
    }
    sql = queries.get(query_name, queries["summary"])
    try:
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from core.db_manager import DBManager
        mgr = DBManager(DB)
        if not mgr.connect():
            return json.dumps({"status": "error", "message": "Cannot connect to MySQL"})
        result = mgr.run_query(sql)
        mgr.disconnect()
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


def run_sql_pipeline(clean_file_path: str, output_dir: str,
                     push_to_db: bool = False,
                     progress_callback=None) -> dict:
    """Full SQL pipeline: generate files + optionally push to MySQL."""
    Path(output_dir).mkdir(exist_ok=True)

    def cb(step, total, msg):
        if progress_callback: progress_callback(step, total, msg)

    total = 4 if not push_to_db else 5
    results = {}

    cb(1, total, "Analysing schema for SQL...")
    schema = json.loads(analyse_for_sql.invoke({"file_path": clean_file_path}))
    results["schema"] = schema

    cb(2, total, "Generating SQL files...")
    sql_files = json.loads(generate_all_sql_files.invoke({
        "file_path": clean_file_path, "output_dir": output_dir
    }))
    results["sql_files"] = sql_files

    cb(3, total, "Testing MySQL connection...")
    conn_test = json.loads(test_mysql_connection.invoke({"dummy": ""}))
    results["connection"] = conn_test

    files = sql_files.get("files", [])

    if push_to_db and conn_test.get("status") == "ok":
        cb(4, total, "Pushing data to MySQL...")
        push_result = json.loads(push_to_mysql.invoke({
            "file_path": clean_file_path,
            "table_name": schema.get("table_name", "sales_data")
        }))
        results["push"] = push_result

    cb(total, total, "Done!")

    return {
        "status": "success",
        "sql_files": files,
        "schema": schema,
        "connection": conn_test,
        "push_result": results.get("push", {}),
        "table_name": schema.get("table_name",""),
        "database": DB["database"],
        "results": results
    }
