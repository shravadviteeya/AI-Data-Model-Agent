"""
Agent 1: Data Cleaning Agent
10 LangChain tools that fix every common Excel data quality issue.
"""

import pandas as pd
import numpy as np
import re, json, shutil
from pathlib import Path
from datetime import datetime

try:
    from langchain.tools import tool
except ImportError:
    def tool(fn):
        fn.invoke = lambda args: fn(**args) if isinstance(args, dict) else fn(args)
        return fn


@tool
def profile_data(file_path: str) -> str:
    """Profile Excel file and detect all quality issues."""
    try:
        df = pd.read_excel(file_path)
        issues, col_profiles = [], []
        total = len(df)
        dups = int(df.duplicated().sum())
        if dups: issues.append(f"DUPLICATE_ROWS:{dups}")

        for col in df.columns:
            s = df[col]
            nulls = int(s.isnull().sum())
            col_issues = []
            if nulls: col_issues.append(f"NULLS:{nulls}")
            if s.dtype == object:
                ws = int(s.dropna().apply(lambda x: str(x) != str(x).strip()).sum())
                if ws: col_issues.append(f"WHITESPACE:{ws}")
                vals = s.dropna().astype(str).str.strip()
                if len(vals) > 0:
                    u = vals.nunique()
                    if u <= 20 and u > 1 and vals.str.lower().str.strip().nunique() < u:
                        col_issues.append(f"INCONSISTENT_CASE")
                    date_hits = sum(1 for v in vals.head(20) if re.search(r'\d{1,4}[-/]\d{1,2}[-/]\d{2,4}', str(v)))
                    if date_hits >= 5: col_issues.append("DATE_FORMAT_INCONSISTENT")
            if pd.api.types.is_numeric_dtype(s):
                neg = int((s < 0).sum())
                if neg: col_issues.append(f"NEGATIVE_VALUES:{neg}")
            col_profiles.append({"column": col, "nulls": nulls, "issues": col_issues})
            for i in col_issues: issues.append(f"COL[{col}]:{i}")

        return json.dumps({
            "status": "success", "file": file_path,
            "total_rows": total, "total_cols": len(df.columns),
            "duplicate_rows": dups, "total_issues": len(issues),
            "quality_score": max(0, 100 - len(issues) * 3),
            "issues": issues, "column_profiles": col_profiles
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_column_names(file_path: str) -> str:
    """Standardise column names: strip, title case, underscores."""
    try:
        df = pd.read_excel(file_path)
        orig = list(df.columns)
        df.columns = [re.sub(r'\s+','_', re.sub(r'[^\w\s]','', str(c).strip())).strip('_').title() for c in df.columns]
        df.to_excel(file_path, index=False)
        changes = {o: n for o, n in zip(orig, df.columns) if o != n}
        return json.dumps({"status": "success", "renamed": changes})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_duplicates(file_path: str) -> str:
    """Remove exact duplicate rows."""
    try:
        df = pd.read_excel(file_path)
        before = len(df)
        df = df.drop_duplicates()
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "removed": before - len(df), "before": before, "after": len(df)})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_text_columns(file_path: str) -> str:
    """Strip whitespace and apply Title Case to string columns."""
    try:
        df = pd.read_excel(file_path)
        fixed = []
        for col in df.select_dtypes(include='object').columns:
            before = df[col].copy()
            df[col] = df[col].apply(lambda x: str(x).strip().title() if pd.notna(x) and str(x) not in ['nan','None',''] else x)
            if not before.equals(df[col]): fixed.append(col)
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixed_columns": fixed})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_dates(file_path: str) -> str:
    """Parse multiple date formats into YYYY-MM-DD."""
    try:
        df = pd.read_excel(file_path)
        date_cols = []
        for col in df.columns:
            if df[col].dtype == object:
                sample = df[col].dropna().head(30).astype(str)
                hits = sum(1 for v in sample if re.search(r'\d{1,4}[-/]\d{1,2}[-/]\d{2,4}|\w{3,9}\s\d{1,2}\s\d{4}', v))
                if hits >= 5:
                    parsed = pd.to_datetime(df[col], infer_datetime_format=True, errors='coerce', dayfirst=True)
                    if parsed.notna().sum() > len(df) * 0.5:
                        df[col] = parsed.dt.strftime('%Y-%m-%d')
                        date_cols.append(col)
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "date_columns_fixed": date_cols})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_nulls(file_path: str) -> str:
    """Fill nulls: median for numeric, 'Unknown' for strings."""
    try:
        df = pd.read_excel(file_path)
        df.replace(['N/A','n/a','NA','None','none','NULL','null','','-'], np.nan, inplace=True)
        fixes = {}
        for col in df.columns:
            n = int(df[col].isnull().sum())
            if n == 0: continue
            if pd.api.types.is_numeric_dtype(df[col]):
                m = df[col].median()
                df[col].fillna(m, inplace=True)
                fixes[col] = f"filled {n} with median({m:.1f})"
            else:
                df[col].fillna('Unknown', inplace=True)
                fixes[col] = f"filled {n} with 'Unknown'"
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixes": fixes})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_numerics(file_path: str) -> str:
    """Convert numeric strings, remove negatives in revenue/cost/qty."""
    try:
        df = pd.read_excel(file_path)
        fixed = {}
        for col in df.columns:
            if df[col].dtype == object:
                conv = pd.to_numeric(df[col].astype(str).str.replace(r'[₹$€£,]','',regex=True).str.strip(), errors='coerce')
                if conv.notna().mean() > 0.7:
                    df[col] = conv
                    fixed[col] = "string→numeric"
            if pd.api.types.is_numeric_dtype(df[col]):
                if any(kw in col.lower() for kw in ['revenue','cost','qty','quantity','amount','price','sales']):
                    neg = int((df[col] < 0).sum())
                    if neg > 0:
                        df[col] = df[col].clip(lower=0)
                        fixed[col] = fixed.get(col,"") + f" removed {neg} negatives"
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixed_columns": fixed})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def fix_categories(file_path: str) -> str:
    """Standardise low-cardinality text columns to consistent values."""
    try:
        df = pd.read_excel(file_path)
        fixed = {}
        for col in df.select_dtypes(include='object').columns:
            unique = df[col].dropna().unique()
            if len(unique) > 25: continue
            norm_map = {}
            for v in unique:
                norm = str(v).lower().strip()
                norm_map.setdefault(norm, []).append(v)
            val_map = {}
            for norm, variants in norm_map.items():
                canonical = norm.title()
                for v in variants:
                    if str(v) != canonical: val_map[str(v)] = canonical
            if val_map:
                df[col] = df[col].apply(lambda x: val_map.get(str(x), x) if pd.notna(x) else x)
                fixed[col] = f"{len(val_map)} variants unified"
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixed_columns": fixed})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def add_derived_columns(file_path: str) -> str:
    """Add Gross_Margin, GM_Pct, Year, Month, Quarter columns."""
    try:
        df = pd.read_excel(file_path)
        added = []
        rev_col  = next((c for c in df.columns if 'revenue' in c.lower()), None)
        cost_col = next((c for c in df.columns if 'cost' in c.lower()), None)
        if rev_col and cost_col and 'Gross_Margin' not in df.columns:
            df['Gross_Margin'] = (df[rev_col] - df[cost_col]).round(2)
            df['Gm_Pct'] = ((df['Gross_Margin'] / df[rev_col].replace(0, np.nan)) * 100).round(2)
            added += ['Gross_Margin','Gm_Pct']
        date_col = next((c for c in df.columns if any(kw in c.lower() for kw in ['date','month','period'])), None)
        if date_col:
            parsed = pd.to_datetime(df[date_col], errors='coerce')
            if parsed.notna().sum() > len(df) * 0.5:
                df['Year']       = parsed.dt.year.astype('Int64')
                df['Month_Num']  = parsed.dt.month.astype('Int64')
                df['Month_Name'] = parsed.dt.strftime('%B')
                df['Quarter']    = 'Q' + parsed.dt.quarter.astype(str)
                added += ['Year','Month_Num','Month_Name','Quarter']
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "added_columns": added})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


@tool
def export_clean_file(file_path: str, output_path: str) -> str:
    """Final export: remove blank rows and save clean Excel."""
    try:
        df = pd.read_excel(file_path)
        df = df.dropna(how='all')
        df.to_excel(output_path, index=False)
        return json.dumps({
            "status": "success", "clean_file": output_path,
            "final_rows": len(df), "final_cols": len(df.columns),
            "columns": list(df.columns)
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


def run_cleaning_pipeline(input_path, output_path, progress_callback=None):
    """Run all 10 cleaning tools in sequence."""
    work = str(Path(output_path).parent / "_work_temp.xlsx")
    shutil.copy2(input_path, work)

    steps = [
        ("Profiling data...",         None),
        ("Fixing column names...",    fix_column_names),
        ("Removing duplicates...",    fix_duplicates),
        ("Fixing text & case...",     fix_text_columns),
        ("Parsing dates...",          fix_dates),
        ("Handling nulls...",         fix_nulls),
        ("Fixing numerics...",        fix_numerics),
        ("Standardising categories...", fix_categories),
        ("Adding derived columns...", add_derived_columns),
        ("Exporting clean file...",   None),
    ]
    total = len(steps)

    def cb(i, msg):
        if progress_callback: progress_callback(i, total, msg)

    cb(1, "Profiling original file...")
    profile_before = json.loads(profile_data.invoke({"file_path": work}))

    for i, (msg, fn) in enumerate(steps[1:-1], start=2):
        cb(i, msg)
        if fn:
            try: fn.invoke({"file_path": work})
            except Exception as e: print(f"Step {i} error: {e}")

    cb(total, "Exporting clean file...")
    export_clean_file.invoke({"file_path": work, "output_path": output_path})
    profile_after = json.loads(profile_data.invoke({"file_path": output_path}))
    if Path(work).exists(): Path(work).unlink()

    return {
        "status": "success", "input_file": input_path, "output_file": output_path,
        "profile_before": profile_before, "profile_after": profile_after,
        "improvement": {
            "quality_before": profile_before.get("quality_score", 0),
            "quality_after":  profile_after.get("quality_score", 0),
            "issues_before":  profile_before.get("total_issues", 0),
            "issues_after":   profile_after.get("total_issues", 0),
            "rows_before":    profile_before.get("total_rows", 0),
            "rows_after":     profile_after.get("total_rows", 0),
        }
    }
