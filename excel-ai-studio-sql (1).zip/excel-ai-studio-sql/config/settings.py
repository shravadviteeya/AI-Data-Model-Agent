"""
Central Configuration — Excel AI Studio (SQL Edition)
All settings in one place. Edit this file to customise.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR   = Path(__file__).parent.parent
OUTPUT_DIR = BASE_DIR / "output"
DATA_DIR   = BASE_DIR / "data"
SQL_DIR    = BASE_DIR / "sql"
MIGRATIONS = BASE_DIR / "migrations"

OUTPUT_DIR.mkdir(exist_ok=True)
SQL_DIR.mkdir(exist_ok=True)
MIGRATIONS.mkdir(exist_ok=True)

# ── MySQL / SQL Workbench Connection ─────────────────────────
DB = {
    "host":     os.getenv("DB_HOST",     "127.0.0.1"),
    "port":     int(os.getenv("DB_PORT", "3306")),
    "user":     os.getenv("DB_USER",     "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME",     "excel_ai_studio"),
    "charset":  "utf8mb4",
}

# ── AI Provider ───────────────────────────────────────────────
AI = {
    "provider":        os.getenv("AI_PROVIDER", "auto"),
    "anthropic_key":   os.getenv("ANTHROPIC_API_KEY", ""),
    "openai_key":      os.getenv("OPENAI_API_KEY", ""),
    "gemini_key":      os.getenv("GEMINI_API_KEY", ""),
    "github_token":    os.getenv("GITHUB_TOKEN", ""),
}

# ── Cleaning Thresholds ───────────────────────────────────────
CLEANING = {
    "max_category_unique": 25,     # above this = not a category
    "null_fill_numeric":   "median",  # median | mean | zero
    "null_fill_string":    "Unknown",
    "remove_negatives":    True,
    "date_output_format":  "%Y-%m-%d",
}

# ── SQL Generation ────────────────────────────────────────────
SQL_SETTINGS = {
    "dialect":        "mysql",     # mysql | postgresql | sqlite
    "schema_name":    os.getenv("DB_NAME", "excel_ai_studio"),
    "batch_size":     500,         # rows per INSERT batch
    "create_indexes": True,
    "add_timestamps": True,        # add created_at, updated_at
}

# ── Power BI ──────────────────────────────────────────────────
POWERBI = {
    "currency_symbol": "₹",
    "fiscal_year_start": 4,        # April = month 4
}
