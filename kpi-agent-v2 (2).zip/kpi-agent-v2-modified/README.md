# KPI Intelligence Agent v2

> **Unified multi-source KPI dashboard** for Coforge D&A PMO — 8 Excel sheets, AI-powered insights, and an in-page agent on every tab.

![Python](https://img.shields.io/badge/python-3.9%2B-blue) ![License](https://img.shields.io/badge/license-MIT-green) ![AI](https://img.shields.io/badge/AI-Claude%20%7C%20GPT--4o%20%7C%20Copilot-purple)

---

## ✨ Features

- **8-source unified dashboard** — Finance, SF Pipeline, Closed Deals, Demand, Bench, Fulfillment, Employee Master, Master Reference
- **EE & NN HBU TCV tile** — dedicated KPI tracking HBU Total Contract Value for Existing New (EN) and Renewal (EE) deal types on the SF Pipeline page
- **Per-page AI Agent** — a floating chat panel on every dashboard tab, context-aware to the page's KPIs, powered by Claude (or GPT-4o / Copilot)
- **Auto AI provider selection** — detects `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, or `GITHUB_TOKEN` and selects the best available model automatically
- **Rule-based fallback** — works with zero API keys using heuristic insights
- **Health Score** — 0–100 composite score across all 8 sources

---

## 🗂 Project Structure

```
kpi-agent-v2/
├── main.py                      # CLI entry point (9-step pipeline)
├── config.yaml                  # Column mappings, thresholds, sheet names
├── requirements.txt
├── .env.example                 # Copy to .env and fill in keys
│
├── core/
│   ├── multi_sheet_loader.py    # Loads all 8 Excel sheets
│   ├── salesforce_kpi.py        # Pipeline + Closed Deals KPIs (incl. EE_NN HBU TCV)
│   ├── finance_kpi.py           # Revenue, GM%, monthly series
│   ├── people_kpi.py            # Employee HC, Bench, Fulfillment
│   ├── demand_kpi.py            # Open RRs, ageing
│   ├── master_kpi.py            # Unified health score
│   └── relationship_mapper.py   # Cross-sheet join validation
│
├── agents/
│   ├── base_agent.py            # Claude / GPT-4o / Copilot / fallback
│   └── insight_engine.py        # AI + rule-based insight generation
│
├── ui/
│   ├── dashboard_builder.py     # Injects KPIs into HTML template
│   └── report_builder.py        # Executive summary HTML report
│
├── templates/
│   └── dashboard.html           # 9-tab SPA with per-page AI agent panel
│
├── data/sample/
│   └── generate_sample.py       # Generates realistic sample DATA2.xlsx
│
├── tests/
│   └── test_all.py
│
└── docs/
    └── ARCHITECTURE.md
```

---

## 🚀 Quick Start

### 1. Clone & install

```bash
git clone https://github.com/YOUR-ORG/kpi-agent-v2.git
cd kpi-agent-v2
pip install -r requirements.txt
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env — add at least one AI provider key
```

```env
ANTHROPIC_API_KEY=sk-ant-...      # Claude (recommended)
OPENAI_API_KEY=sk-...             # GPT-4o (optional)
GITHUB_TOKEN=ghp_...              # GitHub Copilot (optional)
```

### 3. Run with sample data

```bash
python main.py --sample
```

### 4. Run with your data

```bash
python main.py --file path/to/DATA2.xlsx
```

The dashboard opens automatically in your browser at `output/dashboard.html`.

---

## 📊 KPI Reference

### SF Pipeline — EE & NN HBU TCV
Tracks the **HBU Total Contract Value** (`HBU_TCV($)` column) filtered to deal types:
- `Existing New (EN)` — new scope on existing accounts
- `Renewal (EE)` — contract renewals

This tile appears as the 6th card on the **SF Pipeline** tab alongside Total TCV, Avg Probability, AI Proposals, Top BU, and Top Stage.

### Health Score
| Range | Label |
|-------|-------|
| 75–100 | ✅ Healthy |
| 50–74 | ⚠️ Watch |
| 0–49 | 🔴 At Risk |

---

## 🤖 Per-Page AI Agent

Every dashboard tab has a floating **AI Agent panel** (bottom-right). It:

- Automatically updates its context when you switch tabs
- Provides 3 smart **suggestion chips** per page
- Sends the live KPI snapshot from that page to Claude as context
- Maintains conversation history (last 10 turns)
- Streams responses via the Anthropic Messages API

To use it, you need `ANTHROPIC_API_KEY` set in your `.env` (used server-side during build). The agent panel makes direct API calls from the browser — ensure CORS is acceptable for your deployment, or proxy via your backend.

---

## ⚙️ Configuration

Edit `config.yaml` to customise:
- Sheet names in your Excel file
- Currency symbol
- KPI thresholds (GM%, win rate, FFTP, billed%)
- Refresh schedule labels
- Dashboard title and company name

---

## 🧪 Tests

```bash
pytest tests/ -v
```

---

## 📦 Excel Sheet Requirements

| Tab Name (configurable) | Key Columns |
|-------------------------|-------------|
| Finance Tracker | Revenue($), Expenses($), Month |
| SALESFORCE DATA | TCV($), HBU_TCV($), TYPE, STAGE, Probability(%), BU |
| Closed Deals | TCV($), Status (Won/Lost), CloseQTR, BU |
| Demand Data | RequestID, IBU, Status, Ageing bucket |
| BENCH DATA | Employee No, Pool, Skill, Days on bench |
| YTD Fulfillment | Request ID, Type, Quarter, FFTP days |
| EMPLOYEE MASTER | Employee No, IBU, Practice, Billed flag |
| Master Reference | IBU / BU concatenation keys |

---

## 📄 License

MIT — see [LICENSE](LICENSE)
