# Changelog

## [2.1.0] - 2026-04-12
### Added
- **EE & NN HBU TCV KPI tile** on the SF Pipeline tab — tracks `HBU_TCV($)` for Existing New (EN) and Renewal (EE) deal types
- **Per-page AI Agent panel** — floating chat widget on all 9 dashboard tabs, context-aware to each page's live KPI snapshot
- Agent panel updates suggestion chips automatically on tab switch
- Conversation history maintained across 10 turns per session
- `LICENSE` file (MIT)
- `setup.py` for pip-installable distribution

### Changed
- SF Pipeline KPI grid expanded from 5 to 6 tiles
- `salesforce_kpi.py`: `calculate_pipeline()` now returns `ee_nn_hbu_tcv` and `ee_nn_hbu_tcv_fmt`
- `dashboard_builder.py`: injects `EE_NN_HBU_TCV` JS constant and `KV_EE_NN_HBU` template variable
- `dashboard.html`: added AI agent CSS, HTML panel, and full JS engine

## [2.0.0] - 2026-04-10
### Initial Release
- 8-source unified Excel dashboard
- 9-tab SPA (Overview + 8 data sources)
- AI insights via Claude / GPT-4o / Copilot / rule-based fallback
- Health Score composite metric
- Cross-sheet relationship mapper
