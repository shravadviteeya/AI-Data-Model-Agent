"""
Fallback Rule-Based Agent
Used when no AI provider API key is available
"""

import re
from typing import Dict, List, Optional
from loguru import logger
from agents.base_agent import BaseAgent


class FallbackAgent(BaseAgent):
    """Rule-based fallback agent - no API key needed"""

    # Common patterns for key detection
    ID_PATTERNS = re.compile(r'(^id$|_id$|^.*_key$|^pk_)', re.IGNORECASE)
    FK_PATTERNS = re.compile(r'(_id$|_fk$|_ref$)', re.IGNORECASE)
    DATE_PATTERNS = re.compile(r'(date|time|created|updated|modified|timestamp)', re.IGNORECASE)
    EMAIL_PATTERNS = re.compile(r'(email|mail)', re.IGNORECASE)
    PHONE_PATTERNS = re.compile(r'(phone|mobile|contact|tel)', re.IGNORECASE)
    NAME_PATTERNS = re.compile(r'(name|title|label|description|desc)', re.IGNORECASE)
    AMOUNT_PATTERNS = re.compile(r'(amount|price|cost|revenue|salary|wage|total|sum)', re.IGNORECASE)

    def __init__(self):
        super().__init__()
        self.name = "FallbackAgent (Rule-Based)"
        logger.warning("Using rule-based agent. Add AI API key for better results.")

    def is_available(self) -> bool:
        return True  # Always available

    def analyze_schema(self, schema_info: Dict) -> Dict:
        logger.info("Rule-based: Analyzing schema...")
        primary_keys = {}
        indexes = {}

        for table_name, columns in schema_info.items():
            col_names = [c['name'] for c in columns]

            # Detect primary keys
            pk = None
            for col in col_names:
                if self.ID_PATTERNS.match(col):
                    pk = col
                    break
            if not pk and col_names:
                pk = col_names[0]  # Default to first column

            primary_keys[table_name] = pk
            indexes[table_name] = [pk] if pk else []

        return {
            "primary_keys": primary_keys,
            "relationships": [],
            "normalization": {"note": "Add AI API key for deep normalization analysis"},
            "type_corrections": {},
            "indexes": indexes
        }

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        logger.info("Rule-based: Detecting relationships...")
        relationships = []
        table_names = {t['name']: t for t in tables}

        for table in tables:
            for col in table.get('columns', []):
                col_name = col['name']
                if self.FK_PATTERNS.search(col_name):
                    # Try to find matching parent table
                    base = re.sub(r'(_id|_fk|_ref)$', '', col_name, flags=re.IGNORECASE)
                    for tname in table_names:
                        if base.lower() in tname.lower() and tname != table['name']:
                            relationships.append({
                                "parent_table": tname,
                                "parent_column": "id",
                                "child_table": table['name'],
                                "child_column": col_name,
                                "relationship_type": "one-to-many",
                                "confidence": 0.7
                            })
                            break
        return relationships

    def suggest_normalization(self, table: Dict) -> Dict:
        issues = []
        suggestions = []
        columns = table.get('columns', [])
        col_names = [c['name'] for c in columns]

        # Check for repeating groups (array-like column names)
        numbered = [c for c in col_names if re.search(r'\d+$', c)]
        if numbered:
            issues.append(f"Possible repeating groups: {numbered} (violates 1NF)")
            suggestions.append("Create a separate table for repeating data")

        # Check for composite keys
        if len([c for c in col_names if self.ID_PATTERNS.match(c)]) > 1:
            issues.append("Multiple ID columns detected - possible composite key")
            suggestions.append("Consider separating into related tables (2NF)")

        return {"issues": issues, "suggestions": suggestions, "split_tables": []}

    def generate_description(self, column_info: Dict) -> str:
        name = column_info.get('name', '')
        table = column_info.get('table_name', '')
        dtype = column_info.get('dtype', '')

        if self.ID_PATTERNS.match(name):
            return f"Unique identifier for {table} records."
        elif self.DATE_PATTERNS.search(name):
            return f"Date/time when the {table} record was {name.lower().replace('_', ' ')}."
        elif self.EMAIL_PATTERNS.search(name):
            return f"Email address associated with the {table}."
        elif self.PHONE_PATTERNS.search(name):
            return f"Phone/mobile number for the {table}."
        elif self.AMOUNT_PATTERNS.search(name):
            return f"Monetary value representing {name.replace('_', ' ')} for the {table}."
        elif self.NAME_PATTERNS.search(name):
            return f"Name or label for the {table}."
        else:
            return f"Stores {name.replace('_', ' ')} information for {table} ({dtype})."
