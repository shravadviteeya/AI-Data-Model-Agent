"""
OpenAI GPT-4 AI Agent
"""

import os
import json
from typing import Dict, List, Optional
from loguru import logger
from agents.base_agent import BaseAgent


class OpenAIAgent(BaseAgent):
    """AI Agent using OpenAI GPT-4"""

    def __init__(self, model: Optional[str] = None):
        super().__init__(model)
        self.name = "OpenAIAgent (GPT-4)"
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4-turbo-preview")
        self.client = None
        if self.is_available():
            from openai import OpenAI
            self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            logger.success(f"OpenAI agent initialized with model: {self.model}")

    def is_available(self) -> bool:
        return bool(os.getenv("OPENAI_API_KEY"))

    def _call(self, prompt: str, max_tokens: int = 4096) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are an expert data architect and database designer."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=max_tokens,
            response_format={"type": "json_object"} if "JSON" in prompt else None
        )
        return response.choices[0].message.content

    def analyze_schema(self, schema_info: Dict) -> Dict:
        logger.info("GPT-4: Analyzing schema...")
        prompt = self._build_schema_prompt(schema_info)
        try:
            result = self._call(prompt)
            return json.loads(result)
        except Exception as e:
            logger.error(f"GPT-4 schema analysis failed: {e}")
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        logger.info("GPT-4: Detecting relationships...")
        prompt = self._build_relationship_prompt(tables)
        try:
            result = self._call(prompt)
            parsed = json.loads(result)
            return parsed if isinstance(parsed, list) else parsed.get("relationships", [])
        except Exception as e:
            logger.error(f"GPT-4 relationship detection failed: {e}")
            return []

    def suggest_normalization(self, table: Dict) -> Dict:
        prompt = f"""As a data architect, analyze normalization for:
Table: {table['name']}
Columns: {json.dumps(table.get('columns', []))}

Return JSON: {{issues: [], suggestions: [], split_tables: []}}"""
        try:
            return json.loads(self._call(prompt))
        except Exception as e:
            logger.error(f"GPT-4 normalization failed: {e}")
            return {}

    def generate_description(self, column_info: Dict) -> str:
        prompt = f"""Write a 1-2 sentence business description for:
Column: {column_info.get('name')} | Type: {column_info.get('dtype')} | Table: {column_info.get('table_name')}
Samples: {column_info.get('sample_values', [])}
Return only the description."""
        try:
            return self._call(prompt, max_tokens=150).strip()
        except Exception as e:
            logger.error(f"GPT-4 description generation failed: {e}")
            return f"Column {column_info.get('name')}"
