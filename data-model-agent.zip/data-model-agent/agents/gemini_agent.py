"""
Google Gemini AI Agent
"""

import os
import json
from typing import Dict, List, Optional
from loguru import logger
from agents.base_agent import BaseAgent


class GeminiAgent(BaseAgent):
    """AI Agent using Google Gemini"""

    def __init__(self, model: Optional[str] = None):
        super().__init__(model)
        self.name = "GeminiAgent (Google)"
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-pro")
        self.client = None
        if self.is_available():
            import google.generativeai as genai
            genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
            self.client = genai.GenerativeModel(self.model)
            logger.success(f"Gemini agent initialized with model: {self.model}")

    def is_available(self) -> bool:
        return bool(os.getenv("GEMINI_API_KEY"))

    def _call(self, prompt: str) -> str:
        response = self.client.generate_content(prompt)
        return response.text

    def analyze_schema(self, schema_info: Dict) -> Dict:
        logger.info("Gemini: Analyzing schema...")
        prompt = self._build_schema_prompt(schema_info)
        try:
            result = self._call(prompt)
            start = result.find('{')
            end = result.rfind('}') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Gemini schema analysis failed: {e}")
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        logger.info("Gemini: Detecting relationships...")
        prompt = self._build_relationship_prompt(tables)
        try:
            result = self._call(prompt)
            start = result.find('[')
            end = result.rfind(']') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Gemini relationship detection failed: {e}")
            return []

    def suggest_normalization(self, table: Dict) -> Dict:
        prompt = f"Analyze normalization for table {table['name']} with columns {table.get('columns')}. Return JSON with issues and suggestions."
        try:
            result = self._call(prompt)
            start = result.find('{')
            end = result.rfind('}') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Gemini normalization failed: {e}")
            return {}

    def generate_description(self, column_info: Dict) -> str:
        prompt = f"Write a 1-sentence business description for column '{column_info.get('name')}' in table '{column_info.get('table_name')}'. Sample values: {column_info.get('sample_values', [])}. Return only the description."
        try:
            return self._call(prompt).strip()
        except Exception as e:
            logger.error(f"Gemini description failed: {e}")
            return f"Column {column_info.get('name')}"
