"""
Anthropic Claude AI Agent
"""

import os
import json
from typing import Dict, List, Optional
from loguru import logger
from agents.base_agent import BaseAgent


class AnthropicAgent(BaseAgent):
    """AI Agent using Anthropic Claude"""

    def __init__(self, model: Optional[str] = None):
        super().__init__(model)
        self.name = "AnthropicAgent (Claude)"
        self.model = model or os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
        self.client = None
        if self.is_available():
            import anthropic
            self.client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
            logger.success(f"Claude agent initialized with model: {self.model}")

    def is_available(self) -> bool:
        return bool(os.getenv("ANTHROPIC_API_KEY"))

    def _call(self, prompt: str, max_tokens: int = 4096) -> str:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text

    def analyze_schema(self, schema_info: Dict) -> Dict:
        logger.info("Claude: Analyzing schema...")
        prompt = self._build_schema_prompt(schema_info)
        try:
            result = self._call(prompt)
            # Extract JSON from response
            start = result.find('{')
            end = result.rfind('}') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Claude schema analysis failed: {e}")
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        logger.info("Claude: Detecting relationships...")
        prompt = self._build_relationship_prompt(tables)
        try:
            result = self._call(prompt)
            start = result.find('[')
            end = result.rfind(']') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Claude relationship detection failed: {e}")
            return []

    def suggest_normalization(self, table: Dict) -> Dict:
        prompt = f"""Analyze this table for normalization issues:
Table: {table['name']}
Columns: {json.dumps(table.get('columns', []), indent=2)}
Sample data patterns: {json.dumps(table.get('sample', []), indent=2)}

Suggest 1NF, 2NF, 3NF normalization steps. Return JSON with:
- issues: list of normalization issues found
- suggestions: list of fixes
- split_tables: any tables that should be split"""
        try:
            result = self._call(prompt)
            start = result.find('{')
            end = result.rfind('}') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Claude normalization failed: {e}")
            return {}

    def generate_description(self, column_info: Dict) -> str:
        prompt = f"""Generate a clear, concise business description (1-2 sentences) for this database column:
Column name: {column_info.get('name')}
Data type: {column_info.get('dtype')}
Sample values: {column_info.get('sample_values', [])}
Null percentage: {column_info.get('null_pct', 0):.0%}
Table: {column_info.get('table_name')}

Return only the description text, nothing else."""
        try:
            return self._call(prompt, max_tokens=200).strip()
        except Exception as e:
            logger.error(f"Claude description generation failed: {e}")
            return f"Column {column_info.get('name')} in {column_info.get('table_name')}"
