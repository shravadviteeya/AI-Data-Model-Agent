"""
Base AI Agent Interface
All AI providers implement this interface
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import os
from loguru import logger


class BaseAgent(ABC):
    """Abstract base class for all AI agents"""

    def __init__(self, model: Optional[str] = None):
        self.model = model
        self.name = "BaseAgent"
        logger.info(f"Initializing {self.name} agent")

    @abstractmethod
    def analyze_schema(self, schema_info: Dict) -> Dict:
        """Analyze schema and suggest improvements"""
        pass

    @abstractmethod
    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        """Detect relationships between tables"""
        pass

    @abstractmethod
    def suggest_normalization(self, table: Dict) -> Dict:
        """Suggest normalization for a table"""
        pass

    @abstractmethod
    def generate_description(self, column_info: Dict) -> str:
        """Generate human-readable description for a column"""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if this agent's API key is available"""
        pass

    def _build_schema_prompt(self, schema_info: Dict) -> str:
        """Build a prompt for schema analysis"""
        tables_desc = []
        for table_name, columns in schema_info.items():
            col_desc = ", ".join([
                f"{col['name']} ({col['dtype']}, nulls: {col['null_pct']:.0%})"
                for col in columns
            ])
            tables_desc.append(f"Table '{table_name}': {col_desc}")

        return f"""You are a senior data architect. Analyze these tables extracted from Excel files and provide:
1. Suggested primary keys for each table
2. Detected foreign key relationships
3. Normalization recommendations (1NF/2NF/3NF)
4. Data type corrections
5. Suggested indexes

Tables:
{chr(10).join(tables_desc)}

Respond in JSON format with keys: primary_keys, relationships, normalization, type_corrections, indexes"""

    def _build_relationship_prompt(self, tables: List[Dict]) -> str:
        """Build prompt for relationship detection"""
        table_summary = []
        for t in tables:
            cols = [c['name'] for c in t.get('columns', [])]
            table_summary.append(f"- {t['name']}: {', '.join(cols)}")

        return f"""Analyze these database tables and detect relationships:

{chr(10).join(table_summary)}

For each relationship identify:
- parent_table, parent_column
- child_table, child_column  
- relationship_type (one-to-one, one-to-many, many-to-many)
- confidence (0.0 to 1.0)

Respond in JSON array format."""


class AgentFactory:
    """Factory to create and manage AI agents"""

    @staticmethod
    def create(provider: str = "auto") -> "BaseAgent":
        """Create an AI agent based on provider name"""
        from agents.openai_agent import OpenAIAgent
        from agents.anthropic_agent import AnthropicAgent
        from agents.gemini_agent import GeminiAgent
        from agents.copilot_agent import CopilotAgent

        providers = {
            "openai": OpenAIAgent,
            "anthropic": AnthropicAgent,
            "gemini": GeminiAgent,
            "copilot": CopilotAgent,
        }

        if provider == "auto":
            # Try each provider and use first available
            for name, AgentClass in providers.items():
                agent = AgentClass()
                if agent.is_available():
                    logger.info(f"Auto-selected AI provider: {name}")
                    return agent
            logger.warning("No AI provider available. Using rule-based analysis.")
            from agents.fallback_agent import FallbackAgent
            return FallbackAgent()

        if provider not in providers:
            raise ValueError(f"Unknown provider: {provider}. Choose from: {list(providers.keys())}")

        agent = providers[provider]()
        if not agent.is_available():
            logger.warning(f"{provider} API key not found. Falling back to rule-based.")
            from agents.fallback_agent import FallbackAgent
            return FallbackAgent()

        return agent
