"""
GitHub Copilot Agent
Uses GitHub API with Copilot capabilities
"""

import os
import json
from typing import Dict, List, Optional
from loguru import logger
from agents.base_agent import BaseAgent


class CopilotAgent(BaseAgent):
    """AI Agent using GitHub Copilot via API"""

    def __init__(self, model: Optional[str] = None):
        super().__init__(model)
        self.name = "CopilotAgent (GitHub)"
        self.model = "gpt-4o"  # Copilot uses OpenAI models
        self.client = None
        if self.is_available():
            from openai import OpenAI
            # GitHub Copilot uses OpenAI-compatible API
            self.client = OpenAI(
                api_key=os.getenv("GITHUB_TOKEN"),
                base_url="https://models.inference.ai.azure.com"
            )
            logger.success("GitHub Copilot agent initialized")

    def is_available(self) -> bool:
        return bool(os.getenv("GITHUB_TOKEN"))

    def _call(self, prompt: str, max_tokens: int = 4096) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are an expert data architect."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=max_tokens
        )
        return response.choices[0].message.content

    def analyze_schema(self, schema_info: Dict) -> Dict:
        logger.info("Copilot: Analyzing schema...")
        prompt = self._build_schema_prompt(schema_info)
        try:
            result = self._call(prompt)
            start = result.find('{')
            end = result.rfind('}') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Copilot schema analysis failed: {e}")
            return {}

    def detect_relationships(self, tables: List[Dict]) -> List[Dict]:
        logger.info("Copilot: Detecting relationships...")
        prompt = self._build_relationship_prompt(tables)
        try:
            result = self._call(prompt)
            start = result.find('[')
            end = result.rfind(']') + 1
            return json.loads(result[start:end])
        except Exception as e:
            logger.error(f"Copilot relationship detection failed: {e}")
            return []

    def suggest_normalization(self, table: Dict) -> Dict:
        prompt = f"Normalize table {table['name']} columns {table.get('columns')}. Return JSON."
        try:
            result = self._call(prompt)
            start = result.find('{')
            end = result.rfind('}') + 1
            return json.loads(result[start:end])
        except Exception as e:
            return {}

    def generate_description(self, column_info: Dict) -> str:
        prompt = f"1-sentence description for column '{column_info.get('name')}' in '{column_info.get('table_name')}'. Return description only."
        try:
            return self._call(prompt, max_tokens=150).strip()
        except Exception as e:
            return f"Column {column_info.get('name')}"
