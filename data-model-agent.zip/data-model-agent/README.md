# 🤖 AI Data Model Agent

An intelligent agent that analyzes multiple Excel files and automatically generates a robust, normalized data model with ER diagrams, SQL DDL scripts, and documentation.

---

## 🚀 Features

- 📊 **Multi-Excel Analysis** — Processes multiple Excel files simultaneously
- 🧠 **AI-Powered Intelligence** — Supports OpenAI (GPT-4), Anthropic (Claude), GitHub Copilot, Google Gemini
- 🔗 **Relationship Detection** — Auto-detects foreign keys and relationships
- 📐 **Data Normalization** — Applies 1NF, 2NF, 3NF automatically
- 📝 **SQL DDL Generation** — PostgreSQL, MySQL, SQLite, SQL Server
- 📈 **ER Diagram** — Auto-generates Entity Relationship diagrams (Mermaid + HTML)
- 📄 **Full Documentation** — Data dictionary, lineage, and model docs
- 🔍 **Data Quality Reports** — Nulls, duplicates, anomalies detection
- 🌐 **Web UI** — Beautiful browser-based interface
- 💻 **CLI Support** — Command-line interface for automation

---

## 📁 Project Structure

```
data-model-agent/
├── main.py                  # Entry point
├── requirements.txt         # Python dependencies
├── .env.example            # Environment variables template
├── config.yaml             # Configuration file
├── README.md               # This file
│
├── core/
│   ├── excel_analyzer.py   # Excel parsing & analysis
│   ├── data_profiler.py    # Data profiling & quality
│   ├── relationship_detector.py  # FK & relationship detection
│   ├── normalizer.py       # Data normalization engine
│   └── model_builder.py    # Data model construction
│
├── agents/
│   ├── base_agent.py       # Base AI agent interface
│   ├── openai_agent.py     # OpenAI GPT-4 agent
│   ├── anthropic_agent.py  # Anthropic Claude agent
│   ├── gemini_agent.py     # Google Gemini agent
│   └── copilot_agent.py    # GitHub Copilot agent
│
├── utils/
│   ├── sql_generator.py    # SQL DDL generator
│   ├── diagram_generator.py # ER diagram generator
│   ├── doc_generator.py    # Documentation generator
│   └── report_generator.py # HTML report generator
│
├── output/                 # Generated outputs
├── examples/               # Sample Excel files
├── tests/                  # Unit tests
└── docs/                   # Additional documentation
```

---

## ⚙️ Installation

### Step 1 — Clone Repository
```bash
git clone https://github.com/yourusername/data-model-agent.git
cd data-model-agent
```

### Step 2 — Create Virtual Environment
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### Step 3 — Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Configure API Keys
```bash
cp .env.example .env
# Edit .env with your API keys
```

---

## 🔑 AI Provider Configuration

Edit `.env` file:

```env
# Choose your AI provider: openai | anthropic | gemini | copilot | auto
AI_PROVIDER=anthropic

# OpenAI (GPT-4)
OPENAI_API_KEY=your_openai_key_here

# Anthropic (Claude)
ANTHROPIC_API_KEY=your_anthropic_key_here

# Google Gemini
GEMINI_API_KEY=your_gemini_key_here

# GitHub Copilot
GITHUB_TOKEN=your_github_token_here
```

---

## 🎯 Usage

### Web UI (Recommended)
```bash
python main.py --ui
# Opens browser at http://localhost:8501
```

### Command Line
```bash
# Single file
python main.py --files data.xlsx --provider anthropic

# Multiple files
python main.py --files sales.xlsx customers.xlsx products.xlsx --provider openai

# With output directory
python main.py --files *.xlsx --output ./my_model --provider gemini

# Auto-select best available AI
python main.py --files *.xlsx --provider auto
```

---

## 📤 Output Files

After running, the `output/` folder contains:

| File | Description |
|------|-------------|
| `data_model.json` | Complete data model in JSON |
| `er_diagram.html` | Interactive ER diagram |
| `er_diagram.mmd` | Mermaid ER diagram source |
| `schema.sql` | SQL DDL (CREATE TABLE statements) |
| `data_dictionary.md` | Full data dictionary |
| `quality_report.html` | Data quality report |
| `model_summary.pdf` | Executive summary |

---

## 🧠 How It Works

```
Excel Files Input
      ↓
  Parse & Analyze (Excel Analyzer)
      ↓
  Profile Data (Data Profiler)
      ↓
  Detect Relationships (Relationship Detector)
      ↓
  AI Enhancement (Your chosen AI provider)
      ↓
  Normalize Data Model (Normalizer)
      ↓
  Build Final Model (Model Builder)
      ↓
  Generate Outputs:
  ├── SQL DDL Scripts
  ├── ER Diagrams
  ├── Documentation
  └── Quality Reports
```

---

## 🤝 Contributing

Pull requests are welcome! See `docs/CONTRIBUTING.md` for guidelines.

---

## 📜 License

MIT License — see `LICENSE` file for details.
