"""
AI Data Model Agent - Main Entry Point
"""

import os
import sys
import json
import click
from pathlib import Path
from datetime import datetime
from loguru import logger
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logger
logger.remove()
logger.add(sys.stderr, format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}", level="INFO")


def run_pipeline(file_paths: list, provider: str, output_dir: str, dialect: str) -> dict:
    """Run the complete data modeling pipeline"""
    from core.excel_analyzer import ExcelAnalyzer
    from core.relationship_detector import RelationshipDetector
    from agents.base_agent import AgentFactory
    from utils.sql_generator import SQLGenerator
    from utils.diagram_generator import DiagramGenerator

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("🤖 AI DATA MODEL AGENT STARTING")
    logger.info(f"📁 Files: {len(file_paths)}")
    logger.info(f"🧠 AI Provider: {provider}")
    logger.info(f"🗄️  SQL Dialect: {dialect}")
    logger.info("=" * 60)

    # STEP 1: Load and analyze Excel files
    logger.info("\n📊 STEP 1: Loading Excel Files...")
    analyzer = ExcelAnalyzer()
    analyzer.load_files(file_paths)
    schema = analyzer.analyze_all()

    if not schema:
        logger.error("No data found in the provided files!")
        return {}

    # STEP 2: Initialize AI Agent
    logger.info(f"\n🧠 STEP 2: Initializing AI Agent ({provider})...")
    agent = AgentFactory.create(provider)
    logger.success(f"Using: {agent.name}")

    # STEP 3: AI Schema Analysis
    logger.info("\n🔍 STEP 3: AI Schema Analysis...")
    schema_summary = analyzer.get_schema_summary()
    ai_analysis = agent.analyze_schema(schema_summary)

    # STEP 4: Relationship Detection
    logger.info("\n🔗 STEP 4: Detecting Relationships...")
    tables_list = [{"name": k, "columns": v.get("columns", [])} for k, v in schema.items()]
    ai_relationships = agent.detect_relationships(tables_list)

    detector = RelationshipDetector()
    relationships = detector.detect(schema, ai_relationships)

    # STEP 5: Build Final Model
    logger.info("\n🏗️  STEP 5: Building Data Model...")
    model = {}
    for table_name, table_info in schema.items():
        # Set primary keys from AI analysis
        pk_suggestions = ai_analysis.get('primary_keys', {})
        pk = pk_suggestions.get(table_name)

        # Fallback: detect from columns
        if not pk:
            for col in table_info['columns']:
                if col.get('is_pk_candidate'):
                    pk = col['name']
                    break

        # Generate AI descriptions for columns
        for col in table_info['columns']:
            col['description'] = agent.generate_description(col)

        model[table_name] = {**table_info, 'primary_key': pk}

    # STEP 6: Generate SQL DDL
    logger.info(f"\n📝 STEP 6: Generating {dialect.upper()} DDL...")
    sql_gen = SQLGenerator(dialect=dialect)
    sql_ddl = sql_gen.generate(model, relationships)

    sql_file = output_path / "schema.sql"
    sql_file.write_text(sql_ddl)
    logger.success(f"SQL saved: {sql_file}")

    # STEP 7: Generate ER Diagram
    logger.info("\n📐 STEP 7: Generating ER Diagram...")
    diagram_gen = DiagramGenerator()
    mermaid_code = diagram_gen.generate_mermaid(model, relationships)
    html_diagram = diagram_gen.generate_html(model, relationships, title="AI Generated Data Model")

    mermaid_file = output_path / "er_diagram.mmd"
    mermaid_file.write_text(mermaid_code)

    html_file = output_path / "er_diagram.html"
    html_file.write_text(html_diagram)
    logger.success(f"ER Diagram saved: {html_file}")

    # STEP 8: Generate Data Dictionary
    logger.info("\n📚 STEP 8: Generating Data Dictionary...")
    dict_content = generate_data_dictionary(model, relationships)
    dict_file = output_path / "data_dictionary.md"
    dict_file.write_text(dict_content)
    logger.success(f"Data Dictionary saved: {dict_file}")

    # STEP 9: Save Model JSON
    logger.info("\n💾 STEP 9: Saving Model JSON...")
    model_data = {
        "metadata": {
            "generated_at": datetime.now().isoformat(),
            "ai_provider": provider,
            "sql_dialect": dialect,
            "files_processed": len(file_paths),
            "tables": len(model),
            "relationships": len(relationships)
        },
        "model": model,
        "relationships": relationships,
        "ai_analysis": ai_analysis
    }

    json_file = output_path / "data_model.json"
    with open(json_file, 'w', indent=2) as f:
        json.dump(model_data, f, default=str)
    logger.success(f"Model JSON saved: {json_file}")

    # Summary
    logger.info("\n" + "=" * 60)
    logger.success("✅ DATA MODEL GENERATION COMPLETE!")
    logger.info(f"📁 Output directory: {output_path.absolute()}")
    logger.info(f"📊 Tables created: {len(model)}")
    logger.info(f"🔗 Relationships found: {len(relationships)}")
    logger.info(f"📄 Files generated:")
    logger.info(f"   • schema.sql")
    logger.info(f"   • er_diagram.html")
    logger.info(f"   • er_diagram.mmd")
    logger.info(f"   • data_dictionary.md")
    logger.info(f"   • data_model.json")
    logger.info("=" * 60)

    return model_data


def generate_data_dictionary(model: dict, relationships: list) -> str:
    """Generate a Markdown data dictionary"""
    lines = [
        "# Data Dictionary",
        f"\n*Generated by AI Data Model Agent on {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n",
        "## Tables\n"
    ]

    for table_name, table_info in model.items():
        lines.append(f"### {table_name}")
        lines.append(f"- **Rows:** {table_info.get('row_count', 0):,}")
        lines.append(f"- **Columns:** {table_info.get('column_count', 0)}")
        lines.append(f"- **Completeness:** {table_info.get('completeness', 0):.0%}")
        lines.append(f"- **Primary Key:** {table_info.get('primary_key', 'N/A')}\n")

        lines.append("| Column | Type | Nullable | Unique | Description |")
        lines.append("|--------|------|----------|--------|-------------|")

        for col in table_info.get('columns', []):
            nullable = "Yes" if col.get('null_pct', 1) > 0.05 else "No"
            lines.append(
                f"| {col['name']} | `{col.get('sql_type','VARCHAR')}` | {nullable} | "
                f"{col.get('unique_count', 0):,} | {col.get('description', '-')} |"
            )
        lines.append("")

    lines.append("## Relationships\n")
    lines.append("| Parent Table | Parent Column | Child Table | Child Column | Type | Confidence |")
    lines.append("|-------------|--------------|------------|-------------|------|-----------|")
    for rel in relationships:
        lines.append(
            f"| {rel['parent_table']} | {rel['parent_column']} | "
            f"{rel['child_table']} | {rel['child_column']} | "
            f"{rel.get('relationship_type', 'one-to-many')} | {rel['confidence']:.0%} |"
        )

    return '\n'.join(lines)


@click.command()
@click.option('--files', '-f', multiple=True, required=False, help='Excel file paths')
@click.option('--provider', '-p', default='auto',
              type=click.Choice(['auto', 'openai', 'anthropic', 'gemini', 'copilot']),
              help='AI provider to use')
@click.option('--output', '-o', default='./output', help='Output directory')
@click.option('--dialect', '-d', default='postgresql',
              type=click.Choice(['postgresql', 'mysql', 'sqlite', 'sqlserver']),
              help='SQL dialect')
@click.option('--ui', is_flag=True, help='Launch web UI')
def main(files, provider, output, dialect, ui):
    """🤖 AI Data Model Agent - Generate data models from Excel files"""

    if ui:
        logger.info("Launching Web UI...")
        os.system(f"streamlit run ui/app.py --server.port {os.getenv('UI_PORT', 8501)}")
        return

    if not files:
        click.echo("❌ Please provide Excel files with --files flag")
        click.echo("   Example: python main.py --files sales.xlsx customers.xlsx")
        click.echo("   Or launch UI: python main.py --ui")
        sys.exit(1)

    run_pipeline(list(files), provider, output, dialect)


if __name__ == "__main__":
    main()
