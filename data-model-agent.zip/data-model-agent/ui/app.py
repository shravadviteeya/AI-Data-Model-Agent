"""
AI Data Model Agent - Web UI
Built with Streamlit
"""

import streamlit as st
import os
import sys
import json
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

st.set_page_config(
    page_title="AI Data Model Agent",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem; border-radius: 12px; color: white; margin-bottom: 2rem;
    }
    .stat-box {
        background: white; border: 1px solid #e8e8e8; border-radius: 10px;
        padding: 1rem; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .stat-number { font-size: 2rem; font-weight: 700; color: #667eea; }
    .stat-label { color: #666; font-size: 0.85rem; }
    .step-box {
        background: #f8f9ff; border-left: 4px solid #667eea;
        padding: 1rem; border-radius: 0 8px 8px 0; margin: 0.5rem 0;
    }
    .success-box {
        background: #d4edda; border: 1px solid #c3e6cb;
        border-radius: 8px; padding: 1rem; margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)


def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🤖 AI Data Model Agent</h1>
        <p>Upload Excel files → Get a complete, normalized data model with ER diagrams and SQL scripts</p>
    </div>
    """, unsafe_allow_html=True)

    # Sidebar Configuration
    with st.sidebar:
        st.header("⚙️ Configuration")

        # AI Provider
        st.subheader("🧠 AI Provider")
        provider = st.selectbox(
            "Select AI Provider",
            ["auto", "anthropic", "openai", "gemini", "copilot"],
            help="'auto' selects the first available provider based on your API keys"
        )

        # API Keys
        with st.expander("🔑 API Keys"):
            if provider in ["auto", "anthropic"]:
                anthropic_key = st.text_input("Anthropic API Key", type="password",
                    value=os.getenv("ANTHROPIC_API_KEY", ""))
                if anthropic_key:
                    os.environ["ANTHROPIC_API_KEY"] = anthropic_key

            if provider in ["auto", "openai"]:
                openai_key = st.text_input("OpenAI API Key", type="password",
                    value=os.getenv("OPENAI_API_KEY", ""))
                if openai_key:
                    os.environ["OPENAI_API_KEY"] = openai_key

            if provider in ["auto", "gemini"]:
                gemini_key = st.text_input("Google Gemini API Key", type="password",
                    value=os.getenv("GEMINI_API_KEY", ""))
                if gemini_key:
                    os.environ["GEMINI_API_KEY"] = gemini_key

            if provider in ["auto", "copilot"]:
                github_token = st.text_input("GitHub Token", type="password",
                    value=os.getenv("GITHUB_TOKEN", ""))
                if github_token:
                    os.environ["GITHUB_TOKEN"] = github_token

        # SQL Dialect
        st.subheader("🗄️ SQL Settings")
        dialect = st.selectbox(
            "SQL Dialect",
            ["postgresql", "mysql", "sqlite", "sqlserver"]
        )

        # Analysis Settings
        st.subheader("🔬 Analysis Settings")
        confidence = st.slider("Relationship Confidence Threshold", 0.5, 1.0, 0.7, 0.05)
        max_rows = st.number_input("Max Sample Rows", 100, 10000, 1000)

        st.divider()
        st.caption("💡 Add your API keys in `.env` file for persistent configuration")

    # Main Area - File Upload
    st.header("📁 Upload Excel Files")
    uploaded_files = st.file_uploader(
        "Drop your Excel files here",
        type=['xlsx', 'xls'],
        accept_multiple_files=True,
        help="Upload one or more Excel files. Each sheet will be treated as a separate table."
    )

    # How it works
    with st.expander("ℹ️ How It Works"):
        cols = st.columns(5)
        steps = [
            ("1️⃣", "Parse Excel", "Reads all sheets from each Excel file"),
            ("2️⃣", "Profile Data", "Analyzes types, nulls, cardinality"),
            ("3️⃣", "AI Analysis", "AI detects PKs, FKs, normalizes schema"),
            ("4️⃣", "Build Model", "Constructs normalized data model"),
            ("5️⃣", "Generate Output", "SQL, ER diagram, data dictionary"),
        ]
        for col, (num, title, desc) in zip(cols, steps):
            with col:
                st.markdown(f"**{num} {title}**")
                st.caption(desc)

    if uploaded_files:
        st.success(f"✅ {len(uploaded_files)} file(s) uploaded")

        # Show file info
        file_cols = st.columns(min(len(uploaded_files), 4))
        for i, f in enumerate(uploaded_files):
            with file_cols[i % 4]:
                st.metric(f.name, f"{f.size / 1024:.1f} KB")

        st.divider()

        # Generate Button
        if st.button("🚀 Generate Data Model", type="primary", use_container_width=True):
            with tempfile.TemporaryDirectory() as tmp_dir:
                # Save uploaded files
                file_paths = []
                for uploaded_file in uploaded_files:
                    file_path = os.path.join(tmp_dir, uploaded_file.name)
                    with open(file_path, 'wb') as f:
                        f.write(uploaded_file.getbuffer())
                    file_paths.append(file_path)

                output_dir = os.path.join(tmp_dir, "output")

                # Progress tracking
                progress_bar = st.progress(0)
                status_text = st.empty()

                try:
                    steps_done = 0
                    total_steps = 9

                    def update_progress(msg, step):
                        status_text.markdown(f"**{msg}**")
                        progress_bar.progress(step / total_steps)

                    update_progress("📊 Loading Excel files...", 1)
                    from main import run_pipeline
                    
                    update_progress("🧠 Running AI analysis...", 3)
                    result = run_pipeline(file_paths, provider, output_dir, dialect)
                    
                    progress_bar.progress(1.0)
                    status_text.markdown("**✅ Complete!**")

                    if result:
                        st.balloons()
                        st.success("🎉 Data Model Generated Successfully!")

                        # Show stats
                        metadata = result.get('metadata', {})
                        col1, col2, col3, col4 = st.columns(4)
                        with col1:
                            st.markdown(f'<div class="stat-box"><div class="stat-number">{metadata.get("tables", 0)}</div><div class="stat-label">Tables</div></div>', unsafe_allow_html=True)
                        with col2:
                            st.markdown(f'<div class="stat-box"><div class="stat-number">{metadata.get("relationships", 0)}</div><div class="stat-label">Relationships</div></div>', unsafe_allow_html=True)
                        with col3:
                            total_cols = sum(t.get('column_count', 0) for t in result.get('model', {}).values())
                            st.markdown(f'<div class="stat-box"><div class="stat-number">{total_cols}</div><div class="stat-label">Columns</div></div>', unsafe_allow_html=True)
                        with col4:
                            st.markdown(f'<div class="stat-box"><div class="stat-number">{metadata.get("ai_provider", "N/A")}</div><div class="stat-label">AI Provider</div></div>', unsafe_allow_html=True)

                        st.divider()

                        # Tabs for outputs
                        tab1, tab2, tab3, tab4 = st.tabs(["📐 ER Diagram", "📝 SQL DDL", "📚 Data Dictionary", "📊 Model JSON"])

                        with tab1:
                            html_file = Path(output_dir) / "er_diagram.html"
                            if html_file.exists():
                                st.components.v1.html(html_file.read_text(), height=700, scrolling=True)
                                st.download_button("⬇️ Download ER Diagram", html_file.read_bytes(),
                                    "er_diagram.html", "text/html")

                        with tab2:
                            sql_file = Path(output_dir) / "schema.sql"
                            if sql_file.exists():
                                sql_content = sql_file.read_text()
                                st.code(sql_content, language='sql')
                                st.download_button("⬇️ Download SQL", sql_content,
                                    f"schema_{dialect}.sql", "text/plain")

                        with tab3:
                            dict_file = Path(output_dir) / "data_dictionary.md"
                            if dict_file.exists():
                                dict_content = dict_file.read_text()
                                st.markdown(dict_content)
                                st.download_button("⬇️ Download Data Dictionary", dict_content,
                                    "data_dictionary.md", "text/plain")

                        with tab4:
                            json_file = Path(output_dir) / "data_model.json"
                            if json_file.exists():
                                json_content = json_file.read_text()
                                st.json(json.loads(json_content))
                                st.download_button("⬇️ Download JSON", json_content,
                                    "data_model.json", "application/json")

                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
                    st.exception(e)

    else:
        # Show example
        st.info("👆 Upload your Excel files above to get started")
        st.subheader("📋 What you'll get:")
        cols = st.columns(3)
        with cols[0]:
            st.markdown("**🗄️ SQL DDL Scripts**\nPostgreSQL, MySQL, SQLite, SQL Server")
        with cols[1]:
            st.markdown("**📐 ER Diagram**\nInteractive HTML + Mermaid format")
        with cols[2]:
            st.markdown("**📚 Data Dictionary**\nComplete documentation with AI descriptions")


if __name__ == "__main__":
    main()
