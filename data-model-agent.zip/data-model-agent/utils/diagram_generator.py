"""
ER Diagram Generator
Generates Mermaid ER diagrams and interactive HTML diagrams
"""

from typing import Dict, List
from loguru import logger


class DiagramGenerator:
    """Generates ER diagrams in multiple formats"""

    def __init__(self):
        self.mermaid_code = ""

    def generate_mermaid(self, model: Dict, relationships: List[Dict]) -> str:
        """Generate Mermaid ER diagram code"""
        logger.info("Generating Mermaid ER diagram...")
        lines = ["erDiagram"]

        # Add entities
        for table_name, table_info in model.items():
            lines.append(f"    {table_name} {{")
            for col in table_info.get('columns', []):
                dtype = col.get('sql_type', 'VARCHAR').split('(')[0].replace(' ', '_')
                pk_marker = "PK" if col['name'] == table_info.get('primary_key') else ""
                fk_marker = "FK" if col.get('is_fk_candidate') else ""
                marker = pk_marker or fk_marker or ""
                lines.append(f"        {dtype} {col['name']} {marker}".rstrip())
            lines.append("    }")

        lines.append("")

        # Add relationships
        for rel in relationships:
            rel_type = self._mermaid_rel_type(rel.get('relationship_type', 'one-to-many'))
            lines.append(
                f"    {rel['parent_table']} {rel_type} {rel['child_table']} : \"{rel['child_column']}\""
            )

        self.mermaid_code = '\n'.join(lines)
        return self.mermaid_code

    def generate_html(self, model: Dict, relationships: List[Dict], title: str = "Data Model") -> str:
        """Generate interactive HTML ER diagram"""
        logger.info("Generating HTML ER diagram...")
        mermaid = self.generate_mermaid(model, relationships)

        # Build table summary
        table_cards = ""
        for table_name, table_info in model.items():
            pk = table_info.get('primary_key', 'N/A')
            row_count = table_info.get('row_count', 0)
            col_count = table_info.get('column_count', 0)
            completeness = table_info.get('completeness', 0)

            col_rows = ""
            for col in table_info.get('columns', []):
                pk_badge = '<span class="badge pk">PK</span>' if col['name'] == pk else ''
                fk_badge = '<span class="badge fk">FK</span>' if col.get('is_fk_candidate') else ''
                null_class = 'null-high' if col.get('null_pct', 0) > 0.3 else ''
                col_rows += f"""
                <tr class="{null_class}">
                    <td>{col['name']} {pk_badge} {fk_badge}</td>
                    <td><code>{col.get('sql_type','VARCHAR')}</code></td>
                    <td>{col.get('null_pct', 0):.0%}</td>
                    <td>{col.get('unique_count', 0):,}</td>
                </tr>"""

            table_cards += f"""
            <div class="table-card">
                <div class="table-header">
                    <h3>📊 {table_name}</h3>
                    <div class="table-meta">
                        <span>🔢 {row_count:,} rows</span>
                        <span>📋 {col_count} cols</span>
                        <span>✅ {completeness:.0%} complete</span>
                    </div>
                </div>
                <table class="col-table">
                    <thead><tr><th>Column</th><th>Type</th><th>Nulls</th><th>Unique</th></tr></thead>
                    <tbody>{col_rows}</tbody>
                </table>
            </div>"""

        # Relationship list
        rel_rows = ""
        for rel in relationships:
            confidence_class = 'high' if rel['confidence'] >= 0.8 else 'medium' if rel['confidence'] >= 0.6 else 'low'
            rel_rows += f"""
            <tr>
                <td><strong>{rel['parent_table']}</strong>.{rel['parent_column']}</td>
                <td>→</td>
                <td><strong>{rel['child_table']}</strong>.{rel['child_column']}</td>
                <td>{rel.get('relationship_type', 'one-to-many')}</td>
                <td><span class="confidence {confidence_class}">{rel['confidence']:.0%}</span></td>
                <td>{rel.get('source', 'auto')}</td>
            </tr>"""

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - ER Diagram</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f0f2f5; color: #333; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }}
        .header h1 {{ font-size: 2rem; margin-bottom: 8px; }}
        .header p {{ opacity: 0.85; font-size: 1rem; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 30px 20px; }}
        .section {{ background: white; border-radius: 12px; padding: 25px; margin-bottom: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }}
        .section h2 {{ font-size: 1.4rem; color: #667eea; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #f0f0f0; }}
        .diagram-container {{ background: #fafafa; border-radius: 8px; padding: 20px; overflow-x: auto; }}
        .tables-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); gap: 20px; }}
        .table-card {{ border: 1px solid #e8e8e8; border-radius: 10px; overflow: hidden; }}
        .table-header {{ background: linear-gradient(135deg, #667eea20, #764ba220); padding: 15px; }}
        .table-header h3 {{ font-size: 1.1rem; color: #333; }}
        .table-meta {{ display: flex; gap: 15px; margin-top: 8px; font-size: 0.85rem; color: #666; }}
        .col-table {{ width: 100%; border-collapse: collapse; font-size: 0.88rem; }}
        .col-table th {{ background: #f5f5f5; padding: 8px 12px; text-align: left; font-weight: 600; color: #555; }}
        .col-table td {{ padding: 8px 12px; border-top: 1px solid #f0f0f0; }}
        .col-table tr:hover td {{ background: #fafafa; }}
        .col-table tr.null-high td {{ background: #fff5f5; }}
        .badge {{ font-size: 0.7rem; padding: 2px 6px; border-radius: 4px; font-weight: 700; margin-left: 4px; }}
        .badge.pk {{ background: #667eea; color: white; }}
        .badge.fk {{ background: #f5a623; color: white; }}
        code {{ background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 0.82rem; }}
        .rel-table {{ width: 100%; border-collapse: collapse; }}
        .rel-table th {{ background: #f5f5f5; padding: 10px 15px; text-align: left; font-weight: 600; }}
        .rel-table td {{ padding: 10px 15px; border-top: 1px solid #f0f0f0; }}
        .confidence {{ padding: 3px 8px; border-radius: 20px; font-size: 0.82rem; font-weight: 600; }}
        .confidence.high {{ background: #d4edda; color: #155724; }}
        .confidence.medium {{ background: #fff3cd; color: #856404; }}
        .confidence.low {{ background: #f8d7da; color: #721c24; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px; }}
        .stat-card {{ background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-radius: 10px; padding: 20px; text-align: center; }}
        .stat-card .number {{ font-size: 2rem; font-weight: 700; }}
        .stat-card .label {{ font-size: 0.85rem; opacity: 0.9; margin-top: 5px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🗄️ {title}</h1>
        <p>AI-Generated Data Model — Entity Relationship Diagram</p>
    </div>
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card"><div class="number">{len(model)}</div><div class="label">Tables</div></div>
            <div class="stat-card"><div class="number">{sum(t.get('column_count',0) for t in model.values())}</div><div class="label">Total Columns</div></div>
            <div class="stat-card"><div class="number">{sum(t.get('row_count',0) for t in model.values()):,}</div><div class="label">Total Rows</div></div>
            <div class="stat-card"><div class="number">{len(relationships)}</div><div class="label">Relationships</div></div>
        </div>

        <div class="section">
            <h2>📐 ER Diagram</h2>
            <div class="diagram-container">
                <div class="mermaid">{mermaid}</div>
            </div>
        </div>

        <div class="section">
            <h2>📊 Table Details</h2>
            <div class="tables-grid">{table_cards}</div>
        </div>

        <div class="section">
            <h2>🔗 Relationships</h2>
            <table class="rel-table">
                <thead><tr><th>Parent</th><th></th><th>Child</th><th>Type</th><th>Confidence</th><th>Source</th></tr></thead>
                <tbody>{rel_rows}</tbody>
            </table>
        </div>
    </div>
    <script>mermaid.initialize({{ startOnLoad: true, theme: 'default' }});</script>
</body>
</html>"""
        return html

    def _mermaid_rel_type(self, rel_type: str) -> str:
        types = {
            'one-to-one': '||--||',
            'one-to-many': '||--o{',
            'many-to-one': '}o--||',
            'many-to-many': '}o--o{'
        }
        return types.get(rel_type, '||--o{')
