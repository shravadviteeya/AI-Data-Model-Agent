"""
Excel Analyzer - Core module for parsing and analyzing Excel files
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
from loguru import logger
from tqdm import tqdm


class ExcelAnalyzer:
    """Analyzes multiple Excel files and extracts schema information"""

    def __init__(self, max_sample_rows: int = 1000):
        self.max_sample_rows = max_sample_rows
        self.tables = {}
        self.raw_dataframes = {}

    def load_files(self, file_paths: List[str]) -> Dict[str, pd.DataFrame]:
        """Load all Excel files and return as dict of DataFrames"""
        logger.info(f"Loading {len(file_paths)} Excel file(s)...")

        for file_path in tqdm(file_paths, desc="Loading files"):
            path = Path(file_path)
            if not path.exists():
                logger.warning(f"File not found: {file_path}")
                continue

            try:
                # Load all sheets
                xl = pd.ExcelFile(file_path)
                for sheet_name in xl.sheet_names:
                    df = pd.read_excel(file_path, sheet_name=sheet_name)
                    if df.empty:
                        continue

                    # Create table name from file + sheet
                    if len(xl.sheet_names) == 1:
                        table_name = self._clean_name(path.stem)
                    else:
                        table_name = self._clean_name(f"{path.stem}_{sheet_name}")

                    self.raw_dataframes[table_name] = df
                    logger.success(f"Loaded: {table_name} ({len(df)} rows × {len(df.columns)} cols)")

            except Exception as e:
                logger.error(f"Failed to load {file_path}: {e}")

        return self.raw_dataframes

    def analyze_all(self) -> Dict:
        """Analyze all loaded DataFrames and build schema info"""
        logger.info("Analyzing schema for all tables...")
        schema = {}

        for table_name, df in tqdm(self.raw_dataframes.items(), desc="Analyzing tables"):
            schema[table_name] = self._analyze_table(table_name, df)

        self.tables = schema
        return schema

    def _analyze_table(self, table_name: str, df: pd.DataFrame) -> Dict:
        """Analyze a single table/DataFrame"""
        # Clean column names
        df.columns = [self._clean_name(str(c)) for c in df.columns]

        columns = []
        sample_df = df.head(self.max_sample_rows)

        for col in df.columns:
            series = df[col]
            col_info = self._analyze_column(col, series, table_name)
            columns.append(col_info)

        return {
            "name": table_name,
            "row_count": len(df),
            "column_count": len(df.columns),
            "columns": columns,
            "sample_data": sample_df.head(5).to_dict(orient='records'),
            "duplicate_rows": int(df.duplicated().sum()),
            "completeness": float(1 - df.isnull().mean().mean())
        }

    def _analyze_column(self, col_name: str, series: pd.Series, table_name: str) -> Dict:
        """Deep analysis of a single column"""
        non_null = series.dropna()
        null_count = series.isnull().sum()
        null_pct = null_count / len(series) if len(series) > 0 else 0

        # Detect data type
        detected_type, sql_type = self._detect_type(series, col_name)

        # Get sample values
        sample_values = non_null.unique()[:10].tolist()
        sample_values = [str(v) for v in sample_values]

        # Statistics
        stats = {}
        if detected_type in ['integer', 'float']:
            try:
                stats = {
                    "min": float(non_null.min()) if len(non_null) > 0 else None,
                    "max": float(non_null.max()) if len(non_null) > 0 else None,
                    "mean": float(non_null.mean()) if len(non_null) > 0 else None,
                    "std": float(non_null.std()) if len(non_null) > 0 else None
                }
            except:
                pass

        # Cardinality
        unique_count = series.nunique()
        cardinality = unique_count / len(series) if len(series) > 0 else 0

        # Is likely primary key?
        is_pk_candidate = (
            cardinality > 0.95 and
            null_pct == 0 and
            detected_type in ['integer', 'string']
        )

        # Is likely foreign key?
        import re
        is_fk_candidate = bool(re.search(r'(_id|_fk|_ref|_key)$', col_name, re.IGNORECASE))

        return {
            "name": col_name,
            "dtype": detected_type,
            "sql_type": sql_type,
            "null_count": int(null_count),
            "null_pct": float(null_pct),
            "unique_count": int(unique_count),
            "cardinality": float(cardinality),
            "sample_values": sample_values,
            "stats": stats,
            "is_pk_candidate": is_pk_candidate,
            "is_fk_candidate": is_fk_candidate,
            "table_name": table_name,
            "max_length": int(series.astype(str).str.len().max()) if detected_type == 'string' else None
        }

    def _detect_type(self, series: pd.Series, col_name: str) -> Tuple[str, str]:
        """Detect Python type and SQL type for a column"""
        import re
        non_null = series.dropna()

        if len(non_null) == 0:
            return 'string', 'VARCHAR(255)'

        # Check pandas dtype first
        dtype = series.dtype

        if pd.api.types.is_bool_dtype(dtype):
            return 'boolean', 'BOOLEAN'

        if pd.api.types.is_integer_dtype(dtype):
            max_val = non_null.max() if len(non_null) > 0 else 0
            if max_val > 2147483647:
                return 'integer', 'BIGINT'
            return 'integer', 'INTEGER'

        if pd.api.types.is_float_dtype(dtype):
            return 'float', 'DECIMAL(18,4)'

        if pd.api.types.is_datetime64_any_dtype(dtype):
            return 'datetime', 'TIMESTAMP'

        # Try to infer from content and column name
        col_lower = col_name.lower()

        if re.search(r'(date|created|updated|modified)', col_lower):
            try:
                pd.to_datetime(non_null.head(10))
                return 'datetime', 'DATE'
            except:
                pass

        if re.search(r'(email|mail)', col_lower):
            return 'string', 'VARCHAR(320)'

        if re.search(r'(phone|mobile|tel)', col_lower):
            return 'string', 'VARCHAR(20)'

        if re.search(r'(amount|price|cost|salary|revenue|total)', col_lower):
            try:
                pd.to_numeric(non_null.head(20))
                return 'float', 'DECIMAL(18,2)'
            except:
                pass

        # Try numeric conversion
        try:
            converted = pd.to_numeric(non_null.head(50))
            if (converted == converted.astype(int)).all():
                return 'integer', 'INTEGER'
            return 'float', 'DECIMAL(18,4)'
        except:
            pass

        # String - determine length
        max_len = int(series.astype(str).str.len().max())
        if max_len <= 1:
            return 'string', 'CHAR(1)'
        elif max_len <= 50:
            return 'string', f'VARCHAR({min(max_len * 2, 100)})'
        elif max_len <= 255:
            return 'string', 'VARCHAR(255)'
        elif max_len <= 1000:
            return 'string', 'VARCHAR(1000)'
        else:
            return 'string', 'TEXT'

    def _clean_name(self, name: str) -> str:
        """Clean and normalize table/column names"""
        import re
        name = str(name).strip()
        name = re.sub(r'[^\w\s]', '_', name)
        name = re.sub(r'\s+', '_', name)
        name = re.sub(r'_+', '_', name)
        name = name.strip('_').lower()
        if name and name[0].isdigit():
            name = 'col_' + name
        return name or 'unknown'

    def get_schema_summary(self) -> Dict:
        """Get a simplified schema summary for AI analysis"""
        summary = {}
        for table_name, table_info in self.tables.items():
            summary[table_name] = table_info['columns']
        return summary
