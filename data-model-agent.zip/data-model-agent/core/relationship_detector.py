"""
Relationship Detector
Detects foreign key relationships between tables using heuristics + AI
"""

import re
from typing import Dict, List, Tuple
from loguru import logger
from fuzzywuzzy import fuzz


class RelationshipDetector:
    """Detects relationships between tables using multiple strategies"""

    CONFIDENCE_HIGH = 0.9
    CONFIDENCE_MEDIUM = 0.7
    CONFIDENCE_LOW = 0.5

    def __init__(self, confidence_threshold: float = 0.6):
        self.confidence_threshold = confidence_threshold
        self.relationships = []

    def detect(self, tables: Dict, ai_relationships: List[Dict] = None) -> List[Dict]:
        """Run all detection strategies and merge results"""
        logger.info("Detecting table relationships...")

        rule_based = self._detect_by_naming(tables)
        value_based = self._detect_by_values(tables)

        all_relationships = rule_based + value_based

        # Merge AI-detected relationships
        if ai_relationships:
            for ai_rel in ai_relationships:
                if ai_rel.get('confidence', 0) >= self.confidence_threshold:
                    all_relationships.append({**ai_rel, "source": "AI"})

        # Deduplicate
        self.relationships = self._deduplicate(all_relationships)

        # Filter by confidence
        self.relationships = [
            r for r in self.relationships
            if r.get('confidence', 0) >= self.confidence_threshold
        ]

        logger.success(f"Found {len(self.relationships)} relationships")
        return self.relationships

    def _detect_by_naming(self, tables: Dict) -> List[Dict]:
        """Detect relationships by column naming patterns"""
        relationships = []
        table_names = list(tables.keys())

        for table_name, table_info in tables.items():
            for col in table_info.get('columns', []):
                col_name = col['name']

                # Pattern: column ends with _id, _fk, _ref
                fk_match = re.search(r'^(.+?)(_id|_fk|_ref|_key)$', col_name, re.IGNORECASE)
                if not fk_match:
                    continue

                base_name = fk_match.group(1)

                # Find matching parent table
                for parent_table in table_names:
                    if parent_table == table_name:
                        continue

                    # Check fuzzy match
                    score = fuzz.ratio(base_name.lower(), parent_table.lower())
                    if score >= 70:
                        confidence = score / 100.0 * self.CONFIDENCE_HIGH

                        # Find parent PK
                        parent_pk = self._find_primary_key(tables[parent_table])

                        relationships.append({
                            "parent_table": parent_table,
                            "parent_column": parent_pk or "id",
                            "child_table": table_name,
                            "child_column": col_name,
                            "relationship_type": "one-to-many",
                            "confidence": round(confidence, 2),
                            "source": "naming_convention"
                        })

        return relationships

    def _detect_by_values(self, tables: Dict) -> List[Dict]:
        """Detect relationships by overlapping values between columns"""
        relationships = []

        # Get all ID-like columns with their value sets
        id_columns = {}
        for table_name, table_info in tables.items():
            for col in table_info.get('columns', []):
                if col.get('is_pk_candidate') or re.search(r'^id$', col['name'], re.IGNORECASE):
                    samples = set(col.get('sample_values', []))
                    if samples:
                        id_columns[f"{table_name}.{col['name']}"] = {
                            "table": table_name,
                            "column": col['name'],
                            "values": samples
                        }

        # Check FK columns against ID columns
        for table_name, table_info in tables.items():
            for col in table_info.get('columns', []):
                if not col.get('is_fk_candidate'):
                    continue

                fk_values = set(col.get('sample_values', []))
                if not fk_values:
                    continue

                for pk_key, pk_info in id_columns.items():
                    if pk_info['table'] == table_name:
                        continue

                    overlap = fk_values & pk_info['values']
                    if len(overlap) > 0 and len(fk_values) > 0:
                        confidence = len(overlap) / len(fk_values) * self.CONFIDENCE_MEDIUM
                        if confidence >= self.confidence_threshold:
                            relationships.append({
                                "parent_table": pk_info['table'],
                                "parent_column": pk_info['column'],
                                "child_table": table_name,
                                "child_column": col['name'],
                                "relationship_type": "one-to-many",
                                "confidence": round(confidence, 2),
                                "source": "value_overlap"
                            })

        return relationships

    def _find_primary_key(self, table_info: Dict) -> str:
        """Find the primary key column of a table"""
        columns = table_info.get('columns', [])

        # First: look for column named 'id'
        for col in columns:
            if col['name'].lower() == 'id':
                return col['name']

        # Second: look for PK candidates
        for col in columns:
            if col.get('is_pk_candidate'):
                return col['name']

        # Third: look for *_id pattern
        for col in columns:
            if re.match(r'^.+_id$', col['name'], re.IGNORECASE):
                return col['name']

        return columns[0]['name'] if columns else 'id'

    def _deduplicate(self, relationships: List[Dict]) -> List[Dict]:
        """Remove duplicate relationships, keeping highest confidence"""
        seen = {}
        for rel in relationships:
            key = f"{rel['parent_table']}.{rel['parent_column']}->{rel['child_table']}.{rel['child_column']}"
            if key not in seen or rel['confidence'] > seen[key]['confidence']:
                seen[key] = rel
        return list(seen.values())
