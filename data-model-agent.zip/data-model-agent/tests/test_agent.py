"""
Unit Tests for AI Data Model Agent
"""

import pytest
import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestExcelAnalyzer:
    """Tests for Excel Analyzer"""

    def setup_method(self):
        from core.excel_analyzer import ExcelAnalyzer
        self.analyzer = ExcelAnalyzer()

    def test_clean_name(self):
        assert self.analyzer._clean_name("First Name") == "first_name"
        assert self.analyzer._clean_name("Customer ID") == "customer_id"
        assert self.analyzer._clean_name("123abc") == "col_123abc"

    def test_analyze_column_integer(self):
        series = pd.Series([1, 2, 3, 4, 5])
        result = self.analyzer._analyze_column("id", series, "test_table")
        assert result['dtype'] == 'integer'
        assert result['null_count'] == 0
        assert result['unique_count'] == 5

    def test_analyze_column_with_nulls(self):
        series = pd.Series([1, 2, None, 4, None])
        result = self.analyzer._analyze_column("value", series, "test_table")
        assert result['null_count'] == 2
        assert result['null_pct'] == 0.4

    def test_pk_candidate_detection(self):
        series = pd.Series([1, 2, 3, 4, 5])
        result = self.analyzer._analyze_column("id", series, "test_table")
        assert result['is_pk_candidate'] == True

    def test_fk_candidate_detection(self):
        series = pd.Series([1, 2, 3])
        result = self.analyzer._analyze_column("customer_id", series, "orders")
        assert result['is_fk_candidate'] == True


class TestRelationshipDetector:
    """Tests for Relationship Detector"""

    def setup_method(self):
        from core.relationship_detector import RelationshipDetector
        self.detector = RelationshipDetector(confidence_threshold=0.5)

    def test_naming_convention_detection(self):
        tables = {
            "customers": {
                "columns": [
                    {"name": "id", "is_pk_candidate": True, "is_fk_candidate": False, "sample_values": ["1","2","3"]}
                ]
            },
            "orders": {
                "columns": [
                    {"name": "customer_id", "is_pk_candidate": False, "is_fk_candidate": True, "sample_values": ["1","2"]}
                ]
            }
        }
        relationships = self.detector._detect_by_naming(tables)
        assert len(relationships) > 0
        assert any(r['parent_table'] == 'customers' for r in relationships)

    def test_deduplication(self):
        rels = [
            {"parent_table": "a", "parent_column": "id", "child_table": "b", "child_column": "a_id", "confidence": 0.7},
            {"parent_table": "a", "parent_column": "id", "child_table": "b", "child_column": "a_id", "confidence": 0.9},
        ]
        result = self.detector._deduplicate(rels)
        assert len(result) == 1
        assert result[0]['confidence'] == 0.9


class TestSQLGenerator:
    """Tests for SQL Generator"""

    def setup_method(self):
        from utils.sql_generator import SQLGenerator
        self.gen = SQLGenerator(dialect='postgresql')

    def test_drop_table(self):
        result = self.gen._drop_table("customers")
        assert "DROP TABLE" in result
        assert "customers" in result

    def test_column_def_pk(self):
        col = {"name": "id", "sql_type": "INTEGER", "null_pct": 0}
        result = self.gen._column_def(col, "id")
        assert "SERIAL" in result or "INTEGER" in result
        assert "NOT NULL" in result

    def test_fk_constraint(self):
        rel = {
            "parent_table": "customers",
            "parent_column": "id",
            "child_table": "orders",
            "child_column": "customer_id"
        }
        result = self.gen._add_fk_constraint(rel)
        assert "FOREIGN KEY" in result
        assert "customers" in result


class TestFallbackAgent:
    """Tests for Fallback Rule-Based Agent"""

    def setup_method(self):
        from agents.fallback_agent import FallbackAgent
        self.agent = FallbackAgent()

    def test_is_available(self):
        assert self.agent.is_available() == True

    def test_generate_description_id(self):
        col_info = {"name": "id", "dtype": "integer", "table_name": "customers", "sample_values": []}
        desc = self.agent.generate_description(col_info)
        assert "identifier" in desc.lower() or "customers" in desc.lower()

    def test_generate_description_email(self):
        col_info = {"name": "email", "dtype": "string", "table_name": "users", "sample_values": []}
        desc = self.agent.generate_description(col_info)
        assert "email" in desc.lower()

    def test_analyze_schema(self):
        schema = {
            "customers": [
                {"name": "id", "dtype": "integer"},
                {"name": "name", "dtype": "string"}
            ]
        }
        result = self.agent.analyze_schema(schema)
        assert "primary_keys" in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
