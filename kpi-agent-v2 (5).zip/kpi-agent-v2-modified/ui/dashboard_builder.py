"""
Dashboard Builder v2 — builds the full 8-tab interactive HTML dashboard.
All chart data is injected as JS variables; the HTML template renders them.
"""

import json
from typing import Dict, List, Any
from pathlib import Path
from datetime import datetime
from loguru import logger


class DashboardBuilder:
    def __init__(self, config: dict):
        self.cfg = config
        self.sym = config.get('dashboard', {}).get('currency_symbol', '$')
        self.title = config.get('dashboard', {}).get('title',
                                'Coforge D&A PMO — Unified KPI Tracker')
        self.company = config.get('dashboard', {}).get('company', 'Coforge')

    def build(self, all_kpis: Dict, relationships: List,
              insights: List) -> str:
        logger.info("Building unified dashboard...")
        master  = all_kpis.get('master',  {})
        fin     = all_kpis.get('finance', {})
        pipe    = all_kpis.get('pipeline',{})
        closed  = all_kpis.get('closed',  {})
        dem     = all_kpis.get('demand',  {})
        bench   = all_kpis.get('bench',   {})
        ful     = all_kpis.get('fulfillment', {})
        emp     = all_kpis.get('employee', {})

        score       = master.get('health_score', 75)
        score_col   = ('#3B6D11' if score >= 75 else
                       '#BA7517' if score >= 50 else '#A32D2D')
        now_str     = datetime.now().strftime('%d %b %Y %H:%M')
        today_str   = datetime.now().strftime('%d %b %Y')

        # ── JS data blobs ─────────────────────────────────────
        js = ""
        js += f"const FIN_M={json.dumps(fin.get('months',[]))};\n"
        js += f"const FIN_R={json.dumps(fin.get('revenue_series',[]))};\n"
        js += f"const FIN_E={json.dumps(fin.get('expense_series',[]))};\n"
        js += f"const FIN_G={json.dumps(fin.get('gm_pct_series',[]))};\n"
        js += f"const PIPE_STAGE_L={json.dumps(list(pipe.get('by_stage',{}).keys()))};\n"
        js += f"const PIPE_STAGE_V={json.dumps(list(pipe.get('by_stage',{}).values()))};\n"
        js += f"const PIPE_BU_L={json.dumps(list(pipe.get('by_bu',{}).keys()))};\n"
        js += f"const PIPE_BU_V={json.dumps(list(pipe.get('by_bu',{}).values()))};\n"
        js += f"const EE_NN_HBU_TCV={json.dumps(pipe.get('ee_nn_hbu_tcv', 0))};\n"
        js += f"const EE_NN_HBU_TCV_FMT={json.dumps(pipe.get('ee_nn_hbu_tcv_fmt', 'N/A'))};\n"
        js += f"const PIPE_AVG_PROB={json.dumps(pipe.get('avg_probability', 0))};\n"
        js += f"const PIPE_AI_PCT={json.dumps(pipe.get('ai_deals_pct', 0))};\n"
        js += f"const CL_WON_COUNT={json.dumps(closed.get('total_won', 0))};\n"
        js += f"const CL_LOST_COUNT={json.dumps(closed.get('total_lost', 0))};\n"
        js += f"const CL_BU_L={json.dumps(list(closed.get('by_bu_won',{}).keys()))};\n"
        js += f"const CL_BU_V={json.dumps(list(closed.get('by_bu_won',{}).values()))};\n"
        js += f"const CL_QTR_L={json.dumps(list(closed.get('by_quarter',{}).keys()))};\n"
        js += f"const CL_QTR_V={json.dumps(list(closed.get('by_quarter',{}).values()))};\n"
        js += f"const DEM_IBU_L={json.dumps(list(dem.get('by_ibu',{}).keys()))};\n"
        js += f"const DEM_IBU_V={json.dumps(list(dem.get('by_ibu',{}).values()))};\n"
        js += f"const DEM_STATUS_L={json.dumps(list(dem.get('by_status',{}).keys()))};\n"
        js += f"const DEM_STATUS_V={json.dumps(list(dem.get('by_status',{}).values()))};\n"
        js += f"const DEM_AGE_L={json.dumps(list(dem.get('by_aging',{}).keys()))};\n"
        js += f"const DEM_AGE_V={json.dumps(list(dem.get('by_aging',{}).values()))};\n"
        js += f"const BENCH_POOL_L={json.dumps(list(bench.get('by_pool',{}).keys()))};\n"
        js += f"const BENCH_POOL_V={json.dumps(list(bench.get('by_pool',{}).values()))};\n"
        js += f"const BENCH_SKILL_L={json.dumps(list(bench.get('by_skill',{}).keys()))};\n"
        js += f"const BENCH_SKILL_V={json.dumps(list(bench.get('by_skill',{}).values()))};\n"
        js += f"const BENCH_AGE_L={json.dumps(list(bench.get('by_aging',{}).keys()))};\n"
        js += f"const BENCH_AGE_V={json.dumps(list(bench.get('by_aging',{}).values()))};\n"
        js += f"const FUL_QTR_L={json.dumps(list(ful.get('by_quarter',{}).keys()))};\n"
        js += f"const FUL_QTR_V={json.dumps(list(ful.get('by_quarter',{}).values()))};\n"
        js += f"const FUL_TYPE_L={json.dumps(list(ful.get('by_type',{}).keys()))};\n"
        js += f"const FUL_TYPE_V={json.dumps(list(ful.get('by_type',{}).values()))};\n"
        js += f"const EMP_IBU_L={json.dumps(list(emp.get('by_ibu',{}).keys()))};\n"
        js += f"const EMP_IBU_V={json.dumps(list(emp.get('by_ibu',{}).values()))};\n"
        js += f"const EMP_PRAC_L={json.dumps(list(emp.get('by_practice',{}).keys()))};\n"
        js += f"const EMP_PRAC_V={json.dumps(list(emp.get('by_practice',{}).values()))};\n"
        js += f"const EMP_GEO_L={json.dumps(list(emp.get('by_geo',{}).keys()))};\n"
        js += f"const EMP_GEO_V={json.dumps(list(emp.get('by_geo',{}).values()))};\n"

        # ── Insights HTML ────────────────────────────────────
        type_map = {
            'strength':       ('rgba(59,109,17,.12)',   '#3B6D11',  'Strength'),
            'concern':        ('rgba(186,117,23,.12)',  '#BA7517',  'Concern'),
            'recommendation': ('rgba(24,95,165,.12)',   '#185FA5',  'Recommendation'),
            'opportunity':    ('rgba(15,110,86,.12)',   '#0F6E56',  'Opportunity'),
            'risk':           ('rgba(163,45,45,.12)',   '#A32D2D',  'Risk'),
            'info':           ('rgba(83,74,183,.12)',   '#534AB7',  'Insight'),
        }
        ins_html = ''
        for ins in insights[:8]:
            bg, col, label = type_map.get(ins.get('type','info'),
                                          type_map['info'])
            srcs = ', '.join(ins.get('sources', []))
            ins_html += (
                f'<div style="background:{bg};border:1px solid {col}20;'
                f'border-radius:8px;padding:11px 14px;font-size:12px;'
                f'line-height:1.55;">'
                f'<span style="font-size:9px;font-weight:600;color:{col};'
                f'text-transform:uppercase;letter-spacing:.08em;'
                f'display:block;margin-bottom:4px;">'
                f'{label}'
                f'{(" · <span style=color:#888>" + srcs + "</span>") if srcs else ""}'
                f'</span>{ins.get("text","")}</div>'
            )

        # ── Relationship rows ─────────────────────────────────
        rel_rows = ''
        refresh = self.cfg.get('refresh_schedule', {})
        sheet_meta = {
            'finance':     ('Finance Tracker',         refresh.get('finance','Monthly'),     'Customer/GEO',    'Employee, Master'),
            'master':      ('Master Reference',         refresh.get('master','On change'),    'Concatenate',     'All sheets via IBU'),
            'employee':    ('Employee Master',          refresh.get('employee','Weekly'),     'Employee No',     'Bench, Demand, Finance'),
            'sf_pipeline': ('Salesforce Pipeline',     refresh.get('sf_pipeline','Daily'),   'OpportunityID',   'Demand, Closed, Master'),
            'demand':      ('Demand Data',              refresh.get('demand','Daily'),        'RequestID',       'SF Pipeline, Employee, YTD'),
            'bench':       ('Bench Data',               refresh.get('bench','Daily'),         'Employee No',     'Employee Master, Demand'),
            'fulfillment': ('YTD Fulfillment',         refresh.get('fulfillment','Monthly'), 'Request ID',      'Demand, Employee Master'),
            'closed':      ('Closed Deals',             refresh.get('closed','Daily'),        'OpportunityID',   'SF Pipeline, Master Ref'),
        }
        for key, (name, rfr, key_field, links) in sheet_meta.items():
            rel_rows += (
                f'<tr style="border-bottom:0.5px solid var(--color-border-tertiary);">'
                f'<td style="padding:8px 10px;font-weight:500;'
                f'color:var(--color-text-primary);font-size:12px;">{name}</td>'
                f'<td style="padding:8px 10px;font-size:11px;'
                f'color:var(--color-text-secondary);">{rfr}</td>'
                f'<td style="padding:8px 10px;font-size:11px;'
                f'color:var(--color-text-secondary);'
                f'font-family:monospace;">{key_field}</td>'
                f'<td style="padding:8px 10px;font-size:11px;'
                f'color:var(--color-text-secondary);">{links}</td>'
                f'</tr>'
            )

        def fmt(n):
            n = abs(float(n or 0))
            s = self.sym
            if n >= 1e6: return f"{s}{n/1e6:.2f}M"
            if n >= 1e3: return f"{s}{n/1e3:.0f}K"
            return f"{s}{n:.0f}"

        def pill(text, cls):
            colors = {
                'g': ('#EAF3DE','#3B6D11'),
                'r': ('#FCEBEB','#A32D2D'),
                'a': ('#FAEEDA','#BA7517'),
                'b': ('#E6F1FB','#185FA5'),
            }
            bg, col = colors.get(cls, colors['b'])
            return (f'<span style="display:inline-block;font-size:9px;'
                    f'font-weight:600;padding:2px 8px;border-radius:8px;'
                    f'background:{bg};color:{col};margin-top:5px;">{text}</span>')

        gm = fin.get('avg_gm_pct', 0)
        wr = closed.get('win_rate', 0)
        bp = emp.get('billed_pct', 0)
        avail = bench.get('available', 0)

        html = self._template().format(
            TITLE=self.title, COMPANY=self.company,
            NOW=now_str, TODAY=today_str,
            SCORE=score, SCORE_COL=score_col,
            HEALTH_LABEL=master.get('health_label','Watch'),

            KV_REVENUE=fin.get('fy_revenue_fmt','N/A'),
            KV_GM_FMT=fin.get('total_gm_fmt','N/A'),
            KV_GM_PCT=f"{gm}%",
            KV_GM_PILL=pill('Healthy' if gm>=35 else 'Below Target',
                            'g' if gm>=35 else 'r'),
            KV_WIN=f"{wr}%",
            KV_WIN_PILL=pill('Strong' if wr>=50 else 'Watch','g' if wr>=50 else 'a'),
            KV_PIPELINE=pipe.get('total_tcv_fmt','N/A'),
            KV_PIPE_DEALS=str(pipe.get('total_deals',0)),
            KV_EE_NN_HBU=pipe.get('ee_nn_hbu_tcv_fmt','N/A'),
            KV_BENCH=str(avail),
            KV_BENCH_TOTAL=str(bench.get('total_bench',0)),
            KV_OPEN_RRS=str(dem.get('total_open',0)),
            KV_HC=str(emp.get('total_hc',0)),
            KV_BILLED=f"{bp}%",
            KV_BILLED_PILL=pill('Good' if bp>=85 else 'Watch','g' if bp>=85 else 'a'),
            KV_WON_TCV=closed.get('won_tcv_fmt','N/A'),
            KV_DEAL_MARGIN=f"{closed.get('avg_margin_pct',0):.1f}%",
            KV_FULFILLED=str(ful.get('total_fulfilled',0)),
            KV_FFTP=f"{ful.get('avg_fftp',0)} days",
            KV_INTERNAL=f"{ful.get('internal_pct',0):.0f}%",
            KV_FIN_CUSTOMER=fin.get('customer','N/A'),
            KV_FIN_GEO=fin.get('geo','N/A'),
            KV_FIN_CC=fin.get('cost_center','N/A'),
            KV_BEST_MONTH=fin.get('best_month','N/A'),
            KV_WORST_MONTH=fin.get('worst_month','N/A'),
            INSIGHTS_HTML=ins_html,
            REL_ROWS=rel_rows,
            JS_DATA=js,
        )
        return html

    def _template(self) -> str:
        tmpl_path = (Path(__file__).parent.parent /
                     'templates' / 'dashboard.html')
        if tmpl_path.exists():
            return tmpl_path.read_text(encoding='utf-8')
        return self._inline_template()

    def _inline_template(self) -> str:
        # Returns the complete inline HTML template
        return open(
            Path(__file__).parent / '_dashboard_inline.html',
            encoding='utf-8'
        ).read() if (
            Path(__file__).parent / '_dashboard_inline.html'
        ).exists() else self._minimal_template()

    def _minimal_template(self) -> str:
        """Minimal fallback template."""
        return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{TITLE}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
body{{font-family:system-ui;background:#f5f5f5;padding:20px;color:#333;}}
.kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}}
.kpi{{background:white;border-radius:10px;padding:16px;box-shadow:0 1px 4px rgba(0,0,0,.08);}}
.lbl{{font-size:11px;color:#888;text-transform:uppercase;margin-bottom:6px;}}
.val{{font-size:22px;font-weight:600;color:#111;}}
.card{{background:white;border-radius:10px;padding:16px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.08);}}
</style>
</head>
<body>
<h2 style="margin-bottom:16px;">{TITLE} — Health Score: <span style="color:{SCORE_COL}">{SCORE}/100</span></h2>
<p style="color:#888;font-size:12px;margin-bottom:20px;">Generated {NOW} · {COMPANY}</p>
<div class="kpis">
  <div class="kpi"><div class="lbl">FY Revenue</div><div class="val">{KV_REVENUE}</div></div>
  <div class="kpi"><div class="lbl">GM%</div><div class="val">{KV_GM_PCT}</div></div>
  <div class="kpi"><div class="lbl">Win Rate</div><div class="val">{KV_WIN}</div></div>
  <div class="kpi"><div class="lbl">Bench Available</div><div class="val">{KV_BENCH}</div></div>
</div>
<div class="card">
  <h3 style="font-size:14px;margin-bottom:14px;">Revenue vs Expenses</h3>
  <div style="position:relative;height:220px;"><canvas id="c1"></canvas></div>
</div>
<div class="card">
  <h3 style="font-size:14px;margin-bottom:12px;">Insights</h3>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">{INSIGHTS_HTML}</div>
</div>
<script>
{JS_DATA}
new Chart(document.getElementById('c1'),{{type:'bar',data:{{labels:FIN_M,
datasets:[{{label:'Revenue',data:FIN_R,backgroundColor:'rgba(24,95,165,.7)',borderRadius:4}},
{{label:'Expenses',data:FIN_E,backgroundColor:'rgba(163,45,45,.6)',borderRadius:4}}]}},
options:{{responsive:true,maintainAspectRatio:false}}}});
</script>
<p style="text-align:center;font-size:11px;color:#aaa;margin-top:20px;">Generated by KPI Intelligence Agent v2 · Wireframe 2 · {TODAY}</p>
</body></html>"""
