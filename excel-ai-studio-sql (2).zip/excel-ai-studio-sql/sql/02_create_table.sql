-- ============================================================
-- 02_create_table.sql
-- Creates the main data table
-- ============================================================

USE `excel_ai_studio`;

-- Drop if exists (safe re-run)
DROP TABLE IF EXISTS `clean_data`;

-- Table: clean_data
-- Generated: 2026-04-07 08:18
CREATE TABLE IF NOT EXISTS `clean_data` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` TEXT NOT NULL,
  `customer_name` TEXT NOT NULL,
  `region` TEXT NOT NULL,
  `product` TEXT NULL,
  `sale_date` DATE NULL,
  `revenue` DECIMAL(18,4) NULL,
  `cost` BIGINT NOT NULL,
  `quantity` DECIMAL(18,4) NULL,
  `sales_rep` TEXT NULL,
  `status` TEXT NULL,
  `category` TEXT NOT NULL,
  `city` TEXT NOT NULL,
  `gross_margin` DECIMAL(18,4) NULL,
  `gm_pct` DECIMAL(18,4) NULL,
  `year` DECIMAL(18,4) NULL,
  `month_num` DATE NULL,
  `month_name` DATE NULL,
  `quarter` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Verify
DESCRIBE `clean_data`;
SELECT 'Table created successfully' AS status;
