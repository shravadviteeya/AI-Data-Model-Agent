"""
Agent 3: SQL Agent  (Fixed)
============================
Root causes of the "stuck" bug:

1. @tool decorator from LangChain wraps .invoke() to expect a plain
   string, not a dict — so  tool.invoke({"key": val})  hangs silently
   waiting for user input instead of running the function.

2. DB config was loaded once at import time from config/settings.py,
   BEFORE the GUI had written the user's credentials into os.environ.
   So all DB operations were using the wrong (empty) password.

Fix: removed LangChain @tool entirely. Each function is a plain Python
function called directly.  The pipeline reads DB config fresh from
os.environ at call time so GUI changes take effect immediately.
"""

import os
import sys
import json
import re
import pandas as pd
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent))


# ── Read DB config FRESH from environment at call time ────────
# Never cache this at import — the GUI sets os.environ just before
# calling run_sql_pipeline(), so we must read it late.
def _get_db_config() -> dict:
    return {
        "host":     os.environ.get("DB_HOST",     "127.0.0.1"),
        "port":     int(os.environ.get("DB_PORT", "3306")),
        "user":     os.environ.get("DB_USER",     "root"),
        "password": os.environ.get("DB_PASSWORD", ""),
        "database": os.environ.get("DB_NAME",     "excel_ai_studio"),
        "charset":  "utf8mb4",
    }


# ═══════════════════════════════════════════════════════════════
# TOOL 1 — Analyse schema
# ═══════════════════════════════════════════════════════════════
def analyse_for_sql(file_path: str) -> dict:
    """Analyse clean Excel and suggest optimal SQL schema."""
    df         = pd.read_excel(file_path)
    table_name = re.sub(r'[^\w]', '_', Path(file_path).stem).lower()

    col_analysis = []
    for col in df.columns:
        dtype    = str(df[col].dtype)
        unique   = int(df[col].nunique())
        nulls    = int(df[col].isnull().sum())
        sample   = [str(v) for v in df[col].dropna().head(3).tolist()]

        # Infer best SQL type
        if 'int' in dtype:
            sql_type = ('BIGINT'
                        if not df[col].dropna().empty
                        and df[col].max() > 2_000_000_000
                        else 'INT')
        elif 'float' in dtype:
            sql_type = 'DECIMAL(18,4)'
        elif any(k in col.lower()
                 for k in ['date', 'month', 'period']):
            sql_type = 'DATE'
        elif any(k in col.lower()
                 for k in ['revenue', 'cost', 'margin',
                            'amount', 'price']):
            sql_type = 'DECIMAL(18,2)'
        else:
            max_len  = (int(df[col].dropna().astype(str)
                            .str.len().max())
                        if not df[col].dropna().empty else 50)
            sql_type = ('TEXT' if max_len > 500
                        else f'VARCHAR({min(max_len * 2, 500)})')

        suggest_index = (
            any(k in col.lower()
                for k in ['id', 'date', 'region', 'product',
                           'status', 'rep', 'owner'])
            or unique < 20
        )

        col_analysis.append({
            "column":        col,
            "dtype":         dtype,
            "sql_type":      sql_type,
            "unique":        unique,
            "nulls":         nulls,
            "nullable":      nulls > 0,
            "sample":        sample,
            "suggest_index": suggest_index,
        })

    return {
        "status":     "success",
        "table_name": table_name,
        "row_count":  len(df),
        "col_count":  len(df.columns),
        "columns":    col_analysis,
        "database":   _get_db_config()["database"],
    }


# ═══════════════════════════════════════════════════════════════
# TOOL 2 — Generate all SQL files
# ═══════════════════════════════════════════════════════════════
def generate_all_sql_files(file_path: str, output_dir: str) -> dict:
    """Generate the 5 SQL files needed for SQL Workbench."""
    from core.db_manager import DBManager

    df         = pd.read_excel(file_path)
    table_name = re.sub(r'[^\w]', '_', Path(file_path).stem).lower()
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    mgr    = DBManager(_get_db_config())
    result = mgr.generate_sql_files(df, table_name, output_dir)
    return result


# ═══════════════════════════════════════════════════════════════
# TOOL 3 — Test connection
# ═══════════════════════════════════════════════════════════════
def test_mysql_connection() -> dict:
    """Test MySQL connection and return status."""
    from core.db_manager import DBManager
    return DBManager(_get_db_config()).test_connection()


# ═══════════════════════════════════════════════════════════════
# TOOL 4 — Push data to MySQL
# ═══════════════════════════════════════════════════════════════
def push_to_mysql(file_path: str,
                  table_name: str = "",
                  progress_callback=None) -> dict:
    """
    Load clean Excel into MySQL.
    Calls progress_callback(loaded, total) for each batch.
    """
    from core.db_manager import DBManager

    df = pd.read_excel(file_path)
    if not table_name:
        table_name = re.sub(
            r'[^\w]', '_', Path(file_path).stem).lower()

    cfg = _get_db_config()
    mgr = DBManager(cfg)

    # Verify connection before starting
    test = mgr.test_connection()
    if test["status"] != "ok":
        return {
            "status":  "error",
            "message": (f"Cannot connect: {test['message']}\n"
                        f"Check Host/Port/User/Password in Agent 3 form."),
        }

    result = mgr.load_dataframe(
        df, table_name,
        batch_size=500,
        progress_cb=progress_callback)
    mgr.disconnect()
    return result


# ═══════════════════════════════════════════════════════════════
# TOOL 5 — Run KPI query
# ═══════════════════════════════════════════════════════════════
def run_kpi_query(query_name: str = "summary",
                  table_name: str = "clean_data") -> dict:
    """Run a named KPI query against MySQL."""
    from core.db_manager import DBManager

    queries = {
        "summary": (
            f"SELECT COUNT(*) total_records, "
            f"SUM(Revenue) total_revenue, "
            f"SUM(Gross_Margin) total_gm, "
            f"ROUND(AVG(Gm_Pct),2) avg_gm_pct "
            f"FROM `{table_name}`"
        ),
        "by_region": (
            f"SELECT Region, COUNT(*) deals, "
            f"SUM(Revenue) total_revenue "
            f"FROM `{table_name}` "
            f"GROUP BY Region ORDER BY total_revenue DESC"
        ),
        "monthly": (
            f"SELECT DATE_FORMAT(Sale_Date,'%Y-%m') ym, "
            f"SUM(Revenue) revenue, COUNT(*) deals "
            f"FROM `{table_name}` "
            f"GROUP BY ym ORDER BY ym"
        ),
    }
    sql = queries.get(query_name, queries["summary"])

    mgr = DBManager(_get_db_config())
    if not mgr.connect():
        return {"status": "error",
                "message": "Cannot connect to MySQL"}
    result = mgr.run_query(sql)
    mgr.disconnect()
    return result


# ═══════════════════════════════════════════════════════════════
# MAIN PIPELINE — called by the GUI
# ═══════════════════════════════════════════════════════════════
def run_sql_pipeline(clean_file_path: str,
                     output_dir: str,
                     push_to_db: bool = False,
                     progress_callback=None) -> dict:
    """
    Run the full SQL agent pipeline.
    All 5 steps report progress via progress_callback(step, total, msg).
    DB credentials are read fresh from os.environ (set by GUI).
    """

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    def cb(step, total, msg):
        if progress_callback:
            progress_callback(step, total, msg)

    total   = 5 if push_to_db else 4
    results = {}
    files   = []

    # ── Step 1: Schema analysis ───────────────────────────────
    cb(1, total, "Step 1/4  Analysing schema...")
    try:
        schema = analyse_for_sql(clean_file_path)
        results["schema"] = schema
        table_name = schema.get("table_name", "clean_data")
    except Exception as e:
        schema     = {"status": "error", "message": str(e)}
        table_name = "clean_data"
        results["schema"] = schema

    # ── Step 2: Generate SQL files ────────────────────────────
    cb(2, total, "Step 2/4  Generating SQL files...")
    try:
        sql_result = generate_all_sql_files(
            clean_file_path, output_dir)
        results["sql_files"] = sql_result
        files = sql_result.get("files", [])
    except Exception as e:
        results["sql_files"] = {"status": "error",
                                 "message": str(e),
                                 "files": []}

    # ── Step 3: Test connection ───────────────────────────────
    cb(3, total, "Step 3/4  Testing MySQL connection...")
    try:
        conn_test = test_mysql_connection()
    except Exception as e:
        conn_test = {"status": "error", "message": str(e)}
    results["connection"] = conn_test

    # ── Step 4: Push data (optional) ─────────────────────────
    push_result = {}
    if push_to_db:
        if conn_test.get("status") == "ok":
            cb(4, total, "Step 4/5  Pushing data to MySQL...")
            total_rows  = [0]
            loaded_rows = [0]

            try:
                df_preview = pd.read_excel(clean_file_path)
                total_rows[0] = len(df_preview)
            except Exception:
                pass

            def batch_cb(loaded, total_r):
                loaded_rows[0] = loaded
                pct = int(loaded / max(total_r, 1) * 100)
                cb(4, total,
                   f"Step 4/5  Pushing... {loaded}/{total_r} rows ({pct}%)")

            try:
                push_result = push_to_mysql(
                    clean_file_path,
                    table_name,
                    progress_callback=batch_cb)
            except Exception as e:
                push_result = {"status": "error",
                               "message": str(e)}
        else:
            push_result = {
                "status":  "skipped",
                "message": "MySQL not connected — push skipped."
            }
        results["push"] = push_result

    # ── Done ──────────────────────────────────────────────────
    cb(total, total, "All steps complete!")

    return {
        "status":      "success",
        "sql_files":   files,
        "schema":      schema,
        "connection":  conn_test,
        "push_result": push_result,
        "table_name":  table_name,
        "database":    _get_db_config()["database"],
        "results":     results,
    }
