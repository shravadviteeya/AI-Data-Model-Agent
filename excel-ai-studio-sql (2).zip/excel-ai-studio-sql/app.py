"""
Excel AI Studio — SQL Edition
================================
Desktop GUI with 3 AI agents + SQL Workbench integration.

FIX: Removed all  color+"22"  alpha hex patterns.
     Tkinter only supports 6-digit hex colours.
     All tints are now pre-blended solid values.

Run: python app.py
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading, os, sys
from pathlib import Path
from datetime import datetime

BASE       = Path(__file__).parent
OUTPUT_DIR = BASE / "output"
SQL_DIR    = BASE / "sql"
OUTPUT_DIR.mkdir(exist_ok=True)
SQL_DIR.mkdir(exist_ok=True)
sys.path.insert(0, str(BASE))

# ── Solid colour palette ──────────────────────────────────────
# Tkinter requires exactly  #RRGGBB  — no alpha, no 8-digit hex
C = {
    "bg":       "#0d1117",
    "surface":  "#161b22",
    "surface2": "#21262d",
    "border":   "#30363d",
    "accent":   "#58a6ff",
    "green":    "#3fb950",
    "orange":   "#d29922",
    "red":      "#f85149",
    "purple":   "#bc8cff",
    "teal":     "#39d353",
    "text":     "#e6edf3",
    "muted":    "#8b949e",
}

# ── Pre-blended badge backgrounds (~12 % opacity on surface) ─
# Computed once: blend(fg, "#161b22", alpha=0.12)
# Use these instead of  C["accent"]+"22"  etc.
TINT = {
    "accent":  "#1d2b3c",
    "green":   "#1a2d27",
    "orange":  "#2c2a22",
    "red":     "#312126",
    "purple":  "#29283c",
    "teal":    "#1a3127",
    "muted":   "#242930",
}

# ── Pre-blended card-border tints (~25 % opacity on surface) ─
BORDER_TINT = {
    "accent":  "#263d59",
    "green":   "#20422d",
    "orange":  "#453a22",
    "red":     "#4e282b",
    "purple":  "#3f3759",
    "teal":    "#1e492e",
    "muted":   "#333941",
}

# Reverse lookup: hex value -> name
_HEX_TO_NAME = {v: k for k, v in C.items()}

def _tint(hex_color, strong=False):
    """Return the pre-blended solid tint for a colour hex string."""
    name = _HEX_TO_NAME.get(hex_color, "")
    d = BORDER_TINT if strong else TINT
    return d.get(name, C["surface2"])


F = {
    "title": ("Consolas", 13, "bold"),
    "label": ("Consolas", 10),
    "small": ("Consolas", 9),
    "log":   ("Consolas", 9),
    "h1":    ("Consolas", 16, "bold"),
    "mono":  ("Consolas", 10),
}


# ── Reusable Widgets ──────────────────────────────────────────

class Btn(tk.Button):
    """Flat button with hover effect."""
    def __init__(self, parent, text, cmd=None, accent=False, **kw):
        bg = C["accent"] if accent else C["surface2"]
        fg = C["bg"]     if accent else C["text"]
        super().__init__(parent, text=text, command=cmd,
                         bg=bg, fg=fg, relief="flat",
                         font=F["label"], cursor="hand2",
                         padx=12, pady=5, **kw)
        self._bg = bg
        hover_bg = "#79b8ff" if accent else C["border"]
        self.bind("<Enter>", lambda e: self.config(bg=hover_bg))
        self.bind("<Leave>", lambda e: self.config(bg=self._bg))


class Badge(tk.Label):
    """
    Coloured pill label.
    bg uses a pre-blended solid colour — never an 8-digit hex.
    """
    def __init__(self, parent, text, color=None, **kw):
        color = color or C["accent"]
        bg    = _tint(color)          # solid, tkinter-safe
        super().__init__(parent,
                         text=f" {text} ",
                         bg=bg, fg=color,
                         font=("Consolas", 8, "bold"),
                         padx=3, pady=1, **kw)


class Card(tk.Frame):
    """Bordered surface card with optional title."""
    def __init__(self, parent, title="", color=None, **kw):
        super().__init__(parent, bg=C["surface"],
                         highlightbackground=color or C["border"],
                         highlightthickness=1, **kw)
        if title:
            tk.Label(self, text=title, bg=C["surface"],
                     fg=C["muted"], font=F["small"],
                     padx=10, pady=5).pack(anchor="w")


# ══════════════════════════════════════════════════════════════
class App(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("Excel AI Studio — SQL Edition")
        self.geometry("1200x820")
        self.minsize(1000, 680)
        self.configure(bg=C["bg"])

        self.input_file = tk.StringVar()
        self.clean_file = tk.StringVar()
        self.db_status  = tk.StringVar(value="Not connected")
        self.db_ok      = False
        self._running   = {}

        self._build_ui()
        self._log(1, "Welcome! Select your Excel file to start.", "info")
        self._log(2, "Run Agent 1 first, then Agent 2.", "muted")
        self._log(3, "Configure .env or fill in the form below.", "info")

    # ─────────────────────────────────────────────────────────
    def _build_ui(self):
        # Top bar
        top = tk.Frame(self, bg=C["surface"],
                       highlightbackground=C["border"],
                       highlightthickness=1, height=46)
        top.pack(fill="x")
        top.pack_propagate(False)

        tk.Label(top, text="EXCEL AI STUDIO",
                 bg=C["surface"], fg=C["accent"],
                 font=F["title"], padx=14).pack(side="left", pady=8)
        Badge(top, "SQL Edition", C["purple"]).pack(side="left", pady=8)
        Badge(top, "LangChain",   C["green"] ).pack(side="left", padx=4, pady=8)

        # DB status pill  — always solid colours
        self.db_pill = tk.Label(
            top, textvariable=self.db_status,
            bg=TINT["red"], fg=C["red"],
            font=F["small"], padx=8, pady=3)
        self.db_pill.pack(side="right", padx=12, pady=8)
        tk.Label(top, text="MySQL:", bg=C["surface"],
                 fg=C["muted"], font=F["small"]).pack(side="right", pady=8)

        # Notebook
        nb = ttk.Notebook(self)
        self._style_nb()
        nb.pack(fill="both", expand=True)
        self.nb = nb

        for title, builder in [
            ("  Home  ",              self._tab_home),
            ("  Agent 1: Clean  ",    self._tab_agent1),
            ("  Agent 2: Power BI  ", self._tab_agent2),
            ("  Agent 3: SQL  ",      self._tab_agent3),
            ("  SQL Workbench  ",     self._tab_workbench),
            ("  Output Files  ",      self._tab_output),
        ]:
            frame = tk.Frame(nb, bg=C["bg"])
            nb.add(frame, text=title)
            builder(frame)

    def _style_nb(self):
        s = ttk.Style()
        s.theme_use("default")
        s.configure("TNotebook",
                    background=C["bg"], borderwidth=0)
        s.configure("TNotebook.Tab",
                    background=C["surface2"],
                    foreground=C["muted"],
                    padding=[14, 7], font=F["label"])
        s.map("TNotebook.Tab",
              background=[("selected", C["bg"])],
              foreground=[("selected", C["accent"])])

    # ══════════════════════════════════════════════════════════
    # HOME TAB
    # ══════════════════════════════════════════════════════════
    def _tab_home(self, tab):
        hero = tk.Frame(tab, bg=C["bg"])
        hero.pack(fill="both", expand=True, padx=50, pady=30)

        tk.Label(hero, text="Excel AI Studio",
                 bg=C["bg"], fg=C["text"],
                 font=("Consolas", 24, "bold")).pack(anchor="w")
        tk.Label(hero,
                 text="Clean  >  SQL  >  Power BI   |   Three agents, one pipeline.",
                 bg=C["bg"], fg=C["muted"],
                 font=("Consolas", 11)).pack(anchor="w", pady=(3, 20))

        # Pipeline flow
        flow = tk.Frame(hero, bg=C["bg"])
        flow.pack(fill="x", pady=(0, 20))

        pipeline = [
            ("[F]", "Your Excel",  "Raw data",      C["muted"]),
            None,
            ("[A]", "Agent 1",     "Clean & fix",   C["accent"]),
            None,
            ("[*]", "Clean Excel", "Report-ready",  C["green"]),
            None,
            ("[A]", "Agent 2",     "DAX + PQ",      C["purple"]),
            None,
            ("[D]", "Agent 3",     "SQL + Views",   C["orange"]),
            None,
            ("[P]", "Power BI",    "Dashboard",     C["teal"]),
        ]
        for step in pipeline:
            if step is None:
                tk.Label(flow, text="-->", bg=C["bg"],
                         fg=C["border"],
                         font=("Consolas", 12)).pack(side="left", padx=2)
                continue
            icon, title, sub, color = step
            card = tk.Frame(flow, bg=C["surface"],
                            highlightbackground=color,
                            highlightthickness=1, padx=10, pady=8)
            card.pack(side="left")
            tk.Label(card, text=icon, bg=C["surface"],
                     fg=color,
                     font=("Consolas", 13, "bold")).pack()
            tk.Label(card, text=title, bg=C["surface"],
                     fg=color, font=F["label"]).pack()
            tk.Label(card, text=sub, bg=C["surface"],
                     fg=C["muted"], font=F["small"]).pack()

        # File picker card
        pc = Card(hero, "Select Excel File")
        pc.pack(fill="x", pady=(0, 16))
        row = tk.Frame(pc, bg=C["surface"])
        row.pack(fill="x", padx=10, pady=8)
        tk.Entry(row, textvariable=self.input_file,
                 bg=C["surface2"], fg=C["text"], relief="flat",
                 font=F["label"],
                 highlightbackground=C["border"],
                 highlightthickness=1,
                 state="readonly").pack(
            side="left", fill="x", expand=True, ipady=5, padx=(0, 6))
        Btn(row, "Browse...",  self._browse).pack(side="left")
        Btn(row, "Use Sample", self._use_sample).pack(
            side="left", padx=(6, 0))
        Btn(row, "Start  >",   lambda: self.nb.select(1),
            accent=True).pack(side="right")

        # Feature cards — border uses BORDER_TINT (solid)
        fr = tk.Frame(hero, bg=C["bg"])
        fr.pack(fill="x")
        for color, title, desc in [
            (C["accent"], "Agent 1 — Data Cleaner",
             "10 tools  |  Fixes nulls, duplicates,\n"
             "dates, casing, categories, negatives"),
            (C["purple"], "Agent 2 — Power BI Builder",
             "DAX measures  |  Power Query M\n"
             "Step-by-step setup guide"),
            (C["orange"], "Agent 3 — SQL Generator",
             "DDL + inserts + views\n"
             "Push directly to MySQL"),
            (C["teal"],   "SQL Workbench Tab",
             "Live query runner\n"
             "Table browser  |  F5 to run"),
        ]:
            f = tk.Frame(fr, bg=C["surface"],
                         highlightbackground=_tint(color, strong=True),
                         highlightthickness=1, padx=12, pady=12)
            f.pack(side="left", fill="both", expand=True, padx=(0, 8))
            tk.Label(f, text=title, bg=C["surface"],
                     fg=color, font=F["label"]).pack(anchor="w")
            tk.Label(f, text=desc, bg=C["surface"],
                     fg=C["muted"], font=F["small"],
                     justify="left").pack(anchor="w", pady=(4, 0))

    # ══════════════════════════════════════════════════════════
    # AGENT 1 TAB
    # ══════════════════════════════════════════════════════════
    def _tab_agent1(self, tab):
        left = tk.Frame(tab, bg=C["bg"], width=310)
        left.pack(side="left", fill="y", padx=(10, 0), pady=10)
        left.pack_propagate(False)

        tk.Label(left, text="[A1]  Data Cleaning Agent",
                 bg=C["bg"], fg=C["accent"],
                 font=F["title"]).pack(anchor="w")
        tk.Label(left, text="10 LangChain tools  |  Auto-fix all issues",
                 bg=C["bg"], fg=C["muted"],
                 font=F["small"]).pack(anchor="w", pady=(0, 8))

        fc = Card(left, "Input File")
        fc.pack(fill="x", pady=(0, 6))
        row = tk.Frame(fc, bg=C["surface"])
        row.pack(fill="x", padx=8, pady=6)
        tk.Entry(row, textvariable=self.input_file,
                 bg=C["surface2"], fg=C["text"], relief="flat",
                 font=F["small"],
                 highlightbackground=C["border"],
                 highlightthickness=1,
                 state="readonly").pack(
            side="left", fill="x", expand=True, ipady=4)
        Btn(row, "...", self._browse,
            padx=6, pady=3).pack(side="left", padx=(4, 0))

        tc = Card(left, "LangChain Tools")
        tc.pack(fill="x", pady=(0, 6))
        self._tool_lbl = {}
        for key, lbl in [
            ("t1",  "1.  profile_data"),
            ("t2",  "2.  fix_column_names"),
            ("t3",  "3.  fix_duplicates"),
            ("t4",  "4.  fix_text_columns"),
            ("t5",  "5.  fix_dates"),
            ("t6",  "6.  fix_nulls"),
            ("t7",  "7.  fix_numerics"),
            ("t8",  "8.  fix_categories"),
            ("t9",  "9.  add_derived_columns"),
            ("t10", "10. export_clean_file"),
        ]:
            r = tk.Frame(tc, bg=C["surface"])
            r.pack(fill="x", padx=8, pady=1)
            st = tk.Label(r, text="o", bg=C["surface"],
                          fg=C["border"], font=F["small"], width=3)
            st.pack(side="left")
            tk.Label(r, text=lbl, bg=C["surface"],
                     fg=C["muted"], font=F["small"]).pack(side="left")
            self._tool_lbl[key] = st

        pc = Card(left, "Progress")
        pc.pack(fill="x", pady=(0, 6))
        self.prog1 = tk.DoubleVar()
        ttk.Progressbar(pc, variable=self.prog1,
                        maximum=100).pack(fill="x", padx=8, pady=6)
        self.prog1_lbl = tk.Label(pc, text="Ready",
                                  bg=C["surface"], fg=C["muted"],
                                  font=F["small"])
        self.prog1_lbl.pack(anchor="w", padx=8, pady=(0, 6))

        self.quality_card = tk.Frame(
            left, bg=C["surface"],
            highlightbackground=C["border"],
            highlightthickness=1)
        self.quality_card.pack(fill="x", pady=(0, 6))
        tk.Label(self.quality_card,
                 text="Quality report appears after run",
                 bg=C["surface"], fg=C["muted"],
                 font=F["small"], pady=8).pack()

        Btn(left, "Run Agent 1 — Clean Data",
            self._run_a1, accent=True).pack(fill="x", pady=2)
        Btn(left, "Use Sample Data",
            self._use_sample).pack(fill="x")

        right = tk.Frame(tab, bg=C["bg"])
        right.pack(side="right", fill="both", expand=True,
                   padx=10, pady=10)
        tk.Label(right, text="Agent Log", bg=C["bg"],
                 fg=C["muted"], font=F["small"]).pack(anchor="w")
        self.log1_widget = self._make_log(right, C["accent"])
        self.log1_widget.pack(fill="both", expand=True, pady=(3, 0))

    # ══════════════════════════════════════════════════════════
    # AGENT 2 TAB
    # ══════════════════════════════════════════════════════════
    def _tab_agent2(self, tab):
        left = tk.Frame(tab, bg=C["bg"], width=310)
        left.pack(side="left", fill="y", padx=(10, 0), pady=10)
        left.pack_propagate(False)

        tk.Label(left, text="[A2]  Power BI Agent",
                 bg=C["bg"], fg=C["purple"],
                 font=F["title"]).pack(anchor="w")
        tk.Label(left, text="4 tools  |  DAX + Power Query + Guide",
                 bg=C["bg"], fg=C["muted"],
                 font=F["small"]).pack(anchor="w", pady=(0, 8))

        fc = Card(left, "Clean File (from Agent 1)")
        fc.pack(fill="x", pady=(0, 6))
        tk.Entry(fc, textvariable=self.clean_file,
                 bg=C["surface2"], fg=C["text"], relief="flat",
                 font=F["small"],
                 highlightbackground=C["border"],
                 highlightthickness=1,
                 state="readonly").pack(
            fill="x", padx=8, pady=6, ipady=4)

        tc = Card(left, "LangChain Tools")
        tc.pack(fill="x", pady=(0, 6))
        self._tool2_lbl = {}
        for key, lbl in [
            ("t1", "1.  analyse_for_powerbi"),
            ("t2", "2.  generate_dax_measures"),
            ("t3", "3.  generate_power_query"),
            ("t4", "4.  generate_setup_guide"),
        ]:
            r = tk.Frame(tc, bg=C["surface"])
            r.pack(fill="x", padx=8, pady=1)
            st = tk.Label(r, text="o", bg=C["surface"],
                          fg=C["border"], font=F["small"], width=3)
            st.pack(side="left")
            tk.Label(r, text=lbl, bg=C["surface"],
                     fg=C["muted"], font=F["small"]).pack(side="left")
            self._tool2_lbl[key] = st

        pc = Card(left, "Progress")
        pc.pack(fill="x", pady=(0, 6))
        self.prog2 = tk.DoubleVar()
        ttk.Progressbar(pc, variable=self.prog2,
                        maximum=100).pack(fill="x", padx=8, pady=6)
        self.prog2_lbl = tk.Label(pc, text="Run Agent 1 first",
                                  bg=C["surface"], fg=C["muted"],
                                  font=F["small"])
        self.prog2_lbl.pack(anchor="w", padx=8, pady=(0, 6))

        Btn(left, "Run Agent 2 — Power BI",
            self._run_a2, accent=True).pack(fill="x", pady=2)

        right = tk.Frame(tab, bg=C["bg"])
        right.pack(side="right", fill="both", expand=True,
                   padx=10, pady=10)
        tk.Label(right, text="Agent Log", bg=C["bg"],
                 fg=C["muted"], font=F["small"]).pack(anchor="w")
        self.log2_widget = self._make_log(right, C["purple"])
        self.log2_widget.pack(fill="both", expand=True, pady=(3, 0))

    # ══════════════════════════════════════════════════════════
    # AGENT 3 TAB
    # ══════════════════════════════════════════════════════════
    def _tab_agent3(self, tab):
        left = tk.Frame(tab, bg=C["bg"], width=310)
        left.pack(side="left", fill="y", padx=(10, 0), pady=10)
        left.pack_propagate(False)

        tk.Label(left, text="[A3]  SQL Agent",
                 bg=C["bg"], fg=C["orange"],
                 font=F["title"]).pack(anchor="w")
        tk.Label(left, text="5 tools  |  Generate SQL + push to MySQL",
                 bg=C["bg"], fg=C["muted"],
                 font=F["small"]).pack(anchor="w", pady=(0, 8))

        dc = Card(left, "MySQL Connection")
        dc.pack(fill="x", pady=(0, 6))
        for lbl, key, default in [
            ("Host",     "db_host",     "127.0.0.1"),
            ("Port",     "db_port",     "3306"),
            ("User",     "db_user",     "root"),
            ("Database", "db_name",     "excel_ai_studio"),
        ]:
            r = tk.Frame(dc, bg=C["surface"])
            r.pack(fill="x", padx=8, pady=2)
            tk.Label(r, text=lbl, bg=C["surface"],
                     fg=C["muted"], font=F["small"],
                     width=9).pack(side="left")
            sv = tk.StringVar(value=default)
            setattr(self, f"sv_{key}", sv)
            tk.Entry(r, textvariable=sv,
                     bg=C["surface2"], fg=C["text"], relief="flat",
                     font=F["small"],
                     highlightbackground=C["border"],
                     highlightthickness=1).pack(
                side="left", fill="x", expand=True, ipady=3)

        r = tk.Frame(dc, bg=C["surface"])
        r.pack(fill="x", padx=8, pady=2)
        tk.Label(r, text="Password", bg=C["surface"],
                 fg=C["muted"], font=F["small"],
                 width=9).pack(side="left")
        self.sv_db_password = tk.StringVar()
        tk.Entry(r, textvariable=self.sv_db_password,
                 bg=C["surface2"], fg=C["text"], relief="flat",
                 font=F["small"], show="*",
                 highlightbackground=C["border"],
                 highlightthickness=1).pack(
            side="left", fill="x", expand=True, ipady=3)

        Btn(dc, "Test Connection", self._test_db).pack(
            padx=8, pady=6)

        self.push_var = tk.BooleanVar(value=False)
        tk.Checkbutton(left,
                       text="Push data to MySQL after generating SQL",
                       variable=self.push_var,
                       bg=C["bg"], fg=C["text"],
                       selectcolor=C["surface2"],
                       activebackground=C["bg"],
                       font=F["small"]).pack(anchor="w", pady=4)

        tc = Card(left, "LangChain Tools")
        tc.pack(fill="x", pady=(0, 6))
        self._tool3_lbl = {}
        for key, lbl in [
            ("t1", "1.  analyse_for_sql"),
            ("t2", "2.  generate_all_sql_files"),
            ("t3", "3.  test_mysql_connection"),
            ("t4", "4.  push_to_mysql"),
            ("t5", "5.  run_kpi_query"),
        ]:
            r = tk.Frame(tc, bg=C["surface"])
            r.pack(fill="x", padx=8, pady=1)
            st = tk.Label(r, text="o", bg=C["surface"],
                          fg=C["border"], font=F["small"], width=3)
            st.pack(side="left")
            tk.Label(r, text=lbl, bg=C["surface"],
                     fg=C["muted"], font=F["small"]).pack(side="left")
            self._tool3_lbl[key] = st

        pc = Card(left, "Progress")
        pc.pack(fill="x", pady=(0, 6))
        self.prog3 = tk.DoubleVar()
        ttk.Progressbar(pc, variable=self.prog3,
                        maximum=100).pack(fill="x", padx=8, pady=6)
        self.prog3_lbl = tk.Label(pc, text="Ready",
                                  bg=C["surface"], fg=C["muted"],
                                  font=F["small"])
        self.prog3_lbl.pack(anchor="w", padx=8, pady=(0, 6))

        Btn(left, "Run Agent 3 — SQL",
            self._run_a3, accent=True).pack(fill="x", pady=2)
        Btn(left, "Open SQL Folder",
            lambda: self._open_path(SQL_DIR)).pack(fill="x")

        right = tk.Frame(tab, bg=C["bg"])
        right.pack(side="right", fill="both", expand=True,
                   padx=10, pady=10)
        tk.Label(right, text="Agent Log", bg=C["bg"],
                 fg=C["muted"], font=F["small"]).pack(anchor="w")
        self.log3_widget = self._make_log(right, C["orange"])
        self.log3_widget.pack(fill="both", expand=True, pady=(3, 0))

    # ══════════════════════════════════════════════════════════
    # SQL WORKBENCH TAB
    # ══════════════════════════════════════════════════════════
    def _tab_workbench(self, tab):
        top_row = tk.Frame(tab, bg=C["bg"])
        top_row.pack(fill="x", padx=10, pady=(10, 0))
        tk.Label(top_row, text="SQL Workbench",
                 bg=C["bg"], fg=C["teal"],
                 font=F["title"]).pack(side="left")
        Btn(top_row, "Run Query  [F5]",
            self._run_query, accent=True).pack(side="right")
        Btn(top_row, "Clear",
            self._clear_results).pack(side="right", padx=(0, 6))

        preset_row = tk.Frame(tab, bg=C["bg"])
        preset_row.pack(fill="x", padx=10, pady=4)
        tk.Label(preset_row, text="Quick:", bg=C["bg"],
                 fg=C["muted"], font=F["small"]).pack(side="left")
        for label, sql in [
            ("Show Tables",
             "SHOW TABLES;"),
            ("KPI Summary",
             "SELECT COUNT(*) total_rows, SUM(revenue) total_revenue, "
             "ROUND(AVG(gm_pct),2) avg_gm FROM clean_data;"),
            ("By Region",
             "SELECT region, COUNT(*) deals, SUM(revenue) revenue "
             "FROM clean_data GROUP BY region ORDER BY revenue DESC;"),
            ("Monthly",
             "SELECT DATE_FORMAT(sale_date,'%Y-%m') month, "
             "SUM(revenue) revenue, COUNT(*) deals "
             "FROM clean_data GROUP BY month ORDER BY month;"),
            ("Win Rate",
             "SELECT status, COUNT(*) cnt FROM clean_data "
             "GROUP BY status;"),
            ("Top 10",
             "SELECT * FROM clean_data ORDER BY revenue DESC LIMIT 10;"),
        ]:
            Btn(preset_row, label,
                cmd=lambda s=sql: self._set_query(s),
                padx=6, pady=3).pack(side="left", padx=2)

        pane = tk.PanedWindow(tab, orient="vertical",
                              bg=C["border"], sashwidth=4)
        pane.pack(fill="both", expand=True, padx=10, pady=6)

        q_frame = tk.Frame(pane, bg=C["bg"])
        tk.Label(q_frame, text="Query Editor",
                 bg=C["bg"], fg=C["muted"],
                 font=F["small"]).pack(anchor="w")
        self.query_editor = tk.Text(
            q_frame, bg=C["surface"], fg=C["teal"],
            font=F["mono"], relief="flat",
            insertbackground=C["teal"],
            highlightbackground=C["border"],
            highlightthickness=1, height=8, wrap="none")
        self.query_editor.pack(fill="both", expand=True, pady=(3, 0))
        self.query_editor.insert("1.0",
                                 "SELECT * FROM clean_data LIMIT 20;")
        self.query_editor.bind("<F5>", lambda e: self._run_query())
        pane.add(q_frame, minsize=120)

        r_frame = tk.Frame(pane, bg=C["bg"])
        self.result_lbl = tk.Label(r_frame, text="Results",
                                   bg=C["bg"], fg=C["muted"],
                                   font=F["small"])
        self.result_lbl.pack(anchor="w")
        self.result_tree_frame = tk.Frame(r_frame, bg=C["bg"])
        self.result_tree_frame.pack(fill="both", expand=True,
                                    pady=(3, 0))
        pane.add(r_frame, minsize=150)

    # ══════════════════════════════════════════════════════════
    # OUTPUT FILES TAB
    # ══════════════════════════════════════════════════════════
    def _tab_output(self, tab):
        top = tk.Frame(tab, bg=C["bg"])
        top.pack(fill="x", padx=12, pady=(12, 0))
        tk.Label(top, text="Output Files", bg=C["bg"],
                 fg=C["text"], font=F["title"]).pack(side="left")
        Btn(top, "Refresh",
            self._refresh_output).pack(side="right")
        Btn(top, "Open Output Folder",
            lambda: self._open_path(OUTPUT_DIR)).pack(
            side="right", padx=(0, 6))
        Btn(top, "Open SQL Folder",
            lambda: self._open_path(SQL_DIR)).pack(
            side="right", padx=(0, 6))

        self.out_frame = tk.Frame(tab, bg=C["bg"])
        self.out_frame.pack(fill="both", expand=True,
                            padx=12, pady=8)
        self._refresh_output()

    # ══════════════════════════════════════════════════════════
    # ACTIONS
    # ══════════════════════════════════════════════════════════
    def _browse(self):
        p = filedialog.askopenfilename(
            title="Select Excel File",
            filetypes=[("Excel", "*.xlsx *.xls"), ("All", "*.*")])
        if p:
            self.input_file.set(p)
            self._log(1, f"File: {Path(p).name}", "info")

    def _use_sample(self):
        s = BASE / "data" / "sample_messy.xlsx"
        if not s.exists():
            messagebox.showerror(
                "Not found",
                "Sample file missing.\nRe-download the project.")
            return
        self.input_file.set(str(s))
        self._log(1, "Sample loaded: sample_messy.xlsx", "info")
        self.nb.select(1)

    def _test_db(self):
        def _work():
            self._log(3, "Testing MySQL connection...", "info")
            try:
                import mysql.connector
                conn = mysql.connector.connect(
                    host=self.sv_db_host.get(),
                    port=int(self.sv_db_port.get()),
                    user=self.sv_db_user.get(),
                    password=self.sv_db_password.get(),
                    connection_timeout=5)
                v = conn.get_server_info()
                conn.close()
                self.db_ok = True
                self.db_status.set(f"MySQL {v}")
                self.after(0, lambda: self.db_pill.config(
                    bg=TINT["green"], fg=C["green"]))
                self._log(3, f"Connected — MySQL {v}", "ok")
            except ImportError:
                self._log(3,
                          "mysql-connector-python not installed.\n"
                          "Run: pip install mysql-connector-python",
                          "error")
            except Exception as e:
                self.db_ok = False
                self.db_status.set("Not connected")
                self.after(0, lambda: self.db_pill.config(
                    bg=TINT["red"], fg=C["red"]))
                self._log(3, f"Connection failed: {e}", "error")
        threading.Thread(target=_work, daemon=True).start()

    # ── Agent runners ─────────────────────────────────────────
    def _run_a1(self):
        p = self.input_file.get().strip()
        if not p or not Path(p).exists():
            messagebox.showerror("No File",
                                 "Select an Excel file first.")
            return
        if self._running.get("a1"):
            return
        self._running["a1"] = True
        threading.Thread(target=self._a1_worker,
                         args=(p,), daemon=True).start()

    def _a1_worker(self, path):
        try:
            from agents.cleaning_agent import run_cleaning_pipeline
            out       = str(OUTPUT_DIR / "clean_data.xlsx")
            tool_keys = [f"t{i}" for i in range(1, 11)]
            idx       = [0]

            def cb(step, total, msg):
                pct = int(step / total * 100)
                self.after(0, lambda: self.prog1.set(pct))
                self.after(0, lambda: self.prog1_lbl.config(text=msg))
                self._log(1, f"[{step:02}/{total}] {msg}", "tool")
                i = idx[0]
                if i < len(tool_keys):
                    self.after(0, lambda k=tool_keys[i]:
                               self._set_tool(self._tool_lbl, k, "running"))
                if i > 0:
                    self.after(0, lambda k=tool_keys[i - 1]:
                               self._set_tool(self._tool_lbl, k, "done"))
                idx[0] += 1

            self._log(1, "=" * 44, "muted")
            self._log(1, "  AGENT 1 — DATA CLEANING", "info")
            self._log(1, "=" * 44, "muted")

            result = run_cleaning_pipeline(path, out, cb)

            for k in self._tool_lbl:
                self.after(0, lambda kk=k:
                           self._set_tool(self._tool_lbl, kk, "done"))

            imp = result["improvement"]
            self._log(1,
                      f"Quality: {imp['quality_before']} "
                      f"-> {imp['quality_after']}", "ok")
            self._log(1,
                      f"Issues:  {imp['issues_before']} "
                      f"-> {imp['issues_after']}", "ok")
            self._log(1,
                      f"Rows:    {imp['rows_before']} "
                      f"-> {imp['rows_after']}", "ok")
            self._log(1, "Clean file: output/clean_data.xlsx", "ok")

            self.clean_file.set(out)
            self.prog1.set(100)
            self.after(0, lambda: self.prog1_lbl.config(text="Done!"))
            self.after(0, lambda r=result: self._show_quality(r))
            self.after(0, self._refresh_output)
        except Exception as e:
            self._log(1, f"ERROR: {e}", "error")
            import traceback
            self._log(1, traceback.format_exc(), "error")
        finally:
            self._running["a1"] = False

    def _run_a2(self):
        p = self.clean_file.get().strip()
        if not p or not Path(p).exists():
            messagebox.showinfo("Run Agent 1 first",
                                "Agent 1 must run first.")
            self.nb.select(1)
            return
        if self._running.get("a2"):
            return
        self._running["a2"] = True
        threading.Thread(target=self._a2_worker,
                         args=(p,), daemon=True).start()

    def _a2_worker(self, path):
        try:
            from agents.powerbi_agent import run_powerbi_pipeline
            tool_map = {1: "t1", 2: "t2", 3: "t3", 4: "t4"}

            def cb(s, t, m):
                self.after(0, lambda: self.prog2.set(int(s / t * 100)))
                self.after(0, lambda: self.prog2_lbl.config(text=m))
                self._log(2, f"[{s:02}/{t}] {m}", "tool")
                k  = tool_map.get(s)
                pk = tool_map.get(s - 1)
                if k:
                    self.after(0, lambda kk=k: self._set_tool(
                        self._tool2_lbl, kk, "running"))
                if pk:
                    self.after(0, lambda kk=pk: self._set_tool(
                        self._tool2_lbl, kk, "done"))

            self._log(2, "=" * 44, "muted")
            self._log(2, "  AGENT 2 — POWER BI", "info")
            self._log(2, "=" * 44, "muted")

            r = run_powerbi_pipeline(path, str(OUTPUT_DIR), cb)

            for k in self._tool2_lbl:
                self.after(0, lambda kk=k: self._set_tool(
                    self._tool2_lbl, kk, "done"))

            for f in r.get("files_created", []):
                if f and Path(f).exists():
                    self._log(2, f"  {Path(f).name}", "ok")
            self._log(2,
                      f"DAX measures: {r.get('dax_measure_count', 0)}",
                      "ok")
            self._log(2, "Power BI files ready!", "ok")
            self.prog2.set(100)
            self.after(0, lambda: self.prog2_lbl.config(text="Done!"))
            self.after(0, self._refresh_output)
        except Exception as e:
            self._log(2, f"ERROR: {e}", "error")
            import traceback
            self._log(2, traceback.format_exc(), "error")
        finally:
            self._running["a2"] = False

    def _run_a3(self):
        p = self.clean_file.get().strip()
        if not p or not Path(p).exists():
            messagebox.showinfo("Run Agent 1 first",
                                "Agent 1 must run first.")
            self.nb.select(1)
            return
        if self._running.get("a3"):
            return
        self._running["a3"] = True
        os.environ["DB_HOST"]     = self.sv_db_host.get()
        os.environ["DB_PORT"]     = self.sv_db_port.get()
        os.environ["DB_USER"]     = self.sv_db_user.get()
        os.environ["DB_PASSWORD"] = self.sv_db_password.get()
        os.environ["DB_NAME"]     = self.sv_db_name.get()
        push = self.push_var.get()
        threading.Thread(target=self._a3_worker,
                         args=(p, push), daemon=True).start()

    def _a3_worker(self, path, push):
        try:
            # ── Write GUI credentials to os.environ FIRST ─────
            # sql_agent reads _get_db_config() which calls os.environ
            # at call time — so this must happen before any import.
            os.environ["DB_HOST"]     = self.sv_db_host.get()
            os.environ["DB_PORT"]     = self.sv_db_port.get()
            os.environ["DB_USER"]     = self.sv_db_user.get()
            os.environ["DB_PASSWORD"] = self.sv_db_password.get()
            os.environ["DB_NAME"]     = self.sv_db_name.get()

            # Force re-import so settings module picks up new env
            for mod in list(sys.modules.keys()):
                if "sql_agent" in mod or "db_manager" in mod:
                    del sys.modules[mod]

            from agents.sql_agent import run_sql_pipeline

            # Tool label map: pipeline step number -> sidebar key
            tool_map = {1: "t1", 2: "t2", 3: "t3", 4: "t4", 5: "t5"}

            def cb(step, total, msg):
                pct = int(step / total * 100)
                self.after(0, lambda: self.prog3.set(pct))
                self.after(0, lambda: self.prog3_lbl.config(text=msg))
                self._log(3, msg, "tool")
                k  = tool_map.get(step)
                pk = tool_map.get(step - 1)
                if k:
                    self.after(0, lambda kk=k: self._set_tool(
                        self._tool3_lbl, kk, "running"))
                if pk:
                    self.after(0, lambda kk=pk: self._set_tool(
                        self._tool3_lbl, kk, "done"))

            self._log(3, "=" * 44, "muted")
            self._log(3, "  AGENT 3 — SQL", "info")
            self._log(3, f"  DB: {self.sv_db_host.get()}:{self.sv_db_port.get()}"
                         f" / {self.sv_db_name.get()}", "muted")
            self._log(3, "=" * 44, "muted")

            r = run_sql_pipeline(
                path, str(SQL_DIR),
                push_to_db=push,
                progress_callback=cb)

            # Mark all tools done
            for k in self._tool3_lbl:
                self.after(0, lambda kk=k: self._set_tool(
                    self._tool3_lbl, kk, "done"))

            # Report generated files
            for f in r.get("sql_files", []):
                if f and Path(f).exists():
                    self._log(3, f"  Created: {Path(f).name}", "ok")

            # Connection result
            conn = r.get("connection", {})
            if conn.get("status") == "ok":
                self._log(3, f"MySQL: {conn.get('message','')}", "ok")
                self.db_ok = True
                self.db_status.set("Connected")
                self.after(0, lambda: self.db_pill.config(
                    bg=TINT["green"], fg=C["green"]))
            else:
                self._log(3,
                          f"MySQL offline ({conn.get('message','')}) "
                          "— SQL files ready for manual import.", "warn")

            # Push result
            pr = r.get("push_result", {})
            if pr.get("status") == "ok":
                self._log(3,
                          f"Pushed {pr.get('loaded', 0)} rows "
                          f"to `{r.get('table_name','')}`", "ok")
            elif pr.get("status") == "error":
                self._log(3, f"Push failed: {pr.get('message','')}", "error")

            self._log(3, "", "")
            self._log(3, "SQL Agent complete!", "ok")
            self._log(3,
                      "Open SQL Workbench > run files in sql/ folder "
                      "in order 01 -> 02 -> 03 -> 05", "info")

            self.prog3.set(100)
            self.after(0, lambda: self.prog3_lbl.config(text="Done!"))
            self.after(0, self._refresh_output)

        except Exception as e:
            self._log(3, f"ERROR: {e}", "error")
            import traceback
            self._log(3, traceback.format_exc(), "error")
        finally:
            self._running["a3"] = False

    # ── SQL Workbench ─────────────────────────────────────────
    def _run_query(self):
        sql = self.query_editor.get("1.0", "end").strip()
        if not sql:
            return
        threading.Thread(target=self._query_worker,
                         args=(sql,), daemon=True).start()

    def _query_worker(self, sql):
        try:
            from core.db_manager import DBManager
            mgr = DBManager({
                "host":     self.sv_db_host.get(),
                "port":     int(self.sv_db_port.get()),
                "user":     self.sv_db_user.get(),
                "password": self.sv_db_password.get(),
                "database": self.sv_db_name.get(),
            })
            if not mgr.connect():
                self.after(0, lambda: self.result_lbl.config(
                    text="Not connected — test connection in Agent 3",
                    fg=C["red"]))
                return
            result = mgr.run_query(sql)
            mgr.disconnect()
            if result["status"] == "ok":
                rows = result["rows"]
                cols = result["columns"]
                self.after(0, lambda: self._show_results(cols, rows))
                self.after(0, lambda: self.result_lbl.config(
                    text=f"Results: {len(rows)} rows",
                    fg=C["green"]))
            else:
                self.after(0, lambda: self.result_lbl.config(
                    text=f"Error: {result['message']}",
                    fg=C["red"]))
        except ImportError:
            self.after(0, lambda: self.result_lbl.config(
                text="Run: pip install mysql-connector-python",
                fg=C["orange"]))
        except Exception as e:
            self.after(0, lambda: self.result_lbl.config(
                text=f"Error: {e}", fg=C["red"]))

    def _show_results(self, columns, rows):
        for w in self.result_tree_frame.winfo_children():
            w.destroy()
        if not rows:
            tk.Label(self.result_tree_frame, text="No results",
                     bg=C["bg"], fg=C["muted"],
                     font=F["small"]).pack()
            return
        vsb  = ttk.Scrollbar(self.result_tree_frame, orient="vertical")
        hsb  = ttk.Scrollbar(self.result_tree_frame, orient="horizontal")
        tree = ttk.Treeview(self.result_tree_frame,
                            columns=columns, show="headings",
                            yscrollcommand=vsb.set,
                            xscrollcommand=hsb.set)
        vsb.config(command=tree.yview)
        hsb.config(command=tree.xview)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120, minwidth=60)
        for row in rows[:500]:
            vals = [str(row.get(c, "")) for c in columns]
            tree.insert("", "end", values=vals)
        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0,  column=1, sticky="ns")
        hsb.grid(row=1,  column=0, sticky="ew")
        self.result_tree_frame.grid_rowconfigure(0, weight=1)
        self.result_tree_frame.grid_columnconfigure(0, weight=1)

    def _set_query(self, sql):
        self.query_editor.delete("1.0", "end")
        self.query_editor.insert("1.0", sql)

    def _clear_results(self):
        for w in self.result_tree_frame.winfo_children():
            w.destroy()
        self.result_lbl.config(text="Results", fg=C["muted"])

    def _show_quality(self, result):
        for w in self.quality_card.winfo_children():
            w.destroy()
        imp = result.get("improvement", {})
        tk.Label(self.quality_card, text="Quality Report",
                 bg=C["surface"], fg=C["muted"],
                 font=F["small"], pady=4, padx=8).pack(anchor="w")
        r = tk.Frame(self.quality_card, bg=C["surface"])
        r.pack(fill="x", padx=8, pady=(0, 4))
        for lbl, b, a, u in [
            ("Quality",
             imp.get("quality_before", 0),
             imp.get("quality_after",  0), "%"),
            ("Issues",
             imp.get("issues_before",  0),
             imp.get("issues_after",   0), ""),
            ("Rows",
             imp.get("rows_before",    0),
             imp.get("rows_after",     0), ""),
        ]:
            col = tk.Frame(r, bg=C["surface"])
            col.pack(side="left", expand=True)
            tk.Label(col, text=lbl, bg=C["surface"],
                     fg=C["muted"], font=F["small"]).pack()
            tk.Label(col,
                     text=f"{b}{u}  ->  {a}{u}",
                     bg=C["surface"], fg=C["green"],
                     font=F["label"]).pack()
        Btn(self.quality_card, "Go to Agent 2: Power BI",
            lambda: self.nb.select(2),
            accent=True).pack(padx=8, pady=(0, 6))

    def _refresh_output(self):
        for w in self.out_frame.winfo_children():
            w.destroy()
        all_files = []
        for d, label, color in [
            (OUTPUT_DIR, "output/", C["green"]),
            (SQL_DIR,    "sql/",    C["orange"]),
        ]:
            if d.exists():
                for f in sorted(d.iterdir()):
                    if f.is_file():
                        all_files.append((f, label, color))

        if not all_files:
            tk.Label(self.out_frame,
                     text="No output files yet. Run the agents.",
                     bg=C["bg"], fg=C["muted"],
                     font=F["small"]).pack(pady=20)
            return

        ext_colors = {
            ".xlsx": C["green"],  ".txt":  C["accent"],
            ".m":    C["purple"], ".md":   C["orange"],
            ".sql":  C["teal"],   ".json": C["muted"],
        }
        for f, folder, folder_color in all_files:
            row = tk.Frame(self.out_frame, bg=C["surface"],
                           highlightbackground=C["border"],
                           highlightthickness=1)
            row.pack(fill="x", pady=2)
            color = ext_colors.get(f.suffix, C["muted"])
            Badge(row, f.suffix.upper()[1:] or "FILE",
                  color).pack(side="left", padx=8, pady=6)
            Badge(row, folder,
                  folder_color).pack(side="left", pady=6)
            tk.Label(row, text=f.name,
                     bg=C["surface"], fg=C["text"],
                     font=F["label"]).pack(side="left", padx=4)
            sz = f.stat().st_size
            tk.Label(row,
                     text=(f"{sz / 1024:.1f} KB"
                           if sz > 1024 else f"{sz} B"),
                     bg=C["surface"], fg=C["muted"],
                     font=F["small"]).pack(side="right", padx=8)
            Btn(row, "Open",
                cmd=lambda p=f: self._open_path(p),
                padx=6, pady=2).pack(side="right", padx=4)

    # ── Shared helpers ────────────────────────────────────────
    def _make_log(self, parent, accent_color):
        w = scrolledtext.ScrolledText(
            parent,
            bg=C["surface"], fg=C["text"],
            font=F["log"], relief="flat",
            insertbackground=C["text"],
            highlightbackground=C["border"],
            highlightthickness=1,
            wrap="word", state="disabled")
        w.tag_config("info",  foreground=accent_color)
        w.tag_config("ok",    foreground=C["green"])
        w.tag_config("warn",  foreground=C["orange"])
        w.tag_config("error", foreground=C["red"])
        w.tag_config("muted", foreground=C["muted"])
        w.tag_config("tool",  foreground=C["purple"])
        return w

    def _log(self, agent_n, msg, tag=""):
        name = {1: "log1_widget",
                2: "log2_widget",
                3: "log3_widget"}.get(agent_n)
        if not name:
            return
        w = getattr(self, name, None)
        if not w:
            return
        def _do():
            w.config(state="normal")
            ts   = datetime.now().strftime("%H:%M:%S")
            line = f"[{ts}] {msg}\n" if msg else "\n"
            w.insert("end", line, tag)
            w.see("end")
            w.config(state="disabled")
        self.after(0, _do)

    def _set_tool(self, d, key, status):
        text_color = {
            "pending": ("o",   C["border"]),
            "running": (">>",  C["orange"]),
            "done":    ("OK",  C["green"]),
            "error":   ("ERR", C["red"]),
        }
        txt, color = text_color.get(status, ("o", C["border"]))
        if key in d:
            d[key].config(text=txt, fg=color)

    def _open_path(self, path):
        import subprocess, platform
        path   = Path(path)
        target = str(path.parent if path.is_file() else path)
        system = platform.system()
        if system == "Darwin":
            subprocess.run(["open", target])
        elif system == "Windows":
            os.startfile(target)
        else:
            subprocess.run(["xdg-open", target])


# ── Entry point ───────────────────────────────────────────────
if __name__ == "__main__":
    app = App()
    app.mainloop()
