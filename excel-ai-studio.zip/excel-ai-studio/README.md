# 🤖 Excel AI Studio

> Two AI agents in a desktop GUI: clean your Excel data and generate Power BI reports automatically.

---

## What It Does

```
Your Excel File (messy)
        ↓
Agent 1: Data Cleaning
  • Profiles 10+ issue types
  • Fixes nulls, dates, duplicates
  • Standardises categories & case
  • Adds derived columns (GM%, Year, Quarter)
        ↓
Clean Excel File
        ↓
Agent 2: Power BI Builder
  • Generates DAX measures
  • Generates Power Query M code
  • Writes step-by-step setup guide
  • Suggests visuals & report layout
        ↓
Power BI Desktop (you build the report)
```

---

## Quick Start

### 1. Clone & Setup
```bash
git clone https://github.com/YOUR_USERNAME/excel-ai-studio.git
cd excel-ai-studio

python -m venv venv
source venv/bin/activate       # Mac/Linux
venv\Scripts\activate          # Windows

pip install -r requirements.txt
```

### 2. Run the GUI
```bash
python app.py
```

### 3. Use It
1. Click **"Use Sample Data"** or browse to your Excel file
2. Click **"Run Cleaning Agent"** — watch it fix all issues
3. Switch to **Agent 2** tab
4. Click **"Run Power BI Agent"** — get DAX + Power Query
5. Open **Output Files** tab to access all generated files

---

## Project Structure
```
excel-ai-studio/
├── app.py                    ← GUI (run this)
├── requirements.txt
├── README.md
│
├── agents/
│   ├── cleaning_agent.py     ← Agent 1: 10 cleaning tools
│   └── powerbi_agent.py      ← Agent 2: 4 PBI generation tools
│
├── data/
│   └── sample_messy.xlsx     ← Sample messy data to test with
│
└── output/                   ← All generated files appear here
    ├── clean_data.xlsx
    ├── dax_measures.txt
    ├── powerquery_transform.m
    └── powerbi_setup_guide.md
```

---

## Output Files Explained

| File | What it is |
|------|-----------|
| `clean_data.xlsx` | Cleaned Excel — load this into Power BI |
| `dax_measures.txt` | Copy-paste DAX into Power BI New Measure |
| `powerquery_transform.m` | Paste into Power Query Advanced Editor |
| `powerbi_setup_guide.md` | Step-by-step Power BI setup instructions |

---

## Customisation

Edit `agents/cleaning_agent.py` to:
- Change how nulls are filled (median → mean → fixed value)
- Adjust category standardisation rules
- Add custom derived columns

Edit `agents/powerbi_agent.py` to:
- Add more DAX measures
- Customise Power Query steps
- Change suggested visual types

---

## No API Key Needed
The agents use intelligent rule-based logic by default.
Add `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` to a `.env` file
for AI-generated descriptions and smarter analysis.

---

## License
MIT
