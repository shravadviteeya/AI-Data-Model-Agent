"""
Agent 1: Data Cleaning Agent
=============================
Analyses Excel files, detects issues, and produces a clean version
ready for Power BI reporting.

Tools:
  - profile_data      → detect issues in each column
  - fix_column_names  → standardise headers
  - fix_nulls         → handle missing values
  - fix_duplicates    → remove duplicate rows
  - fix_dates         → parse inconsistent date formats
  - fix_text          → trim whitespace, fix case
  - fix_numerics      → convert strings, remove negatives
  - fix_categories    → standardise categorical values
  - export_clean      → write clean Excel + quality report
"""

import pandas as pd
import numpy as np
import re
import json
from pathlib import Path
from datetime import datetime
from loguru import logger


# ── LangChain tool decorator (graceful fallback) ──────────────
try:
    from langchain.tools import tool
except ImportError:
    def tool(fn):
        fn.invoke = lambda args: fn(**args) if isinstance(args, dict) else fn(args)
        return fn


# ═════════════════════════════════════════════════════════════
# TOOL 1 — Profile Data
# ═════════════════════════════════════════════════════════════
@tool
def profile_data(file_path: str) -> str:
    """
    Analyse an Excel file and return a full quality profile.
    Detects: nulls, duplicates, type mismatches, inconsistent
    categories, date format issues, whitespace problems.
    """
    try:
        df = pd.read_excel(file_path)
        issues = []
        col_profiles = []

        total_rows = len(df)
        duplicate_rows = int(df.duplicated().sum())
        if duplicate_rows > 0:
            issues.append(f"DUPLICATE_ROWS: {duplicate_rows} duplicate rows found")

        for col in df.columns:
            s = df[col]
            null_count = int(s.isnull().sum())
            null_pct   = round(null_count / total_rows * 100, 1)
            unique     = int(s.nunique())
            dtype      = str(s.dtype)

            col_issues = []

            # Nulls
            if null_count > 0:
                col_issues.append(f"NULLS:{null_count}({null_pct}%)")

            # Whitespace in string columns
            if s.dtype == object:
                ws = int(s.dropna().apply(lambda x: str(x) != str(x).strip()).sum())
                if ws > 0:
                    col_issues.append(f"WHITESPACE:{ws}")

                # Mixed case
                vals = s.dropna().astype(str).str.strip()
                if len(vals) > 0:
                    upper_pct = (vals == vals.str.upper()).mean()
                    lower_pct = (vals == vals.str.lower()).mean()
                    title_pct = (vals == vals.str.title()).mean()
                    if max(upper_pct, lower_pct, title_pct) < 0.8:
                        col_issues.append("MIXED_CASE")

                # Inconsistent categories (≤20 unique)
                if unique <= 20 and unique > 1:
                    cleaned = vals.str.lower().str.strip()
                    if cleaned.nunique() < unique:
                        col_issues.append(f"INCONSISTENT_CATEGORIES:{unique}→{cleaned.nunique()}")

                # Numeric stored as string
                try:
                    pd.to_numeric(vals.replace(['N/A','n/a','NA','None',''], np.nan), errors='raise')
                    col_issues.append("NUMERIC_AS_STRING")
                except:
                    pass

                # Date detection
                date_sample = vals.head(20)
                date_hits = sum(1 for v in date_sample if re.search(
                    r'\d{1,4}[-/]\d{1,2}[-/]\d{2,4}|\w{3,9}\s+\d{1,2}\s+\d{4}', str(v)))
                if date_hits >= 5:
                    col_issues.append("DATE_FORMAT_INCONSISTENT")

            # Negative values in numeric columns
            if pd.api.types.is_numeric_dtype(s):
                neg = int((s < 0).sum())
                zeros = int((s == 0).sum())
                if neg > 0:
                    col_issues.append(f"NEGATIVE_VALUES:{neg}")
                if zeros > int(total_rows * 0.05):
                    col_issues.append(f"ZERO_VALUES:{zeros}")

            col_profiles.append({
                "column": col,
                "dtype": dtype,
                "nulls": null_count,
                "null_pct": null_pct,
                "unique": unique,
                "issues": col_issues
            })

            for iss in col_issues:
                issues.append(f"COL[{col}]: {iss}")

        quality_score = max(0, 100 - len(issues) * 3)

        result = {
            "status": "success",
            "file": file_path,
            "total_rows": total_rows,
            "total_cols": len(df.columns),
            "duplicate_rows": duplicate_rows,
            "total_issues": len(issues),
            "quality_score": quality_score,
            "issues": issues,
            "column_profiles": col_profiles
        }
        return json.dumps(result)

    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 2 — Fix Column Names
# ═════════════════════════════════════════════════════════════
@tool
def fix_column_names(file_path: str) -> str:
    """
    Standardise column names: strip spaces, title case,
    replace spaces with underscores, remove special chars.
    """
    try:
        df = pd.read_excel(file_path)
        original = list(df.columns)
        new_cols = []
        for c in df.columns:
            nc = str(c).strip()
            nc = re.sub(r'[^\w\s]', '', nc)
            nc = re.sub(r'\s+', '_', nc)
            nc = nc.strip('_').title()
            new_cols.append(nc)
        df.columns = new_cols
        df.to_excel(file_path, index=False)
        changes = {o: n for o, n in zip(original, new_cols) if o != n}
        return json.dumps({"status": "success", "renamed": changes, "total": len(changes)})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 3 — Fix Duplicates
# ═════════════════════════════════════════════════════════════
@tool
def fix_duplicates(file_path: str) -> str:
    """Remove exact duplicate rows from the Excel file."""
    try:
        df = pd.read_excel(file_path)
        before = len(df)
        df = df.drop_duplicates()
        after = len(df)
        removed = before - after
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "removed": removed,
                           "before": before, "after": after})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 4 — Fix Text Columns
# ═════════════════════════════════════════════════════════════
@tool
def fix_text_columns(file_path: str) -> str:
    """
    For all string columns: strip whitespace, apply Title Case.
    Fixes trailing/leading spaces and mixed case inconsistencies.
    """
    try:
        df = pd.read_excel(file_path)
        fixed_cols = []
        for col in df.select_dtypes(include='object').columns:
            before = df[col].copy()
            df[col] = df[col].apply(
                lambda x: str(x).strip().title()
                if pd.notna(x) and str(x) not in ['nan','None',''] else x
            )
            if not before.equals(df[col]):
                fixed_cols.append(col)
        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixed_columns": fixed_cols})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 5 — Fix Dates
# ═════════════════════════════════════════════════════════════
@tool
def fix_dates(file_path: str) -> str:
    """
    Detect date columns and parse multiple formats
    (YYYY-MM-DD, DD/MM/YYYY, Mon DD YYYY etc.)
    into a standard YYYY-MM-DD format.
    """
    try:
        df = pd.read_excel(file_path)
        date_cols = []

        for col in df.columns:
            if df[col].dtype == object:
                sample = df[col].dropna().head(30).astype(str)
                hits = sum(1 for v in sample if re.search(
                    r'\d{1,4}[-/]\d{1,2}[-/]\d{2,4}|\w{3,9}\s\d{1,2}\s\d{4}', v))
                if hits >= 5:
                    try:
                        parsed = pd.to_datetime(df[col], infer_datetime_format=True,
                                                errors='coerce', dayfirst=True)
                        valid = parsed.notna().sum()
                        if valid > len(df) * 0.5:
                            df[col] = parsed.dt.strftime('%Y-%m-%d')
                            date_cols.append(col)
                    except:
                        pass

        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "date_columns_fixed": date_cols})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 6 — Fix Nulls
# ═════════════════════════════════════════════════════════════
@tool
def fix_nulls(file_path: str) -> str:
    """
    Handle missing values intelligently:
    - Numeric columns → fill with median
    - String columns  → fill with 'Unknown'
    - Replace 'N/A', 'None', '' strings with proper NaN first
    """
    try:
        df = pd.read_excel(file_path)
        null_fixes = {}

        # Replace common null-like strings
        df.replace(['N/A', 'n/a', 'NA', 'None', 'none', 'NULL',
                    'null', '', ' '], np.nan, inplace=True)

        for col in df.columns:
            null_count = int(df[col].isnull().sum())
            if null_count == 0:
                continue

            if pd.api.types.is_numeric_dtype(df[col]):
                median_val = df[col].median()
                df[col].fillna(median_val, inplace=True)
                null_fixes[col] = f"filled {null_count} nulls with median ({median_val:.1f})"
            else:
                df[col].fillna('Unknown', inplace=True)
                null_fixes[col] = f"filled {null_count} nulls with 'Unknown'"

        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixes": null_fixes})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 7 — Fix Numerics
# ═════════════════════════════════════════════════════════════
@tool
def fix_numerics(file_path: str) -> str:
    """
    Convert numeric-looking string columns to float.
    Remove negative values (replace with 0 or median).
    Fix zero values that are clearly invalid.
    """
    try:
        df = pd.read_excel(file_path)
        fixed = {}

        for col in df.columns:
            if df[col].dtype == object:
                # Try converting to numeric
                converted = pd.to_numeric(
                    df[col].astype(str).str.replace('[₹,$,€,£,]', '', regex=True).str.strip(),
                    errors='coerce'
                )
                if converted.notna().mean() > 0.7:
                    df[col] = converted
                    fixed[col] = "converted string→numeric"

            if pd.api.types.is_numeric_dtype(df[col]):
                # Remove negatives in revenue/cost/qty columns
                neg_cols = ['revenue','cost','qty','quantity','amount','price','sales']
                if any(kw in col.lower() for kw in neg_cols):
                    neg_count = int((df[col] < 0).sum())
                    if neg_count > 0:
                        df[col] = df[col].clip(lower=0)
                        fixed[col] = fixed.get(col, "") + f" removed {neg_count} negatives"

        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixed_columns": fixed})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 8 — Fix Categories
# ═════════════════════════════════════════════════════════════
@tool
def fix_categories(file_path: str) -> str:
    """
    For low-cardinality string columns (≤25 unique values),
    standardise categories: lowercase+strip, then find the
    most-common form and map all variants to it.
    """
    try:
        df = pd.read_excel(file_path)
        fixed = {}

        for col in df.select_dtypes(include='object').columns:
            unique_vals = df[col].dropna().unique()
            if len(unique_vals) > 25:
                continue

            # Build normalise → canonical map
            norm_map = {}
            for v in unique_vals:
                norm = str(v).lower().strip()
                if norm not in norm_map:
                    norm_map[norm] = []
                norm_map[norm].append(v)

            if len(norm_map) == len(unique_vals):
                continue  # no duplicates

            # Map each value → canonical (Title Case of normalised)
            val_map = {}
            for norm, variants in norm_map.items():
                canonical = norm.title()
                for v in variants:
                    if str(v) != canonical:
                        val_map[str(v)] = canonical

            if val_map:
                df[col] = df[col].apply(
                    lambda x: val_map.get(str(x), x) if pd.notna(x) else x)
                fixed[col] = val_map

        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "fixed_columns": {
            k: f"{len(v)} variants unified" for k, v in fixed.items()}})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 9 — Add Derived Columns
# ═════════════════════════════════════════════════════════════
@tool
def add_derived_columns(file_path: str) -> str:
    """
    Add calculated columns useful for Power BI reporting:
    Gross_Margin, GM_Pct, Year, Month, Quarter, Month_Name.
    """
    try:
        df = pd.read_excel(file_path)
        added = []

        # GM columns
        rev_col  = next((c for c in df.columns if 'revenue' in c.lower()), None)
        cost_col = next((c for c in df.columns if 'cost'    in c.lower()), None)
        if rev_col and cost_col:
            df['Gross_Margin'] = (df[rev_col] - df[cost_col]).round(2)
            df['GM_Pct']       = ((df['Gross_Margin'] / df[rev_col]) * 100).round(2)
            added.extend(['Gross_Margin', 'GM_Pct'])

        # Date columns
        date_col = next((c for c in df.columns
                         if any(kw in c.lower() for kw in ['date','month','period'])), None)
        if date_col:
            parsed = pd.to_datetime(df[date_col], errors='coerce')
            if parsed.notna().sum() > len(df) * 0.5:
                df['Year']       = parsed.dt.year.astype('Int64')
                df['Month_Num']  = parsed.dt.month.astype('Int64')
                df['Month_Name'] = parsed.dt.strftime('%B')
                df['Quarter']    = 'Q' + parsed.dt.quarter.astype(str)
                added.extend(['Year','Month_Num','Month_Name','Quarter'])

        df.to_excel(file_path, index=False)
        return json.dumps({"status": "success", "added_columns": added})
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 10 — Export Clean File
# ═════════════════════════════════════════════════════════════
@tool
def export_clean_file(file_path: str, output_path: str) -> str:
    """
    Final export: produce the clean Excel file and a
    JSON quality report comparing before vs after.
    """
    try:
        import shutil
        df = pd.read_excel(file_path)

        # Final pass — remove any remaining blank rows
        df = df.dropna(how='all')

        df.to_excel(output_path, index=False)

        report = {
            "status": "success",
            "clean_file": output_path,
            "final_rows": len(df),
            "final_cols": len(df.columns),
            "columns": list(df.columns),
            "sample_rows": df.head(3).to_dict('records'),
            "exported_at": datetime.now().isoformat()
        }
        return json.dumps(report, default=str)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# CLEANING PIPELINE — runs all tools in sequence
# ═════════════════════════════════════════════════════════════
def run_cleaning_pipeline(
    input_path: str,
    output_path: str,
    progress_callback=None
) -> dict:
    """
    Run all 10 cleaning tools in sequence.
    progress_callback(step, total, message) for GUI updates.
    """
    import shutil

    steps = [
        ("Profiling data quality...",       None),
        ("Fixing column names...",          fix_column_names),
        ("Removing duplicate rows...",      fix_duplicates),
        ("Fixing text & case...",           fix_text_columns),
        ("Parsing date formats...",         fix_dates),
        ("Handling null values...",         fix_nulls),
        ("Fixing numeric columns...",       fix_numerics),
        ("Standardising categories...",     fix_categories),
        ("Adding derived columns...",       add_derived_columns),
        ("Exporting clean file...",         None),
    ]

    total = len(steps)

    def cb(i, msg):
        if progress_callback:
            progress_callback(i, total, msg)

    # Copy to temp working file
    import os
    work_path = str(Path(output_path).parent / "_work_temp.xlsx")
    shutil.copy2(input_path, work_path)

    cb(0, "Starting pipeline...")

    # Step 0: Profile (before)
    cb(1, "Profiling original file...")
    profile_before = json.loads(profile_data.invoke({"file_path": work_path}))

    # Steps 1-8: Cleaning tools
    results = {}
    tool_steps = steps[1:-1]
    for i, (msg, tool_fn) in enumerate(tool_steps, start=2):
        cb(i, msg)
        try:
            result = json.loads(tool_fn.invoke({"file_path": work_path}))
            results[msg] = result
        except Exception as e:
            results[msg] = {"error": str(e)}

    # Step 9: Export
    cb(total, "Exporting clean file...")
    export_result = json.loads(export_clean_file.invoke({
        "file_path": work_path,
        "output_path": output_path
    }))

    # Profile after
    profile_after = json.loads(profile_data.invoke({"file_path": output_path}))

    # Cleanup temp
    if Path(work_path).exists():
        Path(work_path).unlink()

    return {
        "status": "success",
        "input_file": input_path,
        "output_file": output_path,
        "profile_before": profile_before,
        "profile_after": profile_after,
        "step_results": results,
        "improvement": {
            "issues_before": profile_before.get("total_issues", 0),
            "issues_after":  profile_after.get("total_issues", 0),
            "quality_before": profile_before.get("quality_score", 0),
            "quality_after":  profile_after.get("quality_score", 0),
            "rows_before": profile_before.get("total_rows", 0),
            "rows_after":  profile_after.get("total_rows", 0),
        }
    }


if __name__ == "__main__":
    result = run_cleaning_pipeline(
        "data/sample_messy.xlsx",
        "output/sample_clean.xlsx"
    )
    print(f"\nQuality: {result['improvement']['quality_before']} → {result['improvement']['quality_after']}")
    print(f"Issues:  {result['improvement']['issues_before']} → {result['improvement']['issues_after']}")
    print(f"Rows:    {result['improvement']['rows_before']} → {result['improvement']['rows_after']}")
    print(f"Clean file: {result['output_file']}")
