"""
Agent 2: Power BI Report Generator Agent
==========================================
Analyses the cleaned Excel file and generates:
  1. A complete Power BI Desktop (.pbip) template project
  2. DAX measures file
  3. Power Query M code
  4. A step-by-step setup guide
  5. A pre-built HTML preview of what the PBI report will look like
"""

import pandas as pd
import numpy as np
import json
from pathlib import Path
from datetime import datetime
from loguru import logger


try:
    from langchain.tools import tool
except ImportError:
    def tool(fn):
        fn.invoke = lambda args: fn(**args) if isinstance(args, dict) else fn(args)
        return fn


# ═════════════════════════════════════════════════════════════
# TOOL 1 — Analyse Schema for Power BI
# ═════════════════════════════════════════════════════════════
@tool
def analyse_for_powerbi(file_path: str) -> str:
    """
    Read the clean Excel file and identify:
    - Dimension columns (text, categories, dates)
    - Measure columns (numeric)
    - Suggested relationships
    - Recommended visuals
    """
    try:
        df = pd.read_excel(file_path)
        dimensions, measures, dates = [], [], []

        for col in df.columns:
            dtype = str(df[col].dtype)
            unique = df[col].nunique()
            sample = df[col].dropna().head(5).tolist()

            if 'int' in dtype or 'float' in dtype:
                measures.append({
                    "column": col,
                    "min": float(df[col].min()) if len(df[col].dropna()) > 0 else 0,
                    "max": float(df[col].max()) if len(df[col].dropna()) > 0 else 0,
                    "sum": float(df[col].sum()),
                    "mean": float(df[col].mean()) if len(df[col].dropna()) > 0 else 0
                })
            elif any(kw in col.lower() for kw in ['date','month','year','period']):
                dates.append({"column": col, "sample": [str(s) for s in sample]})
            else:
                dimensions.append({
                    "column": col,
                    "unique_values": unique,
                    "sample": [str(s) for s in sample],
                    "cardinality": "low" if unique <= 20 else "high"
                })

        # Suggest visuals based on columns found
        visuals = []
        if measures:
            visuals.append({"type": "Card", "purpose": "KPI summary", "fields": [m["column"] for m in measures[:4]]})
        if dates:
            visuals.append({"type": "Line Chart", "purpose": "Trend over time",
                           "x_axis": dates[0]["column"],
                           "values": [m["column"] for m in measures[:2]]})
        low_card_dims = [d for d in dimensions if d["cardinality"] == "low"]
        if low_card_dims and measures:
            visuals.append({"type": "Bar Chart", "purpose": "Compare by category",
                           "axis": low_card_dims[0]["column"],
                           "values": [m["column"] for m in measures[:2]]})
            if len(low_card_dims) > 1:
                visuals.append({"type": "Donut Chart", "purpose": "Share breakdown",
                               "legend": low_card_dims[1]["column"],
                               "values": [measures[0]["column"]] if measures else []})
        visuals.append({"type": "Matrix/Table", "purpose": "Detailed data view",
                       "rows": [d["column"] for d in low_card_dims[:2]],
                       "values": [m["column"] for m in measures[:3]]})
        visuals.append({"type": "Slicer", "purpose": "Interactive filter",
                       "fields": [d["column"] for d in low_card_dims[:3]]})

        return json.dumps({
            "status": "success",
            "total_rows": len(df),
            "dimensions": dimensions,
            "measures": measures,
            "dates": dates,
            "suggested_visuals": visuals
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 2 — Generate DAX Measures
# ═════════════════════════════════════════════════════════════
@tool
def generate_dax_measures(file_path: str) -> str:
    """
    Generate a complete set of DAX measures for the data.
    Returns DAX code for KPIs, time intelligence, and comparisons.
    """
    try:
        df = pd.read_excel(file_path)
        cols = {c.lower(): c for c in df.columns}

        rev_col  = next((cols[k] for k in cols if 'revenue' in k or 'sales' in k), None)
        cost_col = next((cols[k] for k in cols if 'cost' in k), None)
        gm_col   = next((cols[k] for k in cols if 'margin' in k or k == 'gm'), None)
        qty_col  = next((cols[k] for k in cols if 'qty' in k or 'quantity' in k), None)
        date_col = next((cols[k] for k in cols if 'date' in k or 'month' in k), None)

        table = "SalesData"
        measures = []

        if rev_col:
            measures += [
                f"-- ── Revenue Measures ─────────────────────────────────",
                f"Total Revenue = SUM('{table}'[{rev_col}])",
                f"",
                f"Avg Revenue = AVERAGE('{table}'[{rev_col}])",
                f"",
                f"Revenue YTD = TOTALYTD(SUM('{table}'[{rev_col}]), 'DateTable'[Date])",
                f"",
                f"Revenue MTD = TOTALMTD(SUM('{table}'[{rev_col}]), 'DateTable'[Date])",
                f"",
                f"Revenue QTD = TOTALQTD(SUM('{table}'[{rev_col}]), 'DateTable'[Date])",
                f"",
            ]

        if cost_col and rev_col:
            measures += [
                f"-- ── Cost & Margin Measures ───────────────────────────",
                f"Total Cost = SUM('{table}'[{cost_col}])",
                f"",
                f"Gross Margin = [Total Revenue] - [Total Cost]",
                f"",
                f"GM % = DIVIDE([Gross Margin], [Total Revenue], 0) * 100",
                f"",
            ]

        if rev_col:
            measures += [
                f"-- ── Growth Measures ─────────────────────────────────",
                f"Revenue PY = CALCULATE(",
                f"    SUM('{table}'[{rev_col}]),",
                f"    SAMEPERIODLASTYEAR('DateTable'[Date])",
                f")",
                f"",
                f"Revenue Growth % = DIVIDE([Total Revenue] - [Revenue PY], [Revenue PY], 0) * 100",
                f"",
                f"Revenue MoM % = ",
                f"VAR CurrentMonth = SUM('{table}'[{rev_col}])",
                f"VAR PrevMonth = CALCULATE(",
                f"    SUM('{table}'[{rev_col}]),",
                f"    DATEADD('DateTable'[Date], -1, MONTH)",
                f")",
                f"RETURN DIVIDE(CurrentMonth - PrevMonth, PrevMonth, 0) * 100",
                f"",
            ]

        if qty_col:
            measures += [
                f"-- ── Volume Measures ─────────────────────────────────",
                f"Total Deals = COUNT('{table}'[{qty_col}])",
                f"",
                f"Avg Deal Size = DIVIDE([Total Revenue], [Total Deals], 0)",
                f"",
            ]

        # Win rate if Status column exists
        status_col = next((cols[k] for k in cols if 'status' in k), None)
        if status_col:
            measures += [
                f"-- ── Win Rate ────────────────────────────────────────",
                f"Won Deals = CALCULATE(",
                f"    COUNT('{table}'[{status_col}]),",
                f"    '{table}'[{status_col}] = \"Won\"",
                f")",
                f"",
                f"Win Rate % = DIVIDE([Won Deals], [Total Deals], 0) * 100",
                f"",
            ]

        measures += [
            f"-- ── Ranking ────────────────────────────────────────",
            f"Revenue Rank = RANKX(",
            f"    ALL('{table}'),",
            f"    [Total Revenue],",
            f"    ,",
            f"    DESC",
            f")",
            f"",
            f"-- ── Dynamic Title ──────────────────────────────────",
            f'Report Title = "Sales Dashboard — " & SELECTEDVALUE(\'DateTable\'[Year], "All Years")',
        ]

        dax_code = "\n".join(measures)

        return json.dumps({
            "status": "success",
            "table_name": table,
            "measure_count": len([m for m in measures if '=' in m and not m.startswith('--')]),
            "dax_code": dax_code,
            "columns_detected": {
                "revenue": rev_col, "cost": cost_col,
                "gm": gm_col, "quantity": qty_col, "date": date_col
            }
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 3 — Generate Power Query M Code
# ═════════════════════════════════════════════════════════════
@tool
def generate_power_query(file_path: str) -> str:
    """
    Generate Power Query M transformation steps
    that mirror what the cleaning agent did,
    so Power BI auto-refreshes stay clean.
    """
    try:
        df = pd.read_excel(file_path)
        fname = Path(file_path).name

        m_code = f'''let
    // ── Step 1: Load Source File ──────────────────────────────
    Source = Excel.Workbook(
        File.Contents("{file_path}"),
        null, true
    ),
    Sheet1 = Source{{[Item="Sheet1",Kind="Sheet"]}}[Data],
    PromotedHeaders = Table.PromoteHeaders(Sheet1, [PromoteAllScalars=true]),

    // ── Step 2: Set Column Types ──────────────────────────────
    CorrectTypes = Table.TransformColumnTypes(PromotedHeaders, {{
'''

        for col in df.columns:
            dtype = str(df[col].dtype)
            if 'int' in dtype:
                m_code += f'        {{"{col}", Int64.Type}},\n'
            elif 'float' in dtype:
                m_code += f'        {{"{col}", type number}},\n'
            elif any(kw in col.lower() for kw in ['date','month','period']):
                m_code += f'        {{"{col}", type date}},\n'
            else:
                m_code += f'        {{"{col}", type text}},\n'

        m_code = m_code.rstrip(',\n') + '\n    }),\n\n'
        m_code += '''    // ── Step 3: Remove Duplicates ─────────────────────────
    NoDuplicates = Table.Distinct(CorrectTypes),

    // ── Step 4: Replace Null-Like Values ──────────────────────
    CleanNulls = Table.ReplaceValue(
        NoDuplicates, "N/A", null,
        Replacer.ReplaceValue, Table.ColumnNames(NoDuplicates)
    ),

    // ── Step 5: Trim Whitespace from Text Columns ─────────────
    TrimmedText = Table.TransformColumns(
        CleanNulls,
        List.Transform(
            Table.ColumnsOfType(CleanNulls, {type text}),
            each {_, Text.Trim}
        )
    ),

    // ── Step 6: Remove Blank Rows ─────────────────────────────
    NoBlankRows = Table.SelectRows(
        TrimmedText,
        each not List.IsEmpty(
            List.RemoveMatchingItems(Record.FieldValues(_), {"", null})
        )
    )

in
    NoBlankRows
'''

        return json.dumps({
            "status": "success",
            "m_code": m_code,
            "steps": ["Load Source","Set Types","Remove Duplicates",
                      "Replace Nulls","Trim Text","Remove Blank Rows"]
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# TOOL 4 — Generate Setup Guide
# ═════════════════════════════════════════════════════════════
@tool
def generate_setup_guide(file_path: str, output_dir: str) -> str:
    """
    Generate a complete step-by-step Power BI setup guide
    as a Markdown file explaining exactly how to build
    the report from the clean data.
    """
    try:
        df = pd.read_excel(file_path)
        fname = Path(file_path).name
        cols  = list(df.columns)

        guide = f"""# Power BI Report Setup Guide
Generated: {datetime.now().strftime('%d %b %Y %H:%M')}
Source File: `{fname}`

---

## STEP 1 — Open Power BI Desktop
1. Launch **Power BI Desktop**
2. Click **Get Data** → **Excel Workbook**
3. Browse to: `{file_path}`
4. Select the sheet and click **Load**

---

## STEP 2 — Apply Power Query Transformations
1. Click **Transform Data** (opens Power Query Editor)
2. In the ribbon, click **Advanced Editor**
3. Paste the M code from `powerquery_transform.m`
4. Click **Done** → **Close & Apply**

---

## STEP 3 — Create a Date Table (Required for Time Intelligence)
In Power BI Desktop, go to **Modeling → New Table** and paste:

```dax
DateTable =
ADDCOLUMNS(
    CALENDAR(DATE(2024,1,1), DATE(2026,12,31)),
    "Year",        YEAR([Date]),
    "Month Num",   MONTH([Date]),
    "Month Name",  FORMAT([Date], "MMMM"),
    "Quarter",     "Q" & QUARTER([Date]),
    "Week Num",    WEEKNUM([Date]),
    "Day Name",    FORMAT([Date], "DDDD")
)
```

Then mark it as a **Date Table**:
- Select the table → **Modeling → Mark as Date Table** → select `Date` column

---

## STEP 4 — Create Relationships
Go to **Model View** and connect:
- `DateTable[Date]` → `SalesData[Sale_Date]` (Many to One)

---

## STEP 5 — Add DAX Measures
1. Select the **SalesData** table
2. Click **New Measure** for each measure in `dax_measures.txt`
3. Paste each measure definition and press Enter

Key measures to create first:
```
Total Revenue = SUM('SalesData'[Revenue])
Gross Margin  = SUM('SalesData'[Gross_Margin])
GM %          = DIVIDE([Gross Margin], [Total Revenue], 0) * 100
Win Rate %    = DIVIDE([Won Deals], [Total Deals], 0) * 100
```

---

## STEP 6 — Build Report Pages

### Page 1: Executive Summary
| Visual | Type | Fields |
|--------|------|--------|
| Total Revenue | Card | [Total Revenue] |
| Gross Margin | Card | [Gross Margin] |
| GM% | Card | [GM %] |
| Win Rate | Card | [Win Rate %] |
| Revenue Trend | Line Chart | Date[Month Name] + [Total Revenue] |
| Sales by Region | Bar Chart | Region + [Total Revenue] |
| Product Mix | Donut | Product + [Total Revenue] |

### Page 2: Sales Team Performance
| Visual | Type | Fields |
|--------|------|--------|
| Rep Leaderboard | Bar (Horizontal) | Sales_Rep + [Total Revenue] |
| Won vs Lost | Stacked Bar | Status + Count |
| Monthly Deals | Column Chart | Month + [Total Deals] |
| Detail Table | Matrix | Region, Product, Revenue, GM% |

### Page 3: Filters & Slicers
Add slicers for:
- **Date Range** (Date Slicer)
- **Region** (Dropdown or Tile)
- **Product** (Multi-select)
- **Status** (Button Slicer)

---

## STEP 7 — Format & Theme
1. **View → Themes → Browse** → Import `powerbi_theme.json`
2. Set background to dark (#0a0e1a) or use a Microsoft built-in theme
3. Add company logo to the header

---

## STEP 8 — Publish (Optional)
1. **File → Publish → Publish to Power BI**
2. Choose your workspace
3. Set **Scheduled Refresh** to point to your Excel file location
4. Share the dashboard link with stakeholders

---

## Column Reference
Your cleaned data has these columns:
{chr(10).join(f'- `{c}` ({str(df[c].dtype)})' for c in cols)}

---
*Generated by Excel AI Studio — Power BI Agent*
"""

        guide_path = str(Path(output_dir) / "powerbi_setup_guide.md")
        Path(guide_path).write_text(guide, encoding='utf-8')

        return json.dumps({
            "status": "success",
            "guide_path": guide_path,
            "sections": ["Open PBI","Power Query","Date Table",
                        "Relationships","DAX Measures","Report Pages",
                        "Format & Theme","Publish"]
        })
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})


# ═════════════════════════════════════════════════════════════
# MAIN PIPELINE
# ═════════════════════════════════════════════════════════════
def run_powerbi_pipeline(
    clean_file_path: str,
    output_dir: str,
    progress_callback=None
) -> dict:
    """Run the full Power BI generation pipeline."""

    Path(output_dir).mkdir(parents=True, exist_ok=True)

    def cb(step, total, msg):
        if progress_callback:
            progress_callback(step, total, msg)

    total_steps = 4
    results = {}

    cb(1, total_steps, "Analysing schema for Power BI...")
    schema = json.loads(analyse_for_powerbi.invoke({"file_path": clean_file_path}))
    results["schema"] = schema

    cb(2, total_steps, "Generating DAX measures...")
    dax = json.loads(generate_dax_measures.invoke({"file_path": clean_file_path}))
    dax_path = str(Path(output_dir) / "dax_measures.txt")
    Path(dax_path).write_text(dax.get("dax_code", ""), encoding='utf-8')
    results["dax"] = dax

    cb(3, total_steps, "Generating Power Query M code...")
    pq = json.loads(generate_power_query.invoke({"file_path": clean_file_path}))
    pq_path = str(Path(output_dir) / "powerquery_transform.m")
    Path(pq_path).write_text(pq.get("m_code", ""), encoding='utf-8')
    results["power_query"] = pq

    cb(4, total_steps, "Generating setup guide...")
    guide = json.loads(generate_setup_guide.invoke({
        "file_path": clean_file_path,
        "output_dir": output_dir
    }))
    results["guide"] = guide

    return {
        "status": "success",
        "output_dir": output_dir,
        "files_created": [dax_path, pq_path, guide.get("guide_path","")],
        "schema": schema,
        "dax_measure_count": dax.get("measure_count", 0),
        "power_query_steps": pq.get("steps", []),
        "suggested_visuals": schema.get("suggested_visuals", []),
        "results": results
    }
