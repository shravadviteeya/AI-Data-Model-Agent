"""
KPI Calculator — computes all metrics from loaded table data.
Add new KPIs here. Each method returns a value that gets
merged into the master kpis dict.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from loguru import logger


class KPICalculator:
    """Calculates all KPIs from loaded Excel data."""

    def __init__(self, config: dict):
        self.cfg = config
        self.currency = config.get(
            'dashboard', {}).get('currency_symbol', '₹')

    def calculate_all(self, data: Dict[str, dict]) -> Dict[str, Any]:
        """Run all KPI calculations and return merged dict."""
        kpis: Dict[str, Any] = {}

        # Find the primary dataframe (largest one)
        dfs = {k: v['df'] for k, v in data.items()
               if isinstance(v, dict) and 'df' in v}
        if not dfs:
            logger.error("No dataframes found in data")
            return kpis

        primary = max(dfs.values(), key=len)

        # ── Revenue KPIs ──────────────────────────────────────
        kpis.update(self._revenue_kpis(primary, dfs))

        # ── Trend KPIs ────────────────────────────────────────
        kpis.update(self._trend_kpis(primary))

        # ── Dimensional KPIs ─────────────────────────────────
        kpis.update(self._dimensional_kpis(primary))

        # ── Pipeline KPIs ─────────────────────────────────────
        kpis.update(self._pipeline_kpis(primary))

        # ── Health score ──────────────────────────────────────
        kpis['health_score'] = self._health_score(kpis)
        kpis['health_label'] = self._health_label(kpis['health_score'])

        # ── Formatted versions ────────────────────────────────
        kpis.update(self._format_kpis(kpis))

        return kpis

    def _revenue_kpis(self, df: pd.DataFrame,
                      dfs: dict) -> Dict[str, Any]:
        out = {}
        rev = self._col(df, 'revenue')
        cost = self._col(df, 'cost')
        gm = self._col(df, 'gross_margin')
        gmpct = self._col(df, 'gm_pct')
        be = self._col(df, 'be_revenue')
        deals = self._col(df, 'deals_closed')
        pipeline = self._col(df, 'pipeline_value')
        wr = self._col(df, 'win_rate')

        if rev is not None:
            out['total_revenue'] = int(df[rev].sum())
            out['avg_monthly_revenue'] = int(df[rev].mean())
        if cost is not None:
            out['total_cost'] = int(df[cost].sum())
        if gm is not None:
            out['total_gm'] = int(df[gm].sum())
        if gmpct is not None:
            out['avg_gm_pct'] = round(float(df[gmpct].mean()), 1)
            out['min_gm_pct'] = round(float(df[gmpct].min()), 1)
            out['max_gm_pct'] = round(float(df[gmpct].max()), 1)
        if be is not None and rev is not None:
            total_be = float(df[be].sum())
            total_rev = float(df[rev].sum())
            out['total_be'] = int(total_be)
            out['revenue_vs_be_pct'] = round(total_rev / total_be * 100, 1)
            out['revenue_variance'] = int(total_rev - total_be)
        if deals is not None:
            out['total_deals'] = int(df[deals].sum())
        if pipeline is not None:
            out['total_pipeline'] = int(df[pipeline].sum())
            if rev is not None and out.get('total_revenue', 0) > 0:
                out['pipeline_coverage'] = round(
                    float(df[pipeline].sum()) /
                    float(df[rev].sum()), 1)
        if wr is not None:
            out['avg_win_rate'] = round(float(df[wr].mean()), 1)
        return out

    def _trend_kpis(self, df: pd.DataFrame) -> Dict[str, Any]:
        out = {}
        month_col = self._col(df, 'month')
        rev_col = self._col(df, 'revenue')
        gm_col = self._col(df, 'gross_margin')
        be_col = self._col(df, 'be_revenue')
        deals_col = self._col(df, 'deals_closed')

        if not month_col or not rev_col:
            return out

        agg: Dict[str, Any] = {rev_col: 'sum'}
        if gm_col:
            agg[gm_col] = 'sum'
        if be_col:
            agg[be_col] = 'sum'
        if deals_col:
            agg[deals_col] = 'sum'

        monthly = df.groupby(month_col).agg(agg).reset_index()
        monthly = monthly.rename(columns={month_col: 'month'})
        monthly['mom_growth'] = (
            monthly[rev_col].pct_change() * 100).round(2)

        if gm_col:
            monthly['gm_pct'] = (
                monthly[gm_col] / monthly[rev_col] * 100).round(2)
        if be_col:
            monthly['vs_be_pct'] = (
                monthly[rev_col] / monthly[be_col] * 100).round(1)

        out['monthly_trend'] = monthly.to_dict('records')
        out['avg_mom_growth'] = round(
            float(monthly['mom_growth'].mean()), 2)
        best_idx = monthly[rev_col].idxmax()
        out['best_month'] = str(monthly.loc[best_idx, 'month'])
        out['best_month_revenue'] = int(monthly.loc[best_idx, rev_col])
        return out

    def _dimensional_kpis(self, df: pd.DataFrame) -> Dict[str, Any]:
        out = {}
        rev_col = self._col(df, 'revenue')
        gm_col = self._col(df, 'gross_margin')
        deals_col = self._col(df, 'deals_closed')
        wr_col = self._col(df, 'win_rate')

        for dim in ['region', 'product', 'sales_owner']:
            dim_col = self._col(df, dim)
            if dim_col and rev_col:
                agg: Dict[str, Any] = {rev_col: 'sum'}
                if gm_col:
                    agg[gm_col] = 'sum'
                if deals_col:
                    agg[deals_col] = 'sum'
                if wr_col:
                    agg[wr_col] = 'mean'
                grp = df.groupby(dim_col).agg(agg).reset_index()
                grp.columns = [
                    'name' if c == dim_col else c
                    for c in grp.columns
                ]
                if gm_col and rev_col in grp.columns:
                    grp['gm_pct'] = (
                        grp[gm_col] / grp[rev_col] * 100).round(2)
                total = grp[rev_col].sum()
                grp['rev_share'] = (
                    grp[rev_col] / total * 100).round(1)
                grp = grp.sort_values(rev_col, ascending=False)
                out[f'by_{dim}'] = grp.to_dict('records')

        return out

    def _pipeline_kpis(self, df: pd.DataFrame) -> Dict[str, Any]:
        out = {}
        stage_col = self._col(df, 'stage')
        rev_col = self._col(df, 'revenue')
        if stage_col and rev_col:
            by_stage = df.groupby(stage_col)[rev_col].agg(
                ['sum', 'count']
            ).reset_index()
            by_stage.columns = ['stage', 'value', 'count']
            out['by_stage'] = by_stage.to_dict('records')
        return out

    def _health_score(self, kpis: dict) -> int:
        score = 75  # Base
        thresholds = self.cfg.get('kpis', {})
        gm = kpis.get('avg_gm_pct', 35)
        rvb = kpis.get('revenue_vs_be_pct', 100)
        wr = kpis.get('avg_win_rate', 40)
        cov = kpis.get('pipeline_coverage', 3)
        if gm >= thresholds.get('gm_healthy_threshold', 35):
            score += 5
        elif gm < thresholds.get('gm_critical_threshold', 25):
            score -= 20
        else:
            score -= 10
        if rvb >= 100:
            score += 5
        elif rvb < thresholds.get('be_achievement_critical', 90):
            score -= 20
        elif rvb < thresholds.get('be_achievement_warn', 95):
            score -= 10
        if wr >= thresholds.get('win_rate_good', 50):
            score += 5
        elif wr < thresholds.get('win_rate_benchmark', 40):
            score -= 10
        if cov >= thresholds.get('pipeline_coverage_min', 3):
            score += 5
        elif cov < thresholds.get('pipeline_coverage_warn', 2.5):
            score -= 15
        return max(0, min(100, score))

    def _health_label(self, score: int) -> str:
        thresholds = self.cfg.get('kpis', {})
        if score >= thresholds.get('health_score_green', 75):
            return 'Healthy'
        if score >= thresholds.get('health_score_amber', 50):
            return 'Watch'
        return 'At Risk'

    def _format_kpis(self, kpis: dict) -> dict:
        sym = self.currency
        def fmt(n: float) -> str:
            if n >= 1e7:
                return f"{sym}{n/1e7:.2f}Cr"
            if n >= 1e5:
                return f"{sym}{n/1e5:.1f}L"
            return f"{sym}{n:,.0f}"

        out = {}
        for key in ['total_revenue', 'total_gm', 'total_cost',
                    'total_pipeline', 'total_be']:
            if key in kpis:
                out[f"{key}_fmt"] = fmt(kpis[key])
        return out

    def _col(self, df: pd.DataFrame,
             canonical: str) -> Optional[str]:
        """Return actual column name if it (or an alias) exists."""
        aliases = self.cfg.get('column_aliases', {})
        candidates = [canonical] + aliases.get(canonical, [])
        for c in candidates:
            if c in df.columns:
                return c
        return None

