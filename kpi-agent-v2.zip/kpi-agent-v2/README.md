# 🤖 KPI Intelligence Agent — Wireframe 2
### Unified Multi-Source Dashboard · Coforge D&A PMO

> Reads **8 Excel sheets** from multiple source systems, establishes cross-sheet relationships, calculates KPIs per source, and generates a single unified interactive dashboard with AI-powered executive insights.

![Version](https://img.shields.io/badge/version-2.0.0-blue)
![Python](https://img.shields.io/badge/python-3.9+-green)
![Sheets](https://img.shields.io/badge/sheets-8_sources-orange)
![License](https://img.shields.io/badge/license-MIT-gray)

---

## 📊 Supported Data Sources (8 Sheets)

| Sheet | Source System | Key Metrics | Refresh |
|-------|--------------|-------------|---------|
| **Finance Tracker** | Finance / ERP | Revenue, Expenses, GM% monthly | Monthly |
| **Master** | Reference Data | IBU↔Customer mapping, GEO | On change |
| **Employee Master** | HR / SAP | Headcount, Billed%, Practice, Skills | Weekly |
| **Salesforce Pipeline** | Salesforce CRM | TCV, ACV, Stage, Probability, AI flag | Daily |
| **Demand Data** | TA / RDG System | Open RRs, Ageing, FFTP | Daily |
| **Bench Data** | Resource Pool | Available HC, Pool ageing, Skills | Daily |
| **YTD Fulfillment** | HR / TA | Closed demands, FFTP, Internal% | Monthly |
| **salesforce closed deal** | Salesforce CRM | Won/Lost, TCV, Margin%, Deal type | Daily |

---

## 🔗 Cross-Sheet Relationships

```
Salesforce Pipeline ──[Opportunity ID]──► Demand Data
Salesforce Pipeline ──[AccountName]──────► Master Reference
Salesforce Pipeline ──[OpportunityID]────► Closed Deals
Demand Data ─────────[Employee Code]─────► Employee Master
Demand Data ─────────[Request ID]────────► YTD Fulfillment
Bench Data ──────────[Employee No]───────► Employee Master
Employee Master ─────[Customer Name]─────► Finance Tracker
Master Reference ────[IBU / GEO]─────────► All Sheets
```

---

## 📁 Project Structure

```
kpi-agent-v2/
│
├── main.py                      ← CLI entry point
├── requirements.txt
├── config.yaml                  ← All thresholds & settings
├── .env.example                 ← API key template
├── README.md
├── CUSTOMIZATION.md
│
├── core/
│   ├── multi_sheet_loader.py    ← Reads all 8 sheets intelligently
│   ├── relationship_mapper.py   ← Detects & maps cross-sheet joins
│   ├── finance_kpi.py           ← Finance Tracker KPIs
│   ├── salesforce_kpi.py        ← Pipeline + Closed Deals KPIs
│   ├── people_kpi.py            ← Employee + Bench + Fulfillment KPIs
│   ├── demand_kpi.py            ← Demand Data KPIs
│   └── master_kpi.py            ← Unified cross-source KPIs
│
├── agents/
│   ├── base_agent.py            ← All AI providers + factory
│   └── insight_engine.py        ← AI prompt for multi-source insights
│
├── ui/
│   ├── dashboard_builder.py     ← Builds full 8-tab HTML dashboard
│   └── report_builder.py        ← Executive summary report
│
├── templates/
│   └── dashboard.html           ← Visual template (customise here)
│
├── data/sample/
│   └── generate_sample.py       ← Generates realistic 8-sheet Excel
│
├── tests/
│   └── test_all.py
│
└── docs/
    └── ARCHITECTURE.md
```

---

## 🚀 Quick Start

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/kpi-agent-v2.git
cd kpi-agent-v2

# 2. Virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate      # Mac/Linux

# 3. Install
pip install -r requirements.txt

# 4. Configure (add ONE API key)
cp .env.example .env

# 5a. Run with your own multi-sheet Excel
python main.py --file DATA2.xlsx

# 5b. Run with generated sample data
python main.py --sample

# Dashboard opens at: output/dashboard.html
```

---

## 🎛️ Using Your Own Excel File

Your file must contain these sheet names (case-insensitive match):

```
FINANCE TRACKER        → or: Finance, Finance Tracker
Master                 → or: Master Ref, Reference
EMPLOYEE MASTER        → or: Employee, HC Master
SALESFORCE DATA        → or: SF Pipeline, Pipeline
DEMAND DATA            → or: Demand, RR Data
BENCH DATA             → or: Bench, Resource Pool
YTD FULFILLMENT DATA   → or: Fulfillment, YTD
salesforce closed deal → or: Closed, Closed Deals
```

Run:
```bash
python main.py --file path/to/your/DATA2.xlsx --provider anthropic
```

---

## 🔑 API Key (optional — works without one)

```env
AI_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-xxxx   # Claude — recommended
# OR
OPENAI_API_KEY=sk-xxxx          # GPT-4
# OR
GITHUB_TOKEN=ghp_xxxx           # GitHub Copilot
```

---

## 🗺️ Wireframe Roadmap

| Version | Status | Features |
|---------|--------|---------|
| Wireframe 1 | ✅ Released | Single Excel, core KPIs, executive summary |
| **Wireframe 2** | ✅ **Current** | 8-sheet multi-source, relationship mapping, per-source tabs |
| Wireframe 3 | 🔜 Planned | Power BI MCP integration, live refresh |
| Wireframe 4 | 🔜 Planned | Salesforce direct API, no export needed |
| Wireframe 5 | 🔜 Planned | Predictive forecasting + scenario planning |

---

## 📜 License
MIT — free to use, modify, and distribute.
