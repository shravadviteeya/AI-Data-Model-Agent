"""
Salesforce KPI Calculator — Pipeline + Closed Deals.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any
from loguru import logger


class SalesforceKPI:
    """KPIs for Salesforce Pipeline and Closed Deals sheets."""

    def __init__(self, config: dict):
        self.cfg = config
        self.sym = config.get('dashboard', {}).get('currency_symbol', '$')

    def calculate_pipeline(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Pipeline (open opportunities) KPIs."""
        if df is None or df.empty:
            return {}
        out = {}

        # Core values
        tcv_col = next((c for c in df.columns if 'TCV' in c and '$' in c
                        and 'HBU' not in c and 'MM' not in c), None)
        acv_col = next((c for c in df.columns if 'ACV' in c and '$' in c
                        and 'HBU' not in c and 'MM' not in c), None)
        prob_col = next((c for c in df.columns
                         if 'Probability' in c), None)
        stage_col = next((c for c in df.columns
                          if c.upper() in ('STAGE', 'OPPORTUNITYSTAGE')), None)
        bu_col    = next((c for c in df.columns if c == 'BU'), None)
        vert_col  = next((c for c in df.columns
                          if 'VERTICAL' in c.upper() or c == 'Vertical'), None)
        ai_col    = next((c for c in df.columns
                          if 'PROPOSAL_CONTAINS_AI' in c.upper()), None)

        total_tcv   = float(df[tcv_col].sum())  if tcv_col  else 0
        total_acv   = float(df[acv_col].sum())  if acv_col  else 0
        avg_prob    = float(df[prob_col].mean()) if prob_col else 0
        total_deals = len(df)
        ai_deals    = (int((df[ai_col].str.lower() == 'yes').sum())
                       if ai_col else 0)

        # Weighted pipeline
        weighted = (float((df[tcv_col] * df[prob_col] / 100).sum())
                    if tcv_col and prob_col else 0)

        # Dimensional breakdowns
        by_stage = {}
        if stage_col and tcv_col:
            by_stage = (df.groupby(stage_col)[tcv_col].sum()
                        .sort_values(ascending=False)
                        .head(8).round(0).to_dict())

        by_bu = {}
        if bu_col and tcv_col:
            by_bu = (df.groupby(bu_col)[tcv_col].sum()
                     .sort_values(ascending=False)
                     .head(8).round(0).to_dict())

        by_vertical = {}
        if vert_col and tcv_col:
            by_vertical = (df.groupby(vert_col)[tcv_col].sum()
                           .sort_values(ascending=False)
                           .head(8).round(0).to_dict())

        out = {
            'total_deals':     total_deals,
            'total_tcv':       round(total_tcv, 2),
            'total_acv':       round(total_acv, 2),
            'weighted_tcv':    round(weighted, 2),
            'avg_probability': round(avg_prob, 1),
            'ai_deals':        ai_deals,
            'ai_deals_pct':    round(ai_deals / total_deals * 100, 1) if total_deals else 0,
            'by_stage':        {str(k): round(float(v), 0) for k, v in by_stage.items()},
            'by_bu':           {str(k): round(float(v), 0) for k, v in by_bu.items()},
            'by_vertical':     {str(k): round(float(v), 0) for k, v in by_vertical.items()},
            'total_tcv_fmt':   self._fmt(total_tcv),
            'total_acv_fmt':   self._fmt(total_acv),
        }
        logger.success(f"Pipeline KPIs: {total_deals} deals, "
                       f"TCV={self._fmt(total_tcv)}, Prob={avg_prob:.1f}%")
        return out

    def calculate_closed(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Closed Won / Lost deals KPIs."""
        if df is None or df.empty:
            return {}

        status_col  = next((c for c in df.columns
                            if c.lower() == 'status'), None)
        tcv_col     = next((c for c in df.columns
                            if 'TCV' in c and '$' in c and 'HBU' not in c
                            and 'MM' not in c), None)
        acv_col     = next((c for c in df.columns
                            if 'ACV' in c and '$' in c and 'HBU' not in c
                            and 'MM' not in c), None)
        margin_col  = next((c for c in df.columns
                            if 'margin' in c.lower() or 'Margin' in c), None)
        bu_col      = next((c for c in df.columns if c == 'BU'), None)
        qtr_col     = next((c for c in df.columns
                            if 'CloseQTR' in c or 'Quarter' in c
                            or 'Qtr' in c), None)
        type_col    = next((c for c in df.columns
                            if c.lower() in ('type', 'opportunitytype')), None)
        ai_col      = next((c for c in df.columns
                            if 'PROPOSAL_CONTAINS_AI' in c.upper()), None)

        won  = (df[df[status_col].str.contains('Won', case=False, na=False)]
                if status_col else pd.DataFrame())
        lost = (df[df[status_col].str.contains('Lost', case=False, na=False)]
                if status_col else pd.DataFrame())

        total_won  = len(won)
        total_lost = len(lost)
        total_all  = total_won + total_lost
        win_rate   = round(total_won / total_all * 100, 1) if total_all else 0

        won_tcv    = float(won[tcv_col].sum())  if tcv_col and len(won)  else 0
        lost_tcv   = float(lost[tcv_col].sum()) if tcv_col and len(lost) else 0
        avg_margin = float(won[margin_col].mean()) if margin_col and len(won) else 0
        ai_won     = (int((won[ai_col].str.lower() == 'yes').sum())
                      if ai_col and len(won) else 0)

        by_bu_won  = {}
        if bu_col and tcv_col and len(won):
            by_bu_won = (won.groupby(bu_col)[tcv_col].sum()
                         .sort_values(ascending=False)
                         .head(8).round(0).to_dict())

        by_qtr = {}
        if qtr_col and tcv_col:
            by_qtr = (df.groupby(qtr_col)[tcv_col].sum()
                      .sort_values(ascending=False)
                      .head(6).round(0).to_dict())

        by_type = {}
        if type_col and tcv_col and len(won):
            by_type = (won.groupby(type_col)[tcv_col].sum()
                       .sort_values(ascending=False)
                       .head(5).round(0).to_dict())

        out = {
            'total_won':      total_won,
            'total_lost':     total_lost,
            'win_rate':       win_rate,
            'won_tcv':        round(won_tcv, 2),
            'lost_tcv':       round(lost_tcv, 2),
            'avg_margin_pct': round(avg_margin, 1),
            'ai_won_deals':   ai_won,
            'by_bu_won':      {str(k): round(float(v), 0)
                               for k, v in by_bu_won.items()},
            'by_quarter':     {str(k): round(float(v), 0)
                               for k, v in by_qtr.items()},
            'by_type':        {str(k): round(float(v), 0)
                               for k, v in by_type.items()},
            'won_tcv_fmt':    self._fmt(won_tcv),
            'lost_tcv_fmt':   self._fmt(lost_tcv),
        }
        logger.success(f"Closed KPIs: Won={total_won} ({win_rate}% win rate), "
                       f"TCV={self._fmt(won_tcv)}")
        return out

    def _fmt(self, n: float) -> str:
        s = self.sym
        n = abs(float(n))
        if n >= 1e6:
            return f"{s}{n/1e6:.2f}M"
        if n >= 1e3:
            return f"{s}{n/1e3:.0f}K"
        return f"{s}{n:.0f}"
