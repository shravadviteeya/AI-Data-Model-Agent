"""
utils/html_exporter.py
========================
Generates a self-contained CEO-ready HTML report from the full KPI + insights dict.
No external dependencies — pure HTML/CSS/JS inline.
"""
import json
from pathlib import Path
from datetime import datetime

RAG_COLOR = {"GREEN":"#22C55E","AMBER":"#F59E0B","RED":"#EF4444"}

def _fmt(n):
    try:
        n=float(n or 0)
        if n>=1e6: return f"${n/1e6:.2f}M"
        if n>=1e3: return f"${n/1e3:.1f}K"
        return f"${n:.0f}"
    except: return str(n)

def _rag_pill(status):
    c = RAG_COLOR.get(status,"#94A3B8")
    return (f'<span style="background:{c}22;color:{c};padding:2px 10px;'
            f'border-radius:12px;font-size:11px;font-weight:700;'
            f'letter-spacing:.04em">{status}</span>')

def _kpi_card(label, value, sub="", color="#4F8EF7"):
    return (f'<div style="background:{color}18;border:1px solid {color}44;'
            f'border-radius:10px;padding:16px 18px;flex:1;min-width:140px;">'
            f'<div style="font-size:11px;color:#94A3B8;margin-bottom:6px">{label}</div>'
            f'<div style="font-size:22px;font-weight:700;color:{color}">{value}</div>'
            f'<div style="font-size:11px;color:#64748B;margin-top:4px">{sub}</div></div>')

def _bar_table(title, data: dict, color="#4F8EF7", fmt_fn=None, n=10):
    if not data: return ""
    try:
        items = sorted(data.items(), key=lambda x: float(str(x[1])), reverse=True)[:n]
    except:
        items = list(data.items())[:n]
    total = sum(float(str(v) or 0) for _,v in items) or 1
    rows = ""
    for k, v in items:
        try:
            pct = float(str(v))/total*100
            display = fmt_fn(v) if fmt_fn else str(v)
        except:
            pct, display = 0, str(v)
        rows += (f'<tr><td style="padding:7px 12px;color:#E2E8F0;font-size:12px">{str(k)[:40]}</td>'
                 f'<td style="padding:7px 12px;color:{color};font-weight:600;'
                 f'font-size:12px;text-align:right">{display}</td>'
                 f'<td style="padding:7px 12px;width:110px">'
                 f'<div style="background:#1C2438;border-radius:3px;height:5px">'
                 f'<div style="background:{color};width:{min(pct,100):.1f}%;'
                 f'height:5px;border-radius:3px"></div></div></td></tr>')
    return (f'<div style="margin-bottom:20px">'
            f'<div style="font-size:10px;font-weight:700;letter-spacing:.1em;'
            f'color:#64748B;margin-bottom:8px;text-transform:uppercase">{title}</div>'
            f'<table style="width:100%;border-collapse:collapse;background:#131929;'
            f'border-radius:8px;overflow:hidden">{rows}</table></div>')

def export_html(result: dict, output_dir: str) -> str:
    kpis     = result.get("kpis",{})
    insights = result.get("insights",{})
    schema   = result.get("schema",{})
    fin  = kpis.get("finance",{})
    pip  = kpis.get("pipeline",{})
    wf   = kpis.get("workforce",{})
    dem  = kpis.get("demand",{})
    ben  = kpis.get("bench",{})
    ff   = kpis.get("fulfillment",{})
    itg  = kpis.get("integrated",{})
    rag  = insights.get("rag_signals",{})
    sc   = insights.get("health_score",0)
    now  = datetime.now().strftime("%d %b %Y %H:%M")
    sc_col = "#22C55E" if sc>=70 else ("#F59E0B" if sc>=50 else "#EF4444")

    # ── Build sections ────────────────────────────────────────
    # RAG signals
    rag_html = ""
    for sig,(status,desc) in rag.items():
        rag_html += (f'<div style="display:flex;align-items:flex-start;gap:12px;'
                     f'padding:9px 14px;border-bottom:1px solid #263048">'
                     f'{_rag_pill(status)}'
                     f'<div><div style="font-size:12px;font-weight:600;color:#F1F5F9">'
                     f'{sig.replace("_"," ")}</div>'
                     f'<div style="font-size:11px;color:#94A3B8">{desc}</div>'
                     f'</div></div>')

    # Risks
    risk_html = ""
    for r in insights.get("risks",[]):
        c = RAG_COLOR.get(r["status"],"#94A3B8")
        risk_html += (f'<div style="border:1px solid {c}44;border-radius:8px;'
                      f'padding:14px 16px;margin-bottom:10px;background:{c}0a">'
                      f'<div style="display:flex;justify-content:space-between;'
                      f'align-items:center;margin-bottom:5px">'
                      f'<span style="font-weight:700;color:{c};font-size:13px">'
                      f'{r["domain"]}</span>'
                      f'<span style="background:{c}22;color:{c};font-size:10px;'
                      f'padding:2px 8px;border-radius:10px">{r["severity"]}</span></div>'
                      f'<div style="font-size:12px;color:#94A3B8;margin-bottom:5px">'
                      f'{r["description"]}</div>'
                      f'<div style="font-size:11px;color:#64748B;font-style:italic">'
                      f'Action: {r.get("action","")}</div></div>')

    # Actions
    act_html = ""
    for a in insights.get("recommended_actions",[]):
        c = "#EF4444" if a["priority"]=="Critical" else "#F59E0B"
        act_html += (f'<div style="border-left:3px solid {c};padding:10px 14px;'
                     f'margin-bottom:10px;background:#131929;border-radius:0 8px 8px 0">'
                     f'<div style="font-weight:700;color:{c};font-size:13px;margin-bottom:4px">'
                     f'{a["title"]}</div>'
                     f'<div style="font-size:12px;color:#94A3B8;margin-bottom:6px">'
                     f'{a["action"]}</div>'
                     f'<div style="display:flex;gap:16px">'
                     f'<span style="font-size:10px;color:#64748B">Owner: {a.get("owner","—")}</span>'
                     f'<span style="font-size:10px;color:#64748B">When: {a.get("timeline","—")}</span>'
                     f'</div></div>')

    # Opportunities
    opp_html = ""
    for o in insights.get("opportunities",[]):
        pot_c = "#22C55E" if o["potential"]=="HIGH" else "#F59E0B"
        opp_html += (f'<div style="border:1px solid #263048;border-radius:8px;'
                     f'padding:14px 16px;margin-bottom:10px;background:#131929">'
                     f'<div style="display:flex;justify-content:space-between;'
                     f'align-items:center;margin-bottom:5px">'
                     f'<span style="font-weight:700;color:#14B8A6;font-size:13px">'
                     f'◆ {o["title"]}</span>'
                     f'<span style="background:{pot_c}22;color:{pot_c};font-size:10px;'
                     f'padding:2px 8px;border-radius:10px">{o["potential"]}</span></div>'
                     f'<div style="font-size:12px;color:#94A3B8">{o["detail"]}</div>'
                     f'<div style="font-size:10px;color:#64748B;margin-top:5px">'
                     f'Timeline: {o.get("timeline","—")}</div></div>')

    # KPI cards row
    kpi_cards = "".join([
        _kpi_card(h["label"],h["value"],h.get("sub",""),
                  {"blue":"#4F8EF7","green":"#22C55E","amber":"#F59E0B",
                   "red":"#EF4444","purple":"#A78BFA","teal":"#14B8A6",
                   "orange":"#F97316"}.get(h.get("color","blue"),"#4F8EF7"))
        for h in insights.get("kpi_highlights",[])
    ])

    # Data quality table
    schema_rows = "".join([
        f'<tr><td style="padding:6px 12px;color:#E2E8F0;font-size:12px">{k.upper()}</td>'
        f'<td style="padding:6px 12px;color:#4F8EF7;text-align:right;font-size:12px">'
        f'{v.get("rows",0)}</td>'
        f'<td style="padding:6px 12px;color:#94A3B8;text-align:right;font-size:12px">'
        f'{v.get("cols",0)}</td>'
        f'<td style="padding:6px 12px;color:#F59E0B;text-align:right;font-size:12px">'
        f'{v.get("null_pct",0):.1f}%</td></tr>'
        for k,v in schema.items()
    ])

    # Finance breakdowns
    fin_html = (
        _bar_table("Revenue by Geography",    fin.get("by_geo",{}),         "#4F8EF7", _fmt) +
        _bar_table("Top Customers by Revenue",fin.get("by_customer",{}),    "#14B8A6", _fmt) +
        _bar_table("GM% by Geography",        fin.get("gm_by_geo",{}),      "#22C55E",
                   lambda n: f"{float(n):.1f}%")
    )

    pip_html = (
        _bar_table("Pipeline by Stage (TCV)",     pip.get("stage_breakdown_tcv",{}),"#A78BFA",_fmt)+
        _bar_table("Pipeline by Business Unit",   pip.get("by_bu_tcv",{}),          "#4F8EF7",_fmt)+
        _bar_table("Pipeline by Vertical",        pip.get("by_vertical_tcv",{}),    "#14B8A6",_fmt)+
        _bar_table("Pipeline by Product Family",  pip.get("by_product_family_tcv",{}),"#F59E0B",_fmt)
    )

    wf_html = (
        _bar_table("HC by Practice",       wf.get("by_practice",{}),      "#4F8EF7") +
        _bar_table("HC by IBU",            wf.get("by_ibu",{}),           "#14B8A6") +
        _bar_table("HC by Location",       wf.get("by_location",{}),      "#A78BFA") +
        _bar_table("HC by Skill Cluster",  wf.get("by_skill_cluster",{}), "#22C55E")
    )

    dem_html = (
        _bar_table("Demand by Status",         dem.get("by_rr_status",{}),        "#F59E0B") +
        _bar_table("Demand by Practice",       dem.get("by_practice",{}),         "#4F8EF7") +
        _bar_table("Top Skills in Demand",     dem.get("top_skills_demanded",{}), "#14B8A6") +
        _bar_table("Demand by Ageing Range",   dem.get("by_ageing_range",{}),     "#EF4444")
    )

    bench_html = (
        _bar_table("Bench by Pool Type",       ben.get("by_pool_type",{}),        "#F59E0B") +
        _bar_table("Bench by Skill Cluster",   ben.get("by_skill_cluster",{}),    "#14B8A6") +
        _bar_table("Bench by Ageing Category", ben.get("by_ageing_category",{}),  "#EF4444")
    )

    ff_html = (
        _bar_table("Fulfilment by Practice",   ff.get("by_practice",{}),   "#22C55E") +
        _bar_table("Fulfilment by Quarter",    ff.get("by_quarter",{}),    "#4F8EF7") +
        _bar_table("Fulfilment by Skill Group",ff.get("by_skill_group",{}), "#A78BFA")
    )

    # ── Assemble full HTML ─────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>CXO Intelligence Dashboard — {now}</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0;}}
body{{font-family:'Segoe UI',Arial,sans-serif;background:#0B0F19;color:#F1F5F9;line-height:1.5;}}
.wrap{{max-width:1280px;margin:0 auto;padding:28px 20px;}}
.hdr{{background:#131929;border:1px solid #263048;border-radius:14px;
       padding:24px 32px;margin-bottom:24px;
       display:flex;align-items:center;justify-content:space-between;}}
.card{{background:#131929;border:1px solid #263048;border-radius:12px;
       padding:22px 24px;margin-bottom:20px;}}
.card-title{{font-size:10px;font-weight:700;letter-spacing:.12em;
              color:#64748B;text-transform:uppercase;margin-bottom:14px;}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:20px;}}
.grid3{{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;}}
.flex-wrap{{display:flex;flex-wrap:wrap;gap:12px;}}
.section-hdr{{font-size:18px;font-weight:700;color:#E2E8F0;
               border-bottom:1px solid #263048;padding-bottom:10px;
               margin:32px 0 16px;}}
@media(max-width:900px){{.grid2,.grid3{{grid-template-columns:1fr;}}}}
</style>
</head>
<body>
<div class="wrap">

<!-- HEADER -->
<div class="hdr">
 <div>
  <div style="font-size:22px;font-weight:700;color:#4F8EF7;margin-bottom:4px">
   ◈ CXO Intelligence Dashboard</div>
  <div style="font-size:13px;color:#94A3B8">
   IT Services Weekly Analytics · AI-Powered · {now}</div>
 </div>
 <div style="text-align:right">
  <div style="font-size:42px;font-weight:700;color:{sc_col};line-height:1">{sc}</div>
  <div style="font-size:11px;color:#64748B">Business Health / 100</div>
 </div>
</div>

<!-- EXECUTIVE HEADLINE -->
<div class="card">
 <div class="card-title">Executive Headline</div>
 <div style="font-size:16px;font-weight:600;color:#E2E8F0;line-height:1.6">
  {insights.get("executive_headline","")}</div>
</div>

<!-- KPI HIGHLIGHTS -->
<div class="card">
 <div class="card-title">Key Performance Indicators</div>
 <div class="flex-wrap">{kpi_cards}</div>
</div>

<!-- EXECUTIVE NARRATIVE -->
<div class="card">
 <div class="card-title">Executive Narrative (AI-Enhanced)</div>
 <div style="font-size:14px;color:#CBD5E1;line-height:1.75">
  {insights.get("ai_narrative","").replace(chr(10),"<br>")}</div>
</div>

<!-- SIGNALS + ACTIONS -->
<div class="grid2">
 <div class="card">
  <div class="card-title">Business Signals (RAG)</div>
  {rag_html}
 </div>
 <div class="card">
  <div class="card-title">Recommended CEO Actions</div>
  {act_html}
 </div>
</div>

<!-- RISKS + OPPORTUNITIES -->
<div class="grid2">
 <div class="card">
  <div class="card-title">Risk Register</div>
  {risk_html or '<p style="color:#64748B;font-size:13px">No critical risks identified.</p>'}
 </div>
 <div class="card">
  <div class="card-title">Strategic Opportunities</div>
  {opp_html}
 </div>
</div>

<!-- FINANCE -->
<div class="section-hdr">Finance Performance</div>
<div class="grid2">
 <div class="card">
  <div class="card-title">Revenue KPIs</div>
  {_bar_table("Quarterly Revenue",fin.get("quarterly_revenue",{}),
               "#4F8EF7",_fmt,10)}
  {_bar_table("Monthly Revenue (FY26)",fin.get("monthly_revenue",{}),
               "#14B8A6",_fmt,10)}
 </div>
 <div class="card">
  <div class="card-title">Geography & Customer</div>
  {fin_html}
 </div>
</div>

<!-- PIPELINE -->
<div class="section-hdr">Sales Pipeline</div>
<div class="grid2">
 <div>
  <div class="card">
   <div class="card-title">Pipeline Summary</div>
   <div style="display:flex;flex-wrap:wrap;gap:10px">
    {_kpi_card("Total TCV",_fmt(pip.get("total_pipeline_tcv_usd",0)),"","#A78BFA")}
    {_kpi_card("Weighted",_fmt(pip.get("weighted_pipeline_usd",0)),"Prob-adj","#4F8EF7")}
    {_kpi_card("AI Deals",f"{pip.get('ai_deal_pct',0):.0f}%","of pipeline","#22C55E")}
    {_kpi_card("Avg Prob",f"{pip.get('avg_probability_pct',0):.1f}%","","#F59E0B")}
   </div>
  </div>
 </div>
 <div class="card">
  <div class="card-title">Pipeline Breakdowns</div>
  {pip_html}
 </div>
</div>

<!-- WORKFORCE -->
<div class="section-hdr">Workforce & Employee</div>
<div class="grid2">
 <div>
  <div class="card">
   <div class="card-title">Workforce Summary</div>
   <div style="display:flex;flex-wrap:wrap;gap:10px">
    {_kpi_card("Total HC",str(wf.get("total_headcount",0)),"","#4F8EF7")}
    {_kpi_card("Billed",str(wf.get("billed_headcount",0)),"","#22C55E")}
    {_kpi_card("Util%",f"{wf.get('utilisation_pct',0):.1f}%","","#14B8A6")}
    {_kpi_card("Offshore%",f"{wf.get('offshore_pct',0):.1f}%","","#A78BFA")}
   </div>
  </div>
 </div>
 <div class="card">
  <div class="card-title">Workforce Breakdowns</div>
  {wf_html}
 </div>
</div>

<!-- DEMAND + BENCH -->
<div class="section-hdr">Talent — Demand & Bench</div>
<div class="grid2">
 <div class="card">
  <div class="card-title">Demand (Resource Requisitions)</div>
  {dem_html}
 </div>
 <div class="card">
  <div class="card-title">Bench Pool</div>
  {bench_html}
 </div>
</div>

<!-- FULFILLMENT -->
<div class="section-hdr">YTD Fulfillment</div>
<div class="grid2">
 <div>
  <div class="card">
   <div class="card-title">Fulfillment Summary</div>
   <div style="display:flex;flex-wrap:wrap;gap:10px">
    {_kpi_card("YTD Filled",str(ff.get("ytd_total_filled",0)),"","#22C55E")}
    {_kpi_card("Avg FFTP",f"{ff.get('avg_fftp_days',0):.0f}d","","#14B8A6")}
    {_kpi_card("Internal%",f"{ff.get('internal_pct',0):.0f}%","","#4F8EF7")}
   </div>
  </div>
 </div>
 <div class="card">
  <div class="card-title">Fulfillment Breakdowns</div>
  {ff_html}
 </div>
</div>

<!-- DATA QUALITY -->
<div class="section-hdr">Data Quality — Source Tables</div>
<div class="card">
 <div class="card-title">Table Summary</div>
 <table style="width:100%;border-collapse:collapse">
  <thead>
   <tr>
    <th style="text-align:left;padding:8px 12px;color:#64748B;font-size:11px;border-bottom:1px solid #263048">Table</th>
    <th style="text-align:right;padding:8px 12px;color:#64748B;font-size:11px;border-bottom:1px solid #263048">Rows</th>
    <th style="text-align:right;padding:8px 12px;color:#64748B;font-size:11px;border-bottom:1px solid #263048">Columns</th>
    <th style="text-align:right;padding:8px 12px;color:#64748B;font-size:11px;border-bottom:1px solid #263048">Null %</th>
   </tr>
  </thead>
  <tbody>{schema_rows}</tbody>
 </table>
</div>

<!-- FOOTER -->
<div style="text-align:center;padding:20px;font-size:11px;color:#475569;
             border-top:1px solid #263048;margin-top:24px">
 Generated by IT Company CXO Intelligence Dashboard &bull;
 AI-Powered Weekly Analytics &bull; {now}
</div>

</div>
</body>
</html>"""

    ts   = datetime.now().strftime("%Y%m%d_%H%M")
    path = Path(output_dir) / f"cxo_report_{ts}.html"
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    path.write_text(html, encoding="utf-8")
    print(f"  [Export] HTML report: {path}")
    return str(path)
