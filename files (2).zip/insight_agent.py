"""
agents/insight_agent.py
========================
AI Reasoning Engine for CXO Dashboard

Three reasoning layers:
  1. Rule-based RAG signals  — deterministic, always works
  2. Structured narrative     — template-driven intelligence
  3. LLM narrative (optional) — Claude/GPT if API key present

Output: complete insights dict with RAG, risks, opps, actions, narrative
"""
import os, json
from datetime import datetime

RAG = {"GREEN":"GREEN","AMBER":"AMBER","RED":"RED"}

def _fmt(n):
    n=float(n or 0)
    if n>=1e6: return f"${n/1e6:.2f}M"
    if n>=1e3: return f"${n/1e3:.1f}K"
    return f"${n:.0f}"

def _llm(prompt):
    """Try Anthropic then OpenAI. Return None if neither available."""
    try:
        import anthropic
        key = os.getenv("ANTHROPIC_API_KEY","")
        if key:
            c = anthropic.Anthropic(api_key=key)
            r = c.messages.create(model="claude-sonnet-4-5",max_tokens=1000,
                                  messages=[{"role":"user","content":prompt}])
            return r.content[0].text
    except: pass
    try:
        from openai import OpenAI
        key = os.getenv("OPENAI_API_KEY","")
        if key:
            c = OpenAI(api_key=key)
            r = c.chat.completions.create(
                model="gpt-4o", max_tokens=1000,
                messages=[{"role":"system","content":"You are a senior analyst briefing the CEO of an IT company."},
                           {"role":"user","content":prompt}])
            return r.choices[0].message.content
    except: pass
    return None


class InsightAgent:
    """Generates CXO-level insights from computed KPIs."""

    def __init__(self, kpis: dict):
        self.k   = kpis
        self.fin = kpis.get("finance",     {})
        self.pip = kpis.get("pipeline",    {})
        self.wf  = kpis.get("workforce",   {})
        self.dem = kpis.get("demand",      {})
        self.ben = kpis.get("bench",       {})
        self.ff  = kpis.get("fulfillment", {})
        self.itg = kpis.get("integrated",  {})

    def generate_all(self) -> dict:
        rag       = self._rag_signals()
        narrative = self._rule_narrative(rag)
        ai_narr   = self._ai_narrative(rag) or narrative

        return {
            "health_score":       self.itg.get("health_score", 0),
            "executive_headline": self._headline(rag),
            "executive_summary":  narrative,
            "ai_narrative":       ai_narr,
            "rag_signals":        rag,
            "kpi_highlights":     self._highlights(),
            "risks":              self._risks(rag),
            "opportunities":      self._opportunities(),
            "recommended_actions":self._actions(rag),
            "domain_commentary":  self._domain_commentary(),
            "generated_at":       datetime.now().strftime("%d %b %Y %H:%M"),
        }

    # ── RAG SIGNALS ───────────────────────────────────────────
    def _rag_signals(self) -> dict:
        """
        Deterministic Red/Amber/Green per business domain.
        Each signal has (STATUS, short description).
        """
        signals = {}

        # ── Finance: Gross Margin % ───────────────────────────
        gm = self.fin.get("ytd_gm_pct", 0) or 0
        rev= self.fin.get("ytd_revenue_usd", 0) or 0
        if gm >= 30:
            signals["Gross_Margin"] = ("GREEN", f"GM {gm:.1f}% — healthy margin performance")
        elif gm >= 20:
            signals["Gross_Margin"] = ("AMBER", f"GM {gm:.1f}% — watch margin compression")
        elif gm > 0:
            signals["Gross_Margin"] = ("RED",   f"GM {gm:.1f}% — below minimum threshold of 20%")
        else:
            signals["Gross_Margin"] = ("AMBER", "Gross Margin data pending — check Finance Tracker")

        # ── Pipeline Coverage ────────────────────────────────
        tcv = self.pip.get("total_pipeline_tcv_usd", 0) or 0
        cov = self.itg.get("pipeline_to_revenue_ratio", 0) or 0
        if cov >= 3:
            signals["Pipeline_Coverage"] = ("GREEN", f"Pipeline {cov:.1f}× revenue — strong coverage")
        elif cov >= 1.5:
            signals["Pipeline_Coverage"] = ("AMBER", f"Pipeline {cov:.1f}× revenue — needs building")
        else:
            signals["Pipeline_Coverage"] = ("RED",   f"Pipeline {cov:.1f}× revenue — critical gap")

        # ── AI Pipeline Mix ──────────────────────────────────
        ai_pct = self.pip.get("ai_deal_pct", 0) or 0
        if ai_pct >= 30:
            signals["AI_Pipeline"] = ("GREEN", f"{ai_pct:.0f}% AI deals — strong differentiation")
        elif ai_pct >= 15:
            signals["AI_Pipeline"] = ("AMBER", f"{ai_pct:.0f}% AI deals — below market expectation")
        else:
            signals["AI_Pipeline"] = ("RED",   f"{ai_pct:.0f}% AI deals — urgently needs uplift")

        # ── Workforce Utilisation ────────────────────────────
        util = self.wf.get("utilisation_pct", 0) or 0
        if util >= 85:
            signals["Utilisation"] = ("GREEN", f"Utilisation {util:.1f}% — excellent billability")
        elif util >= 75:
            signals["Utilisation"] = ("AMBER", f"Utilisation {util:.1f}% — acceptable but improve")
        else:
            signals["Utilisation"] = ("RED",   f"Utilisation {util:.1f}% — revenue leakage risk")

        # ── Demand vs Bench ──────────────────────────────────
        open_p = self.dem.get("total_open_positions", 0) or 0
        b_tot  = self.ben.get("total_bench", 0) or 0
        ratio  = open_p / max(b_tot, 1)
        if ratio <= 1.5:
            signals["Demand_Bench_Balance"] = ("GREEN",
                f"{open_p} open demands vs {b_tot} bench — balanced")
        elif ratio <= 3:
            signals["Demand_Bench_Balance"] = ("AMBER",
                f"{open_p} demands vs {b_tot} bench — watch the gap")
        else:
            signals["Demand_Bench_Balance"] = ("RED",
                f"{open_p} demands vs {b_tot} bench — critical talent shortage")

        # ── Hiring Speed (FFTP) ──────────────────────────────
        fftp = self.dem.get("avg_fftp_days", 0) or 0
        if 0 < fftp <= 15:
            signals["Hiring_Speed"] = ("GREEN", f"Avg FFTP {fftp:.0f} days — fast fulfilment")
        elif fftp <= 30:
            signals["Hiring_Speed"] = ("AMBER", f"Avg FFTP {fftp:.0f} days — room to improve")
        elif fftp > 30:
            signals["Hiring_Speed"] = ("RED",   f"Avg FFTP {fftp:.0f} days — slow hiring cycle")
        else:
            signals["Hiring_Speed"] = ("GREEN", "FFTP data pending")

        # ── Bench Aging ──────────────────────────────────────
        aging = self.ben.get("by_ageing_category", {})
        aged  = sum(v for k,v in aging.items()
                    if any(x in str(k) for x in ["30","45","60","> 30","31-"]))
        if aged == 0:
            signals["Bench_Aging"] = ("GREEN", "No bench resources aged >30 days")
        elif aged <= 2:
            signals["Bench_Aging"] = ("AMBER", f"{aged} bench resources aged >30 days")
        else:
            signals["Bench_Aging"] = ("RED",   f"{aged} bench resources aged >30 days — cost risk")

        return signals

    # ── KPI HIGHLIGHTS ────────────────────────────────────────
    def _highlights(self) -> list:
        """12 top-line KPI cards for the overview tab."""
        return [
            {"label":"YTD Revenue",        "value":self.fin.get("revenue_display","—"),
             "sub":"FY2026 Accrued",        "color":"blue"},
            {"label":"Gross Margin %",      "value":self.fin.get("gm_display","—"),
             "sub":"YTD Average",           "color":"green"
             if (self.fin.get("ytd_gm_pct",0) or 0)>=25 else "red"},
            {"label":"Total Pipeline TCV",  "value":self.pip.get("tcv_display","—"),
             "sub":"Salesforce",            "color":"purple"},
            {"label":"Weighted Pipeline",   "value":self.pip.get("weighted_display","—"),
             "sub":"Probability-adjusted",  "color":"teal"},
            {"label":"Total Headcount",     "value":str(self.wf.get("total_headcount",0)),
             "sub":"Employee Master",       "color":"blue"},
            {"label":"Utilisation",         "value":f"{self.wf.get('utilisation_pct',0):.1f}%",
             "sub":"Billed / Total HC",     "color":"green"
             if (self.wf.get("utilisation_pct",0) or 0)>=80 else "amber"},
            {"label":"Open Demands",        "value":str(self.dem.get("total_open_positions",0)),
             "sub":"Active RRs",            "color":"orange"},
            {"label":"Bench Pool",          "value":str(self.ben.get("total_bench",0)),
             "sub":"Resources in pool",     "color":"amber"},
            {"label":"YTD Joiners",         "value":str(self.ff.get("ytd_total_filled",0)),
             "sub":"Fulfilled positions",   "color":"teal"},
            {"label":"Avg FFTP",            "value":f"{self.dem.get('avg_fftp_days',0):.0f}d",
             "sub":"Demand fulfilment",     "color":"green"
             if (self.dem.get("avg_fftp_days",0) or 0)<=20 else "red"},
            {"label":"AI-Enabled Deals",    "value":f"{self.pip.get('ai_deal_pct',0):.0f}%",
             "sub":"of total pipeline",     "color":"purple"},
            {"label":"Pipeline / Revenue",  "value":f"{self.itg.get('pipeline_to_revenue_ratio',0):.1f}×",
             "sub":"Coverage ratio",        "color":"blue"},
        ]

    # ── RULE-BASED NARRATIVE ──────────────────────────────────
    def _headline(self, rag: dict) -> str:
        reds  = [k for k,(s,_) in rag.items() if s=="RED"]
        greens= [k for k,(s,_) in rag.items() if s=="GREEN"]
        hs    = self.itg.get("health_score",0)
        if hs >= 70:
            return "Business is performing strongly across key dimensions — maintain momentum."
        elif reds:
            top = reds[0].replace("_"," ")
            return (f"Business health at {hs}/100 — {top} requires "
                    f"immediate leadership attention this week.")
        return f"Business is stable with selective improvement areas. Health score: {hs}/100."

    def _rule_narrative(self, rag: dict) -> str:
        fin = self.fin; pip = self.pip; wf = self.wf
        dem = self.dem; ben = self.ben; ff = self.ff
        rev   = fin.get("ytd_revenue_usd",0)   or 0
        gm    = fin.get("ytd_gm_pct",0)        or 0
        tcv   = pip.get("total_pipeline_tcv_usd",0) or 0
        wtd   = pip.get("weighted_pipeline_usd",0)  or 0
        ai_p  = pip.get("ai_deal_pct",0)        or 0
        hc    = wf.get("total_headcount",0)     or 0
        util  = wf.get("utilisation_pct",0)     or 0
        open_p= dem.get("total_open_positions",0) or 0
        btot  = ben.get("total_bench",0)         or 0
        joined= ff.get("ytd_total_filled",0)     or 0
        fftp  = dem.get("avg_fftp_days",0)       or 0

        reds  = [k.replace("_"," ") for k,(s,_) in rag.items() if s=="RED"]
        ambers= [k.replace("_"," ") for k,(s,_) in rag.items() if s=="AMBER"]

        lines = []
        lines.append(
            f"YTD revenue stands at {_fmt(rev)} with gross margin at {gm:.1f}%. "
            f"The total sales pipeline is {_fmt(tcv)} with a probability-weighted value "
            f"of {_fmt(wtd)}. AI-enabled deals represent {ai_p:.0f}% of the pipeline, "
            f"reflecting the market shift towards AI-led IT services.")
        lines.append(
            f"Workforce strength is {hc} employees with {util:.1f}% utilisation. "
            f"Talent acquisition has fulfilled {joined} positions year-to-date with "
            f"an average demand fulfilment time of {fftp:.0f} days. "
            f"Open resource requisitions stand at {open_p} against a bench pool of {btot}.")
        if reds:
            lines.append(
                f"Critical attention required on: {', '.join(reds)}. "
                f"These are rated RED and require immediate executive intervention.")
        if ambers:
            lines.append(
                f"Monitored areas (AMBER status): {', '.join(ambers)}. "
                f"Proactive management can prevent escalation to RED.")
        return " ".join(lines)

    # ── LLM NARRATIVE ────────────────────────────────────────
    def _ai_narrative(self, rag: dict):
        prompt = f"""You are a senior analyst presenting to the CEO of Coforge, an IT services company.
Write a precise 4-paragraph executive briefing (max 220 words) based on this week's data:

FINANCIAL: Revenue {_fmt(self.fin.get('ytd_revenue_usd',0))}, GM% {self.fin.get('ytd_gm_pct',0):.1f}%
PIPELINE: TCV {_fmt(self.pip.get('total_pipeline_tcv_usd',0))}, Weighted {_fmt(self.pip.get('weighted_pipeline_usd',0))}, AI deals {self.pip.get('ai_deal_pct',0):.0f}%
WORKFORCE: {self.wf.get('total_headcount',0)} HC, {self.wf.get('utilisation_pct',0):.1f}% utilised
TALENT: {self.dem.get('total_open_positions',0)} open demands, {self.ben.get('total_bench',0)} bench, FFTP {self.dem.get('avg_fftp_days',0):.0f}d
RAG: {json.dumps({k:s for k,(s,_) in rag.items()})}

Write direct, data-led, no fluff. Paragraph 4: top 2 actions CEO should take this week."""
        return _llm(prompt)

    # ── RISK REGISTER ─────────────────────────────────────────
    def _risks(self, rag: dict) -> list:
        risks = []
        color_sev = {"RED":"High","AMBER":"Medium","GREEN":"Low"}
        action_map = {
            "Gross_Margin":          "Review top 5 low-margin accounts; initiate rate revision & offshore shift.",
            "Pipeline_Coverage":     "Convene pipeline war room; add 40%+ qualified pipeline within 30 days.",
            "AI_Pipeline":           "Embed AI propositions in all active pursuits; train account executives.",
            "Utilisation":           "Deploy bench against open demands; target 85% utilisation by month-end.",
            "Demand_Bench_Balance":  "Activate external recruitment for top 10 critical RRs immediately.",
            "Hiring_Speed":          "Streamline interview loops; target FFTP < 15 days for critical demands.",
            "Bench_Aging":           "Escalate bench resources >30 days to practice heads for placement.",
        }
        for signal, (status, desc) in rag.items():
            if status in ("RED","AMBER"):
                risks.append({
                    "severity":    color_sev[status],
                    "domain":      signal.replace("_"," "),
                    "description": desc,
                    "status":      status,
                    "action":      action_map.get(signal, "Review with relevant department head."),
                })
        return sorted(risks, key=lambda x: 0 if x["severity"]=="High" else 1)

    # ── OPPORTUNITIES ────────────────────────────────────────
    def _opportunities(self) -> list:
        opps = []
        ai_pct = self.pip.get("ai_deal_pct",0) or 0
        if ai_pct < 40:
            opps.append({
                "title": "AI Deal Acceleration",
                "detail": (f"Only {ai_pct:.0f}% of pipeline is AI-enabled. "
                           f"IT buyers are mandating AI components in 70%+ of new contracts. "
                           f"Dedicated AI pursuit teams and CoE solution accelerators "
                           f"can increase win rates by 15–20%."),
                "potential":"HIGH", "timeline":"30–60 days"})

        open_p = self.dem.get("total_open_positions",0) or 0
        btot   = self.ben.get("total_bench",0) or 0
        if btot > 0 and open_p > 0:
            opps.append({
                "title": "Internal Bench Deployment",
                "detail": (f"{btot} bench resources are available against {open_p} open demands. "
                           f"Faster internal placement reduces cost-to-hire by 60% and "
                           f"improves margin by deploying bench on billable projects."),
                "potential":"HIGH", "timeline":"This week"})

        by_geo = self.fin.get("by_geo",{})
        if by_geo:
            top_geo = max(by_geo, key=lambda k: float(by_geo[k] or 0))
            opps.append({
                "title": f"{top_geo} Market Expansion",
                "detail": (f"{top_geo} leads revenue contribution. "
                           f"Deepening existing account penetration and adding 2–3 new logos "
                           f"in this region represents the highest near-term growth potential."),
                "potential":"MEDIUM", "timeline":"Q2 target"})

        gm_pct = self.fin.get("ytd_gm_pct",0) or 0
        if 0 < gm_pct < 30:
            opps.append({
                "title": "Margin Improvement Programme",
                "detail": (f"Current GM at {gm_pct:.1f}%. A structured programme targeting "
                           f"pyramid optimisation, offshore mix improvement and rate revision "
                           f"at renewal could add 3–5 margin points within 2 quarters."),
                "potential":"MEDIUM", "timeline":"Q review"})

        util = self.wf.get("utilisation_pct",0) or 0
        if util < 85:
            opps.append({
                "title": "Utilisation Revenue Unlock",
                "detail": (f"Moving utilisation from {util:.1f}% to 85% across {self.wf.get('total_headcount',0)} HC "
                           f"directly converts unbilled time to revenue without adding headcount."),
                "potential":"HIGH", "timeline":"30 days"})
        return opps

    # ── RECOMMENDED ACTIONS ───────────────────────────────────
    def _actions(self, rag: dict) -> list:
        actions_map = {
            "Pipeline_Coverage": {
                "title":"Pipeline Sprint (War Room)",
                "action":("Call weekly pipeline review for all deals > $500K. "
                          "Assign C-level sponsors to top 5 opportunities. "
                          "Target: add 2× current TCV in 30 days."),
                "owner":"CRO / Sales Head", "timeline":"This week"},
            "Utilisation": {
                "title":"Utilisation Drive",
                "action":("Map all unbilled resources to open demands. "
                          "Create a daily dashboard tracking billed vs unbilled. "
                          "Target 85% by month-end."),
                "owner":"Delivery Head / RM", "timeline":"Immediate"},
            "Demand_Bench_Balance": {
                "title":"Talent Gap Resolution",
                "action":("Activate external sourcing for top 10 critical RRs. "
                          "Initiate bench positioning for skill-matched resources. "
                          "Daily TA-RM sync required."),
                "owner":"HR / TA Head", "timeline":"Immediate"},
            "Hiring_Speed": {
                "title":"FFTP Acceleration",
                "action":("Reduce interview rounds. Pre-screen bench for top demand skills. "
                          "Target FFTP < 15 days for critical band 3–5 demands."),
                "owner":"TA Manager", "timeline":"30 days"},
            "Gross_Margin": {
                "title":"Margin Recovery Plan",
                "action":("Audit bottom-5 margin accounts. Initiate rate revision. "
                          "Propose offshore mix improvement to clients. "
                          "Track weekly at CFO level."),
                "owner":"CFO + Account Heads", "timeline":"Q review"},
            "AI_Pipeline": {
                "title":"AI Proposition Uplift",
                "action":("Mandate AI section in all new proposals. "
                          "Run 2-day AI solutions workshop for account executives. "
                          "Deploy pre-built AI assets from CoE in active bids."),
                "owner":"Pre-Sales / CoE Head", "timeline":"30 days"},
            "Bench_Aging": {
                "title":"Bench Deployment Campaign",
                "action":("Daily review of bench resources > 20 days in pool. "
                          "Practice heads to identify placement options. "
                          "Escalate un-placed resources > 30 days to CEO review."),
                "owner":"Resource Management", "timeline":"This week"},
        }
        actions = []
        for signal, (status, _) in rag.items():
            if signal in actions_map:
                a = dict(actions_map[signal])
                a["priority"] = "Critical" if status=="RED" else "High"
                a["status"]   = status
                actions.append(a)
        return actions

    # ── DOMAIN COMMENTARY ────────────────────────────────────
    def _domain_commentary(self) -> dict:
        """Short 2-line commentary per domain for tab headers."""
        gm  = self.fin.get("ytd_gm_pct",0) or 0
        rev = self.fin.get("ytd_revenue_usd",0) or 0
        tcv = self.pip.get("total_pipeline_tcv_usd",0) or 0
        hc  = self.wf.get("total_headcount",0) or 0
        return {
            "finance":     (f"YTD Revenue: {_fmt(rev)} | GM: {gm:.1f}% | "
                           f"Q1→Q3 trend visible in quarterly breakdown below."),
            "pipeline":    (f"Total TCV: {_fmt(tcv)} | "
                           f"{self.pip.get('total_opportunities',0)} opportunities across "
                           f"{len(self.pip.get('by_bu_tcv',{}))} Business Units."),
            "workforce":   (f"{hc} employees | "
                           f"{self.wf.get('utilisation_pct',0):.1f}% billed | "
                           f"{self.wf.get('offshore_pct',0):.1f}% offshore."),
            "demand":      (f"{self.dem.get('total_open_positions',0)} open RRs | "
                           f"Avg ageing {self.dem.get('avg_ageing_ta',0):.0f}d TA | "
                           f"Fill rate {self.dem.get('fill_rate_pct',0):.1f}%."),
            "bench":       (f"{self.ben.get('total_bench',0)} in pool | "
                           f"{self.ben.get('available_count',0)} available | "
                           f"Avg {self.ben.get('avg_days_in_rp',0):.1f} days in RP."),
            "fulfillment": (f"{self.ff.get('ytd_total_filled',0)} filled YTD | "
                           f"Avg FFTP {self.ff.get('avg_fftp_days',0):.0f} days | "
                           f"{self.ff.get('internal_pct',0):.0f}% internal hires."),
        }
