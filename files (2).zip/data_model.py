"""
core/data_model.py  — Excel Parsing + Data Cleaning + KPI Computation
"""
import pandas as pd
import numpy as np
import re
import warnings
from datetime import datetime

warnings.filterwarnings("ignore")

SHEETS = {
    "finance":     "FINANCE TRACKER",
    "employee":    "EMPLOYEE MASTER",
    "salesforce":  "SALESFORCE DATA",
    "demand":      "DEMAND DATA",
    "bench":       "BENCH DATA",
    "fulfillment": "YTD FULFILLMENT DATA",
}

PERIOD_ORDER = [
    "Apr25","May25","Jun25","Q12026",
    "Jul25","Aug25","Sep25","Q22026",
    "Oct25","Nov25","Dec25","Q32026",
    "Jan26","Feb26","Mar26","Q42026","FY2026"
]

NULL_STRINGS = {"nan","none","na","n/a","null","#n/a","",".","-","--"}

# ── helpers ───────────────────────────────────────────────────
def _sum(df, col):
    if col in df.columns:
        return float(pd.to_numeric(df[col], errors="coerce").fillna(0).sum())
    return 0.0

def _mean(df, col):
    if col in df.columns:
        v = pd.to_numeric(df[col], errors="coerce")
        return float(v.mean()) if v.notna().any() else 0.0
    return 0.0

def _vcounts(df, col, n=10):
    if col in df.columns:
        return df[col].dropna().astype(str).value_counts().head(n).to_dict()
    return {}

def _groupsum(df, gcol, vcol, n=10):
    if gcol in df.columns and vcol in df.columns:
        g = df.groupby(gcol, observed=True)[vcol].apply(
            lambda s: pd.to_numeric(s, errors="coerce").sum()
        ).sort_values(ascending=False)
        return {str(k): round(float(v),2) for k,v in g.head(n).items()}
    return {}

def _fmt(n):
    n=float(n or 0)
    if n>=1e6: return f"${n/1e6:.2f}M"
    if n>=1e3: return f"${n/1e3:.1f}K"
    return f"${n:.0f}"

def _replace_nulls(df):
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].apply(
            lambda x: None if str(x).strip().lower() in NULL_STRINGS else x)
    return df

# ══════════════════════════════════════════════════════════════
# EXCEL PARSER
# ══════════════════════════════════════════════════════════════
class ExcelParser:
    def __init__(self, fp):
        self.fp = fp
        self.errors = []

    def parse_all(self):
        out = {}
        for key, sheet in SHEETS.items():
            try:
                fn = getattr(self, f"_p_{key}", self._p_generic)
                df = fn(sheet)
                out[key] = df
                print(f"  [Parse] {sheet}: {len(df)} rows × {len(df.columns)} cols")
            except Exception as e:
                self.errors.append(f"{sheet}: {e}")
                print(f"  [Parse] ERROR {sheet}: {e}")
                out[key] = pd.DataFrame()
        return out

    def _p_finance(self, sheet):
        raw = pd.read_excel(self.fp, sheet_name=sheet, header=None)
        if len(raw) < 6:
            return pd.DataFrame()
        measure_row = raw.iloc[2].values
        period_row  = raw.iloc[3].values
        data_rows   = raw.iloc[5:]
        col_meta = {}
        for ci in range(3, len(raw.columns)):
            m = str(measure_row[ci]).strip() if ci < len(measure_row) else ""
            p = str(period_row[ci]).strip()  if ci < len(period_row)  else ""
            if m not in ("nan","None","") and p not in ("nan","None",""):
                col_meta[ci] = (m, p)
        records = []
        for _, row in data_rows.iterrows():
            geo  = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
            cc   = str(row.iloc[1]).strip() if pd.notna(row.iloc[1]) else ""
            cust = str(row.iloc[2]).strip() if pd.notna(row.iloc[2]) else ""
            if geo in ("nan","None","") and cust in ("nan","None",""):
                continue
            for ci, (measure, period) in col_meta.items():
                val = row.iloc[ci]
                try: val_f = float(val)
                except: continue
                if pd.isna(val_f): continue
                records.append({"Geo": geo, "Cost_Center": cc, "Customer": cust,
                                 "Measure": measure, "Period": period,
                                 "Value_USD": round(val_f, 4)})
        df = pd.DataFrame(records)
        if not df.empty:
            df["Period_Order"] = df["Period"].apply(
                lambda x: PERIOD_ORDER.index(x) if x in PERIOD_ORDER else 99)
        return df

    def _p_employee(self, sheet):
        df = pd.read_excel(self.fp, sheet_name=sheet)
        df.columns = [str(c).strip().replace("\n"," ").replace("  "," ") for c in df.columns]
        return df

    def _p_salesforce(self, sheet):
        date_cols = ["ProjectStartDate","ProjectEndDate","EstCloseDate","Createddate"]
        df = pd.read_excel(self.fp, sheet_name=sheet)
        for c in date_cols:
            if c in df.columns:
                df[c] = pd.to_datetime(df[c], errors="coerce")
        return df

    def _p_demand(self, sheet):
        date_cols = ["Required By Date","Created On","Bill Start Date",
                     "RDG Last Received Date","TA Last Received Date"]
        df = pd.read_excel(self.fp, sheet_name=sheet)
        for c in date_cols:
            if c in df.columns:
                df[c] = pd.to_datetime(df[c], errors="coerce")
        return df

    def _p_bench(self, sheet):
        df = pd.read_excel(self.fp, sheet_name=sheet)
        if "Pool Start Date" in df.columns:
            df["Pool Start Date"] = pd.to_datetime(df["Pool Start Date"], errors="coerce")
        return df

    def _p_fulfillment(self, sheet):
        df = pd.read_excel(self.fp, sheet_name=sheet)
        for c in ["Joining Date","Offer Date","Created On"]:
            if c in df.columns:
                df[c] = pd.to_datetime(df[c], errors="coerce")
        drop = [c for c in df.columns if str(c).startswith("Unnamed:")]
        return df.drop(columns=drop, errors="ignore")

    def _p_generic(self, sheet):
        return pd.read_excel(self.fp, sheet_name=sheet)


# ══════════════════════════════════════════════════════════════
# DATA CLEANER
# ══════════════════════════════════════════════════════════════
class DataCleaner:
    def clean_all(self, parsed):
        cleaned = {}
        for key, df in parsed.items():
            if df.empty:
                cleaned[key] = df; continue
            try:
                df = df.dropna(how="all").reset_index(drop=True)
                df = df.loc[:, df.notna().any()]
                df = _replace_nulls(df)
                fn = getattr(self, f"_c_{key}", None)
                if fn: df = fn(df)
                cleaned[key] = df
                null_pct = df.isnull().mean().mean()*100
                print(f"  [Clean] {key}: {len(df)} rows, {null_pct:.1f}% null")
            except Exception as e:
                print(f"  [Clean] ERROR {key}: {e}")
                cleaned[key] = df
        return cleaned

    def _num(self, df, cols):
        for c in cols:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        return df

    def _title(self, df, cols):
        for c in cols:
            if c in df.columns:
                df[c] = df[c].astype(str).str.strip().str.title()
                df[c] = df[c].replace({s.title(): None for s in NULL_STRINGS})
        return df

    def _c_finance(self, df):
        df["Value_USD"] = pd.to_numeric(df["Value_USD"], errors="coerce")
        df = df.dropna(subset=["Value_USD"])
        df["Geo"] = df["Geo"].str.title().str.strip()
        # GM% may be stored as 0–1 decimal; convert to %
        mask = df["Measure"] == "Gross Margin %"
        if mask.any() and df.loc[mask,"Value_USD"].abs().max() < 1.5:
            df.loc[mask,"Value_USD"] = (df.loc[mask,"Value_USD"]*100).round(2)
        def ptype(p):
            if re.match(r"Q\d\d{4}",str(p)): return "Quarter"
            if re.match(r"FY\d{4}",str(p)):  return "Full_Year"
            return "Month"
        df["Period_Type"] = df["Period"].apply(ptype)
        return df

    def _c_employee(self, df):
        df = self._num(df, ["Employee No","Role Band","Designation Level"])
        df = self._title(df, ["Onsite/Offshore","Gender","Status","Billed/Unbilled",
                               "Employee Type","Geo","Location","IBU","Sub IBU",
                               "Skill Cluster","Emp Practice ","IT / BPS HC"])
        if "Date of Joining" in df.columns:
            df["Date of Joining"] = pd.to_datetime(df["Date of Joining"],
                                                    errors="coerce", dayfirst=True)
            df["Tenure_Years"] = ((datetime.now()-df["Date of Joining"]).dt.days/365.25).round(1)
        if "Billed/Unbilled" in df.columns:
            df["Is_Billed"] = df["Billed/Unbilled"].astype(str).str.lower().str.contains("bill")
        if "Onsite/Offshore" in df.columns:
            df["Is_Offshore"] = df["Onsite/Offshore"].astype(str).str.lower().str.contains("offshore")
        return df

    def _c_salesforce(self, df):
        money = ["TCV($)","ACV($)","HBU_TCV($)","HBU_ACV($)",
                 "OpportunityValue(USD)","TotalPrice(USD)",
                 "EN_NN_HBU_TCV($)","EXISTING_NEW_NN($)","RENEWAL_EE($)"]
        df = self._num(df, money+["Probability(%)","DaysInStage"])
        if "PROPOSAL_CONTAINS_AI" in df.columns:
            df["AI_Deal"] = df["PROPOSAL_CONTAINS_AI"].astype(str)\
                              .str.upper().str.strip().isin(["YES","TRUE","1","Y"])
        else:
            df["AI_Deal"] = False
        if "OpportunityStatus" in df.columns:
            df["Is_Open"] = df["OpportunityStatus"].astype(str).str.lower().str.contains("open")
        df = self._title(df, ["BU","VERTICAL","SubBu","BIDTYPE"])
        return df

    def _c_demand(self, df):
        int_cols = ["Open Position","Requested Positions","WIP","Offered",
                    "Joined Market","Joined Internal","Total CV Positioned",
                    "FFTP","Bill Rate","Ageing (RDG  Recvd DATE)","Ageing (TA Recvd DATE)"]
        df = self._num(df, int_cols)
        df = self._title(df, ["RR Status","Status Category","Actual Status",
                               "Employee Practice","Skill Category","BU",
                               "Offshore / Onsite","Geography Desc"])
        if "Ageing Range" in df.columns:
            df["Ageing Range"] = df["Ageing Range"].astype(str).str.strip()
        if "Ageing (TA Recvd DATE)" in df.columns:
            df["Is_Aged_30Plus"] = pd.to_numeric(
                df["Ageing (TA Recvd DATE)"], errors="coerce") > 30
        return df

    def _c_bench(self, df):
        df = self._num(df, ["Employee No","Role Band","No. of Days in RP"])
        df = self._title(df, ["Pool Type","Status","Emp Practise","Skill Cluster"])
        if "Pool Start Date" in df.columns:
            df["Days_On_Bench"] = (datetime.now()-df["Pool Start Date"]).dt.days.clip(lower=0)
        if "Status" in df.columns:
            df["Is_Available"] = df["Status"].astype(str).str.lower().str.contains("avail")
        if "Ageing (Days)" in df.columns:
            df["Ageing_Cat"] = df["Ageing (Days)"].astype(str).str.strip()
        return df

    def _c_fulfillment(self, df):
        df = self._num(df, ["Fulfilment Days","FFTP","Requested Positions"])
        df = self._title(df, ["Employee Practice","Employee Group Practice",
                               "Offshore / Onsite","Skill Group","Employee Type"])
        if "Joining Date" in df.columns:
            df["Join_Month"] = df["Joining Date"].dt.strftime("%b'%y")
        if "Employee Type" in df.columns:
            df["Is_Internal"] = df["Employee Type"].astype(str).str.lower().str.contains("internal")
        return df


# ══════════════════════════════════════════════════════════════
# KPI ENGINE
# ══════════════════════════════════════════════════════════════
class KPIEngine:
    def __init__(self, tables):
        self.t   = tables
        self.fin = tables.get("finance",     pd.DataFrame())
        self.emp = tables.get("employee",    pd.DataFrame())
        self.sf  = tables.get("salesforce",  pd.DataFrame())
        self.dem = tables.get("demand",      pd.DataFrame())
        self.ben = tables.get("bench",       pd.DataFrame())
        self.ful = tables.get("fulfillment", pd.DataFrame())

    def compute_all(self):
        k = {
            "finance":     self._finance(),
            "pipeline":    self._pipeline(),
            "workforce":   self._workforce(),
            "demand":      self._demand(),
            "bench":       self._bench(),
            "fulfillment": self._fulfillment(),
            "metadata":    {"computed_at": datetime.now().isoformat(),
                            "rows": {k2:len(v) for k2,v in self.t.items()}}
        }
        k["integrated"] = self._integrated(k)
        return k

    def _pval(self, measure_kw, period):
        df = self.fin
        if df.empty: return 0.0
        mask = (df["Measure"].str.contains(measure_kw, case=False, na=False) &
                (df["Period"] == period))
        return float(df.loc[mask,"Value_USD"].sum())

    # ── Finance KPIs ─────────────────────────────────────────
    def _finance(self):
        df = self.fin
        if df.empty: return {}
        pv = self._pval

        rev_fy = pv("Total Accrued Revenue","FY2026")
        exp_fy = pv("Total Direct Expenses","FY2026")
        gm_fy  = pv("Gross Margin %","FY2026")

        rev_df = df[df["Measure"].str.contains("Total Accrued Revenue",case=False,na=False)
                    & (df["Period"]=="FY2026")]
        by_geo  = _groupsum(rev_df,"Geo","Value_USD")
        by_cust = _groupsum(rev_df,"Customer","Value_USD")
        gm_df   = df[df["Measure"].str.contains("Gross Margin",case=False,na=False)
                    & (df["Period"]=="FY2026")]
        gm_geo  = {str(k):round(float(v),2) for k,v in
                   gm_df.groupby("Geo")["Value_USD"].mean().items()} if not gm_df.empty else {}

        # Monthly trend: Jan, Feb, Mar 26
        monthly = {}
        for mo in ["Jan26","Feb26","Mar26"]:
            monthly[mo] = pv("Total Accrued Revenue", mo)

        # Quarterly trend
        quarterly = {q: pv("Total Accrued Revenue", q)
                     for q in ["Q12026","Q22026","Q32026","Q42026"]}
        gm_quarterly = {q: pv("Gross Margin %", q)
                        for q in ["Q12026","Q22026","Q32026"]}

        return {
            "ytd_revenue_usd":   rev_fy,
            "ytd_expenses_usd":  exp_fy,
            "ytd_gm_usd":        rev_fy - exp_fy,
            "ytd_gm_pct":        gm_fy,
            "q1_revenue":        pv("Total Accrued Revenue","Q12026"),
            "q2_revenue":        pv("Total Accrued Revenue","Q22026"),
            "q3_revenue":        pv("Total Accrued Revenue","Q32026"),
            "q4_revenue":        pv("Total Accrued Revenue","Q42026"),
            "q1_gm_pct":         pv("Gross Margin %","Q12026"),
            "q2_gm_pct":         pv("Gross Margin %","Q22026"),
            "q3_gm_pct":         pv("Gross Margin %","Q32026"),
            "q1_expense":        pv("Total Direct Expenses","Q12026"),
            "monthly_revenue":   monthly,
            "quarterly_revenue": quarterly,
            "quarterly_gm_pct":  gm_quarterly,
            "by_geo":            by_geo,
            "by_customer":       by_cust,
            "gm_by_geo":         gm_geo,
            "revenue_display":   _fmt(rev_fy),
            "gm_display":        f"{gm_fy:.1f}%",
        }

    # ── Pipeline KPIs ─────────────────────────────────────────
    def _pipeline(self):
        df = self.sf
        if df.empty: return {}
        total = len(df)
        tcv   = _sum(df,"TCV($)")
        acv   = _sum(df,"ACV($)")
        hbu_t = _sum(df,"HBU_TCV($)")
        # Weighted pipeline
        if "TCV($)" in df.columns and "Probability(%)" in df.columns:
            wtd = float((pd.to_numeric(df["TCV($)"],errors="coerce").fillna(0) *
                         pd.to_numeric(df["Probability(%)"],errors="coerce").fillna(0)/100).sum())
        else: wtd = 0.0
        avg_prob = _mean(df,"Probability(%)")
        open_cnt = int(df.get("Is_Open",pd.Series([False]*total)).sum())
        ai_cnt   = int(df.get("AI_Deal",pd.Series([False]*total)).sum())
        ai_pct   = round(ai_cnt/max(total,1)*100,1)
        return {
            "total_opportunities":       total,
            "open_opportunities":        open_cnt,
            "total_pipeline_tcv_usd":    tcv,
            "total_pipeline_acv_usd":    acv,
            "hbu_tcv_usd":               hbu_t,
            "weighted_pipeline_usd":     round(wtd,2),
            "avg_probability_pct":       round(avg_prob,1),
            "ai_enabled_deals":          ai_cnt,
            "ai_deal_pct":               ai_pct,
            "new_business_usd":          _sum(df,"EN_NN_HBU_TCV($)"),
            "existing_nn_usd":           _sum(df,"EXISTING_NEW_NN($)"),
            "renewal_usd":               _sum(df,"RENEWAL_EE($)"),
            "stage_breakdown_tcv":       _groupsum(df,"STAGE","TCV($)"),
            "by_bu_tcv":                 _groupsum(df,"BU","TCV($)"),
            "by_vertical_tcv":           _groupsum(df,"VERTICAL","TCV($)"),
            "by_product_family_tcv":     _groupsum(df,"ProductFamily(Practice)","TCV($)"),
            "bid_type_split":            _vcounts(df,"BIDTYPE",8),
            "tcv_display":               _fmt(tcv),
            "weighted_display":          _fmt(wtd),
        }

    # ── Workforce KPIs ────────────────────────────────────────
    def _workforce(self):
        df = self.emp
        if df.empty: return {}
        total    = len(df)
        billed   = int(df.get("Is_Billed",pd.Series([False]*total)).sum())
        offshore = int(df.get("Is_Offshore",pd.Series([False]*total)).sum())
        util_pct = round(billed/max(total,1)*100,1)
        off_pct  = round(offshore/max(total,1)*100,1)
        avg_ten  = round(_mean(df,"Tenure_Years"),1) if "Tenure_Years" in df.columns else 0.0
        band_dist = {}
        if "Role Band" in df.columns:
            band_dist = {str(k):int(v) for k,v in
                         df["Role Band"].value_counts().sort_index().items()}
        return {
            "total_headcount":    total,
            "billed_headcount":   billed,
            "unbilled_headcount": total-billed,
            "utilisation_pct":    util_pct,
            "offshore_count":     offshore,
            "onsite_count":       total-offshore,
            "offshore_pct":       off_pct,
            "avg_tenure_years":   avg_ten,
            "by_practice":        _vcounts(df,"Emp Practice ",10),
            "by_ibu":             _vcounts(df,"IBU",10),
            "by_band":            band_dist,
            "by_geo":             _vcounts(df,"Geo",10),
            "by_location":        _vcounts(df,"Location",10),
            "by_skill_cluster":   _vcounts(df,"Skill Cluster",10),
            "by_status":          _vcounts(df,"Status",8),
            "by_gender":          _vcounts(df,"Gender",5),
            "by_employee_type":   _vcounts(df,"Employee Type",5),
            "by_designation":     _vcounts(df,"Designation",10),
        }

    # ── Demand KPIs ───────────────────────────────────────────
    def _demand(self):
        df = self.dem
        if df.empty: return {}
        req_pos   = _sum(df,"Requested Positions")
        open_pos  = _sum(df,"Open Position")
        offered   = _sum(df,"Offered")
        wip       = _sum(df,"WIP")
        jmkt      = _sum(df,"Joined Market")
        jint      = _sum(df,"Joined Internal")
        total_join= jmkt + jint
        fill_rate = round(total_join/max(req_pos,1)*100,1)
        aged_30   = int(df.get("Is_Aged_30Plus",pd.Series([False]*len(df))).sum())
        return {
            "total_rr_count":       len(df),
            "total_open_positions": int(open_pos),
            "total_requested":      int(req_pos),
            "wip_positions":        int(wip),
            "offered_positions":    int(offered),
            "joined_market":        int(jmkt),
            "joined_internal":      int(jint),
            "total_joined":         int(total_join),
            "fill_rate_pct":        fill_rate,
            "avg_fftp_days":        round(_mean(df,"FFTP"),1),
            "avg_ageing_rdg":       round(_mean(df,"Ageing (RDG  Recvd DATE)"),1),
            "avg_ageing_ta":        round(_mean(df,"Ageing (TA Recvd DATE)"),1),
            "aged_demands_30plus":  aged_30,
            "by_rr_status":         _vcounts(df,"RR Status",10),
            "by_practice":          _vcounts(df,"Employee Practice",10),
            "by_ibu":               _vcounts(df,"IBU",10),
            "by_ageing_range":      _vcounts(df,"Ageing Range",8),
            "top_skills_demanded":  _vcounts(df,"Primary Skills",15),
            "by_offshore_onsite":   _vcounts(df,"Offshore / Onsite",4),
            "by_demand_category":   _vcounts(df,"Demand category ",6),
        }

    # ── Bench KPIs ────────────────────────────────────────────
    def _bench(self):
        df = self.ben
        if df.empty: return {}
        total     = len(df)
        available = int(df.get("Is_Available",pd.Series([False]*total)).sum())
        positioned= int(
            df["Status"].astype(str).str.lower().str.contains("position|finali").sum()
            if "Status" in df.columns else 0)
        return {
            "total_bench":          total,
            "available_count":      available,
            "positioned_count":     positioned,
            "bench_available_pct":  round(available/max(total,1)*100,1),
            "avg_days_in_rp":       round(_mean(df,"No. of Days in RP"),1),
            "by_pool_type":         _vcounts(df,"Pool Type",8),
            "by_practice":          _vcounts(df,"Emp Practise",8),
            "by_skill_cluster":     _vcounts(df,"Skill Cluster",10),
            "by_status":            _vcounts(df,"Status",8),
            "by_ageing_category":   _vcounts(df,"Ageing_Cat",8),
            "by_role_band":         _vcounts(df,"Role Band",8),
        }

    # ── Fulfillment KPIs ─────────────────────────────────────
    def _fulfillment(self):
        df = self.ful
        if df.empty: return {}
        total    = len(df)
        internal = int(df.get("Is_Internal",pd.Series([False]*total)).sum())
        return {
            "ytd_total_filled":     total,
            "avg_fulfillment_days": round(_mean(df,"Fulfilment Days"),1),
            "avg_fftp_days":        round(_mean(df,"FFTP"),1),
            "internal_hires":       internal,
            "external_hires":       total-internal,
            "internal_pct":         round(internal/max(total,1)*100,1),
            "by_practice":          _vcounts(df,"Employee Practice",10),
            "by_bu":                _vcounts(df,"BU",10),
            "by_quarter":           _vcounts(df,"Quarter",8),
            "by_month":             _vcounts(df,"Join_Month",12),
            "by_skill_group":       _vcounts(df,"Skill Group",10),
            "by_offshore_onsite":   _vcounts(df,"Offshore / Onsite",4),
        }

    # ── Integrated KPIs ───────────────────────────────────────
    def _integrated(self, k):
        fin = k.get("finance",{});    pip = k.get("pipeline",{})
        wf  = k.get("workforce",{});  dem = k.get("demand",{})
        ben = k.get("bench",{});      ff  = k.get("fulfillment",{})
        rev    = fin.get("ytd_revenue_usd",0)
        tcv    = pip.get("total_pipeline_tcv_usd",0)
        hc     = wf.get("total_headcount",1)
        util   = wf.get("utilisation_pct",0)
        gm_pct = fin.get("ytd_gm_pct",0)
        ai_pct = pip.get("ai_deal_pct",0)
        open_p = dem.get("total_open_positions",0)
        b_tot  = ben.get("total_bench",1)
        fftp   = dem.get("avg_fftp_days",0)
        pipe_cov   = round(tcv/max(rev,1),2) if rev>0 else 0
        dmnd_bench = round(open_p/max(b_tot,1),2)
        bench_pct  = round(b_tot/max(hc,1)*100,1)
        rev_per_hc = round(rev/max(hc,1),2)

        def risk(val,low,high,rev=False):
            if rev: return "HIGH" if val>high else ("MEDIUM" if val>low else "LOW")
            return "LOW" if val>high else ("MEDIUM" if val>low else "HIGH")

        score = min(100,max(0,int(
            (util/100*25) +
            (min(gm_pct,40)/40*25) +
            (min(pipe_cov,4)/4*25) +
            (max(0,1-dmnd_bench/4)*25)
        )))
        return {
            "revenue_per_head_usd":      rev_per_hc,
            "pipeline_to_revenue_ratio": pipe_cov,
            "demand_to_bench_ratio":     dmnd_bench,
            "bench_to_hc_pct":           bench_pct,
            "workforce_utilisation_pct": util,
            "ytd_gm_pct":                gm_pct,
            "ai_pipeline_pct":           ai_pct,
            "avg_demand_fftp_days":      fftp,
            "pipeline_risk":             risk(pipe_cov,1.5,3.0),
            "demand_risk":               risk(dmnd_bench,1.0,2.0,rev=True),
            "bench_risk":                risk(bench_pct,5.0,15.0,rev=True),
            "utilisation_risk":          risk(util,75.0,85.0),
            "margin_risk":               risk(gm_pct,20.0,30.0),
            "hiring_risk":               risk(fftp,0,20,rev=True),
            "health_score":              score,
        }


# ── PUBLIC API ────────────────────────────────────────────────
def build_model(file_path: str) -> dict:
    print(f"\n[DataModel] ═══ build_model starting ═══")
    print(f"[DataModel] File: {file_path}")
    parser  = ExcelParser(file_path)
    parsed  = parser.parse_all()
    cleaner = DataCleaner()
    cleaned = cleaner.clean_all(parsed)
    engine  = KPIEngine(cleaned)
    kpis    = engine.compute_all()
    schema  = {k: {"rows":len(v),"cols":len(v.columns),
                   "null_pct":round(v.isnull().mean().mean()*100,1) if not v.empty else 0}
               for k,v in cleaned.items()}
    print(f"[DataModel] Health Score: {kpis['integrated'].get('health_score',0)}/100")
    return {"kpis":kpis, "tables":cleaned, "schema":schema, "errors":parser.errors}
