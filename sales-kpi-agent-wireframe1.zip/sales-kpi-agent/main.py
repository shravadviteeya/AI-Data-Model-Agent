"""
╔══════════════════════════════════════════════════════════════╗
║   Sales KPI Intelligence Agent — Wireframe 1                ║
║   LangChain + Excel + AI → KPI Dashboard + Exec Summary     ║
╚══════════════════════════════════════════════════════════════╝

Usage:
    python main.py --demo                        # run with sample data
    python main.py --file data/sales.xlsx        # run with your file
    python main.py --file data/sales.xlsx --email
    python main.py --schedule                    # run on schedule
"""

import os
import sys
import click
import webbrowser
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
from loguru import logger

load_dotenv()

# ── Configure rich logging ────────────────────────────────────
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:HH:mm:ss}</green> | <level>{level:<8}</level> | {message}",
    level="INFO",
    colorize=True
)


def print_banner():
    banner = """
╔══════════════════════════════════════════════════════╗
║        🤖  SALES KPI INTELLIGENCE AGENT              ║
║           Wireframe 1 · LangChain Edition            ║
╚══════════════════════════════════════════════════════╝
"""
    click.echo(click.style(banner, fg='cyan'))


def run_agent(file_path: str, send_email: bool = False) -> dict:
    """Run the complete KPI analysis pipeline."""
    from core.excel_analyzer import ExcelAnalyzer
    from core.kpi_calculator import KPICalculator
    from core.insight_engine import InsightEngine
    from agents.base_agent import AgentFactory
    from utils.dashboard_builder import DashboardBuilder
    from utils.report_builder import ReportBuilder
    from utils.email_sender import EmailSender

    import yaml
    cfg = yaml.safe_load(open("config.yaml"))

    output_dir = Path(os.getenv("OUTPUT_DIR", "./output"))
    output_dir.mkdir(exist_ok=True)

    logger.info("═" * 52)
    logger.info("  Starting Sales KPI Agent")
    logger.info(f"  File   : {file_path}")
    logger.info(f"  Company: {cfg['company']['name']}")
    logger.info("═" * 52)

    # ── STEP 1: Load Excel ────────────────────────────────────
    logger.info("\n📂 STEP 1 — Loading Excel data...")
    analyzer = ExcelAnalyzer(cfg)
    data = analyzer.load(file_path)
    logger.success(f"   Loaded {data['row_count']} rows × {data['col_count']} columns")

    # ── STEP 2: Calculate KPIs ────────────────────────────────
    logger.info("\n📊 STEP 2 — Calculating KPIs...")
    calculator = KPICalculator(cfg)
    kpis = calculator.calculate_all(data['df'])
    logger.success(f"   Revenue: {cfg['dashboard']['currency_symbol']}{kpis['summary']['total_revenue']:,.0f}")
    logger.success(f"   GM%:     {kpis['summary']['avg_gm_pct']:.1f}%")
    logger.success(f"   Win Rate:{kpis['summary']['avg_win_rate']:.1f}%")

    # ── STEP 3: AI Agent Analysis ─────────────────────────────
    logger.info(f"\n🧠 STEP 3 — AI Analysis ({os.getenv('AI_PROVIDER','auto')})...")
    agent = AgentFactory.create(os.getenv("AI_PROVIDER", "auto"))
    logger.success(f"   Using: {agent.name}")

    ai_results = {
        "schema_insights": agent.analyze_schema(data['schema']),
        "relationships": agent.detect_relationships(data['tables']),
        "column_descriptions": {
            col: agent.generate_description({"name": col, "dtype": dtype,
                "table_name": "sales", "sample_values": []})
            for col, dtype in list(data['schema'].items())[:10]
        }
    }

    # ── STEP 4: Generate Insights ─────────────────────────────
    logger.info("\n🔍 STEP 4 — Generating insights & risk register...")
    engine = InsightEngine(cfg)
    insights = engine.generate(kpis, ai_results)
    logger.success(f"   Health Score: {insights['health_score']}/100")
    logger.success(f"   Risks found: {len(insights['risks'])}")

    # ── STEP 5: Build Dashboard ───────────────────────────────
    logger.info("\n🎨 STEP 5 — Building KPI dashboard...")
    builder = DashboardBuilder(cfg)
    dashboard_path = output_dir / "kpi_dashboard.html"
    builder.build(kpis, insights, str(dashboard_path))
    logger.success(f"   Dashboard: {dashboard_path}")

    # ── STEP 6: Build Executive Summary ──────────────────────
    logger.info("\n📄 STEP 6 — Building executive summary...")
    report_builder = ReportBuilder(cfg)
    summary_path = output_dir / "executive_summary.html"
    report_builder.build(kpis, insights, str(summary_path))
    logger.success(f"   Summary:   {summary_path}")

    # ── STEP 7: Send Email (optional) ────────────────────────
    if send_email:
        logger.info("\n📧 STEP 7 — Sending email to leadership...")
        sender = EmailSender()
        sender.send(kpis, insights)

    # ── Done ─────────────────────────────────────────────────
    logger.info("\n" + "═" * 52)
    logger.success("  ✅ AGENT COMPLETE!")
    logger.info(f"  📁 Output: {output_dir.absolute()}")
    logger.info("═" * 52)

    result = {
        "kpis": kpis,
        "insights": insights,
        "dashboard_path": str(dashboard_path),
        "summary_path": str(summary_path)
    }

    # Auto-open browser
    if os.getenv("OPEN_BROWSER", "true").lower() == "true":
        webbrowser.open(f"file://{dashboard_path.absolute()}")

    return result


def generate_sample_data():
    """Generate sample Excel file for demo."""
    import pandas as pd
    import numpy as np

    np.random.seed(42)
    months = [
        'Jan-2025','Feb-2025','Mar-2025','Apr-2025','May-2025','Jun-2025',
        'Jul-2025','Aug-2025','Sep-2025','Oct-2025','Nov-2025','Dec-2025',
        'Jan-2026','Feb-2026','Mar-2026'
    ]
    regions  = ['North','South','East','West','Central']
    products = ['Product A','Product B','Product C','Product D','Product E']
    owners   = ['Raj Kumar','Priya Sharma','Amit Singh','Neha Verma',
                'Vikram Patel','Sunita Joshi','Deepak Gupta','Anita Rao']

    rows = []
    for _ in range(300):
        rev  = np.random.randint(50000, 800000)
        cost = rev * np.random.uniform(0.45, 0.70)
        gm   = rev - cost
        rows.append({
            'Month':        np.random.choice(months),
            'Region':       np.random.choice(regions),
            'Product':      np.random.choice(products),
            'Sales_Owner':  np.random.choice(owners),
            'Revenue':      round(rev),
            'Cost':         round(cost),
            'Gross_Margin': round(gm),
            'GM_Pct':       round((gm / rev) * 100, 2),
            'Deals_Closed': np.random.randint(1, 15),
            'BE_Revenue':   round(rev * np.random.uniform(0.85, 1.20)),
            'Pipeline_Value': round(rev * np.random.uniform(2, 5)),
            'Win_Rate':     round(np.random.uniform(25, 65), 1)
        })

    path = Path("data/sample/sales_sample.xlsx")
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_excel(path, index=False)
    logger.success(f"Sample data created: {path}")
    return str(path)


# ── CLI ───────────────────────────────────────────────────────
@click.command()
@click.option("--file",     "-f", default=None,    help="Path to Excel file")
@click.option("--demo",     "-d", is_flag=True,     help="Run with sample data")
@click.option("--email",    "-e", is_flag=True,     help="Send email to leadership")
@click.option("--schedule", "-s", is_flag=True,     help="Run on recurring schedule")
@click.option("--provider", "-p", default="auto",
              type=click.Choice(["auto","anthropic","openai","gemini","copilot"]),
              help="AI provider to use")
def main(file, demo, email, schedule, provider):
    """🤖 Sales KPI Intelligence Agent — Wireframe 1"""
    print_banner()

    if provider != "auto":
        os.environ["AI_PROVIDER"] = provider

    if schedule:
        import schedule as sched
        import time
        import yaml
        cfg = yaml.safe_load(open("config.yaml"))
        run_time = cfg["email"]["send_time"]
        logger.info(f"📅 Scheduled: Every {cfg['email']['send_day']} at {run_time}")
        sched.every().monday.at(run_time).do(
            lambda: run_agent(file or generate_sample_data(), email))
        while True:
            sched.run_pending()
            time.sleep(60)
        return

    if demo:
        logger.info("🎮 Demo mode — generating sample data...")
        file = generate_sample_data()

    if not file:
        click.echo(click.style(
            "\n❌  No file specified.\n"
            "   Use --demo for sample data\n"
            "   Use --file path/to/your.xlsx for your data\n",
            fg='red'
        ))
        sys.exit(1)

    if not Path(file).exists():
        click.echo(click.style(f"\n❌  File not found: {file}\n", fg='red'))
        sys.exit(1)

    run_agent(file, send_email=email)


if __name__ == "__main__":
    main()
