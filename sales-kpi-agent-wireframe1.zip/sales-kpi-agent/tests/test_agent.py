"""
Tests for Sales KPI Agent
Run: pytest tests/ -v
"""
import pytest
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


class TestFallbackAgent:
    def setup_method(self):
        from agents.fallback_agent import FallbackAgent
        self.agent = FallbackAgent()

    def test_is_available(self):
        assert self.agent.is_available() is True

    def test_generate_description_id(self):
        desc = self.agent.generate_description({"name": "customer_id", "table_name": "sales"})
        assert "identifier" in desc.lower() or "id" in desc.lower()

    def test_analyze_schema(self):
        schema = {"sales": ["id", "revenue", "cost"]}
        result = self.agent.analyze_schema(schema)
        assert "primary_keys" in result


class TestKPICalculator:
    def setup_method(self):
        import pandas as pd
        import yaml
        from core.kpi_calculator import KPICalculator
        cfg = yaml.safe_load(open("config.yaml"))
        self.calc = KPICalculator(cfg)
        self.df = pd.DataFrame({
            "revenue": [100000, 200000, 150000],
            "cost":    [60000, 110000, 80000],
            "gross_margin": [40000, 90000, 70000],
            "gm_pct": [40.0, 45.0, 46.7],
            "win_rate": [40.0, 50.0, 45.0],
            "deals_closed": [5, 8, 6],
            "be_revenue": [110000, 190000, 160000],
            "pipeline_value": [300000, 500000, 400000],
        })

    def test_summary_revenue(self):
        result = self.calc._summary(self.df)
        assert result["total_revenue"] == 450000

    def test_summary_gm_pct(self):
        result = self.calc._summary(self.df)
        assert result["avg_gm_pct"] > 0

    def test_summary_win_rate(self):
        result = self.calc._summary(self.df)
        assert result["avg_win_rate"] == pytest.approx(45.0, 0.1)


class TestInsightEngine:
    def setup_method(self):
        import yaml
        from core.insight_engine import InsightEngine
        cfg = yaml.safe_load(open("config.yaml"))
        self.engine = InsightEngine(cfg)

    def test_health_score_good(self):
        s = {"revenue_vs_be_pct": 105, "avg_gm_pct": 42, "avg_win_rate": 45, "pipeline_coverage": 3.5}
        score = self.engine._health_score(s)
        assert score >= 80

    def test_health_score_poor(self):
        s = {"revenue_vs_be_pct": 85, "avg_gm_pct": 22, "avg_win_rate": 25, "pipeline_coverage": 1.5}
        score = self.engine._health_score(s)
        assert score < 60

    def test_findings_not_empty(self):
        kpis = {"summary": {"revenue_vs_be_pct": 97, "avg_gm_pct": 41, "avg_win_rate": 43, "pipeline_coverage": 2.8, "total_revenue": 12000000, "revenue_variance": -300000}, "product": [{"product": "A", "revenue_share_pct": 30}, {"product": "B", "revenue_share_pct": 15}], "owner": [{"sales_owner": "Raj", "revenue": 2000000}]}
        findings = self.engine._findings(kpis["summary"], kpis)
        assert len(findings) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
