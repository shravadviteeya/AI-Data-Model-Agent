# 🤖 Sales KPI Intelligence Agent — Wireframe 1

> LangChain-powered Excel analytics agent that generates an interactive KPI dashboard with executive summary, risk register, and AI-driven recommendations.

---

## 📸 What It Does

```
Excel Files (Salesforce + Finance + BE)
            ↓
   LangChain Agent (7 Tools)
            ↓
  Interactive KPI Dashboard (HTML)
            ↓
  Executive Summary + Risk Report
            ↓
  Auto-Email to Leadership (optional)
```

---

## 🚀 Quick Start (5 minutes)

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/sales-kpi-agent.git
cd sales-kpi-agent

# 2. Setup environment
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure
cp .env.example .env
# Edit .env — add your AI API key (optional)

# 5. Run with sample data
python main.py --demo

# 6. Run with your own Excel file
python main.py --file data/your_file.xlsx
```

Dashboard opens automatically at: `output/kpi_dashboard.html`

---

## 📁 Project Structure

```
sales-kpi-agent/
│
├── main.py                      ← Entry point
├── requirements.txt             ← All Python dependencies
├── .env.example                 ← Environment template
├── config.yaml                  ← All customization settings
├── README.md
│
├── agents/
│   ├── __init__.py
│   ├── base_agent.py            ← Abstract agent interface
│   ├── anthropic_agent.py       ← Claude (Anthropic)
│   ├── openai_agent.py          ← GPT-4 (OpenAI)
│   ├── gemini_agent.py          ← Gemini (Google)
│   ├── copilot_agent.py         ← GitHub Copilot
│   └── fallback_agent.py        ← No API key needed
│
├── core/
│   ├── __init__.py
│   ├── excel_analyzer.py        ← Load & parse Excel files
│   ├── kpi_calculator.py        ← All KPI calculations
│   ├── relationship_detector.py ← Auto-detect table joins
│   └── insight_engine.py        ← Risk & recommendation logic
│
├── utils/
│   ├── __init__.py
│   ├── dashboard_builder.py     ← HTML dashboard generator
│   ├── report_builder.py        ← Executive summary builder
│   ├── email_sender.py          ← Email report to leadership
│   └── chart_data.py            ← Chart data preparation
│
├── templates/
│   ├── dashboard.html           ← KPI dashboard template
│   ├── executive_summary.html   ← Executive summary template
│   └── email_report.html        ← Email HTML template
│
├── data/
│   └── sample/
│       └── sales_sample.xlsx    ← Sample data to test with
│
├── output/                      ← Generated files (git-ignored)
│
├── tests/
│   ├── test_analyzer.py
│   ├── test_kpis.py
│   └── test_agents.py
│
└── docs/
    ├── CUSTOMIZATION.md         ← How to customize (Wireframe 2+)
    ├── API_KEYS.md              ← How to get API keys
    └── COLUMN_MAPPING.md        ← Map your Excel columns
```

---

## 🔑 AI Provider Setup

You need ONE of these (agent works without any key using rule-based logic):

| Provider | Environment Variable | Get Key |
|----------|---------------------|---------|
| Anthropic Claude | `ANTHROPIC_API_KEY` | console.anthropic.com |
| OpenAI GPT-4 | `OPENAI_API_KEY` | platform.openai.com |
| Google Gemini | `GEMINI_API_KEY` | makersuite.google.com |
| GitHub Copilot | `GITHUB_TOKEN` | github.com/settings/tokens |

---

## 📊 Supported Excel Columns

The agent auto-detects these column names (case-insensitive):

| Category | Column Names Detected |
|----------|-----------------------|
| Revenue | `Revenue`, `Sales`, `Amount`, `Rev` |
| Cost | `Cost`, `COGS`, `Expense` |
| Margin | `GM`, `Gross_Margin`, `Margin` |
| Date | `Month`, `Date`, `Period` |
| Region | `Region`, `Territory`, `Area` |
| Product | `Product`, `SKU`, `Item`, `Service` |
| Owner | `Sales_Owner`, `Rep`, `Owner`, `Salesperson` |
| Budget | `BE_Revenue`, `Budget`, `Target`, `Forecast` |
| Pipeline | `Pipeline`, `Pipeline_Value` |
| Win Rate | `Win_Rate`, `Win%`, `Conversion` |

---

## ⚙️ Customization (config.yaml)

```yaml
# Customize everything in config.yaml
company:
  name: "Your Company Name"
  logo: "assets/logo.png"          # optional

dashboard:
  theme: "dark"                     # dark | light | custom
  primary_color: "#185FA5"
  accent_color:  "#3B6D11"
  currency: "INR"                   # INR | USD | EUR | GBP
  currency_symbol: "₹"

kpis:
  gm_healthy_threshold: 35          # % — below this = red
  win_rate_good: 40                 # % — above this = green
  pipeline_coverage_min: 3.0        # x — below this = amber

email:
  enabled: false
  smtp_server: "smtp.office365.com"
  recipients:
    - "ceo@company.com"
    - "vp_sales@company.com"

agent:
  provider: "auto"                  # auto | anthropic | openai | gemini | copilot
  model: "claude-sonnet-4-5"
```

---

## 📧 Email Report Setup

```bash
# In .env file:
EMAIL_SENDER=you@company.com
EMAIL_PASSWORD=your_app_password
LEADERSHIP_EMAILS=ceo@co.com,vp@co.com

# Run with email
python main.py --file data/sales.xlsx --email
```

---

## 🔄 Wireframe Roadmap

| Version | Status | Features |
|---------|--------|----------|
| **Wireframe 1** (this) | ✅ Current | KPI Dashboard + Executive Summary + Risk Register |
| Wireframe 2 | 🔜 Planned | Multi-file merge, Salesforce live sync |
| Wireframe 3 | 🔜 Planned | Power BI export, scheduled auto-reports |
| Wireframe 4 | 🔜 Planned | Conversational Q&A over your data |

---

## 🤝 Contributing

PRs welcome! See `docs/CONTRIBUTING.md`.

---

## 📜 License

MIT — free for personal and commercial use.
