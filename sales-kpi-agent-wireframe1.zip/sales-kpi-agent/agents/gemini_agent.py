import os, json
from agents.base_agent import BaseAgent
from loguru import logger

class GeminiAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.name = "GeminiAgent (Google)"
        self.client = None
        if self.is_available():
            try:
                import google.generativeai as genai
                genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
                self.client = genai.GenerativeModel(os.getenv("GEMINI_MODEL", "gemini-pro"))
                logger.success("   Gemini agent ready")
            except ImportError:
                logger.warning("   google-generativeai not installed")

    def is_available(self):
        return bool(os.getenv("GEMINI_API_KEY"))

    def _call(self, prompt):
        return self.client.generate_content(prompt).text

    def analyze_schema(self, schema):
        try:
            r = self._call(self._build_schema_prompt(schema))
            s, e = r.find('{'), r.rfind('}') + 1
            return json.loads(r[s:e])
        except:
            return {}

    def detect_relationships(self, tables):
        return []

    def generate_description(self, col_info):
        try:
            return self._call(f"1-sentence description for column '{col_info.get('name')}'. Return description only.").strip()
        except:
            return f"Column {col_info.get('name')}"
