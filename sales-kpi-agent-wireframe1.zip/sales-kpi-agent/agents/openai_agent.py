import os, json
from agents.base_agent import BaseAgent
from loguru import logger

class OpenAIAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.name   = "OpenAIAgent (GPT-4)"
        self.client = None
        if self.is_available():
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
                self.model  = os.getenv("OPENAI_MODEL", "gpt-4o")
                logger.success("   OpenAI agent ready")
            except ImportError:
                logger.warning("   openai package not installed: pip install openai")

    def is_available(self):
        return bool(os.getenv("OPENAI_API_KEY"))

    def _call(self, prompt, max_tokens=1000):
        r = self.client.chat.completions.create(
            model=self.model, max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": "You are an expert data architect."},
                {"role": "user",   "content": prompt}
            ]
        )
        return r.choices[0].message.content

    def analyze_schema(self, schema):
        try:
            r = self._call(self._build_schema_prompt(schema))
            return json.loads(r)
        except:
            return {}

    def detect_relationships(self, tables):
        try:
            p = f"Detect relationships between: {[t['name'] for t in tables]}. Return JSON array."
            r = self._call(p)
            s, e = r.find('['), r.rfind(']') + 1
            return json.loads(r[s:e])
        except:
            return []

    def generate_description(self, col_info):
        try:
            return self._call(
                f"1-sentence description for column '{col_info.get('name')}'. Return only description.", 100
            ).strip()
        except:
            return f"Column {col_info.get('name')}"
