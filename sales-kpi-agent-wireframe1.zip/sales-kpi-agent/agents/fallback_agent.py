import re
from agents.base_agent import BaseAgent
from loguru import logger

class FallbackAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.name = "FallbackAgent (Rule-Based)"
        logger.info("   Rule-based agent active — add API key for AI insights")
    def is_available(self): return True
    def analyze_schema(self, schema):
        pks = {}
        for t, cols in schema.items():
            col_names = cols if isinstance(cols, list) else list(cols.keys())
            pk = next((c for c in col_names if re.search(r"(^id$|_id$)",str(c),re.I)), col_names[0] if col_names else "id")
            pks[t] = pk
        return {"primary_keys": pks, "relationships": []}
    def detect_relationships(self, tables): return []
    def generate_description(self, col_info):
        n = col_info.get("name","")
        t = col_info.get("table_name","")
        if re.search(r"(^id$|_id)", n, re.I): return f"Unique identifier for {t}."
        if re.search(r"revenue|sales", n, re.I): return f"Revenue amount for {t}."
        if re.search(r"cost", n, re.I): return f"Cost amount for {t}."
        if re.search(r"margin|gm", n, re.I): return f"Gross margin for {t}."
        return f"Column {n} in {t}."
