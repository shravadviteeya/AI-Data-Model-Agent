from abc import ABC, abstractmethod
import os, json, re
from loguru import logger

class BaseAgent(ABC):
    def __init__(self): self.name = "BaseAgent"
    @abstractmethod
    def analyze_schema(self, schema): pass
    @abstractmethod
    def detect_relationships(self, tables): pass
    @abstractmethod
    def generate_description(self, col_info): pass
    @abstractmethod
    def is_available(self): pass
    def _build_schema_prompt(self, schema):
        return f"Analyze this schema and return JSON with primary_keys, relationships: {str(schema)[:500]}"

class AgentFactory:
    @staticmethod
    def create(provider="auto"):
        from agents.fallback_agent import FallbackAgent
        providers = {}
        try:
            from agents.anthropic_agent import AnthropicAgent
            providers["anthropic"] = AnthropicAgent
        except: pass
        try:
            from agents.openai_agent import OpenAIAgent
            providers["openai"] = OpenAIAgent
        except: pass
        if provider == "auto":
            for name, Cls in providers.items():
                a = Cls()
                if a.is_available():
                    logger.info(f"   Auto-selected: {name}")
                    return a
            return FallbackAgent()
        Cls = providers.get(provider)
        if Cls:
            a = Cls()
            if a.is_available(): return a
        return FallbackAgent()
