import os
from agents.openai_agent import OpenAIAgent
from loguru import logger

class CopilotAgent(OpenAIAgent):
    """GitHub Copilot via GitHub Models API (OpenAI-compatible)."""

    def __init__(self):
        # Set OPENAI_API_KEY to GitHub token for OpenAI client
        if os.getenv("GITHUB_TOKEN"):
            os.environ["OPENAI_API_KEY"] = os.getenv("GITHUB_TOKEN")
        super().__init__()
        self.name = "CopilotAgent (GitHub Models)"
        if self.client:
            self.client.base_url = "https://models.inference.ai.azure.com"
            self.model = os.getenv("COPILOT_MODEL", "gpt-4o")
            logger.success("   Copilot agent ready (GitHub Models)")

    def is_available(self):
        return bool(os.getenv("GITHUB_TOKEN"))
