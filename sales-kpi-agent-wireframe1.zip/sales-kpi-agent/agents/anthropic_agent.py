import os, json
from agents.base_agent import BaseAgent
from loguru import logger

class AnthropicAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.name = "AnthropicAgent (Claude)"
        self.client = None
        if self.is_available():
            try:
                import anthropic
                self.client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
                self.model  = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5")
                logger.success("   Claude agent ready")
            except ImportError:
                logger.warning("   anthropic package not installed: pip install anthropic")

    def is_available(self):
        return bool(os.getenv("ANTHROPIC_API_KEY"))

    def _call(self, prompt, max_tokens=1000):
        r = self.client.messages.create(
            model=self.model, max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}]
        )
        return r.content[0].text

    def analyze_schema(self, schema):
        try:
            r = self._call(self._build_schema_prompt(schema))
            s, e = r.find('{'), r.rfind('}') + 1
            return json.loads(r[s:e])
        except Exception as ex:
            logger.warning(f"   Schema analysis failed: {ex}")
            return {}

    def detect_relationships(self, tables):
        try:
            names = [t["name"] for t in tables]
            p = f"Detect FK relationships between these tables: {names}. Return JSON array with parent_table, child_table, confidence."
            r = self._call(p)
            s, e = r.find('['), r.rfind(']') + 1
            return json.loads(r[s:e])
        except:
            return []

    def generate_description(self, col_info):
        try:
            r = self._call(
                f"Write a 1-sentence business description for column "
                f"'{col_info.get('name')}' in table '{col_info.get('table_name')}'. "
                f"Return only the description.", 150
            )
            return r.strip()
        except:
            return f"Column {col_info.get('name')}"
