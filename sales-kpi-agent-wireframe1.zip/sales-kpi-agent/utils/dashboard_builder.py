"""
Dashboard Builder — Step 5 of the pipeline
Generates the complete KPI dashboard HTML
"""

import json
from datetime import datetime
from pathlib import Path
from loguru import logger


class DashboardBuilder:
    """Builds the KPI dashboard HTML from KPIs and insights."""

    def __init__(self, config: dict):
        self.config = config
        self.sym   = config.get("dashboard", {}).get("currency_symbol", "₹")
        self.co    = config.get("company", {}).get("name", "Company")

    def build(self, kpis: dict, insights: dict, output_path: str) -> str:
        s       = kpis.get("summary", {})
        monthly = kpis.get("monthly", [])
        regional = kpis.get("regional", [])
        product  = kpis.get("product", [])
        owner    = kpis.get("owner", [])

        # Build JS data
        months_j  = json.dumps([str(m.get("month","")) for m in monthly])
        rev_j     = json.dumps([int(m.get("revenue",0)) for m in monthly])
        gm_j      = json.dumps([int(m.get("gross_margin",0)) for m in monthly])
        gmpct_j   = json.dumps([float(m.get("gm_pct",0)) for m in monthly])
        vsbe_j    = json.dumps([float(m.get("vs_be_pct",100)) for m in monthly])
        deals_j   = json.dumps([int(m.get("deals_closed",0)) for m in monthly])
        reg_l_j   = json.dumps([str(r.get("region","")) for r in regional])
        reg_r_j   = json.dumps([int(r.get("revenue",0)) for r in regional])
        prod_l_j  = json.dumps([str(p.get("product","")) for p in product])
        prod_s_j  = json.dumps([float(p.get("revenue_share_pct",0)) for p in product])
        own_l_j   = json.dumps([str(o.get("sales_owner","")) for o in owner])
        own_r_j   = json.dumps([int(o.get("revenue",0)) for o in owner])

        # KPI values
        tr  = s.get("total_revenue",0)
        tg  = s.get("total_gm",0)
        gp  = s.get("avg_gm_pct",0)
        wr  = s.get("avg_win_rate",0)
        td  = s.get("total_deals",0)
        tp  = s.get("total_pipeline",0)
        rvb = s.get("revenue_vs_be_pct",100)
        cov = s.get("pipeline_coverage",0)
        sc  = insights.get("health_score",75)
        var = s.get("revenue_variance",0)
        var_sign = "+" if var >= 0 else ""

        sym = self.sym

        def fmt_cr(n): return f"{sym}{n/1e7:.2f}Cr"
        def fmt_raw(n): return f"{sym}{n:,.0f}"

        gm_cls   = "pill-g" if gp  >= 35 else "pill-r"
        wr_cls   = "pill-g" if wr  >= 40 else "pill-a"
        rvb_cls  = "pill-g" if rvb >= 100 else ("pill-a" if rvb >= 95 else "pill-r")
        cov_cls  = "pill-g" if cov >= 3  else "pill-a"
        sc_ico   = "&#9899;" if sc >= 70 else "&#9898;"
        sc_col   = "#3B6D11" if sc >= 70 else ("#BA7517" if sc >= 50 else "#A32D2D")
        rvb_col  = "#3B6D11" if rvb >= 100 else ("#BA7517" if rvb >= 95 else "#A32D2D")
        var_col  = "#3B6D11" if var >= 0 else "#A32D2D"

        # Findings HTML
        fc = {"good":"g","warning":"a","danger":"r","info":"b"}
        fl = {"good":"Strength","warning":"Watch","danger":"Alert","info":"Info"}
        findings_html = ""
        for f in insights.get("findings",[]):
            t   = f.get("type","info")
            cls = fc.get(t,"b")
            lbl = fl.get(t,"Info")
            findings_html += (
                f'<div class="finding {cls}">'
                f'<div class="f-label {cls}">{lbl}: {f["label"]}</div>'
                f'<div class="f-text">{f["text"]}</div></div>'
            )

        # Risks HTML
        risks_html = ""
        sev_col = {"High":"H","Medium":"M","Low":"L"}
        for r in insights.get("risks",[]):
            sc_cls = sev_col.get(r["severity"],"M")
            ip = r.get("impact_pct",50)
            pp = r.get("prob_pct",50)
            bc = "#A32D2D" if r["severity"]=="High" else ("#BA7517" if r["severity"]=="Medium" else "#3B6D11")
            risks_html += f"""
<div class="risk">
  <span class="risk-sev {sc_cls}">{r["severity"]}</span>
  <div><div class="risk-name">{r["name"]}</div><div class="risk-detail">{r["detail"]}</div></div>
  <div class="risk-impact">{r["impact"]}
    <div class="bar-wrap"><div class="bar-fill" style="width:{ip}%;background:{bc};"></div></div>
  </div>
  <div class="risk-prob">{r["probability"]}
    <div class="bar-wrap"><div class="bar-fill" style="width:{pp}%;background:{bc};"></div></div>
  </div>
</div>"""

        # Recs HTML
        recs_html = ""
        for r in insights.get("recommendations",[]):
            recs_html += f"""
<div class="rec">
  <div class="rec-num">{r["num"]}</div>
  <div class="rec-title">{r["title"]}</div>
  <div class="rec-body">{r["body"]}</div>
  <span class="rec-tag">{r["tag"]}</span>
</div>"""

        # Owner table HTML
        owner_rows = ""
        for o in owner:
            nm  = str(o.get("sales_owner",""))
            av  = nm[0] if nm else "?"
            rev = int(o.get("revenue",0))
            gmp = float(o.get("gm_pct",0))
            dls = int(o.get("deals_closed",0))
            wrp = float(o.get("win_rate",0))
            wp  = min(wrp, 100)
            owner_rows += (
                f'<tr><td><span class="av">{av}</span>{nm}</td>'
                f'<td>{sym}{rev:,}</td><td>{gmp:.1f}%</td><td>{dls}</td>'
                f'<td><div class="pb"><div class="pf" style="width:{wp:.0f}%;"></div>'
                f'<span>{wrp:.1f}%</span></div></td></tr>'
            )

        headline = insights.get("headline","")
        today    = datetime.now().strftime("%d %b %Y %H:%M")

        html = self._html_template(
            headline=headline, sc=sc, sc_col=sc_col,
            tr=tr, tg=tg, gp=gp, wr=wr, td=td, tp=tp,
            rvb=rvb, cov=cov, var=var, var_sign=var_sign,
            rvb_col=rvb_col, var_col=var_col,
            gm_cls=gm_cls, wr_cls=wr_cls, rvb_cls=rvb_cls, cov_cls=cov_cls,
            findings_html=findings_html, risks_html=risks_html,
            recs_html=recs_html, owner_rows=owner_rows,
            months_j=months_j, rev_j=rev_j, gm_j=gm_j, gmpct_j=gmpct_j,
            vsbe_j=vsbe_j, deals_j=deals_j, reg_l_j=reg_l_j, reg_r_j=reg_r_j,
            prod_l_j=prod_l_j, prod_s_j=prod_s_j,
            own_l_j=own_l_j, own_r_j=own_r_j,
            sym=sym, co=self.co, today=today,
            fmt_cr=fmt_cr, fmt_raw=fmt_raw
        )

        Path(output_path).write_text(html, encoding="utf-8")
        logger.success(f"   Dashboard written: {output_path}")
        return output_path

    def _html_template(self, **v) -> str:
        """Returns the complete dashboard HTML."""
        sym = v['sym']
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{v['co']} — KPI Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
<style>
:root{{--bg:#0a0e1a;--su:#111827;--s2:#1a2235;--bd:#1e2d45;--ac:#00d97e;--a2:#3b82f6;--a3:#f59e0b;--a4:#ec4899;--tx:#e2e8f0;--mu:#64748b;--dn:#e63757;}}
*{{box-sizing:border-box;margin:0;padding:0;}}
body{{font-family:'Syne',sans-serif;background:var(--bg);color:var(--tx);}}
.shell{{display:grid;grid-template-columns:200px 1fr;min-height:100vh;}}
.sidebar{{background:var(--su);border-right:1px solid var(--bd);padding:16px 0;display:flex;flex-direction:column;}}
.logo{{padding:12px 16px 16px;border-bottom:1px solid var(--bd);margin-bottom:8px;}}
.logo-t{{font-size:13px;font-weight:800;color:var(--ac);}}
.logo-s{{font-size:10px;color:var(--mu);margin-top:2px;}}
.nav-s{{padding:8px 16px 4px;font-size:9px;font-weight:700;letter-spacing:.12em;color:var(--mu);text-transform:uppercase;}}
.nav-i{{padding:7px 16px;font-size:11px;cursor:pointer;color:var(--mu);border-left:2px solid transparent;display:flex;align-items:center;gap:8px;}}
.nav-i:hover,.nav-i.active{{color:var(--tx);border-left-color:var(--ac);background:var(--s2);}}
.nd{{width:6px;height:6px;border-radius:50%;flex-shrink:0;}}
.ng{{background:#3B6D11;}}.nb{{background:#185FA5;}}.na{{background:#BA7517;}}
.pulse{{width:6px;height:6px;border-radius:50%;background:#3B6D11;animation:pulse 2s infinite;flex-shrink:0;}}
@keyframes pulse{{0%,100%{{opacity:1;}}50%{{opacity:.3;}}}}
.status{{margin-top:auto;padding:12px 16px;border-top:1px solid var(--bd);font-size:10px;color:var(--mu);display:flex;flex-direction:column;gap:4px;}}
.main{{display:flex;flex-direction:column;}}
.topbar{{background:var(--su);border-bottom:1px solid var(--bd);padding:10px 20px;display:flex;align-items:center;justify-content:space-between;}}
.tb-t{{font-size:13px;font-weight:700;}}
.tb-m{{font-size:10px;color:var(--mu);margin-top:2px;}}
.ctrl-row{{display:flex;gap:8px;align-items:center;}}
select{{font-family:'JetBrains Mono',monospace;font-size:10px;padding:5px 8px;border:1px solid var(--bd);border-radius:6px;background:var(--su);color:var(--tx);cursor:pointer;}}
.btn{{padding:5px 14px;font-size:10px;font-family:'JetBrains Mono',monospace;border:1px solid var(--bd);border-radius:6px;background:transparent;color:var(--tx);cursor:pointer;}}
.btn:hover{{background:var(--s2);}}
.btn.primary{{background:var(--ac);color:#000;border-color:var(--ac);font-weight:700;}}
.content{{padding:16px 20px;display:flex;flex-direction:column;gap:14px;}}
.slbl{{font-size:9px;font-weight:700;letter-spacing:.12em;color:var(--mu);text-transform:uppercase;margin-bottom:8px;}}
.kg{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;}}
.kc{{background:var(--su);border:1px solid var(--bd);border-radius:12px;padding:16px;position:relative;overflow:hidden;}}
.kc::before{{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--ca,var(--ac));}}
.kc.b2{{--ca:#3b82f6;}}.kc.b3{{--ca:#f59e0b;}}.kc.b4{{--ca:#ec4899;}}.kc.b5{{--ca:#8b5cf6;}}
.kl{{font-size:9px;color:var(--mu);letter-spacing:.08em;text-transform:uppercase;margin-bottom:6px;}}
.kv{{font-size:22px;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1;margin-bottom:4px;}}
.ks{{font-size:10px;color:var(--mu);font-family:'JetBrains Mono',monospace;}}
.pill{{display:inline-block;font-size:9px;font-weight:700;padding:2px 8px;border-radius:10px;margin-top:5px;}}
.pill-g{{background:rgba(59,109,17,.2);color:#9FE1CB;}}.pill-r{{background:rgba(163,45,45,.2);color:#F09595;}}.pill-a{{background:rgba(186,117,23,.2);color:#FAC775;}}
.rw{{display:grid;gap:12px;margin-bottom:12px;}}
.rw.t21{{grid-template-columns:2fr 1fr;}}.rw.eq{{grid-template-columns:1fr 1fr;}}.rw.t3{{grid-template-columns:2fr 1fr 1fr;}}
.cc{{background:var(--su);border:1px solid var(--bd);border-radius:12px;padding:18px;}}
.ct{{font-size:13px;font-weight:700;margin-bottom:2px;}}
.cs{{font-size:9px;color:var(--mu);margin-bottom:12px;}}
.gw{{display:flex;flex-direction:column;align-items:center;padding:8px;}}
.gv{{font-size:40px;font-weight:800;font-family:'JetBrains Mono',monospace;line-height:1;color:{v['rvb_col']};}}
.gl{{font-size:9px;color:var(--mu);margin-top:4px;letter-spacing:1px;text-transform:uppercase;}}
.gvar{{font-size:12px;font-family:'JetBrains Mono',monospace;margin-top:3px;color:{v['var_col']};}}
.score-pill{{display:flex;align-items:center;gap:10px;background:var(--s2);border:1px solid var(--bd);border-radius:50px;padding:6px 16px;}}
.sn{{font-size:20px;font-weight:800;font-family:'JetBrains Mono',monospace;color:{v['sc_col']};}}
.hl{{font-size:13px;font-weight:700;color:var(--tx);line-height:1.4;}}
.hdr-row{{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;}}
.finding-grid{{display:grid;grid-template-columns:1fr 1fr;gap:8px;}}
.finding{{border-radius:8px;padding:11px 13px;border:1px solid;}}
.finding.g{{background:rgba(59,109,17,.12);border-color:rgba(59,109,17,.3);}}.finding.a{{background:rgba(186,117,23,.12);border-color:rgba(186,117,23,.3);}}.finding.r{{background:rgba(163,45,45,.12);border-color:rgba(163,45,45,.3);}}.finding.b{{background:rgba(24,95,165,.12);border-color:rgba(24,95,165,.3);}}
.f-label{{font-size:9px;font-weight:700;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em;}}
.f-label.g{{color:#9FE1CB;}}.f-label.a{{color:#FAC775;}}.f-label.r{{color:#F09595;}}.f-label.b{{color:#85B7EB;}}
.f-text{{font-size:11px;color:var(--mu);line-height:1.5;}}
.risk{{display:grid;grid-template-columns:70px 1fr 100px 100px;gap:10px;align-items:start;padding:9px 11px;border-radius:8px;border:1px solid var(--bd);margin-bottom:6px;}}
.risk:hover{{background:var(--s2);}}
.risk-sev{{font-size:9px;font-weight:700;padding:3px 8px;border-radius:8px;text-align:center;}}
.risk-sev.H{{background:rgba(163,45,45,.2);color:#F09595;}}.risk-sev.M{{background:rgba(186,117,23,.2);color:#FAC775;}}.risk-sev.L{{background:rgba(59,109,17,.2);color:#9FE1CB;}}
.risk-name{{font-size:11px;font-weight:700;margin-bottom:3px;}}
.risk-detail{{font-size:10px;color:var(--mu);line-height:1.4;}}
.risk-impact,.risk-prob{{font-size:10px;color:var(--mu);text-align:right;}}
.bar-wrap{{background:var(--bd);border-radius:3px;height:3px;width:100%;margin-top:4px;}}
.bar-fill{{height:3px;border-radius:3px;}}
.rec-grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px;}}
.rec{{background:var(--s2);border:1px solid var(--bd);border-radius:10px;padding:14px;}}
.rec-num{{font-size:20px;font-weight:800;color:var(--bd);font-family:'JetBrains Mono',monospace;line-height:1;margin-bottom:6px;}}
.rec-title{{font-size:12px;font-weight:700;margin-bottom:5px;}}
.rec-body{{font-size:11px;color:var(--mu);line-height:1.5;}}
.rec-tag{{display:inline-block;font-size:9px;padding:2px 8px;border-radius:8px;margin-top:7px;background:rgba(59,130,246,.15);color:#85B7EB;}}
.ot{{width:100%;border-collapse:collapse;font-size:11px;}}
.ot th{{text-align:left;padding:8px 10px;font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--mu);border-bottom:1px solid var(--bd);}}
.ot td{{padding:9px 10px;border-bottom:1px solid rgba(30,45,69,.4);vertical-align:middle;}}
.ot tr:last-child td{{border-bottom:none;}}
.ot tr:hover td{{background:var(--s2);}}
.av{{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:6px;background:linear-gradient(135deg,#3b82f6,#ec4899);font-size:10px;font-weight:700;margin-right:7px;color:#fff;}}
.pb{{display:flex;align-items:center;gap:6px;}}
.pf{{height:4px;background:linear-gradient(90deg,#3b82f6,#00d97e);border-radius:2px;min-width:3px;flex-shrink:0;}}
.pb span{{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--mu);white-space:nowrap;}}
.legend-row{{display:flex;gap:12px;font-size:10px;color:var(--mu);margin-bottom:8px;flex-wrap:wrap;}}
.ld{{width:8px;height:8px;border-radius:2px;display:inline-block;margin-right:3px;}}
@media(max-width:1100px){{.shell{{grid-template-columns:1fr;}}.sidebar{{display:none;}}.kg{{grid-template-columns:repeat(2,1fr);}}.rw.t21,.rw.eq,.rw.t3{{grid-template-columns:1fr;}}.finding-grid,.rec-grid{{grid-template-columns:1fr;}}}}
</style>
</head>
<body>
<div class="shell">
<aside class="sidebar">
 <div class="logo"><div class="logo-t">// KPI AGENT</div><div class="logo-s">LangChain · Wireframe 1</div></div>
 <div class="nav-s">Data</div>
 <div class="nav-i active"><span class="nd ng"></span>sales_data.xlsx</div>
 <div class="nav-s" style="margin-top:6px;">Tools</div>
 <div class="nav-i"><span class="nd nb"></span>load_excel_file</div>
 <div class="nav-i"><span class="nd nb"></span>calc_revenue_kpis</div>
 <div class="nav-i"><span class="nd nb"></span>analyze_by_dimension</div>
 <div class="nav-i"><span class="nd nb"></span>monthly_trend</div>
 <div class="nav-i"><span class="nd nb"></span>generate_insights</div>
 <div class="status"><div style="display:flex;align-items:center;gap:6px;"><span class="pulse"></span>Agent complete</div><div style="font-family:'JetBrains Mono',monospace;font-size:9px;line-height:1.6;">load_excel_file ✓<br>calc_kpis ✓<br>analyze_dims ✓<br>trend ✓<br>insights ✓</div></div>
</aside>
<main class="main">
 <div class="topbar">
  <div><div class="tb-t">{v['co']} — Sales Intelligence</div><div class="tb-m">Wireframe 1 · {v['today']}</div></div>
  <div class="score-pill"><span style="font-size:11px;color:var(--mu)">Health</span><span class="sn">{v['sc']}</span><span>/100</span></div>
 </div>
 <div class="content">

  <div class="hdr-row">
   <div style="flex:1;"><div style="font-size:10px;color:var(--mu);margin-bottom:5px;font-family:'JetBrains Mono',monospace;">Executive headline</div><div class="hl">{v['headline']}</div></div>
  </div>

  <div>
   <div class="slbl">Key Performance Indicators</div>
   <div class="kg">
    <div class="kc"><div class="kl">Total Revenue</div><div class="kv">{v['fmt_cr'](v['tr'])}</div><div class="ks">{v['fmt_raw'](v['tr'])}</div></div>
    <div class="kc b2"><div class="kl">Gross Margin</div><div class="kv">{v['fmt_cr'](v['tg'])}</div><div class="pill {v['gm_cls']}">GM% {v['gp']:.1f}%</div></div>
    <div class="kc b3"><div class="kl">Win Rate</div><div class="kv">{v['wr']:.1f}%</div><div class="pill {v['wr_cls']}">{'Strong' if v['wr']>=40 else 'Improve'}</div></div>
    <div class="kc b4"><div class="kl">Deals Closed</div><div class="kv">{v['td']:,}</div><div class="ks">Pipeline {v['fmt_cr'](v['tp'])}</div></div>
    <div class="kc b5"><div class="kl">Pipeline Cover</div><div class="kv">{v['cov']:.1f}x</div><div class="pill {v['cov_cls']}">{'Healthy' if v['cov']>=3 else 'Watch'}</div></div>
   </div>
  </div>

  <div class="rw t21">
   <div class="cc">
    <div class="ct">Revenue vs Gross Margin</div><div class="cs">Monthly trend</div>
    <div class="legend-row"><span><span class="ld" style="background:#3b82f6;"></span>Revenue</span><span><span class="ld" style="background:#00d97e;"></span>GM</span><span><span class="ld" style="background:#f59e0b;opacity:.7;"></span>BE</span></div>
    <div style="position:relative;height:190px;"><canvas id="c1"></canvas></div>
   </div>
   <div class="cc">
    <div class="ct">vs Budget Estimate</div><div class="cs">Monthly achievement %</div>
    <div class="gw">
     <div class="gv">{v['rvb']:.1f}%</div>
     <div class="gl">of Budget Estimate</div>
     <div class="gvar">{v['var_sign']}{v['sym']}{abs(v['var']):,}</div>
     <div style="width:100%;position:relative;height:80px;margin-top:10px;"><canvas id="c2"></canvas></div>
    </div>
   </div>
  </div>

  <div class="rw t3">
   <div class="cc"><div class="ct">GM% Trend</div><div class="cs">Monthly %</div><div style="position:relative;height:150px;"><canvas id="c3"></canvas></div></div>
   <div class="cc"><div class="ct">Deals</div><div class="cs">Monthly count</div><div style="position:relative;height:150px;"><canvas id="c4"></canvas></div></div>
   <div class="cc"><div class="ct">Product Mix</div><div class="cs">Revenue share</div><div style="position:relative;height:150px;"><canvas id="c5"></canvas></div></div>
  </div>

  <div class="rw eq">
   <div class="cc"><div class="ct">Revenue by Region</div><div class="cs">Ranked</div><div style="position:relative;height:200px;"><canvas id="c6"></canvas></div></div>
   <div class="cc"><div class="ct">Sales Team</div><div class="cs">By revenue</div><div style="position:relative;height:200px;"><canvas id="c7"></canvas></div></div>
  </div>

  <div class="cc">
   <div class="ct" style="margin-bottom:12px;">Key Findings</div>
   <div class="finding-grid">{v['findings_html']}</div>
  </div>

  <div class="cc">
   <div class="ct" style="margin-bottom:10px;">Risk Register</div>
   <div style="display:grid;grid-template-columns:70px 1fr 100px 100px;gap:10px;padding:4px 11px;margin-bottom:3px;"><span style="font-size:9px;color:var(--mu);">Severity</span><span style="font-size:9px;color:var(--mu);">Risk</span><span style="font-size:9px;color:var(--mu);text-align:right;">Impact</span><span style="font-size:9px;color:var(--mu);text-align:right;">Likelihood</span></div>
   {v['risks_html']}
  </div>

  <div class="cc">
   <div class="ct" style="margin-bottom:12px;">Recommendations</div>
   <div class="rec-grid">{v['recs_html']}</div>
  </div>

  <div class="cc">
   <div class="ct" style="margin-bottom:12px;">Sales Team Leaderboard</div>
   <table class="ot"><thead><tr><th>Owner</th><th>Revenue</th><th>GM%</th><th>Deals</th><th>Win Rate</th></tr></thead>
   <tbody>{v['owner_rows']}</tbody></table>
  </div>

  <div style="text-align:center;padding:12px;font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--mu);border-top:1px solid var(--bd);">
   Generated by Sales KPI Agent · Wireframe 1 · {v['today']}
  </div>

 </div>
</main>
</div>
<script>
const CL=['#3b82f6','#00d97e','#f59e0b','#ec4899','#8b5cf6','#06b6d4','#10b981','#f97316'];
const M={v['months_j']};const RV={v['rev_j']};const GM={v['gm_j']};const GP={v['gmpct_j']};const VB={v['vsbe_j']};const DL={v['deals_j']};const RL={v['reg_l_j']};const RR={v['reg_r_j']};const PL={v['prod_l_j']};const PS={v['prod_s_j']};const OL={v['own_l_j']};const OR2={v['own_r_j']};
const gOpt={{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{display:false}}}}}};
function fM(v){{return'{sym}'+(v/1e6).toFixed(1)+'M';}}
new Chart(document.getElementById('c1'),{{type:'bar',data:{{labels:M,datasets:[{{data:RV,backgroundColor:'rgba(59,130,246,.7)',borderRadius:4,label:'Revenue'}},{{data:GM,backgroundColor:'rgba(0,217,126,.7)',borderRadius:4,label:'GM'}},{{data:BE_DATA,type:'line',borderColor:'#f59e0b',borderDash:[4,3],borderWidth:1.5,pointRadius:0,fill:false,label:'BE'}}]}},options:{{...gOpt,scales:{{x:{{grid:{{display:false}},ticks:{{font:{{size:8}},maxRotation:45}}}},y:{{grid:{{color:'rgba(255,255,255,.04)'}},ticks:{{callback:fM,font:{{size:8}}}}}}}}}}}}}});
new Chart(document.getElementById('c2'),{{type:'bar',data:{{labels:M,datasets:[{{data:VB,backgroundColor:VB.map(v=>v>=100?'rgba(0,217,126,.8)':v>=95?'rgba(245,158,11,.8)':'rgba(230,55,87,.8)'),borderRadius:3}}]}},options:{{...gOpt,scales:{{x:{{display:false}},y:{{grid:{{color:'rgba(255,255,255,.04)'}},ticks:{{callback:v=>v+'%',font:{{size:8}},maxTicksLimit:4}}}}}}}}}}}});
new Chart(document.getElementById('c3'),{{type:'line',data:{{labels:M,datasets:[{{data:GP,borderColor:'#00d97e',backgroundColor:'rgba(0,217,126,.1)',fill:true,tension:.35,pointRadius:2,borderWidth:2}}]}},options:{{...gOpt,scales:{{x:{{grid:{{display:false}},ticks:{{font:{{size:8}},maxRotation:45}}}},y:{{grid:{{color:'rgba(255,255,255,.04)'}},ticks:{{callback:v=>v+'%',font:{{size:8}}}},suggestedMin:30,suggestedMax:55}}}}}}}}}});
new Chart(document.getElementById('c4'),{{type:'bar',data:{{labels:M,datasets:[{{data:DL,backgroundColor:'rgba(245,158,11,.7)',borderRadius:3}}]}},options:{{...gOpt,scales:{{x:{{grid:{{display:false}},ticks:{{font:{{size:8}},maxRotation:45}}}},y:{{grid:{{color:'rgba(255,255,255,.04)'}},ticks:{{font:{{size:8}}}}}}}}}}}}}});
new Chart(document.getElementById('c5'),{{type:'doughnut',data:{{labels:PL,datasets:[{{data:PS,backgroundColor:CL,borderWidth:2,borderColor:'#111827'}}]}},options:{{...gOpt,cutout:'60%',plugins:{{legend:{{display:true,position:'right',labels:{{color:'#64748b',font:{{size:9}},boxWidth:8}}}}}}}}}}}});
new Chart(document.getElementById('c6'),{{type:'bar',data:{{labels:RL,datasets:[{{data:RR,backgroundColor:CL,borderRadius:4}}]}},options:{{...gOpt,indexAxis:'y',scales:{{x:{{grid:{{color:'rgba(255,255,255,.04)'}},ticks:{{callback:fM,font:{{size:8}}}}}},y:{{grid:{{display:false}},ticks:{{font:{{size:9}}}}}}}}}}}}}});
new Chart(document.getElementById('c7'),{{type:'bar',data:{{labels:OL,datasets:[{{data:OR2,backgroundColor:CL,borderRadius:4}}]}},options:{{...gOpt,scales:{{x:{{grid:{{display:false}},ticks:{{font:{{size:8}},maxRotation:45}}}},y:{{grid:{{color:'rgba(255,255,255,.04)'}},ticks:{{callback:fM,font:{{size:8}}}}}}}}}}}}}});
</script>
<script>const BE_DATA={v['vsbe_j']}.map((v,i)=>RV[i]?Math.round(RV[i]/v*100):0);</script>
</body>
</html>"""
