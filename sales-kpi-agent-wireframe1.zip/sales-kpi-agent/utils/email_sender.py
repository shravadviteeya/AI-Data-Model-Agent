import os, smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from loguru import logger

class EmailSender:
    def __init__(self):
        self.smtp   = os.getenv("EMAIL_SMTP","smtp.office365.com")
        self.port   = int(os.getenv("EMAIL_PORT",587))
        self.sender = os.getenv("EMAIL_SENDER","")
        self.pwd    = os.getenv("EMAIL_PASSWORD","")
        self.recips = [r.strip() for r in os.getenv("LEADERSHIP_EMAILS","").split(",") if r.strip()]
    def send(self, kpis, insights):
        if not self.sender or not self.recips:
            logger.warning("Email not configured — skipping")
            return
        s = kpis.get("summary",{})
        sym = "₹"
        subject = f"📊 Sales KPI Report — {datetime.now().strftime('%d %b %Y')} | Revenue: {sym}{s.get('total_revenue',0)/1e7:.2f}Cr"
        body = f"<h2>Sales KPI Summary</h2><p>Health Score: {insights.get('health_score',0)}/100</p><p>{insights.get('headline','')}</p><p>See attached dashboard for full details.</p>"
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = self.sender
        msg["To"] = ", ".join(self.recips)
        msg.attach(MIMEText(body,"html"))
        try:
            with smtplib.SMTP(self.smtp,self.port) as srv:
                srv.starttls()
                srv.login(self.sender,self.pwd)
                srv.sendmail(self.sender,self.recips,msg.as_string())
            logger.success(f"Email sent to: {', '.join(self.recips)}")
        except Exception as e:
            logger.error(f"Email failed: {e}")
