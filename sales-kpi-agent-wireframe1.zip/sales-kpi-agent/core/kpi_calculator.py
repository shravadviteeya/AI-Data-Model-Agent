"""
KPI Calculator — Step 2 of the pipeline
Calculates all KPIs from the loaded DataFrame
"""

import pandas as pd
import numpy as np
from loguru import logger


class KPICalculator:
    """Calculates summary, monthly, regional, product, and owner KPIs."""

    def __init__(self, config: dict):
        self.config = config
        self.thresh = config.get("kpis", {})

    def calculate_all(self, df: pd.DataFrame) -> dict:
        """Run all KPI calculations and return complete results dict."""
        logger.info("   Calculating summary KPIs...")
        summary = self._summary(df)

        logger.info("   Calculating monthly trends...")
        monthly = self._monthly(df)

        logger.info("   Calculating regional breakdown...")
        regional = self._by_dimension(df, 'region')

        logger.info("   Calculating product breakdown...")
        product = self._by_dimension(df, 'product')

        logger.info("   Calculating owner leaderboard...")
        owner = self._owner(df)

        return {
            "summary": summary,
            "monthly": monthly,
            "regional": regional,
            "product": product,
            "owner": owner
        }

    def _summary(self, df: pd.DataFrame) -> dict:
        rev  = df['revenue'].sum()  if 'revenue'  in df.columns else 0
        cost = df['cost'].sum()     if 'cost'      in df.columns else 0
        gm   = df['gross_margin'].sum() if 'gross_margin' in df.columns else rev-cost
        be   = df['be_revenue'].sum()   if 'be_revenue' in df.columns else 0
        pipe = df['pipeline_value'].sum() if 'pipeline_value' in df.columns else 0
        deals = df['deals_closed'].sum()  if 'deals_closed' in df.columns else 0
        wr   = df['win_rate'].mean()      if 'win_rate' in df.columns else 0
        gmpct = df['gm_pct'].mean()       if 'gm_pct' in df.columns else (gm/rev*100 if rev else 0)

        rvb  = (rev / be * 100) if be > 0 else 100
        cov  = (pipe / rev)     if rev > 0 else 0

        return {
            "total_revenue":     round(rev),
            "total_cost":        round(cost),
            "total_gm":          round(gm),
            "avg_gm_pct":        round(float(gmpct), 2),
            "total_deals":       int(deals),
            "avg_win_rate":      round(float(wr), 1),
            "total_pipeline":    round(pipe),
            "total_be":          round(be),
            "revenue_vs_be_pct": round(float(rvb), 1),
            "revenue_variance":  round(rev - be),
            "pipeline_coverage": round(float(cov), 2),
        }

    def _monthly(self, df: pd.DataFrame) -> list:
        if 'month' not in df.columns or 'revenue' not in df.columns:
            return []
        agg = {k: (k, 'sum') for k in ['revenue','cost','gross_margin','deals_closed','be_revenue']
               if k in df.columns}
        if not agg:
            return []
        monthly = df.groupby('month').agg(**agg).reset_index()
        if 'revenue' in monthly.columns and 'gross_margin' in monthly.columns:
            monthly['gm_pct'] = (monthly['gross_margin'] / monthly['revenue'] * 100).round(2)
        if 'revenue' in monthly.columns and 'be_revenue' in monthly.columns:
            monthly['vs_be_pct'] = (monthly['revenue'] / monthly['be_revenue'] * 100).round(1)
        if 'revenue' in monthly.columns:
            monthly['mom_growth'] = monthly['revenue'].pct_change().mul(100).round(2)
        return monthly.fillna(0).to_dict('records')

    def _by_dimension(self, df: pd.DataFrame, dim: str) -> list:
        if dim not in df.columns or 'revenue' not in df.columns:
            return []
        agg = {k: (k,'sum') for k in ['revenue','cost','gross_margin','deals_closed']
               if k in df.columns}
        result = df.groupby(dim).agg(**agg).reset_index()
        if 'revenue' in result.columns:
            total = result['revenue'].sum()
            result['revenue_share_pct'] = (result['revenue'] / total * 100).round(1)
            if 'gross_margin' in result.columns:
                result['gm_pct'] = (result['gross_margin'] / result['revenue'] * 100).round(2)
        return result.sort_values('revenue', ascending=False).fillna(0).to_dict('records')

    def _owner(self, df: pd.DataFrame) -> list:
        if 'sales_owner' not in df.columns or 'revenue' not in df.columns:
            return []
        agg = {k: (k,'sum') for k in ['revenue','gross_margin','deals_closed'] if k in df.columns}
        wr_agg = {}
        if 'win_rate' in df.columns:
            wr_agg['win_rate'] = ('win_rate', 'mean')
        result = df.groupby('sales_owner').agg(**{**agg, **wr_agg}).reset_index()
        if 'revenue' in result.columns and 'gross_margin' in result.columns:
            result['gm_pct'] = (result['gross_margin'] / result['revenue'] * 100).round(2)
        n = self.config.get('analysis', {}).get('top_n_owners', 10)
        return result.sort_values('revenue', ascending=False).head(n).fillna(0).to_dict('records')
