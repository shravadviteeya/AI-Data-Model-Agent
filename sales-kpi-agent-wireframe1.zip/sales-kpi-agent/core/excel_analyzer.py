"""
Excel Analyzer — Step 1 of the pipeline
Loads, cleans, and profiles Excel files
"""

import pandas as pd
import numpy as np
import re
from pathlib import Path
from typing import Dict, List, Tuple, Any
from loguru import logger


class ExcelAnalyzer:
    """Loads and profiles Excel files using column mappings from config."""

    def __init__(self, config: dict):
        self.config = config
        self.col_map = config.get("columns", {})

    def load(self, file_path: str) -> dict:
        """Load Excel file and return structured data dict."""
        path = Path(file_path)
        logger.info(f"   Reading: {path.name}")

        # Load all sheets
        xl = pd.ExcelFile(file_path)
        dfs = {}
        for sheet in xl.sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet)
            if not df.empty:
                df.columns = [str(c).strip() for c in df.columns]
                table_name = self._clean_name(
                    path.stem if len(xl.sheet_names) == 1
                    else f"{path.stem}_{sheet}"
                )
                dfs[table_name] = df

        # Use first non-empty sheet as primary
        main_name = list(dfs.keys())[0]
        df = dfs[main_name]

        # Map columns
        mapped = self._map_columns(df)

        return {
            "df": mapped,
            "raw_df": df,
            "file_name": path.name,
            "row_count": len(mapped),
            "col_count": len(mapped.columns),
            "schema": self._build_schema(mapped),
            "tables": [{"name": main_name, "columns": [
                {"name": c, "dtype": str(mapped[c].dtype)}
                for c in mapped.columns
            ]}],
            "all_sheets": dfs
        }

    def _map_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Rename columns to standard names using config mapping."""
        rename_map = {}
        df_cols_lower = {c.lower(): c for c in df.columns}

        for standard_name, variants in self.col_map.items():
            for variant in variants:
                if variant.lower() in df_cols_lower:
                    original = df_cols_lower[variant.lower()]
                    rename_map[original] = standard_name
                    break

        df = df.rename(columns=rename_map)

        # Convert numeric columns
        for col in df.columns:
            if col in ['revenue','cost','gross_margin','gm_pct',
                       'be_revenue','pipeline_value','win_rate','deals_closed']:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

        # Convert month/date
        if 'month' in df.columns:
            df['month'] = df['month'].astype(str)

        return df

    def _build_schema(self, df: pd.DataFrame) -> dict:
        """Build column schema dict."""
        return {col: str(df[col].dtype) for col in df.columns}

    def _clean_name(self, name: str) -> str:
        name = re.sub(r'[^\w\s]', '_', str(name))
        return re.sub(r'\s+', '_', name).lower().strip('_')
