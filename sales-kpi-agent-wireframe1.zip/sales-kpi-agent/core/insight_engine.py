"""
Insight Engine — Step 4 of the pipeline
Generates risks, findings, recommendations, health score
"""

from loguru import logger


class InsightEngine:
    """Rule-based + AI insight generation."""

    def __init__(self, config: dict):
        self.config = config
        self.thresh = config.get("kpis", {})
        self.sym = config.get("dashboard", {}).get("currency_symbol", "₹")

    def generate(self, kpis: dict, ai_results: dict = None) -> dict:
        s = kpis.get("summary", {})
        findings        = self._findings(s, kpis)
        risks           = self._risks(s)
        recommendations = self._recommendations(s, kpis)
        health_score    = self._health_score(s)

        return {
            "health_score":     health_score,
            "headline":         self._headline(s, health_score),
            "findings":         findings,
            "risks":            risks,
            "recommendations":  recommendations,
        }

    def _health_score(self, s: dict) -> int:
        score = 100
        rvb   = s.get("revenue_vs_be_pct", 100)
        gm    = s.get("avg_gm_pct", 0)
        wr    = s.get("avg_win_rate", 0)
        cov   = s.get("pipeline_coverage", 0)

        if rvb < 100:  score -= min(25, int((100 - rvb) * 2))
        if gm  < 35:   score -= 15
        elif gm < 25:  score -= 25
        if wr  < 40:   score -= 10
        elif wr < 30:  score -= 20
        if cov < 3:    score -= 10
        elif cov < 2:  score -= 20

        return max(0, min(100, score))

    def _headline(self, s: dict, score: int) -> str:
        rvb = s.get("revenue_vs_be_pct", 100)
        gm  = s.get("avg_gm_pct", 0)
        if rvb >= 100 and gm >= 35:
            return "Business is performing above budget with healthy margins — focus on sustaining momentum."
        elif rvb < 100:
            gap = round(100 - rvb, 1)
            return (f"Business is structurally healthy but running {gap}% below budget — "
                    f"pipeline acceleration and deal conversion are the critical levers.")
        else:
            return "Mixed signals — margins are strong but pipeline coverage needs attention."

    def _findings(self, s: dict, kpis: dict) -> list:
        sym  = self.sym
        findings = []
        rvb  = s.get("revenue_vs_be_pct", 100)
        gm   = s.get("avg_gm_pct", 0)
        wr   = s.get("avg_win_rate", 0)
        cov  = s.get("pipeline_coverage", 0)
        var  = s.get("revenue_variance", 0)

        # Revenue vs BE
        if rvb >= 100:
            findings.append({"type":"good","label":"Revenue above target",
                "text": f"YTD revenue exceeds BE by {rvb-100:.1f}% — strong commercial execution."})
        else:
            findings.append({"type":"warning","label":"Revenue below budget",
                "text": f"YTD revenue is {sym}{abs(var):,.0f} short of budget estimate ({rvb:.1f}% achieved). "
                        f"Consistent monthly shortfall pattern suggests structural BE calibration issue."})

        # GM
        if gm >= 35:
            findings.append({"type":"good","label":"Margin strength",
                "text": f"GM% of {gm:.1f}% is {gm-35:.1f} points above the 35% healthy threshold — cost structure and pricing discipline are holding."})
        else:
            findings.append({"type":"danger","label":"Margin below threshold",
                "text": f"GM% of {gm:.1f}% is below the 35% healthy benchmark. "
                        f"Review pricing strategy and cost structure immediately."})

        # Win rate
        if wr >= 40:
            findings.append({"type":"good","label":"Win rate outperforms",
                "text": f"Win rate of {wr:.1f}% exceeds the 40% industry average — sales qualification is strong. Best regions can serve as a coaching model."})
        else:
            findings.append({"type":"warning","label":"Win rate needs improvement",
                "text": f"Win rate of {wr:.1f}% is below the 40% benchmark. "
                        f"Implement structured qualification frameworks (MEDDIC/BANT) to improve conversion."})

        # Pipeline coverage
        if cov >= 3:
            findings.append({"type":"good","label":"Pipeline coverage healthy",
                "text": f"Pipeline coverage at {cov:.1f}x provides sufficient buffer for next quarter target attainment."})
        else:
            findings.append({"type":"warning","label":"Pipeline coverage thin",
                "text": f"Coverage at {cov:.1f}x is below the 3x minimum. "
                        f"Any deal slippage will directly impact quarterly number. Top-of-funnel acceleration required."})

        # Product analysis
        prod = kpis.get("product", [])
        if prod:
            bottom = prod[-1]
            pname  = bottom.get("product", "Unknown")
            pshare = bottom.get("revenue_share_pct", 0)
            findings.append({"type":"info","label":"Product concentration risk",
                "text": f"{pname} contributes only {pshare:.1f}% revenue share — "
                        f"investigate whether pricing, positioning, or seller enablement is the root cause."})

        # Owner concentration
        owners = kpis.get("owner", [])
        if len(owners) >= 2:
            top_rev = owners[0].get("revenue", 0)
            total_r = s.get("total_revenue", 1)
            pct     = top_rev / total_r * 100 if total_r else 0
            if pct > 15:
                name = owners[0].get("sales_owner", "Top performer")
                findings.append({"type":"info","label":"Key person dependency",
                    "text": f"{name} accounts for {pct:.0f}% of total revenue — "
                            f"creates delivery risk. Begin account coverage planning."})

        return findings

    def _risks(self, s: dict) -> list:
        sym  = self.sym
        rvb  = s.get("revenue_vs_be_pct", 100)
        gm   = s.get("avg_gm_pct", 0)
        cov  = s.get("pipeline_coverage", 0)
        var  = s.get("revenue_variance", 0)
        tr   = s.get("total_revenue", 0)

        risks = []

        if rvb < 100:
            risks.append({
                "severity": "High", "name": "Budget shortfall escalation",
                "detail": f"{100-rvb:.1f}% miss compounds if pipeline does not close — could widen to 5–8% gap",
                "impact": f"{sym}{abs(var)*2:,.0f} exposure", "impact_pct": 85,
                "probability": "75%", "prob_pct": 75
            })

        if tr > 0:
            risks.append({
                "severity": "High" if tr > 0 else "Medium",
                "name": "Key person concentration",
                "detail": "Over-reliance on top performer — departure creates immediate revenue gap",
                "impact": f"15–20% revenue at risk", "impact_pct": 70,
                "probability": "40%", "prob_pct": 40
            })

        if cov < 3:
            risks.append({
                "severity": "Medium", "name": "Pipeline coverage shortfall",
                "detail": f"{cov:.1f}x coverage leaves less than 1 quarter buffer — deal slippage is high-risk",
                "impact": f"{sym}{tr*0.05:,.0f} exposure", "impact_pct": 55,
                "probability": "50%", "prob_pct": 50
            })

        if gm < 35:
            risks.append({
                "severity": "Medium", "name": "Margin compression",
                "detail": f"GM% of {gm:.1f}% below 35% threshold — pricing pressure or cost escalation",
                "impact": f"{sym}{tr*0.02:,.0f} GM impact", "impact_pct": 60,
                "probability": "55%", "prob_pct": 55
            })

        risks.append({
            "severity": "Low", "name": "Regional performance divergence",
            "detail": "Variance in win rates across regions signals inconsistent sales execution",
            "impact": f"{sym}{tr*0.01:,.0f} exposure", "impact_pct": 25,
            "probability": "30%", "prob_pct": 30
        })

        max_r = self.config.get("insights", {}).get("max_risks", 5)
        return risks[:max_r]

    def _recommendations(self, s: dict, kpis: dict) -> list:
        sym  = self.sym
        rvb  = s.get("revenue_vs_be_pct", 100)
        wr   = s.get("avg_win_rate", 0)
        cov  = s.get("pipeline_coverage", 0)

        recs = [
            {"num":"01","title":"Launch a Q4 deal acceleration sprint",
             "body": "Convene a weekly pipeline war room for all deals above a threshold value. "
                     "Assign executive sponsors to top 10 open opportunities. "
                     "Target closing material slipped deals before quarter-end.",
             "tag": "Immediate · Revenue"},
            {"num":"02","title":"Rebuild pipeline to 3.5x coverage",
             "body": "Increase outbound prospecting by 40% for 60 days. "
                     "Set a hard gate: no deal leaves pipeline review without a confirmed next step. "
                     f"Current coverage {cov:.1f}x needs to reach 3.5x.",
             "tag": "30 days · Pipeline"},
            {"num":"03","title":"Conduct a Product B emergency review",
             "body": "Commission a 2-week win/loss analysis on the lowest-performing product. "
                     "Interview lost prospects and won customers to identify root cause — "
                     "pricing, messaging, or competitive displacement.",
             "tag": "45 days · Product"},
            {"num":"04","title":"Replicate top region playbook company-wide",
             "body": "Document the top region's qualification criteria, talk tracks, and deal structure. "
                     "Run a 2-day enablement workshop for underperforming regions.",
             "tag": "60 days · Enablement"},
            {"num":"05","title":"Mitigate key person concentration risk",
             "body": "Assign the top performer a shadow for all strategic accounts. "
                     "Begin transitioning 20% of accounts to a second senior rep over next quarter.",
             "tag": "90 days · Talent"},
            {"num":"06","title":"Recalibrate BE targets for next FY",
             "body": "The consistent miss pattern suggests BE targets are set 3–4% above realistic capacity. "
                     "Involve bottom-up rep-level input in next year's planning cycle.",
             "tag": "Next planning cycle · Finance"},
        ]

        max_r = self.config.get("insights", {}).get("max_recommendations", 6)
        return recs[:max_r]
