# Column Mapping Guide

## How Auto-Detection Works

The agent scans your Excel column names and maps them to
standard internal names using the list in `config.yaml`.

It is case-insensitive and looks for partial matches.

---

## Standard Internal Names

| Internal Name    | What It Represents              |
|------------------|---------------------------------|
| `revenue`        | Total sales / revenue amount    |
| `cost`           | Total cost / COGS               |
| `gross_margin`   | Gross profit (revenue - cost)   |
| `gm_pct`         | Gross margin percentage         |
| `month`          | Reporting period / date         |
| `region`         | Geographic region / territory   |
| `product`        | Product / service name          |
| `sales_owner`    | Salesperson / account executive |
| `be_revenue`     | Budget estimate / target        |
| `pipeline_value` | Open pipeline value             |
| `win_rate`       | Win rate percentage             |
| `deals_closed`   | Number of deals closed          |

---

## Adding Your Column Names

Open `config.yaml` and add your column names to the list:

```yaml
columns:
  revenue:
    - Revenue          # already in list
    - Net_Revenue      # add yours here
    - Billed_Amount    # and here

  sales_owner:
    - Sales_Owner
    - AE               # short form
    - Account_Manager  # your variant
```

---

## Salesforce Export Column Names

If exporting from Salesforce, map these common SF columns:

| Salesforce Column     | Map to          |
|-----------------------|-----------------|
| Amount                | revenue         |
| Close Date            | month           |
| Account Name          | region / client |
| Owner Full Name       | sales_owner     |
| Opportunity Name      | product         |
| Stage                 | (custom filter) |
| Probability           | win_rate        |
| Forecast Amount       | be_revenue      |

Add to config.yaml:
```yaml
columns:
  revenue:
    - Amount
  month:
    - Close Date
    - Close_Date
  sales_owner:
    - Owner Full Name
    - Owner_Full_Name
```
