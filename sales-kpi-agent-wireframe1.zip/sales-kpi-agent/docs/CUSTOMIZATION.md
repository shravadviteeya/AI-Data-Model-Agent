# Customization Guide — Sales KPI Agent

This guide explains every way you can customize the agent
for Wireframe 2, 3, and beyond.

---

## 1. Change Colors & Theme

Edit `config.yaml`:

```yaml
dashboard:
  theme: "dark"          # dark | light
  colors:
    primary:  "#185FA5"  # change to your brand color
    success:  "#3B6D11"
    warning:  "#BA7517"
    danger:   "#A32D2D"
  currency_symbol: "₹"   # ₹ | $ | € | £
```

---

## 2. Map Your Own Excel Columns

If your Excel has different column names, add them to `config.yaml`:

```yaml
columns:
  revenue:
    - Revenue
    - Net_Sales          # add your column name here
    - Gross_Billed

  sales_owner:
    - Sales_Owner
    - Account_Executive  # your column name
    - AE_Name
```

---

## 3. Adjust KPI Thresholds

```yaml
kpis:
  gm_pct:
    healthy: 35          # above = green badge
    warning: 25          # below = red badge

  win_rate:
    good: 40             # above = green
    acceptable: 30       # below = red

  pipeline_coverage:
    healthy: 3.0         # above = green
    minimum: 2.0         # below = red
```

---

## 4. Add a New AI Provider

Create `agents/my_agent.py`:

```python
from agents.base_agent import BaseAgent

class MyCustomAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.name = "MyCustomAgent"

    def is_available(self):
        return True  # always available

    def analyze_schema(self, schema):
        return {}

    def detect_relationships(self, tables):
        return []

    def generate_description(self, col_info):
        return f"Custom description for {col_info.get('name')}"
```

Then register it in `agents/base_agent.py`:

```python
from agents.my_agent import MyCustomAgent
providers["my_agent"] = MyCustomAgent
```

Run with: `python main.py --file data.xlsx --provider my_agent`

---

## 5. Add a New KPI

In `core/kpi_calculator.py`, add to `_summary()`:

```python
# Add your custom KPI
if 'your_column' in df.columns:
    kpis['my_custom_kpi'] = round(df['your_column'].mean(), 2)
```

Then display it in `utils/dashboard_builder.py` in the KPI grid section.

---

## 6. Add a New Chart

In `utils/dashboard_builder.py`, add a new canvas in the HTML
template, then add the Chart.js code in the `<script>` section:

```javascript
new Chart(document.getElementById('myNewChart'), {
    type: 'line',
    data: { labels: M, datasets: [{ data: MY_DATA }] },
    options: { responsive: true, maintainAspectRatio: false }
});
```

---

## 7. Customize Email Template

Edit `utils/email_sender.py` — the `body` variable contains the HTML.
You can add your company logo, change colors, add more KPI rows.

---

## 8. Add Multiple Excel Files

In `core/excel_analyzer.py`, extend `load()` to accept a list:

```python
def load_multiple(self, file_paths: list) -> dict:
    dfs = [self.load(f)['df'] for f in file_paths]
    import pandas as pd
    merged = pd.concat(dfs, ignore_index=True)
    return {**self.load(file_paths[0]), 'df': merged}
```

Then in `main.py`:
```python
data = analyzer.load_multiple(["pipeline.xlsx", "actuals.xlsx", "be.xlsx"])
```

---

## Wireframe Roadmap

| Wireframe | Key Addition |
|-----------|-------------|
| **1** (current) | Core KPI dashboard + executive summary |
| **2** | Multi-file merge + Salesforce live pull |
| **3** | Power BI export + scheduled auto-reports |
| **4** | Conversational Q&A over your data |
| **5** | Predictive forecasting + ML models |
